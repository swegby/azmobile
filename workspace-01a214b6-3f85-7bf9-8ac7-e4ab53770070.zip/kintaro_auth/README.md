# Kintaro Studio — Вход (Логин+TOTP / Почта+IMAP), БИО и Фото-карусели TikTok

Готовый софт (Веб-панель + Консольный мультипоточный CLI + Python SDK) для автоматизации аккаунтов TikTok через **Kintaro API** (`https://service.kintaroapi.com`).

### Реализованный и проверенный в бою функционал:
1. **Вход по Логину + Паролю + TOTP (`/v1/auth/signin/username`):**
   - Поддерживает формат `email|username|password|totp` (а также `username:password:totp`).
   - Автоматическая синхронизация 30-секундного окна TOTP (исключает протухание кода во время мобильного запроса).
   - **Авто-определение домашнего кластера IDC аккаунта (`no1a` / `DE`, `useast` / `US`, `alisg` / `SG`, `maliva` / `GB`):** если прокси другой страны вызывает `suspicious_login` (`2135`), софт автоматически считывает `api_domain` аккаунта, перерегистрирует устройство на родной регион и выполняет чистый вход по TOTP (`200 OK`).
2. **Вход по Почте (`/v1/auth/signin/email` + `/v1/auth/signin/email/send_code`):**
   - Как с паролем, так и без пароля (по 6-значному коду с почты).
   - Встроенный IMAP/POP3-ридер для **Firstmail, NotLetters, Rambler, Mail.ru, Yandex, Outlook/Hotmail, Gmail, GMX** и кастомных доменов.
3. **Редактирование профиля (`/v1/account/set_bio`, `/v1/account/self`):**
   - Мгновенная смена БИО сразу при входе или в 1 клик из таблицы сессий.
4. **Публикация Фото-постов / Каруселей до 10 слайдов (`/v1/post/create/photo`):**
   - Загрузка от 1 до 10 изображений (`JPEG` / `PNG`) в один карусельный пост с описанием, хэштегами (например `#kintaro`), музыкой и настройками приватности.

---

## Запуск

```bash
pip install -r requirements.txt

# 1. Веб-интерфейс (http://localhost:8000):
python3 web_app.py

# 2. Консольный вход (Логин+Пароль+TOTP) + смена БИО:
python3 cli.py --api-key ВАШ_КЛЮЧ --accounts accounts.txt --proxies proxies.txt --mode username_totp --set-bio "Hello ✨"

# 3. Публикация карусели из 3 фото на сохранённую сессию:
python3 cli.py --api-key ВАШ_КЛЮЧ --session ukolywnj2me.json --post-photos media/slide_1.jpg media/slide_2.jpg media/slide_3.jpg --caption "#kintaro"
```
