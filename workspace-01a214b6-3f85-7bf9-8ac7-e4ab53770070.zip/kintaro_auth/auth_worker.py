"""
Account parser, session storage, and multi-threaded login + bio + photo-posting engine for Kintaro API.
"""

from __future__ import annotations

import concurrent.futures
import datetime as dt
import html
import json
import os
import random
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from kintaro_client import (
    DEFAULT_BASE_URL,
    AuthStepResult,
    KintaroClient,
    allocate_sticky_proxy,
    apply_device_geo_profile,
    is_valid_base32_totp,
    normalize_proxy,
    serialize_device_header,
    swap_proxy_country,
)
from mail_code_reader import prepare_imap_mailbox, wait_for_email_code
from outlook_hub_reader import prepare_outlook_hub_mailbox, wait_for_outlook_hub_code
from photo_uniquifier import expand_spintax, uniquify_photo_batch


BASE_DIR = Path(__file__).resolve().parent
SESSIONS_DIR = BASE_DIR / "sessions"
OUTPUT_DIR = BASE_DIR / "output"
MEDIA_DIR = BASE_DIR / "media"
CONFIG_FILE = BASE_DIR / "config.json"

SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
MEDIA_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class AccountTask:
    email: str = ""
    username: Optional[str] = None
    tiktok_password: Optional[str] = None
    mail_login: Optional[str] = None
    mail_password: Optional[str] = None
    recovery_email: Optional[str] = None
    recovery_password: Optional[str] = None
    mail_totp: Optional[str] = None
    use_outlook_hub: bool = False
    totp_token: Optional[str] = None
    proxy: Optional[str] = None
    region: str = "DE"
    imap_host: Optional[str] = None
    raw_line: str = ""

    @property
    def identifier(self) -> str:
        return self.username or self.email or "account"


@dataclass
class LoginOptions:
    api_key: str
    base_url: str = DEFAULT_BASE_URL
    # Modes: "username_totp" | "password_imap" | "otp_only" | "password_only"
    login_mode: str = "username_totp"
    default_region: str = "DE"
    app_locale: str = ""
    threads: int = 3
    pre_register_device: bool = True
    update_hosts_after_register: bool = False
    reuse_existing_device: bool = True
    auto_retry_detected_region: bool = True
    check_self_after_login: bool = True
    token_beat_after_login: bool = False
    delete_old_posts: bool = False
    bio_after_login: str = ""
    same_password_fallback: bool = True
    custom_imap_host: str = ""
    imap_timeout_sec: int = 90
    allow_manual_code: bool = True


def safe_filename(identifier: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9._@-]+", "_", identifier.strip().lower().lstrip("@"))
    return cleaned[:120] or "account"


def _looks_like_proxy_token(token: str) -> bool:
    t = token.strip().lower()
    if t.startswith(("http://", "https://", "socks5://", "socks5h://", "socks4://")):
        return True
    # host:port or host:port:user:pass
    if re.match(r"^[a-z0-9.-]+:\d{2,5}(:.+)?$", t):
        return True
    if "@" in t and re.search(r":\d{2,5}$", t):
        return True
    return False


_EMAIL_TOKEN_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_OUTLOOK_DOMAINS = (
    "outlook.com",
    "hotmail.com",
    "live.com",
    "msn.com",
    "outlook.de",
    "outlook.fr",
    "hotmail.co.uk",
    "hotmail.fr",
    "hotmail.de",
)


def _is_outlook_domain(email_addr: str) -> bool:
    dom = email_addr.strip().lower().split("@")[-1] if "@" in email_addr else ""
    return dom in _OUTLOOK_DOMAINS or dom.startswith(("outlook.", "hotmail.", "live."))


def parse_account_line(
    line: str,
    login_mode: str = "username_totp",
    default_region: str = "DE",
) -> Optional[AccountTask]:
    """
    Parses flexible account strings across all supported formats:
      1) Outlook-Hub extended format (7 or 8 colon-delimited fields):
         - `tt_login:tt_pass:outlook_email:outlook_pass:rec_email:rec_pass:hotmail_2fa`
         - `tt_login:tt_pass:outlook_email:outlook_login:outlook_pass:rec_email:rec_pass:hotmail_2fa`
      2) Pipe-delimited format (`email|username|password|totp[|proxy]` or `username|password|email|totp`):
         e.g. `ukolyjusihucy96@mail.com|ukolywnj2me|8QRSs9Hk!T!|4OX55UJKBSDWHXNU5EF362QJBUKBPWR2`
      3) Colon-delimited `username_totp`:
         `username:password:totp` or `email:username:password:totp`
      4) Email modes (`email_outlook`, `password_imap`, `otp_only`, `password_only`):
         `email:tiktok_pass:mail_pass[:totp][|proxy][;region=XX]`
    """
    s = html.unescape(line.strip())
    if not s or s.startswith("#"):
        return None

    # Strip accidental markdown mailto links (including nested `\[...\]`), underline markers & escaped underscores
    s = s.replace(r"\[", "[").replace(r"\]", "]")
    for _ in range(3):
        s = re.sub(r"\[\+\+([^\]]+?)\+\+\]\(mailto:[^)]+\)", r"\1", s)
        s = re.sub(r"\[([^\]]+)\]\(mailto:[^)]+\)", r"\1", s)
    s = re.sub(r"\(mailto:[^:\s)]+\)", "", s)
    s = re.sub(r"\+\+(.+?)\+\+", r"\1", s)
    s = re.sub(r"\*\*(.+?)\*\*", r"\1", s)
    s = s.replace(r"\_", "_")

    region = (default_region or "DE").upper().strip()
    reg_match = re.search(r"[;|]region=([A-Za-z]{2})\b", s, flags=re.IGNORECASE)
    if reg_match:
        region = reg_match.group(1).upper()
        s = s[: reg_match.start()] + s[reg_match.end() :]

    inline_proxy: Optional[str] = None

    # Check if pipe-separated:
    #   - `email|username|password|totp[|proxy]`
    #   - `username|password|email|totp[|proxy]`
    #   - `username|password|totp[|proxy]`
    if "|" in s:
        pipe_parts = [p.strip() for p in s.split("|")]
        if _looks_like_proxy_token(pipe_parts[-1]):
            inline_proxy = pipe_parts.pop()

        if len(pipe_parts) >= 3 and (":" not in pipe_parts[0]):
            if "@" in pipe_parts[0] and len(pipe_parts) >= 4:
                return AccountTask(
                    email=pipe_parts[0],
                    username=pipe_parts[1].lstrip("@"),
                    tiktok_password=pipe_parts[2],
                    totp_token=pipe_parts[3] or None,
                    proxy=inline_proxy,
                    region=region,
                    raw_line=line.strip(),
                )
            elif len(pipe_parts) >= 4 and "@" in pipe_parts[2] and "@" not in pipe_parts[0]:
                # Format: username|password|email|totp (email ignored during username_totp login)
                return AccountTask(
                    email=pipe_parts[2],
                    username=pipe_parts[0].lstrip("@"),
                    tiktok_password=pipe_parts[1],
                    totp_token=pipe_parts[3] or None,
                    proxy=inline_proxy,
                    region=region,
                    raw_line=line.strip(),
                )
            elif "@" not in pipe_parts[0] and len(pipe_parts) >= 3:
                return AccountTask(
                    email="",
                    username=pipe_parts[0].lstrip("@"),
                    tiktok_password=pipe_parts[1],
                    totp_token=pipe_parts[2] or None,
                    proxy=inline_proxy,
                    region=region,
                    raw_line=line.strip(),
                )
        s = "|".join(pipe_parts)

    # Standard colon/semicolon/tab parsing
    if ":" not in s and ";" in s:
        raw_parts = [p.strip() for p in s.split(";")]
    elif "\t" in s and ":" not in s:
        raw_parts = [p.strip() for p in s.split("\t") if p.strip()]
    else:
        raw_parts = [p.strip() for p in s.split(":")]

    # Detect `tt_login:tt_pass:email:mail_pass[...]` format (4+ fields: Rambler/Firstmail IMAP or Outlook Hub 7/8-field)
    non_empty = [p for p in raw_parts if p]
    email_idxs = [i for i, tok in enumerate(non_empty) if _EMAIL_TOKEN_RE.match(tok)]
    if email_idxs and email_idxs[0] == 2 and len(non_empty) >= 4:
        tt_u = non_empty[0].lstrip("@")
        tt_p = non_empty[1]
        primary_email = non_empty[2].lower()
        mail_login = primary_email
        mail_pw: Optional[str] = None
        rec_email: Optional[str] = None
        rec_pw: Optional[str] = None
        hotmail_2fa: Optional[str] = None

        if len(email_idxs) >= 3 and email_idxs[1] == 3 and email_idxs[2] == 5:
            # 8-field where mail_login is also an email: [2]=email, [3]=mail_login, [4]=mail_pw, [5]=rec_email, [6]=rec_pw, [7]=2fa
            mail_login = non_empty[3]
            mail_pw = non_empty[4]
            rec_email = non_empty[5].lower()
            rec_pw = non_empty[6] if len(non_empty) > 6 else None
            hotmail_2fa = non_empty[7] if len(non_empty) > 7 else None
        elif len(email_idxs) >= 2 and email_idxs[1] == 5:
            # 8-field where mail_login has no '@': [2]=email, [3]=mail_login, [4]=mail_pw, [5]=rec_email, [6]=rec_pw, [7]=2fa
            mail_login = non_empty[3]
            mail_pw = non_empty[4]
            rec_email = non_empty[5].lower()
            rec_pw = non_empty[6] if len(non_empty) > 6 else None
            hotmail_2fa = non_empty[7] if len(non_empty) > 7 else None
        elif len(email_idxs) >= 2 and email_idxs[1] == 4:
            # 7-field standard Outlook-Hub format: [2]=email, [3]=mail_pw, [4]=rec_email, [5]=rec_pw, [6]=2fa
            mail_pw = non_empty[3]
            rec_email = non_empty[4].lower()
            rec_pw = non_empty[5] if len(non_empty) > 5 else None
            hotmail_2fa = non_empty[6] if len(non_empty) > 6 else None
        else:
            # 5-field without recovery email: [2]=email, [3]=mail_pw, [4]=2fa
            mail_pw = non_empty[3] if len(non_empty) > 3 else None
            hotmail_2fa = non_empty[4] if len(non_empty) > 4 else None

        is_outlook = _is_outlook_domain(primary_email) or bool(rec_email or hotmail_2fa)
        return AccountTask(
            email=primary_email,
            username=tt_u,
            tiktok_password=tt_p,
            mail_login=mail_login,
            mail_password=mail_pw,
            recovery_email=rec_email,
            recovery_password=rec_pw,
            mail_totp=hotmail_2fa,
            use_outlook_hub=is_outlook,
            totp_token=None,  # ZWC57GLTYIAP5JS4 is Hotmail 2FA, NOT TikTok TOTP!
            proxy=inline_proxy,
            region=region,
            raw_line=s.strip(),
        )

    parts = raw_parts

    if login_mode == "username_totp":
        # Either email:username:password[:totp] OR username:password[:totp]
        if "@" in parts[0] and len(parts) >= 3:
            return AccountTask(
                email=parts[0],
                username=parts[1].lstrip("@"),
                tiktok_password=parts[2],
                totp_token=parts[3] if len(parts) >= 4 and parts[3] else None,
                proxy=inline_proxy,
                region=region,
                raw_line=line.strip(),
            )
        if len(parts) >= 2:
            return AccountTask(
                email="",
                username=parts[0].lstrip("@"),
                tiktok_password=parts[1],
                totp_token=parts[2] if len(parts) >= 3 and parts[2] else None,
                proxy=inline_proxy,
                region=region,
                raw_line=line.strip(),
            )
        raise ValueError(f"Некорректный формат username_totp в строке: {line!r}")

    email_addr = parts[0]
    if "@" not in email_addr:
        raise ValueError(f"Некорректный email в строке: {line!r}")

    tiktok_pw: Optional[str] = None
    mail_pw: Optional[str] = None
    totp: Optional[str] = None
    imap_host: Optional[str] = None

    if login_mode == "otp_only":
        if len(parts) >= 2 and parts[1]:
            mail_pw = parts[1]
        if len(parts) >= 3 and parts[2]:
            imap_host = parts[2]
    elif login_mode == "password_only":
        if len(parts) >= 2 and parts[1]:
            tiktok_pw = parts[1]
        if len(parts) >= 3 and parts[2]:
            totp = parts[2]
    else:
        # "password_imap"
        if len(parts) >= 2 and parts[1]:
            tiktok_pw = parts[1]
        if len(parts) >= 3 and parts[2]:
            mail_pw = parts[2]
        if len(parts) >= 4 and parts[3]:
            totp = parts[3]
        if len(parts) >= 5 and parts[4]:
            imap_host = parts[4]

    return AccountTask(
        email=email_addr,
        tiktok_password=tiktok_pw,
        mail_password=mail_pw,
        totp_token=totp,
        proxy=inline_proxy,
        region=region,
        imap_host=imap_host,
        raw_line=line.strip(),
    )


def extract_profile_summary(self_body: Any, auth_body: Any = None) -> Dict[str, Any]:
    info: Dict[str, Any] = {
        "username": None,
        "nickname": None,
        "signature": None,
        "uid": None,
        "sec_uid": None,
        "follower_count": None,
    }

    def _scan(obj: Any) -> None:
        if not isinstance(obj, dict):
            return
        for ukey in ("unique_id", "username", "login_name"):
            if not info["username"] and isinstance(obj.get(ukey), str) and obj.get(ukey):
                info["username"] = obj[ukey]
        if not info["nickname"] and isinstance(obj.get("nickname"), str) and obj.get("nickname"):
            info["nickname"] = obj["nickname"]
        if info["signature"] is None and isinstance(obj.get("signature"), str):
            info["signature"] = obj["signature"]
        for idkey in ("uid", "user_id", "id_str"):
            if not info["uid"] and obj.get(idkey):
                info["uid"] = str(obj[idkey])
        if not info["sec_uid"] and isinstance(obj.get("sec_uid"), str) and obj.get("sec_uid"):
            info["sec_uid"] = obj["sec_uid"]
        if info["follower_count"] is None and isinstance(obj.get("follower_count"), int):
            info["follower_count"] = obj["follower_count"]

        for subkey in ("user", "data", "response", "account", "user_info", "user_profile_info"):
            if isinstance(obj.get(subkey), dict):
                _scan(obj[subkey])

    if self_body:
        _scan(self_body)
    if auth_body:
        _scan(auth_body)
    return info


class SessionStore:
    """Thread-safe persistence for logged-in Kintaro `x-device` sessions and post history."""

    def __init__(self, sessions_dir: Path = SESSIONS_DIR, output_dir: Path = OUTPUT_DIR) -> None:
        self.sessions_dir = sessions_dir
        self.output_dir = output_dir
        self._lock = threading.Lock()
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def load_existing_device(self, identifier: str) -> Optional[Dict[str, Any]]:
        fp = self.sessions_dir / f"{safe_filename(identifier)}.json"
        if not fp.exists():
            return None
        try:
            data = json.loads(fp.read_text(encoding="utf-8"))
            dev = data.get("device")
            if isinstance(dev, dict) and dev:
                return dev
            if isinstance(data.get("x_device"), str):
                return json.loads(data["x_device"])
        except Exception:
            return None
        return None

    def save_success(
        self,
        task: AccountTask,
        proxy_normalized: str,
        device: Any,
        auth_response: Any,
        self_response: Any = None,
    ) -> Dict[str, Any]:
        x_device_str = serialize_device_header(device) if device is not None else ""
        device_dict = device
        if isinstance(device, str):
            try:
                device_dict = json.loads(device)
            except Exception:
                device_dict = {"raw": device}

        profile = extract_profile_summary(self_response, auth_response)
        final_username = profile.get("username") or task.username
        key_id = final_username or task.email or "account"
        now_iso = dt.datetime.now(dt.timezone.utc).isoformat()

        session_file = self.sessions_dir / f"{safe_filename(key_id)}.json"
        existing_posts: List[Dict[str, Any]] = []
        existing_meta: Dict[str, Any] = {}
        if session_file.exists():
            try:
                old = json.loads(session_file.read_text(encoding="utf-8"))
                existing_posts = old.get("posts") or []
                for k_keep in ("appeal_folder", "appeal_verdict_label", "appeal_meta", "raw_line"):
                    if old.get(k_keep):
                        existing_meta[k_keep] = old[k_keep]
            except Exception:
                pass

        record: Dict[str, Any] = {
            **existing_meta,
            "email": task.email,
            "username": final_username,
            "tiktok_password": task.tiktok_password,
            "totp_token": task.totp_token,
            "raw_line": task.raw_line or existing_meta.get("raw_line") or "",
            "region": task.region,
            "proxy": proxy_normalized,
            "nickname": profile.get("nickname"),
            "signature": profile.get("signature") or "",
            "uid": profile.get("uid"),
            "sec_uid": profile.get("sec_uid") or (device_dict.get("sec_uid") if isinstance(device_dict, dict) else None),
            "follower_count": profile.get("follower_count"),
            "logged_in_at": now_iso,
            "x_device": x_device_str,
            "device": device_dict,
            "posts": existing_posts,
            "self_info": self_response,
            "auth_response": auth_response,
        }

        with self._lock:
            session_file.write_text(
                json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            with open(self.output_dir / "sessions.jsonl", "a", encoding="utf-8") as jf:
                jf.write(
                    json.dumps(
                        {
                            "email": task.email,
                            "username": final_username,
                            "uid": record["uid"],
                            "region": task.region,
                            "proxy": proxy_normalized,
                            "x_device": x_device_str,
                            "logged_in_at": now_iso,
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
            with open(self.output_dir / "success.txt", "a", encoding="utf-8") as sf:
                uname = f"@{final_username}" if final_username else task.email
                sf.write(f"{uname} | {task.email} | {proxy_normalized} | {session_file.name}\n")

        record["session_file"] = session_file.name
        return record

    def update_session_data(self, filename: str, updater_fn: Callable[[Dict[str, Any]], None]) -> Optional[Dict[str, Any]]:
        safe_name = os.path.basename(filename)
        fp = self.sessions_dir / safe_name
        with self._lock:
            if not fp.exists():
                return None
            data = json.loads(fp.read_text(encoding="utf-8"))
            updater_fn(data)
            if isinstance(data.get("device"), dict):
                data["x_device"] = serialize_device_header(data["device"])
            fp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            return data

    def save_failure(self, task: AccountTask, reason: str) -> None:
        with self._lock:
            with open(self.output_dir / "failed.txt", "a", encoding="utf-8") as ff:
                ff.write(f"{task.raw_line or task.identifier} | ERROR: {reason}\n")

    def list_sessions(self) -> List[Dict[str, Any]]:
        items: List[Dict[str, Any]] = []
        for fp in sorted(
            self.sessions_dir.glob("*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        ):
            try:
                data = json.loads(fp.read_text(encoding="utf-8"))
                items.append(
                    {
                        "filename": fp.name,
                        "email": data.get("email") or "",
                        "username": data.get("username") or "",
                        "nickname": data.get("nickname") or "",
                        "signature": data.get("signature") or "",
                        "uid": data.get("uid") or "",
                        "sec_uid": data.get("sec_uid") or "",
                        "follower_count": data.get("follower_count"),
                        "region": data.get("region") or "",
                        "proxy": data.get("proxy") or "",
                        "logged_in_at": data.get("logged_in_at") or "",
                        "posts": data.get("posts") or [],
                        "appeal_folder": data.get("appeal_folder") or "",
                        "appeal_verdict_label": data.get("appeal_verdict_label") or "",
                        "x_device": data.get("x_device") or "",
                    }
                )
            except Exception:
                continue
        return items

    def get_session(self, filename: str) -> Optional[Dict[str, Any]]:
        safe_name = os.path.basename(filename)
        fp = self.sessions_dir / safe_name
        if not fp.exists():
            return None
        return json.loads(fp.read_text(encoding="utf-8"))

    def delete_session(self, filename: str) -> bool:
        safe_name = os.path.basename(filename)
        fp = self.sessions_dir / safe_name
        if fp.exists():
            fp.unlink()
            return True
        return False


@dataclass
class PendingCodeChallenge:
    challenge_id: str
    task: AccountTask
    proxy_normalized: str
    device: Any
    verify: Optional[Dict[str, Any]]
    options: LoginOptions
    is_username_flow: bool = False
    created_at: float = field(default_factory=time.time)
    code_event: threading.Event = field(default_factory=threading.Event)
    submitted_code: Optional[str] = None
    cancelled: bool = False


def _delete_all_account_posts(
    client: KintaroClient,
    proxy: str,
    device: Any,
    tag: str,
    log_fn: Callable[[str], None],
) -> Tuple[int, Any]:
    """Fetches all existing videos/photos via `/v1/account/posts` and deletes each via `/v1/post/delete`."""
    current_dev = device
    deleted_count = 0
    seen_ids: set = set()

    for _page in range(10):
        posts_body, updated_dev = client.get_self_posts(
            proxy=proxy, device=current_dev, count=20, max_cursor="0"
        )
        if updated_dev is not None:
            current_dev = updated_dev
        aweme_list = (posts_body.get("aweme_list") if isinstance(posts_body, dict) else None) or []
        to_delete = [
            str(item.get("aweme_id"))
            for item in aweme_list
            if isinstance(item, dict) and item.get("aweme_id") and str(item.get("aweme_id")) not in seen_ids
        ]
        if not to_delete:
            break

        log_fn(f"[{tag}] ⚡ Найдено старых роликов/постов для параллельного удаления: {len(to_delete)} шт.")
        for aid in to_delete:
            seen_ids.add(aid)

        def _del_one(aid_val: str) -> Tuple[str, Optional[Any], Optional[str]]:
            try:
                _, upd = client.delete_post(proxy=proxy, device=current_dev, aweme_id=aid_val)
                return aid_val, upd, None
            except Exception as exc:
                return aid_val, None, str(exc)

        with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(to_delete))) as pool:
            for aid_val, upd, err_str in pool.map(_del_one, to_delete):
                if err_str is None:
                    if upd is not None:
                        current_dev = upd
                    deleted_count += 1
                    log_fn(f"[{tag}] 🗑 Удалён старый ролик/пост ID={aid_val}")
                else:
                    log_fn(f"[{tag}] Предупреждение при удалении поста {aid_val}: {err_str}")

        has_more = bool(posts_body.get("has_more")) if isinstance(posts_body, dict) else False
        if not has_more:
            break

    if deleted_count == 0:
        log_fn(f"[{tag}] Старых роликов на аккаунте не обнаружено (0 шт.)")
    else:
        log_fn(f"[{tag}] Успешно удалено старых роликов/постов: {deleted_count} шт.")
    return deleted_count, current_dev


def finalize_authenticated_session(
    client: KintaroClient,
    store: SessionStore,
    task: AccountTask,
    proxy_norm: str,
    device: Any,
    auth_response: Any,
    options: LoginOptions,
    log_fn: Callable[[str], None],
) -> Dict[str, Any]:
    """Runs optional post-login actions (`delete_old_posts`, `set_bio`, `token_beat`, `account/self`) and saves session."""
    current_device = device
    self_body = None
    tag = task.identifier

    if options.token_beat_after_login and current_device is not None:
        try:
            _, updated_dev = client.token_beat(proxy=proxy_norm, device=current_device)
            if updated_dev is not None:
                current_device = updated_dev
            log_fn(f"[{tag}] token_beat выполнен успешно")
        except Exception as exc:
            log_fn(f"[{tag}] Предупреждение token_beat: {exc}")

    if options.delete_old_posts and current_device is not None:
        try:
            _, current_device = _delete_all_account_posts(
                client=client,
                proxy=proxy_norm,
                device=current_device,
                tag=tag,
                log_fn=log_fn,
            )
        except Exception as exc:
            log_fn(f"[{tag}] Предупреждение при очистке старых роликов: {exc}")

    if options.bio_after_login and options.bio_after_login.strip() and current_device is not None:
        new_bio = options.bio_after_login.strip()
        try:
            _, updated_dev = client.set_bio(proxy=proxy_norm, device=current_device, text=new_bio)
            if updated_dev is not None:
                current_device = updated_dev
            log_fn(f"[{tag}] БИО успешно изменено на: {new_bio!r}")
        except Exception as exc:
            log_fn(f"[{tag}] Ошибка при смене БИО: {exc}")

    if options.check_self_after_login and current_device is not None:
        try:
            self_body, updated_dev = client.get_self(proxy=proxy_norm, device=current_device)
            if updated_dev is not None:
                current_device = updated_dev
            prof = extract_profile_summary(self_body, auth_response)
            uname = f"@{prof['username']}" if prof.get("username") else f"uid={prof.get('uid') or 'ok'}"
            log_fn(f"[{tag}] Профиль проверен (/v1/account/self): {uname} | bio={prof.get('signature')!r}")
        except Exception as exc:
            log_fn(f"[{tag}] Предупреждение /v1/account/self: {exc}")

    saved = store.save_success(
        task=task,
        proxy_normalized=proxy_norm,
        device=current_device,
        auth_response=auth_response,
        self_response=self_body,
    )
    log_fn(f"[{tag}] Сессия сохранена -> sessions/{saved['session_file']}")
    return saved


def _format_tiktok_auth_error(http_status: int, raw_msg: str) -> str:
    low = (raw_msg or "").lower()
    if "account doesn't exist" in low or "account does not exist" in low or "error_code=1011" in low:
        return f"Такого аккаунта TikTok не существует! ({raw_msg})"
    if "suspended" in low or "error_code=1091" in low:
        return f"Аккаунт TikTok заблокирован / заморожен! ({raw_msg})"
    return f"Ошибка ({http_status}): {raw_msg}"


def process_single_account(
    task: AccountTask,
    proxy_raw: str,
    options: LoginOptions,
    store: SessionStore,
    log_fn: Callable[[str], None],
    manual_code_callback: Optional[Callable[[PendingCodeChallenge], Optional[str]]] = None,
) -> Dict[str, Any]:
    """
    Executes full login pipeline for either:
      - Username + Password (+ TOTP) via `/v1/auth/signin/username`
      - Email (+ Password / TOTP / Outlook Hub / IMAP OTP) via `/v1/auth/signin/email`
    For Outlook/Hotmail email logins: logs into Outlook FIRST, snapshots old message IDs,
    and concurrently polls Microsoft Graph API for the brand-new TikTok code while requesting it.
    """
    proxy_norm = normalize_proxy(proxy_raw)
    tag = task.identifier
    requested_phone_region = (task.region or options.default_region or "DE").upper().strip()
    if proxy_norm and "bpproxy." in proxy_norm.lower():
        if proxy_norm.startswith("http://") and ":1000" in proxy_norm:
            proxy_norm = "socks5://" + proxy_norm[len("http://") :].replace(":1000", ":1002")
        proxy_norm = allocate_sticky_proxy(
            proxy_norm,
            target_country=requested_phone_region,
            lifetime="60m",
            preserve_existing_session=True,
        )
    use_username_flow = bool(task.username and (options.login_mode == "username_totp" or not task.email))

    if use_username_flow and task.totp_token and not is_valid_base32_totp(task.totp_token):
        log_fn(
            f"[{tag}] ВНИМАНИЕ: поле TOTP ({task.totp_token[:10]}...) не является валидным Base32 TOTP ключом "
            f"(содержит недопустимые символы 0/1/8/9 или строчные буквы токена почты)."
        )

    imap_password = task.mail_password
    if (
        not imap_password
        and options.login_mode == "password_imap"
        and options.same_password_fallback
        and task.tiktok_password
    ):
        imap_password = task.tiktok_password

    is_outlook_flow = (
        not use_username_flow
        and bool(task.email and imap_password)
        and (task.use_outlook_hub or _is_outlook_domain(task.email))
    )
    is_standard_imap_flow = (
        not use_username_flow
        and not is_outlook_flow
        and options.login_mode != "password_only"
        and bool(task.email and imap_password)
    )
    pre_outlook_token = ""
    pre_imap_server: Optional[Tuple[str, int]] = None
    known_old_ids: Optional[set] = None

    with KintaroClient(api_key=options.api_key, base_url=options.base_url) as client:
        device: Optional[Any] = None

        if options.reuse_existing_device:
            existing_dev = store.load_existing_device(task.username or task.email)
            if existing_dev:
                device = existing_dev
                log_fn(f"[{tag}] Найдено сохранённое устройство (x-device), используем его")

        need_dev_reg = device is None and options.pre_register_device
        imap_host_cfg = task.imap_host or (options.custom_imap_host.strip() or None)

        # Parallel optimization: run Mailbox Login (Outlook Hub OR IMAP) AND Kintaro /v1/device/register simultaneously!
        if (is_outlook_flow or is_standard_imap_flow) and need_dev_reg:
            mail_label = "Outlook Hub" if is_outlook_flow else "IMAP"
            log_fn(
                f"[{tag}] ⚡ Параллельный запуск: вход в почту {task.email} ({mail_label}) "
                f"+ регистрация устройства (region={task.region})..."
            )
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                if is_outlook_flow:
                    fut_mail = pool.submit(
                        prepare_outlook_hub_mailbox,
                        outlook_email=task.email,
                        outlook_login=task.mail_login or task.email,
                        outlook_password=imap_password or "",
                        recovery_email=task.recovery_email or "",
                        recovery_password=task.recovery_password or "",
                        hotmail_totp=task.mail_totp or "",
                        log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                    )
                else:
                    fut_mail = pool.submit(
                        prepare_imap_mailbox,
                        email_addr=task.email,
                        mail_password=imap_password or "",
                        custom_imap_host=imap_host_cfg,
                        log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                    )
                fut_dev = pool.submit(client.register_device, proxy=proxy_norm, region=task.region)
                try:
                    if is_outlook_flow:
                        pre_outlook_token, known_old_ids = fut_mail.result()
                    else:
                        pre_imap_server, known_old_ids = fut_mail.result()
                except Exception as exc:
                    err = f"Не удалось войти в почту ({task.email}): {exc}"
                    log_fn(f"[{tag}] ОШИБКА: {err}")
                    store.save_failure(task, err)
                    return {"status": "error", "identifier": tag, "error": err}
                device = fut_dev.result()
                if options.update_hosts_after_register:
                    _, device = client.update_hosts(proxy=proxy_norm, device=device)
                log_fn(f"[{tag}] Почта и устройство готовы одновременно!")
        else:
            if is_outlook_flow:
                log_fn(f"[{tag}] Вход в почту {task.email} через Outlook Hub ПЕРЕД запросом кода в TikTok...")
                try:
                    pre_outlook_token, known_old_ids = prepare_outlook_hub_mailbox(
                        outlook_email=task.email,
                        outlook_login=task.mail_login or task.email,
                        outlook_password=imap_password or "",
                        recovery_email=task.recovery_email or "",
                        recovery_password=task.recovery_password or "",
                        hotmail_totp=task.mail_totp or "",
                        log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                    )
                except Exception as exc:
                    err = f"Не удалось войти в почту Outlook ({task.email}): {exc}"
                    log_fn(f"[{tag}] ОШИБКА: {err}")
                    store.save_failure(task, err)
                    return {"status": "error", "identifier": tag, "error": err}
            elif is_standard_imap_flow:
                log_fn(f"[{tag}] Вход в почту {task.email} по IMAP ПЕРЕД запросом кода в TikTok...")
                try:
                    pre_imap_server, known_old_ids = prepare_imap_mailbox(
                        email_addr=task.email,
                        mail_password=imap_password or "",
                        custom_imap_host=imap_host_cfg,
                        log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                    )
                except Exception as exc:
                    err = f"Не удалось войти в почту по IMAP ({task.email}): {exc}"
                    log_fn(f"[{tag}] ОШИБКА: {err}")
                    store.save_failure(task, err)
                    return {"status": "error", "identifier": tag, "error": err}
            if need_dev_reg:
                log_fn(f"[{tag}] Регистрация устройства (/v1/device/register, region={task.region})...")
                device = client.register_device(proxy=proxy_norm, region=task.region)
                if options.update_hosts_after_register:
                    _, device = client.update_hosts(proxy=proxy_norm, device=device)
                log_fn(f"[{tag}] Устройство успешно зарегистрировано")

        if device is not None and options.app_locale:
            device = apply_device_geo_profile(device, "", app_locale=options.app_locale)

        signin_started_ts = time.time()
        concurrent_code_box: Dict[str, Any] = {"code": None, "error": None}
        poller_thread: Optional[threading.Thread] = None

        # Start concurrent real-time mail poller (Outlook Hub OR IMAP) AT THE SAME TIME as requesting TikTok login!
        if is_outlook_flow and pre_outlook_token:
            def _bg_poll_outlook() -> None:
                try:
                    concurrent_code_box["code"] = wait_for_outlook_hub_code(
                        outlook_email=task.email,
                        outlook_login=task.mail_login or task.email,
                        outlook_password=imap_password or "",
                        recovery_email=task.recovery_email or "",
                        recovery_password=task.recovery_password or "",
                        hotmail_totp=task.mail_totp or "",
                        min_timestamp=signin_started_ts,
                        pre_access_token=pre_outlook_token,
                        known_old_ids=known_old_ids,
                        timeout_sec=options.imap_timeout_sec,
                        poll_interval_sec=1.0,
                        log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                    )
                except Exception as e:
                    concurrent_code_box["error"] = str(e)

            poller_thread = threading.Thread(target=_bg_poll_outlook, daemon=True)
            poller_thread.start()
        elif is_standard_imap_flow and pre_imap_server:
            def _bg_poll_imap() -> None:
                try:
                    log_fn(f"[{tag}] Параллельное ожидание НОВОГО кода TikTok по IMAP ({pre_imap_server[0]})...")
                    concurrent_code_box["code"] = wait_for_email_code(
                        email_addr=task.email,
                        mail_password=imap_password or "",
                        since_timestamp=signin_started_ts,
                        pre_server=pre_imap_server,
                        known_old_ids=known_old_ids,
                        timeout_sec=options.imap_timeout_sec,
                        poll_interval_sec=2.0,
                        log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                    )
                except Exception as e:
                    concurrent_code_box["error"] = str(e)

            poller_thread = threading.Thread(target=_bg_poll_imap, daemon=True)
            poller_thread.start()

        if use_username_flow:
            log_fn(
                f"[{tag}] Вход по логину @{task.username} + паролю"
                + (" + TOTP" if task.totp_token else "")
                + f" (region={task.region})..."
            )
            step1 = client.signin_username(
                username=task.username or "",
                password=task.tiktok_password or "",
                proxy=proxy_norm,
                region=task.region,
                totp_token=task.totp_token,
                device=device,
                log_fn=lambda m: log_fn(f"[{tag}] {m}"),
            )
        else:
            pw_to_send = None if options.login_mode == "otp_only" else task.tiktok_password
            mode_desc = "по коду с почты (без пароля)" if not pw_to_send else "по почте и паролю"
            log_fn(f"[{tag}] Запрос входа в TikTok ({mode_desc}, region={task.region})...")
            step1 = client.signin_email(
                email=task.email,
                proxy=proxy_norm,
                region=task.region,
                password=pw_to_send,
                totp_token=task.totp_token,
                device=device,
                log_fn=lambda m: log_fn(f"[{tag}] {m}"),
            )
            # Auto-fallback: if email signin hits error_code=1206 (too many codes), try username+password flow
            if (
                step1.status == "error"
                and ("1206" in (step1.message or "") or "troppi codici" in (step1.message or "").lower() or "too many" in (step1.message or "").lower())
                and task.username
                and task.tiktok_password
            ):
                log_fn(
                    f"[{tag}] Email-вход получил лимит кодов (1206) — автоматический обход через логин @{task.username} + пароль..."
                )
                use_username_flow = True
                step1 = client.signin_username(
                    username=task.username,
                    password=task.tiktok_password,
                    proxy=proxy_norm,
                    region=task.region,
                    totp_token=task.totp_token,
                    device=device,
                    log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                )

        # Auto-recover if 403 suspicious_login revealed a different home IDC (e.g. US -> DE for no1a.tiktokv.eu)
        if (
            step1.status == "code_required"
            and step1.detected_region
            and options.auto_retry_detected_region
            and task.totp_token
        ):
            new_reg = step1.detected_region
            login_proxy = swap_proxy_country(proxy_norm, new_reg)
            proxy_note = f" + прокси {new_reg}" if login_proxy != proxy_norm else ""
            log_fn(
                f"[{tag}] Обнаружен домашний кластер аккаунта ({new_reg} вместо {task.region}). "
                f"Перерегистрация устройства под {new_reg}{proxy_note} для чистого входа по TOTP..."
            )
            task.region = new_reg
            device = client.register_device(proxy=login_proxy, region=new_reg)
            signin_started_ts = time.time()
            if use_username_flow:
                step1 = client.signin_username(
                    username=task.username or "",
                    password=task.tiktok_password or "",
                    proxy=login_proxy,
                    region=new_reg,
                    totp_token=task.totp_token,
                    device=device,
                    log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                )
            else:
                step1 = client.signin_email(
                    email=task.email,
                    proxy=login_proxy,
                    region=new_reg,
                    password=task.tiktok_password,
                    totp_token=task.totp_token,
                    device=device,
                    log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                )

        if step1.status == "success":
            final_dev = step1.device
            if final_dev is not None and requested_phone_region and requested_phone_region != task.region:
                log_fn(
                    f"[{tag}] Переключение SIM/гео профиля телефона {task.region} -> {requested_phone_region} "
                    f"(под целевой регион залива {requested_phone_region})..."
                )
                final_dev = apply_device_geo_profile(final_dev, requested_phone_region)
                task.region = requested_phone_region
            log_fn(f"[{tag}] Вход выполнен успешно (HTTP 200, {step1.elapsed_ms}мс)")
            saved = finalize_authenticated_session(
                client=client,
                store=store,
                task=task,
                proxy_norm=proxy_norm,
                device=final_dev,
                auth_response=step1.response,
                options=options,
                log_fn=log_fn,
            )
            return {"status": "success", "identifier": tag, "session": saved}

        if step1.status == "code_required":
            log_fn(f"[{tag}] Kintaro API запросил доп. код подтверждения (HTTP 403)...")
            if not step1.device:
                err = "API вернул 403, но без x-device. Включите '/v1/device/register'."
                store.save_failure(task, err)
                return {"status": "error", "identifier": tag, "error": err}

            otp_code: Optional[str] = None
            imap_error: Optional[str] = None

            # 1) Join concurrent Outlook Hub Graph poller (or run on-demand if username flow hit email 403)
            if poller_thread is not None:
                poller_thread.join(timeout=options.imap_timeout_sec + 5)
                otp_code = concurrent_code_box.get("code")
                imap_error = concurrent_code_box.get("error")
                if imap_error:
                    log_fn(f"[{tag}] Ошибка Outlook Hub: {imap_error}")
            elif (task.use_outlook_hub or _is_outlook_domain(task.email)) and imap_password and task.email:
                log_fn(
                    f"[{tag}] Запуск Outlook Hub для получения ТОЛЬКО нового кода ({task.email})..."
                )
                try:
                    otp_code = wait_for_outlook_hub_code(
                        outlook_email=task.email,
                        outlook_login=task.mail_login or task.email,
                        outlook_password=imap_password,
                        recovery_email=task.recovery_email or "",
                        recovery_password=task.recovery_password or "",
                        hotmail_totp=task.mail_totp or "",
                        min_timestamp=signin_started_ts,
                        timeout_sec=options.imap_timeout_sec,
                        log_fn=lambda m: log_fn(f"[{tag}] {m}"),
                    )
                except Exception as exc:
                    imap_error = str(exc)
                    log_fn(f"[{tag}] Ошибка Outlook Hub: {imap_error}")

            # 2) Standard IMAP fallback (Firstmail, Rambler, Mail.ru, etc.)
            elif imap_password and task.email:
                imap_host = task.imap_host or (options.custom_imap_host.strip() or None)
                try:
                    otp_code = wait_for_email_code(
                        email_addr=task.email,
                        mail_password=imap_password,
                        since_timestamp=signin_started_ts,
                        custom_imap_host=imap_host,
                        timeout_sec=options.imap_timeout_sec,
                        log_fn=log_fn,
                    )
                except Exception as exc:
                    imap_error = str(exc)
                    log_fn(f"[{tag}] Не удалось получить код по IMAP: {imap_error}")

            if not otp_code and options.allow_manual_code and manual_code_callback is not None:
                challenge = PendingCodeChallenge(
                    challenge_id=uuid.uuid4().hex[:12],
                    task=task,
                    proxy_normalized=proxy_norm,
                    device=step1.device,
                    verify=step1.verify,
                    options=options,
                    is_username_flow=use_username_flow,
                )
                log_fn(f"[{tag}] Ожидание ручного ввода 6-значного кода...")
                otp_code = manual_code_callback(challenge)

            if not otp_code:
                reason = imap_error or "Требуется код подтверждения (403), но новый код не получен"
                store.save_failure(task, reason)
                return {"status": "error", "identifier": tag, "error": reason}

            if use_username_flow and step1.verify:
                step2 = client.signin_username_send_code(
                    username=task.username or "",
                    password=task.tiktok_password or "",
                    code=otp_code,
                    verify=step1.verify,
                    proxy=proxy_norm,
                    device=step1.device,
                )
            else:
                pw_to_send = None if options.login_mode == "otp_only" else task.tiktok_password
                step2 = client.signin_email_send_code(
                    email=task.email,
                    code=otp_code,
                    proxy=proxy_norm,
                    device=step1.device,
                    password=pw_to_send,
                    verify=step1.verify,
                )
                # Fallback if TikTok's email+password returned a passport_ticket challenge expecting username/send_code
                if step2.status != "success" and step1.verify and task.username and pw_to_send:
                    log_fn(f"[{tag}] Повтор отправки кода через /v1/auth/signin/username/send_code...")
                    step2 = client.signin_username_send_code(
                        username=task.username,
                        password=pw_to_send,
                        code=otp_code,
                        verify=step1.verify,
                        proxy=proxy_norm,
                        device=step1.device,
                    )

            if step2.status == "success":
                final_dev2 = step2.device
                if final_dev2 is not None and requested_phone_region and requested_phone_region != task.region:
                    final_dev2 = apply_device_geo_profile(final_dev2, requested_phone_region)
                    task.region = requested_phone_region
                log_fn(f"[{tag}] Новый код принят! Вход через почту успешно завершён ({step2.elapsed_ms}мс)")
                saved = finalize_authenticated_session(
                    client=client,
                    store=store,
                    task=task,
                    proxy_norm=proxy_norm,
                    device=final_dev2,
                    auth_response=step2.response,
                    options=options,
                    log_fn=log_fn,
                )
                return {"status": "success", "identifier": tag, "session": saved}

            err = _format_tiktok_auth_error(step2.http_status, step2.message)
            log_fn(f"[{tag}] ❌ {err}")
            store.save_failure(task, err)
            return {"status": "error", "identifier": tag, "error": err}

        err = _format_tiktok_auth_error(step1.http_status, step1.message)
        log_fn(f"[{tag}] ❌ {err}")
        store.save_failure(task, err)
        return {"status": "error", "identifier": tag, "error": err}


def delete_all_posts_for_session(
    api_key: str,
    session_filename: str,
    store: SessionStore,
    log_fn: Callable[[str], None],
    proxy_override: str = "",
) -> int:
    """Deletes all existing TikTok posts on a saved session and updates the stored session."""
    sess = store.get_session(session_filename)
    if not sess:
        raise ValueError(f"Сессия {session_filename} не найдена")
    tag = f"@{sess.get('username')}" if sess.get("username") else (sess.get("email") or session_filename)
    proxy = normalize_proxy(proxy_override) if proxy_override.strip() else (sess.get("proxy") or "")
    device = sess.get("device") or sess.get("x_device")

    with KintaroClient(api_key=api_key) as client:
        deleted_count, updated_dev = _delete_all_account_posts(
            client=client, proxy=proxy, device=device, tag=tag, log_fn=log_fn
        )

    def _upd(data: Dict[str, Any]) -> None:
        if updated_dev:
            data["device"] = updated_dev
        data["posts"] = []

    store.update_session_data(session_filename, _upd)
    return deleted_count


def parse_delay_range(val: Union[str, Tuple[float, float], int, float, None], default_min: float = 30.0, default_max: float = 50.0) -> Tuple[float, float]:
    """Parses delay strings like '30-50', '30..50', '40' into (min_sec, max_sec)."""
    if val is None:
        return default_min, default_max
    if isinstance(val, (int, float)):
        v = max(0.0, float(val))
        return v, v
    if isinstance(val, tuple) and len(val) == 2:
        a, b = max(0.0, float(val[0])), max(0.0, float(val[1]))
        return (a, b) if a <= b else (b, a)
    s = str(val).strip()
    if not s:
        return default_min, default_max
    nums = [float(x) for x in re.findall(r"\d+(?:\.\d+)?", s)]
    if len(nums) >= 2:
        a, b = nums[0], nums[1]
        return (a, b) if a <= b else (b, a)
    if len(nums) == 1:
        return nums[0], nums[0]
    return default_min, default_max


def _restart_tiktok_app_on_client(
    client: KintaroClient,
    proxy: str,
    device: Any,
    target_region: str,
    tag: str,
    log_fn: Callable[[str], None],
    app_locale: str = "",
) -> Any:
    """
    Simulates closing and cold-restarting the TikTok Android app via Kintaro API:
      1) Rotates app launch `session_ids.session`, `start_time`, and `counters.sessions`
         (and attempts `/v1/device/new_session` without failing if cluster skips region_submit)
      2) POST /v1/device/update_hosts (cold-boot TNC host discovery)
      3) POST /v1/device/report {"type": "launch"} (MSSDK launch telemetry & fresh `report_tk`)
      4) POST /v1/account/token_beat (passport session heartbeat on startup)
      5) GET  /v1/account/self       (home profile sync)
    """
    log_fn(f"[{tag}] 🔄 Перезапуск приложения TikTok (смена app-сессии + update_hosts + launch report + token_beat)...")
    dev_dict: Dict[str, Any] = (
        dict(json.loads(device)) if isinstance(device, str) else dict(device)
    )
    # Rotate app session UUID & cold-boot timestamp just like Android process restart
    sess_ids = dict(dev_dict.get("session_ids") or {})
    old_sess_uuid = sess_ids.get("session")
    new_sess_uuid = str(uuid.uuid4())
    sess_ids["session"] = new_sess_uuid
    sess_ids["request"] = str(uuid.uuid4())
    dev_dict["session_ids"] = sess_ids
    dev_dict["start_time"] = int(time.time() * 1000)
    counters = dict(dev_dict.get("counters") or {})
    counters["sessions"] = int(counters.get("sessions") or 1) + 1
    dev_dict["counters"] = counters
    current_dev: Any = dev_dict

    # 1) Try /v1/device/new_session (single fast attempt; some non-US clusters return 500 on region_submit)
    prev_retries = client.max_retries
    client.max_retries = 0
    try:
        _, upd_ns = client.new_session(proxy=proxy, device=current_dev)
        if upd_ns is not None:
            current_dev = upd_ns
    except Exception:
        pass
    finally:
        client.max_retries = prev_retries

    # 2) TNC hosts refresh on cold start
    try:
        _, upd_hosts = client.update_hosts(proxy=proxy, device=current_dev)
        if upd_hosts is not None:
            current_dev = upd_hosts
    except Exception as exc:
        log_fn(f"[{tag}] Предупреждение update_hosts: {exc}")

    # 3) MSSDK app launch report (`report_tk` refresh)
    try:
        _, upd_rep = client.device_report(proxy=proxy, device=current_dev, report_type="launch")
        if upd_rep is not None:
            current_dev = upd_rep
    except Exception as exc:
        log_fn(f"[{tag}] Предупреждение device/report: {exc}")

    # 4) Passport token beat
    try:
        _, upd_tb = client.token_beat(proxy=proxy, device=current_dev)
        if upd_tb is not None:
            current_dev = upd_tb
    except Exception as exc:
        log_fn(f"[{tag}] Предупреждение token_beat: {exc}")

    # 5) Home profile check
    try:
        _, upd_self = client.get_self(proxy=proxy, device=current_dev)
        if upd_self is not None:
            current_dev = upd_self
    except Exception as exc:
        log_fn(f"[{tag}] Предупреждение /v1/account/self: {exc}")

    if (target_region or app_locale) and current_dev is not None:
        current_dev = apply_device_geo_profile(current_dev, target_region, app_locale=app_locale or None)
    log_fn(
        f"[{tag}] ✅ Приложение TikTok перезапущено! "
        f"(session_id: {str(old_sess_uuid)[:8]}.. -> {new_sess_uuid[:8]}.., сессий={counters['sessions']})"
    )
    return current_dev


def restart_tiktok_app_for_session(
    api_key: str,
    session_filename: str,
    store: SessionStore,
    log_fn: Callable[[str], None],
    proxy_override: str = "",
) -> Dict[str, Any]:
    """Standalone helper to cold-restart the TikTok app for a saved session."""
    sess = store.get_session(session_filename)
    if not sess:
        raise ValueError(f"Сессия {session_filename} не найдена")
    tag = f"@{sess.get('username')}" if sess.get("username") else (sess.get("email") or session_filename)
    proxy = normalize_proxy(proxy_override) if proxy_override.strip() else (sess.get("proxy") or "")
    device = sess.get("device") or sess.get("x_device")
    target_region = (sess.get("region") or "").upper().strip()

    with KintaroClient(api_key=api_key) as client:
        new_dev = _restart_tiktok_app_on_client(
            client=client,
            proxy=proxy,
            device=device,
            target_region=target_region,
            tag=tag,
            log_fn=log_fn,
        )

    def _upd(data: Dict[str, Any]) -> None:
        if new_dev is not None:
            data["device"] = new_dev
        data["last_restarted_at"] = dt.datetime.now(dt.timezone.utc).isoformat()

    store.update_session_data(session_filename, _upd)
    return {"ok": True}


def _randomize_description_tags(description: str, used_captions: set, shuffle_tags: bool = True) -> str:
    """
    Expands `{A|B}` spintax + `{RAND4}` and optionally randomizes hashtag order inside `description`.
    """
    if not description:
        return description
    expanded = expand_spintax(description)
    if not shuffle_tags or "#" not in expanded:
        return expanded
    tags = re.findall(r"#[^\s#]+", expanded)
    if len(tags) <= 1:
        return expanded
    prefix = re.sub(r"#[^\s#]+", "", expanded).strip()
    for _ in range(25):
        shuffled = list(tags)
        random.shuffle(shuffled)
        candidate = (f"{prefix} " if prefix else "") + " ".join(shuffled)
        if candidate not in used_captions:
            used_captions.add(candidate)
            return candidate
    shuffled = list(tags)
    random.shuffle(shuffled)
    return (f"{prefix} " if prefix else "") + " ".join(shuffled)


def publish_photo_carousel_for_session(
    api_key: str,
    session_filename: str,
    photos: List[Any],
    description: str,
    store: SessionStore,
    log_fn: Callable[[str], None],
    region: str = "",
    phone_region: str = "",
    app_locale: str = "",
    proxy_override: str = "",
    delete_old_posts: bool = False,
    randomize_tags: bool = False,
    uniquify_photos: bool = False,
    uniquify_mode: str = "minimal",
    uniquifier_settings: Optional[Dict[str, Any]] = None,
    copies_count: int = 1,
    delay_min_sec: float = 30.0,
    delay_max_sec: float = 50.0,
    restart_every_n: int = 0,
    music_id: str = "",
    auto_music_query: str = "",
    is_private: bool = False,
    disable_comments: bool = False,
    is_story: bool = False,
    inter_post_hook: Optional[Callable[[int, List[str]], None]] = None,
) -> Dict[str, Any]:
    """
    Publishes 1..N photo carousel posts (each 1..10 slides) on a saved session:
      - `region` = upload geo passed to `/v1/post/create/photo` (e.g. `US`)
      - `phone_region` = SIM/phone geo on `x-device` (e.g. `KZ`; if omitted, defaults to `region` or session's phone region)
      - `app_locale` = app/device language & locale (e.g. `en_US`)
    """
    sess = store.get_session(session_filename)
    if not sess:
        raise ValueError(f"Сессия {session_filename} не найдена")

    copies = max(1, min(30, int(copies_count or 1)))
    restart_n = max(0, int(restart_every_n or 0))
    d_min = max(0.0, float(delay_min_sec))
    d_max = max(d_min, float(delay_max_sec))
    tag = f"@{sess.get('username')}" if sess.get("username") else (sess.get("email") or session_filename)
    proxy = normalize_proxy(proxy_override) if proxy_override.strip() else (sess.get("proxy") or "")
    device = sess.get("device") or sess.get("x_device")
    target_upload_region = (region or sess.get("upload_region") or sess.get("region") or "").upper().strip()
    target_phone_region = (phone_region or sess.get("phone_region") or target_upload_region).upper().strip()
    target_locale = (app_locale or sess.get("app_locale") or "").strip()

    if (target_phone_region or target_locale) and device is not None:
        device = apply_device_geo_profile(device, target_phone_region, app_locale=target_locale or None)

    deleted_before = 0
    published_records: List[Dict[str, Any]] = []
    used_captions: set = set()

    with KintaroClient(api_key=api_key) as client:
        if delete_old_posts:
            log_fn(f"[{tag}] Очистка старых роликов перед заливом...")
            deleted_before, device = _delete_all_account_posts(
                client=client, proxy=proxy, device=device, tag=tag, log_fn=log_fn
            )
            if (target_phone_region or target_locale) and device is not None:
                device = apply_device_geo_profile(device, target_phone_region, app_locale=target_locale or None)

        music_pool: List[Dict[str, str]] = []
        used_music_ids: set = set()
        if not str(music_id or "").strip() and str(auto_music_query or "").strip():
            q_label = str(auto_music_query).strip()
            log_fn(f"[{tag}] 🎵 Подбор треков в TikTok ({q_label} / предложенные, регион {target_upload_region or 'IT'})...")
            music_pool = client.build_music_pool(
                keyword=q_label,
                proxy=proxy,
                device=device,
                region=target_upload_region or "IT",
            )
            log_fn(f"[{tag}] 🎵 Найдено {len(music_pool)} доступных треков для авто-добавления")

        for copy_idx in range(1, copies + 1):
            step_label = f" [{copy_idx}/{copies}]" if copies > 1 else ""
            cur_desc = _randomize_description_tags(description, used_captions, shuffle_tags=randomize_tags)
            eff_mode = (uniquifier_settings or {}).get("mode") or uniquify_mode
            cur_photos = (
                uniquify_photo_batch(photos, mode=eff_mode, settings=uniquifier_settings)
                if uniquify_photos and eff_mode != "off"
                else photos
            )
            uniq_note = f", ❄️ уник={eff_mode}" if (uniquify_photos and eff_mode != "off") else ""

            chosen_music_id = str(music_id or "").strip()
            chosen_music_label = chosen_music_id
            if not chosen_music_id and music_pool:
                avail_tracks = [t for t in music_pool if t["id"] not in used_music_ids] or list(music_pool)
                picked_track = random.choice(avail_tracks)
                used_music_ids.add(picked_track["id"])
                chosen_music_id = picked_track["id"]
                chosen_music_label = f"{picked_track['title']} — {picked_track['author']} ({chosen_music_id})"

            mus_note = f", 🎵 трек={chosen_music_label}" if chosen_music_id else ""
            log_fn(
                f"[{tag}]{step_label} Загрузка карусели из {len(cur_photos)} фото "
                f"(гео залива={target_upload_region or 'auto'}, гео телефона={target_phone_region or 'auto'}, "
                f"язык={target_locale or 'auto'}{uniq_note}{mus_note}, описание={cur_desc!r})..."
            )
            try:
                resp_body, updated_dev = client.create_photo_post(
                    proxy=proxy,
                    device=device,
                    photos=cur_photos,
                    description=cur_desc,
                    region=target_upload_region or None,
                    music_id=chosen_music_id,
                    is_private=is_private,
                    disable_comments=disable_comments,
                    is_story=is_story,
                )
            except KintaroAPIError as m_exc:
                # If a specific track was region/copyright restricted on photo mode, retry immediately with fallback track
                if chosen_music_id and not str(music_id or "").strip():
                    alt_candidates = [t for t in music_pool if t["id"] != chosen_music_id and t["id"] not in used_music_ids]
                    alt_track = alt_candidates[0] if alt_candidates else {"id": "", "title": "Auto TikTok Sound", "author": ""}
                    log_fn(
                        f"[{tag}]{step_label} ⚠️ Трек {chosen_music_id} отклонён ({m_exc}) -> авто-замена на {alt_track['title']!r}..."
                    )
                    chosen_music_id = alt_track["id"]
                    chosen_music_label = (
                        f"{alt_track['title']} — {alt_track['author']} ({chosen_music_id})"
                        if chosen_music_id
                        else "Auto TikTok Sound"
                    )
                    resp_body, updated_dev = client.create_photo_post(
                        proxy=proxy,
                        device=device,
                        photos=cur_photos,
                        description=cur_desc,
                        region=target_upload_region or None,
                        music_id=chosen_music_id,
                        is_private=is_private,
                        disable_comments=disable_comments,
                        is_story=is_story,
                    )
                else:
                    raise
            if updated_dev is not None:
                device = (
                    apply_device_geo_profile(updated_dev, target_phone_region, app_locale=target_locale or None)
                    if (target_phone_region or target_locale)
                    else updated_dev
                )

            aweme = resp_body.get("aweme") if isinstance(resp_body, dict) else {}
            if not isinstance(aweme, dict):
                aweme = {}
            aweme_id = str(aweme.get("aweme_id") or "")
            aweme_region = str(aweme.get("region") or target_upload_region or "")
            uname = (aweme.get("author") or {}).get("unique_id") or sess.get("username") or ""

            share_url = (
                aweme.get("share_url")
                or (aweme.get("share_info") or {}).get("share_url")
                or (f"https://www.tiktok.com/@{uname}/photo/{aweme_id}" if uname and aweme_id else "")
            )
            clean_url = f"https://www.tiktok.com/@{uname}/photo/{aweme_id}" if uname and aweme_id else share_url

            rec = {
                "aweme_id": aweme_id,
                "region": aweme_region,
                "phone_region": target_phone_region,
                "app_locale": target_locale,
                "description": cur_desc,
                "music_id": chosen_music_id,
                "music": chosen_music_label,
                "slides_count": len(photos),
                "deleted_old_posts": deleted_before if copy_idx == 1 else 0,
                "url": clean_url,
                "share_url": share_url,
                "created_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            }
            published_records.append(rec)
            log_fn(f"[{tag}]{step_label} Фото-пост опубликован! ID={aweme_id} | Регион поста: {aweme_region} | Телефон: {target_phone_region}/{target_locale or 'default'} -> {clean_url}")

            def _upd_each(data: Dict[str, Any], _rec: Dict[str, Any] = rec, _first: bool = (copy_idx == 1)) -> None:
                if device:
                    data["device"] = device
                if target_upload_region:
                    data["upload_region"] = target_upload_region
                if target_phone_region:
                    data["phone_region"] = target_phone_region
                    data["region"] = target_phone_region
                if target_locale:
                    data["app_locale"] = target_locale
                if proxy_override.strip():
                    data["proxy"] = proxy
                posts = [] if (delete_old_posts and _first) else (data.get("posts") or [])
                posts.insert(0, _rec)
                data["posts"] = posts

            store.update_session_data(session_filename, _upd_each)

            if copy_idx < copies:
                need_restart = restart_n > 0 and (copy_idx % restart_n == 0)
                hook_elapsed = 0.0
                if inter_post_hook is not None:
                    t_hook0 = time.monotonic()
                    try:
                        cur_ids = [str(r.get("aweme_id")) for r in published_records if r.get("aweme_id")]
                        inter_post_hook(copy_idx, cur_ids)
                    except Exception as hk_exc:
                        log_fn(f"[{tag}] ⚠️ Предупреждение промежуточной проверки огранов: {hk_exc}")
                    hook_elapsed = time.monotonic() - t_hook0

                if d_max > 0:
                    pause_sec = round(random.uniform(d_min, d_max), 1)
                    rem_pause = max(0.0, round(pause_sec - hook_elapsed, 1))
                    range_lbl = f"{int(d_min)}–{int(d_max)}" if d_min != d_max else f"{int(d_min)}"
                    if rem_pause > 0.2:
                        log_fn(
                            f"[{tag}] ⏱ Ожидание {rem_pause} сек (настройка {range_lbl} сек) "
                            f"{'перед перезапуском TikTok и постом ' if need_restart else 'перед публикацией поста '}"
                            f"{copy_idx + 1}/{copies}..."
                        )
                        time.sleep(rem_pause)

                if need_restart:
                    device = _restart_tiktok_app_on_client(
                        client=client,
                        proxy=proxy,
                        device=device,
                        target_region=target_phone_region,
                        app_locale=target_locale,
                        tag=tag,
                        log_fn=log_fn,
                    )
                    store.update_session_data(
                        session_filename,
                        lambda d, _dv=device: d.__setitem__("device", _dv) if _dv else None,
                    )

    summary = dict(published_records[-1])
    summary["all_posts"] = published_records
    summary["copies_published"] = len(published_records)
    return summary


def load_saved_config() -> Dict[str, Any]:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "api_key": "",
        "base_url": DEFAULT_BASE_URL,
        "default_region": "DE",
        "login_mode": "username_totp",
        "threads": 3,
        "pre_register_device": True,
        "update_hosts_after_register": False,
        "reuse_existing_device": True,
        "check_self_after_login": True,
        "token_beat_after_login": False,
        "same_password_fallback": True,
        "custom_imap_host": "",
        "imap_timeout_sec": 90,
    }


def save_config(cfg: Dict[str, Any]) -> None:
    current = load_saved_config()
    current.update(cfg)
    CONFIG_FILE.write_text(json.dumps(current, indent=2, ensure_ascii=False), encoding="utf-8")
