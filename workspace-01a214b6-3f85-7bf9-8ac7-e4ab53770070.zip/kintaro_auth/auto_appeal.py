"""
Auto Appeal & Restriction Scanner Engine for Kintaro Studio
Ported & adapted from `overloooooord/kintaro-auto` (`src/kintaro_auto/appeals.py`):
  1) Pure-HTTP Mobile IDC & TikTok Studio Restriction Audit ($0 Kintaro API cost):
     - Queries `/tiktokstudio/api/web/user` (`uid`, `RegistrationCountry`, `CurrentRegion`)
     - Resolves regional Mobile IDC gateway (`no1a`, `useast1a`, `useast2a`, `useast5`, `alisg`)
     - Scans `/aweme/v1/notice/count/` + `/aweme/v1/notice/multi/` (`group=47/661/...`)
       + `/api/violation/v1/get_violation_detail` (`Status`, `CanAppeal`, `AppealId`, `ViolationReasons`)
     - Scans TikTok Studio `/tiktok/creator/manage/item_list/v1/` + `/mod/v1/getPenaltyDetails/`
       + `/api/moderation/penalties/gettransparencypagecontent`
  2) 3-Channel Cascading Unbanner (`remove_account_restrictions`):
     - Account/Inbox Notices (`2048 Account FYP Restriction`, `2004 AccountOriginal`, `1039 PhotoNotRecommend`, etc.):
       Channel 1: Pure-HTTP `POST {idc_gw}/api/violation/v1/commit_appeal`
       Channel 2: Pure-HTTP `POST {idc_gw}/aweme/v2/appeal/commit/`
       Channel 3: Lazy Headless Chromium `BytedanceWebview` (`webmssdk`) UI + `/tns-api/appeal/post-commit`
     - TikTok Studio Post FYP Restrictions (`UNORIGINAL_NR`, `UNORIGINAL`, `SPAM`, `COMMUNITY_GUIDELINES`, etc.):
       Channel 1A: Pure-HTTP `POST /api/moderation/penalties/submitappeal` (`aid=1988`)
       Channel 1B: Pure-HTTP `POST /mod/v1/submitAppeals` (`aid=1988`)
       Channel 2:  Lazy Headless Chromium TikTok Studio (`/tiktokstudio/analytics/{item_id}`) `webmssdk` fallback
     - Optional `hide_rejected`: switches `FAILED` (`appeal_status == 5`) posts to Private (`visibility_type=2`)
       via `POST /tiktokstudio/api/web/item/visibility` to prevent 30-day `punish_type=2048` account FYP bans.
  3) Loop-Until-Clean (`ensure_session_clean_loop`) & Standalone / Watchdog Manager (`AutoAppealManager`):
     - Standalone Audit, Standalone Unban (loop until 0 appealable restrictions remain), Continuous Watchdog,
       and Mass Upload Pre-Upload + Post-Upload Auto Appeal integration.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import datetime as dt
import glob
import json
import os
import random
import sys
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, parse_qsl, urlencode, urlparse, urlsplit

BASE_DIR = Path(__file__).resolve().parent
VENDOR_DIR = BASE_DIR / "_vendor"
if VENDOR_DIR.exists() and str(VENDOR_DIR) not in sys.path:
    sys.path.insert(0, str(VENDOR_DIR))

import io
import shutil
import zipfile
import httpx

from auth_worker import (
    OUTPUT_DIR,
    LoginOptions,
    SessionStore,
    parse_account_line,
    process_single_account,
    safe_filename,
)
from kintaro_client import KintaroClient, allocate_sticky_proxy
from photo_uniquifier import expand_spintax
from studio_tools import _resolve_session_proxy

try:
    import socksio as _socksio_mod  # noqa: F401
    HAS_SOCKSIO = True
except Exception:
    HAS_SOCKSIO = False


AUTO_APPEAL_REPORT_FILE = OUTPUT_DIR / "auto_appeal_report.json"
SORTED_ACCOUNTS_DIR = BASE_DIR / "sorted_accounts"

APPEAL_FOLDER_SPECS: Dict[str, Dict[str, str]] = {
    "clean": {
        "key": "clean",
        "dir_name": "clean",
        "txt_name": "чистые_без_ограна.txt",
        "title": "✅ Без ограна / Снят",
        "subtitle": "Чистые аккаунты и одобренные апелляции (0 огранов)",
    },
    "ogran_na_proverke": {
        "key": "ogran_na_proverke",
        "dir_name": "ogran_na_proverke",
        "txt_name": "огран_на_проверке.txt",
        "title": "⏳ Огран / На проверке",
        "subtitle": "Снять сразу не вышло — апелляция висит на проверке TikTok",
    },
    "ogran_ne_snyat": {
        "key": "ogran_ne_snyat",
        "dir_name": "ogran_ne_snyat",
        "txt_name": "огран_не_снят.txt",
        "title": "🚨 Огран / Не снят",
        "subtitle": "Остались активные ограничения или апелляция отклонена (FAILED)",
    },
    "errors": {
        "key": "errors",
        "dir_name": "errors",
        "txt_name": "ошибки_входа.txt",
        "title": "❌ Ошибки входа / Сессии",
        "subtitle": "Не удалось войти или сессия недействительна",
    },
}

_FOLDER_SORT_LOCK = threading.Lock()

DEFAULT_APPEAL_TEXT = (
    "{Our content is original, authentic, and strictly follows all TikTok Community Guidelines.|"
    "Original content created and edited exclusively by our team in full compliance with TikTok rules.|"
    "All slides and edits in this post are original creative work made specifically for our TikTok audience.}"
)

# ── Regional Mobile IDC Gateways & Moderation Enums ──────────────────────────

IDC_GATEWAY_MAP: Dict[str, str] = {
    "no1a": "https://api16-normal-no1a.tiktokv.eu",
    "useast2b": "https://api16-normal-no1a.tiktokv.eu",
    "us-eastred": "https://api16-normal-no1a.tiktokv.eu",
    "useastred": "https://api16-normal-no1a.tiktokv.eu",
    "euttp": "https://api16-normal-no1a.tiktokv.eu",
    "useast1a": "https://api16-normal-c-useast1a.tiktokv.com",
    "useast2a": "https://api16-normal-c-useast2a.tiktokv.com",
    "useast5": "https://api16-normal-us.tiktokv.us",
    "useast8": "https://api16-normal-us.tiktokv.us",
    "maliva": "https://api16-normal-c-useast1a.tiktokv.com",
    "alisg": "https://api16-normal-c-alisg.tiktokv.com",
    "sg1": "https://api16-normal-c-alisg.tiktokv.com",
}

FALLBACK_GATEWAYS = (
    "https://api16-normal-no1a.tiktokv.eu",
    "https://api16-normal-c-useast1a.tiktokv.com",
    "https://api16-normal-c-useast2a.tiktokv.com",
    "https://api16-normal-c-alisg.tiktokv.com",
)

WWW_BASE = "https://www.tiktok.com"

CORE_SYSTEM_NOTICE_GROUPS = (47, 46, 84, 210, 214, 69, 13, 226, 227, 228, 229, 661, 702)

VIOLATION_V1_STATUS: Dict[int, str] = {
    1: "Effecting (Активный огран — можно подать апелляцию)",
    2: "ViolationExpired (Истёк)",
    3: "ViolationRecovered (Снят)",
    4: "Appealing (На рассмотрении TikTok)",
    5: "AppealExpired (Срок истёк)",
    6: "AppealSuccess (Апелляция одобрена — снят)",
    7: "AppealFailed (Отклонена)",
    8: "AppealInterrupted",
}

STUDIO_APPEAL_STATUS: Dict[int, str] = {
    0: "CAN_SUBMIT",
    1: "CANNOT_SUBMIT",
    2: "NO_PENALTY",
    3: "REVIEWING",
    4: "SUCCEEDED",
    5: "FAILED",
    6: "TIMEOUT",
}

STUDIO_REASON_CODES: Dict[int, str] = {
    0: "OTHER",
    1: "COMMUNITY_GUIDELINES",
    2: "TOBACCO",
    3: "VIOLENT",
    4: "DANGEROUS",
    5: "OVERLY_SEXUALIZED",
    6: "SPAM",
    7: "UNORIGINAL",
    8: "MINOR_SAFETY",
    9: "UNORIGINAL_NR",
    10: "REPRODUCED_ACCOUNT",
    11: "CLICKBAIT_NFF",
}

PUNISH_TYPE_NAMES: Dict[int, str] = {
    1030: "VideoNotRecommend (Видео не в реках)",
    1039: "PhotoNotRecommend (Фото/карусель не в реках)",
    1052: "VideoUMNotRecommend (Неоригинальный контент)",
    2004: "AccountOriginal (Огран оригинальности аккаунта)",
    2048: "AccountIneligibleForRecommendation (Бан реков на аккаунте)",
}

APPEAL_STAGGER_SECONDS: Tuple[float, float] = (0.45, 0.95)

MOBILE_BASE_PARAMS: Dict[str, str] = {
    "aid": "1233",
    "app_name": "musical_ly",
    "version_code": "37.1.0",
    "build_number": "371014",
    "device_platform": "iphone",
    "os_version": "17.5.1",
    "app_language": "en",
    "language": "en",
}

CHROME_CANDIDATES = (
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
)

ANDROID_WEBVIEW_UA = (
    "Mozilla/5.0 (Linux; Android 16; SM-A546E Build/BP2A.250605.031.A3; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/131.0.0.0 Mobile Safari/537.36 "
    "musical_ly_2024102030 JsSdk/1.0 NetType/WIFI Channel/googleplay AppName/musical_ly "
    "app_version/41.2.3 ByteLocale/en ByteFullLocale/en_US Region/US AppId/1233 "
    "Spark/1.5.9.1-bugfix BytedanceWebview/d8a21c6"
)

DESKTOP_CHROME_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)


# ── Data Models ──────────────────────────────────────────────────────────────

@dataclass
class NoticeViolation:
    nid: str
    group: int
    create_time: int
    title: str
    content: str
    object_id: str
    object_type: str
    punish_id: str
    punish_type: int
    punish_type_name: str = ""
    schema_url: str = ""
    web_schema_url: str = ""
    can_appeal: bool = False
    status_code: int = 0
    status_label: str = "Unknown"
    appeal_id: str = ""
    punish_source: str = ""
    punish_end_time: int = 0
    reason_title: str = ""


@dataclass
class PostPenalty:
    item_id: str
    create_time: int
    desc: str
    play_count: int
    appeal_status: int = 2
    appeal_status_label: str = "NO_PENALTY"
    penalties: List[Dict[str, Any]] = field(default_factory=list)
    reason_labels: List[str] = field(default_factory=list)
    v2_can_appeal: bool = False
    v2_appeal_details: Any = None


@dataclass
class AccountAuditResult:
    account_id: str
    username: str
    uid: str = ""
    reg_country: str = ""
    current_region: str = ""
    idc_gateway: str = ""
    region_warning_present: bool = False
    recent_device_logins: List[str] = field(default_factory=list)
    notice_violations: List[NoticeViolation] = field(default_factory=list)
    post_penalties: List[PostPenalty] = field(default_factory=list)
    total_posts: int = 0


@dataclass
class RestrictionActionReport:
    account_id: str
    scope: str  # "account_or_inbox" | "post_studio" | "post_cleanup"
    target_id: str
    punish_key: str
    title: str
    previous_state: str
    action_taken: str
    appealed_now: bool
    detail: str = ""


@dataclass
class AccountAppealSummary:
    account_id: str
    items: List[RestrictionActionReport] = field(default_factory=list)
    audit: Optional[AccountAuditResult] = None
    notice_appeals_verified: int = 0
    post_appeals_verified: int = 0
    posts_hidden: int = 0


# ── Proxy & Cookie Helpers ───────────────────────────────────────────────────

def _resolve_httpx_proxy(raw_proxy: str) -> Optional[str]:
    px = (raw_proxy or "").strip()
    if not px:
        return None
    if px.lower().startswith("socks") and not HAS_SOCKSIO:
        parsed = urlparse(px)
        host = parsed.hostname or ""
        port = parsed.port or 1002
        if "bpproxy." in host.lower() and port == 1002:
            return "http://" + px.split("://", 1)[1].replace(":1002", ":1000")
    return px


def _resolve_playwright_http_proxy(raw_proxy: str) -> Dict[str, str]:
    parsed = urlparse(raw_proxy)
    host = parsed.hostname or ""
    port = parsed.port or 80
    scheme = (parsed.scheme or "http").lower()

    if scheme.startswith("socks") and "bpproxy." in host.lower() and port == 1002:
        scheme = "http"
        port = 1000
    elif scheme.startswith("socks"):
        raise RuntimeError(
            f"Для браузерного фоллбэка через Chromium нужен HTTP-порт прокси (получен {raw_proxy}). "
            "На bpproxy это порт 1000 (переключается автоматически)."
        )

    cfg: Dict[str, str] = {"server": f"{scheme}://{host}:{port}"}
    if parsed.username:
        cfg["username"] = parsed.username
    if parsed.password:
        cfg["password"] = parsed.password
    return cfg


def extract_cookie_dict_from_device(device: Any, account_label: str = "account") -> Dict[str, str]:
    if not device:
        raise RuntimeError(f"[{account_label}] Нет `device` / `x-device` в файле сессии.")
    dev = json.loads(device) if isinstance(device, str) else device
    cookies_map = dev.get("cookies") if isinstance(dev, dict) else None
    if not isinstance(cookies_map, dict):
        cookies_map = {}
    out = {str(k): str(v) for k, v in cookies_map.items() if v is not None and str(v) != ""}
    if not (out.get("sessionid") or out.get("sid_tt")):
        raise RuntimeError(
            f"[{account_label}] В `device.cookies` отсутствует `sessionid`/`sid_tt` — сессия не авторизована."
        )
    return out


def _extract_cookies_for_browser(device: Any, account_label: str = "account") -> List[Dict[str, str]]:
    cookies_map = extract_cookie_dict_from_device(device, account_label)
    out: List[Dict[str, str]] = []
    for name, val in cookies_map.items():
        for dom in (".tiktok.com", ".tiktokv.com", ".tiktokv.eu", ".tiktokw.eu"):
            out.append({"name": name, "value": val, "domain": dom, "path": "/"})
    return out


def build_tns_appeal_reason_json(
    *,
    appeal_reasons_options: Optional[List[Dict[str, Any]]],
    description_text: str,
) -> str:
    clean_desc = (description_text or "").strip()
    if appeal_reasons_options:
        first_opt = appeal_reasons_options[0]
        opt_val = (
            first_opt.get("id")
            or first_opt.get("code")
            or first_opt.get("reason_id")
            or first_opt.get("value")
        )
        if opt_val is not None:
            return json.dumps(
                {"type": 2, "options": [opt_val], "description": clean_desc},
                separators=(",", ":"),
                ensure_ascii=False,
            )
    if clean_desc:
        return json.dumps(
            {"file_uri": "", "description": clean_desc},
            separators=(",", ":"),
            ensure_ascii=False,
        )
    return ""


def _extract_query_from_schema(schema_url: str) -> Tuple[str, Dict[str, str]]:
    if not schema_url:
        return "", {}
    raw = schema_url.strip()
    if raw.startswith(("aweme://", "sslocal://")):
        outer_q = dict(parse_qsl(urlsplit(raw).query))
        inner = outer_q.get("url", "")
        if inner:
            return inner, dict(parse_qsl(urlsplit(inner).query))
        return raw, outer_q
    return raw, dict(parse_qsl(urlsplit(raw).query))


def _find_chrome_executable(explicit: Optional[str] = None) -> Optional[str]:
    if explicit and os.path.isfile(explicit):
        return explicit
    for cand in CHROME_CANDIDATES:
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    pw_chromes = sorted(
        glob.glob(os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux*/chrome"))
        + glob.glob(os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-mac*/Chromium.app/Contents/MacOS/Chromium"))
    )
    if pw_chromes:
        return pw_chromes[-1]
    return None


# ── 1. Pure-HTTP Mobile IDC & TikTok Studio Restriction Audit ────────────────

async def _resolve_idc_gateway(cookies: Dict[str, str], http: httpx.AsyncClient) -> str:
    for key in ("store-idc", "tt-target-idc"):
        val = (cookies.get(key) or "").lower().strip()
        if val in IDC_GATEWAY_MAP:
            return IDC_GATEWAY_MAP[val]

    async def _probe(gw: str) -> Optional[str]:
        try:
            r = await http.get(
                f"{gw}/aweme/v1/notice/count/",
                params={**MOBILE_BASE_PARAMS, "source": "1"},
                timeout=6.0,
            )
            if r.status_code == 200 and r.json().get("groups_in_filters") is not None:
                return gw
        except Exception:
            pass
        return None

    probed = await asyncio.gather(*(_probe(gw) for gw in FALLBACK_GATEWAYS))
    for p_gw in probed:
        if p_gw:
            return p_gw
    return FALLBACK_GATEWAYS[0]


async def _enrich_violation_detail(
    http: httpx.AsyncClient, idc_gateway: str, vio: NoticeViolation, uid: str
) -> None:
    params = {
        **MOBILE_BASE_PARAMS,
        "ViolationId": vio.punish_id,
        "UserId": uid,
        "ObjectId": vio.object_id,
        "ViolationType": str(vio.punish_type),
        "enter_from": "1",
    }
    try:
        resp = await http.get(f"{idc_gateway}/api/violation/v1/get_violation_detail", params=params)
        if resp.status_code != 200:
            return
        data = resp.json()
        if (data.get("BaseResp") or {}).get("StatusCode", -1) != 0:
            return
        vio.can_appeal = bool(data.get("CanAppeal", False))
        vinfo = data.get("ViolationInfo") or {}
        status_int = int(vinfo.get("Status") or 0)
        vio.status_code = status_int
        vio.status_label = VIOLATION_V1_STATUS.get(status_int, f"Status({status_int})")
        vio.appeal_id = str(vinfo.get("AppealId") or "")
        vio.punish_source = str(vinfo.get("PunishFromSource") or "")
        vio.punish_end_time = int(vinfo.get("PunishEndTime") or 0)
        reasons = data.get("ViolationReasons") or []
        if reasons and isinstance(reasons[0], dict):
            vio.reason_title = str(reasons[0].get("Title") or "")
    except Exception:
        pass


async def _check_single_post_penalty_http(http: httpx.AsyncClient, pp: PostPenalty) -> None:
    async def _req_v1() -> None:
        try:
            r1 = await http.get(
                f"{WWW_BASE}/mod/v1/getPenaltyDetails/",
                params={"aid": "1988", "app_name": "tiktok_creator_center", "vid": pp.item_id},
            )
            if r1.status_code == 200:
                d1 = r1.json()
                st = int(d1.get("appeal_status", 2))
                pp.appeal_status = st
                pp.appeal_status_label = STUDIO_APPEAL_STATUS.get(st, f"UNKNOWN({st})")
                pp.penalties = d1.get("penalties") or []
                codes: List[str] = []
                for pen in pp.penalties:
                    for rc in pen.get("reason_codes") or []:
                        codes.append(STUDIO_REASON_CODES.get(int(rc), f"CODE_{rc}"))
                pp.reason_labels = codes
        except Exception:
            pass

    async def _req_v2() -> None:
        try:
            r2 = await http.get(
                f"{WWW_BASE}/api/moderation/penalties/gettransparencypagecontent",
                params={"aid": "1988", "entityId": pp.item_id, "enterFrom": ""},
            )
            if r2.status_code == 200:
                d2 = r2.json()
                if d2.get("showAppealBtn"):
                    pp.v2_can_appeal = True
                    pp.v2_appeal_details = d2.get("appealDetails")
                else:
                    pp.v2_can_appeal = False
        except Exception:
            pass

    await asyncio.gather(_req_v1(), _req_v2())


def _is_account_ineligible_notice(vio: NoticeViolation) -> bool:
    """
    Returns True ONLY for the account-level recommendation ban:
      `Account ineligible for recommendation` (`punish_type == 2048`)
      and its restored confirmation (`Account eligible for recommendation`, `status=6`).
    Ignores individual post-level notices (`1030`, `1039`, `1052`) and `2004`.
    """
    if vio.punish_type == 2048:
        return True
    low_t = (vio.title or "").lower()
    if "account ineligible for recommendation" in low_t or "account eligible for recommendation" in low_t:
        return True
    if vio.object_type == "4" and "ineligible for recommendation" in f"{low_t} {(vio.content or '').lower()}":
        return True
    return False


async def _audit_with_client(
    *,
    http: httpx.AsyncClient,
    cookies: Dict[str, str],
    account_id: str,
    username: str,
    extra_post_ids: Optional[List[str]] = None,
    max_posts: int = 50,
    cached_meta: Optional[Dict[str, str]] = None,
    only_account_ineligible: bool = True,
) -> AccountAuditResult:
    meta = cached_meta if isinstance(cached_meta, dict) else {}
    uid = str(meta.get("uid") or cookies.get("uid_tt") or cookies.get("uid_tt_ss") or "")
    reg_country = str(meta.get("reg_country") or cookies.get("store-country-code-src") or "")
    current_region = str(meta.get("current_region") or cookies.get("store-country-code") or "")
    detected_uname = str(meta.get("username") or username or account_id)
    idc_gw = str(meta.get("idc_gateway") or "")
    if not idc_gw:
        for ck_k in ("store-idc", "tt-target-idc"):
            ck_v = (cookies.get(ck_k) or "").lower().strip()
            if ck_v in IDC_GATEWAY_MAP:
                idc_gw = IDC_GATEWAY_MAP[ck_v]
                break

    async def _fetch_user() -> None:
        nonlocal uid, reg_country, current_region, detected_uname
        try:
            r_user = await http.get(
                f"{WWW_BASE}/tiktokstudio/api/web/user",
                params={"needIsVerified": "true", "needProfileBio": "true"},
            )
            if r_user.status_code == 200:
                u_data = r_user.json()
                uid = str(u_data.get("userId") or uid or "")
                if u_data.get("uniqueId"):
                    detected_uname = str(u_data["uniqueId"])
                reg_info = (
                    (u_data.get("userBaseInfo") or {})
                    .get("UserProfile", {})
                    .get("UserBase", {})
                    .get("Region", {})
                )
                reg_country = str(reg_info.get("RegistrationCountry") or reg_country or "")
                current_region = str(reg_info.get("Region") or current_region or "")
        except Exception:
            pass

    async def _fetch_idc() -> None:
        nonlocal idc_gw
        idc_gw = await _resolve_idc_gateway(cookies, http)

    init_tasks = []
    if not uid:
        init_tasks.append(_fetch_user())
    if not idc_gw:
        init_tasks.append(_fetch_idc())
    if init_tasks:
        await asyncio.gather(*init_tasks)
    if cached_meta is not None:
        cached_meta["uid"] = uid
        cached_meta["reg_country"] = reg_country
        cached_meta["current_region"] = current_region
        cached_meta["username"] = detected_uname
        cached_meta["idc_gateway"] = idc_gw

    audit = AccountAuditResult(
        account_id=account_id,
        username=detected_uname,
        uid=uid,
        reg_country=reg_country,
        current_region=current_region,
        idc_gateway=idc_gw,
        total_posts=len(extra_post_ids or []),
    )

    async def _scan_notices_branch() -> None:
        groups: set[int] = set(CORE_SYSTEM_NOTICE_GROUPS)
        # In `only_account_ineligible` mode, `CORE_SYSTEM_NOTICE_GROUPS` (incl. 47) fits in 1 single batch!
        if not only_account_ineligible:
            cached_groups_str = meta.get("notice_groups")
            if cached_groups_str:
                for g_tok in cached_groups_str.split(","):
                    if g_tok.strip().isdigit():
                        groups.add(int(g_tok.strip()))
            else:
                try:
                    r_cnt = await http.get(
                        f"{idc_gw}/aweme/v1/notice/count/",
                        params={**MOBILE_BASE_PARAMS, "source": "1"},
                    )
                    if r_cnt.status_code == 200:
                        for flt in r_cnt.json().get("groups_in_filters") or []:
                            if flt.get("filter_type") in (33, 41, 6, 14):
                                for g in flt.get("groups") or []:
                                    groups.add(int(g))
                        if cached_meta is not None:
                            cached_meta["notice_groups"] = ",".join(str(x) for x in sorted(groups))
                except Exception:
                    pass

        raw_notices: List[Tuple[int, Dict[str, Any]]] = []
        sorted_groups = sorted(groups)
        chunks = [sorted_groups[i : i + 20] for i in range(0, len(sorted_groups), 20)]

        async def _fetch_notice_chunk(ch: List[int]) -> List[Tuple[int, Dict[str, Any]]]:
            out_pairs: List[Tuple[int, Dict[str, Any]]] = []
            group_list = json.dumps(
                [{"count": 50, "group": g, "is_mark_read": 0, "max_time": 0, "min_time": 0} for g in ch],
                separators=(",", ":"),
            )
            try:
                r_multi = await http.get(
                    f"{idc_gw}/aweme/v1/notice/multi/",
                    params={**MOBILE_BASE_PARAMS, "group_list": group_list},
                )
                if r_multi.status_code == 200:
                    for nl in r_multi.json().get("notice_lists") or []:
                        g_id = int(nl.get("group") or 0)
                        for item in nl.get("notice_list") or []:
                            if isinstance(item, dict):
                                out_pairs.append((g_id, item))
            except Exception:
                pass
            return out_pairs

        chunk_lists = await asyncio.gather(*(_fetch_notice_chunk(ch) for ch in chunks))
        for cl in chunk_lists:
            raw_notices.extend(cl)

        raw_notices.sort(
            key=lambda pair: (
                int(
                    pair[1].get("create_time")
                    or (pair[1].get("template_notice") or {}).get("create_time")
                    or 0
                ),
                str(pair[1].get("nid_str") or pair[1].get("nid") or ""),
            ),
            reverse=True,
        )

        seen_punish_ids: set[str] = set()
        candidate_vios: List[Tuple[str, NoticeViolation]] = []

        for g_id, item in raw_notices:
            nid = str(item.get("nid_str") or item.get("nid") or "")
            ctime = int(
                item.get("create_time")
                or (item.get("template_notice") or {}).get("create_time")
                or 0
            )
            tn = item.get("template_notice") or {}
            txt = item.get("text") or {}
            ann = item.get("announcement") or {}
            notice_body = tn.get("notice") or {}

            title = str(
                (notice_body.get("title") or {}).get("title")
                or txt.get("title")
                or ann.get("title")
                or ""
            )
            content = str(
                notice_body.get("content")
                or txt.get("content")
                or ann.get("content")
                or ""
            )

            low_title = title.lower()
            if "update your account region" in low_title:
                audit.region_warning_present = True
            if "logged in from a new device" in low_title and content:
                if content not in audit.recent_device_logins and len(audit.recent_device_logins) < 5:
                    audit.recent_device_logins.append(content)

            raw_schema = str(
                tn.get("schema_url")
                or notice_body.get("right_schema_url")
                or txt.get("schema_url")
                or ann.get("schema_url")
                or ""
            )
            web_schema = ""
            msg_extra_raw = tn.get("message_extra") or ""
            if msg_extra_raw:
                try:
                    me = json.loads(msg_extra_raw)
                    be_raw = me.get("business_extra") or ""
                    if be_raw:
                        be = json.loads(be_raw) if isinstance(be_raw, str) else be_raw
                        web_schema = str(be.get("web_schema_url") or "")
                except Exception:
                    pass

            falcon_url, q_falcon = _extract_query_from_schema(raw_schema)
            _, q_web = _extract_query_from_schema(web_schema)
            merged_q = {**q_web, **q_falcon}

            punish_id = merged_q.get("punish_id") or merged_q.get("punish_key") or ""
            object_id = merged_q.get("object_id") or ""
            punish_type_str = merged_q.get("punish_type") or "0"
            object_type = merged_q.get("object_type") or ""

            if not punish_id or not object_id:
                continue
            if punish_id in seen_punish_ids:
                continue
            seen_punish_ids.add(punish_id)

            effective_obj_type = object_type or ("4" if object_id == uid else "1")
            try:
                punish_type = int(punish_type_str)
            except ValueError:
                punish_type = 0

            vio = NoticeViolation(
                nid=nid,
                group=g_id,
                create_time=ctime,
                title=title or "Moderation Notice",
                content=content,
                object_id=object_id,
                object_type=effective_obj_type,
                punish_id=punish_id,
                punish_type=punish_type,
                punish_type_name=PUNISH_TYPE_NAMES.get(punish_type, f"Type({punish_type})"),
                schema_url=falcon_url or raw_schema,
                web_schema_url=web_schema,
            )
            if only_account_ineligible and not _is_account_ineligible_notice(vio):
                continue

            obj_dedup = f"2048:{object_id}" if _is_account_ineligible_notice(vio) else f"{effective_obj_type}:{object_id}"
            candidate_vios.append((obj_dedup, vio))

        if candidate_vios:
            vio_sem = asyncio.Semaphore(8)

            async def _enrich_one(v_obj: NoticeViolation) -> None:
                async with vio_sem:
                    await _enrich_violation_detail(http, idc_gw, v_obj, uid)

            await asyncio.gather(*(_enrich_one(v_obj) for _, v_obj in candidate_vios))

        seen_objects: set[str] = set()
        newest_restored_2048_ts = max(
            (
                v.create_time
                for _, v in candidate_vios
                if _is_account_ineligible_notice(v)
                and (v.status_code in (2, 3, 6) or "account eligible for recommendation" in (v.title or "").lower())
            ),
            default=0,
        )
        for obj_dedup, vio in candidate_vios:
            is_active_appealable = vio.can_appeal or vio.status_code == 1
            # If a newer "Account eligible for recommendation" (status=6) already restored the account,
            # ignore older historical 2048 notices created strictly before that restoration unless CanAppeal=True.
            if (
                _is_account_ineligible_notice(vio)
                and newest_restored_2048_ts > 0
                and vio.create_time < newest_restored_2048_ts
                and not vio.can_appeal
            ):
                continue
            if not is_active_appealable:
                if obj_dedup in seen_objects:
                    continue
                seen_objects.add(obj_dedup)
            else:
                seen_objects.add(obj_dedup)
            audit.notice_violations.append(vio)

    async def _scan_posts_branch() -> None:
        post_map: Dict[str, PostPenalty] = {}
        try:
            r_items = await http.post(
                f"{WWW_BASE}/tiktok/creator/manage/item_list/v1/",
                params={"aid": "1988", "app_name": "tiktok_creator_center", "device_platform": "web_pc"},
                json={
                    "cursor": 0,
                    "size": max_posts,
                    "query": {
                        "sort_orders": [{"field_name": "post_time", "order": 2}],
                        "conditions": [],
                        "is_recent_posts": False,
                    },
                },
            )
            if r_items.status_code == 200:
                for it in r_items.json().get("item_list") or []:
                    vid = str(it.get("item_id") or "")
                    if vid:
                        post_map[vid] = PostPenalty(
                            item_id=vid,
                            create_time=int(it.get("create_time") or 0),
                            desc=str(it.get("desc") or ""),
                            play_count=int(it.get("play_count") or 0),
                        )
        except Exception:
            pass

        for extra_vid in extra_post_ids or []:
            sv = str(extra_vid or "").strip()
            if sv and sv not in post_map:
                post_map[sv] = PostPenalty(item_id=sv, create_time=0, desc="", play_count=0)

        audit.total_posts = len(post_map)
        sem = asyncio.Semaphore(8)

        async def _check_one(p_obj: PostPenalty) -> None:
            async with sem:
                await _check_single_post_penalty_http(http, p_obj)

        if post_map:
            await asyncio.gather(*(_check_one(pp) for pp in post_map.values()))
        audit.post_penalties = list(post_map.values())

    if only_account_ineligible:
        await _scan_notices_branch()
    else:
        await asyncio.gather(_scan_notices_branch(), _scan_posts_branch())
    return audit


async def audit_account_restrictions(
    *,
    account_id: str,
    username: str,
    device: Any,
    proxy: str,
    extra_post_ids: Optional[List[str]] = None,
    max_posts: int = 50,
    shared_http: Optional[httpx.AsyncClient] = None,
    cached_meta: Optional[Dict[str, str]] = None,
    only_account_ineligible: bool = True,
) -> AccountAuditResult:
    cookies = extract_cookie_dict_from_device(device, account_id)
    if shared_http is not None:
        return await _audit_with_client(
            http=shared_http,
            cookies=cookies,
            account_id=account_id,
            username=username,
            extra_post_ids=extra_post_ids,
            max_posts=max_posts,
            cached_meta=cached_meta,
            only_account_ineligible=only_account_ineligible,
        )

    headers = {
        "user-agent": DESKTOP_CHROME_UA,
        "accept": "application/json, text/plain, */*",
    }
    httpx_proxy = _resolve_httpx_proxy(proxy)
    async with httpx.AsyncClient(
        proxy=httpx_proxy,
        cookies=cookies,
        headers=headers,
        timeout=20.0,
        follow_redirects=True,
    ) as http:
        return await _audit_with_client(
            http=http,
            cookies=cookies,
            account_id=account_id,
            username=username,
            extra_post_ids=extra_post_ids,
            max_posts=max_posts,
            cached_meta=cached_meta,
            only_account_ineligible=only_account_ineligible,
        )


# ── 2. Lazy Headless Chromium `webmssdk` Fallbacks ───────────────────────────

async def _attach_fast_cdn_router(page: Any, direct_http: httpx.AsyncClient) -> None:
    async def _route_handler(route: Any) -> None:
        req = route.request
        u = req.url
        if req.resource_type in ("image", "media", "font"):
            await route.abort()
            return
        if any(
            cdn in u
            for cdn in ("ttwstatic.com", "tiktokcdn.com", "tiktokcdn-eu.com", "ibytedtos.com")
        ):
            try:
                r = await direct_http.get(u)
                await route.fulfill(status=r.status_code, headers=dict(r.headers), body=r.content)
                return
            except Exception:
                pass
        await route.continue_()

    await page.route("**/*", _route_handler)


async def _submit_notice_via_browser_webview(
    *,
    account_id: str,
    device: Any,
    proxy: str,
    vio: NoticeViolation,
    reason_options: Optional[List[Dict[str, Any]]],
    appeal_text: str,
    chrome_executable: Optional[str] = None,
) -> Tuple[bool, str]:
    try:
        from playwright.async_api import async_playwright
    except Exception as exc:
        return False, f"playwright_unavailable({exc})"

    exe = _find_chrome_executable(chrome_executable)
    pw_proxy = _resolve_playwright_http_proxy(proxy)
    pw_cookies = _extract_cookies_for_browser(device, account_id)

    target_url = vio.web_schema_url or vio.schema_url
    if not target_url or not target_url.startswith("http"):
        target_url = (
            f"{WWW_BASE}/violation-appeal?enter_from=1&hide_nav_bar=1&is_new_vio_platform=1"
            f"&object_id={vio.object_id}&object_type={vio.object_type}"
            f"&punish_key={vio.punish_id}&punish_type={vio.punish_type}"
        )

    launch_kwargs: Dict[str, Any] = {
        "headless": True,
        "proxy": pw_proxy,
        "args": ["--disable-blink-features=AutomationControlled", "--no-sandbox"],
    }
    if exe:
        launch_kwargs["executable_path"] = exe

    async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as direct_http:
        async with async_playwright() as p:
            browser = await p.chromium.launch(**launch_kwargs)
            try:
                ctx_webview = await browser.new_context(
                    viewport={"width": 430, "height": 932},
                    user_agent=ANDROID_WEBVIEW_UA,
                )
                await ctx_webview.add_cookies(pw_cookies)
                wpage = await ctx_webview.new_page()
                await _attach_fast_cdn_router(wpage, direct_http)

                detail_common_qs = (
                    "aid=1988&app_language=en&app_name=tiktok_web&channel=tiktok_web"
                    "&device_platform=web_mobile&os=android"
                )
                ui_commit_resp: Optional[Dict[str, Any]] = None

                async def _capture(resp: Any) -> None:
                    nonlocal detail_common_qs, ui_commit_resp
                    if "/tns-api/appeal/violation-detail" in resp.url:
                        try:
                            raw_qs = parse_qs(urlparse(resp.url).query, keep_blank_values=True)
                            filtered = {
                                k: v[0]
                                for k, v in raw_qs.items()
                                if k not in ("object_id", "object_type", "punish_key", "msToken", "X-Bogus", "X-Gnarly")
                            }
                            if filtered:
                                detail_common_qs = urlencode(filtered)
                        except Exception:
                            pass
                    elif "/tns-api/appeal/post-commit" in resp.url:
                        try:
                            ui_commit_resp = await resp.json()
                        except Exception:
                            pass

                wpage.on("response", lambda r: asyncio.create_task(_capture(r)))
                await wpage.goto(target_url, wait_until="domcontentloaded", timeout=35000)
                await wpage.wait_for_timeout(4500)

                low_txt = (await wpage.inner_text("body")).lower()
                if "appeal submitted" in low_txt or "request received" in low_txt or "appeal approved" in low_txt:
                    return True, "already_submitted_or_approved"

                appeal_btn = wpage.get_by_role("button", name="Appeal")
                if await appeal_btn.count() == 0:
                    appeal_btn = wpage.get_by_text("Appeal", exact=True)
                if await appeal_btn.count() > 0 and await appeal_btn.first.is_visible():
                    await appeal_btn.first.click()
                    await wpage.wait_for_timeout(2000)

                    radios = wpage.locator('input[type="radio"], [role="radio"]')
                    if await radios.count() > 0 and await radios.first.is_visible():
                        await radios.first.click()
                        await wpage.wait_for_timeout(400)

                    ta = wpage.locator("textarea")
                    if await ta.count() > 0 and await ta.first.is_visible() and appeal_text:
                        await ta.first.fill(appeal_text)
                        await wpage.wait_for_timeout(400)

                    sub_btn = wpage.get_by_role("button", name="Submit")
                    if await sub_btn.count() == 0:
                        sub_btn = wpage.get_by_text("Submit", exact=True)
                    if await sub_btn.count() > 0 and await sub_btn.first.is_visible():
                        for _ in range(3):
                            ui_commit_resp = None
                            await sub_btn.first.click()
                            await wpage.wait_for_timeout(2500)
                            if isinstance(ui_commit_resp, dict) and ui_commit_resp.get("status_code") == 0:
                                return True, "ui_post_commit(status_code=0)"
                            after_txt = (await wpage.inner_text("body")).lower()
                            if "appeal submitted" in after_txt or "request received" in after_txt:
                                return True, "ui_submitted"

                opts = reason_options
                if not opts:
                    r_reasons = await wpage.evaluate(
                        """async ({appealType, objectId, qs}) => {
                            const r = await fetch(`/tns-api/appeal/reason?${qs}&appeal_type=${appealType}&object_id=${encodeURIComponent(objectId)}`, {credentials: 'include'});
                            return await r.json().catch(() => ({}));
                        }""",
                        {"appealType": vio.punish_type, "objectId": vio.object_id, "qs": detail_common_qs},
                    )
                    cand = (r_reasons or {}).get("appeal_reasons")
                    if isinstance(cand, list):
                        opts = cand

                reason_str = build_tns_appeal_reason_json(
                    appeal_reasons_options=opts,
                    description_text=appeal_text,
                )
                commit_payload = {
                    "object_id": vio.object_id,
                    "appeal_type": vio.punish_type,
                    "reason": reason_str,
                    "punish_key": vio.punish_id,
                    "punish_id": vio.punish_id,
                    "appeal_uri": "",
                    "extra": "",
                }
                last_resp: Any = {}
                for _ in range(3):
                    last_resp = await wpage.evaluate(
                        """async ({payload, qs}) => {
                            const r = await fetch(`/tns-api/appeal/post-commit?${qs}`, {
                                method: 'POST',
                                credentials: 'include',
                                headers: {'content-type': 'application/json'},
                                body: JSON.stringify(payload),
                            });
                            return await r.json().catch(() => ({status_code: -1}));
                        }""",
                        {"payload": commit_payload, "qs": detail_common_qs},
                    )
                    if isinstance(last_resp, dict) and last_resp.get("status_code") == 0:
                        return True, "tns_post_commit(status_code=0)"
                    await wpage.wait_for_timeout(1500)
                return False, f"tns_resp={last_resp}"
            finally:
                await browser.close()


async def _submit_post_via_browser_studio(
    *,
    account_id: str,
    device: Any,
    proxy: str,
    pp: PostPenalty,
    chrome_executable: Optional[str] = None,
) -> Tuple[bool, str]:
    try:
        from playwright.async_api import async_playwright
    except Exception as exc:
        return False, f"playwright_unavailable({exc})"

    exe = _find_chrome_executable(chrome_executable)
    pw_proxy = _resolve_playwright_http_proxy(proxy)
    pw_cookies = _extract_cookies_for_browser(device, account_id)

    launch_kwargs: Dict[str, Any] = {
        "headless": True,
        "proxy": pw_proxy,
        "args": ["--disable-blink-features=AutomationControlled", "--no-sandbox"],
    }
    if exe:
        launch_kwargs["executable_path"] = exe

    async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as direct_http:
        async with async_playwright() as p:
            browser = await p.chromium.launch(**launch_kwargs)
            try:
                ctx_desktop = await browser.new_context(
                    viewport={"width": 1440, "height": 900},
                    user_agent=DESKTOP_CHROME_UA,
                )
                await ctx_desktop.add_cookies(pw_cookies)
                page = await ctx_desktop.new_page()
                await _attach_fast_cdn_router(page, direct_http)
                await page.goto(
                    f"{WWW_BASE}/tiktokstudio/analytics/{pp.item_id}",
                    wait_until="domcontentloaded",
                    timeout=40000,
                )
                await page.wait_for_timeout(4500)

                if pp.v2_can_appeal and pp.v2_appeal_details is not None:
                    res_v2 = await page.evaluate(
                        """async ({appealDetails, itemId}) => {
                            const r = await fetch('/api/moderation/penalties/submitappeal', {
                                method: 'POST',
                                credentials: 'include',
                                headers: {'content-type': 'application/json'},
                                body: JSON.stringify({appealDetails, itemId}),
                            });
                            return await r.json().catch(() => ({}));
                        }""",
                        {"appealDetails": pp.v2_appeal_details, "itemId": pp.item_id},
                    )
                    if (res_v2.get("BaseResp") or {}).get("StatusCode") == 0:
                        return True, "browser_studio_v2(StatusCode=0)"

                details = [
                    {
                        "issuer": pen.get("issuer"),
                        "penalty_id": (pen.get("penalty_id") or {}).get("id")
                        if isinstance(pen.get("penalty_id"), dict)
                        else pen.get("penalty_id"),
                    }
                    for pen in pp.penalties
                ]
                qs_params = urlencode(
                    {
                        "aid": "1988",
                        "app_name": "tiktok_creator_center",
                        "vid": pp.item_id,
                        "appeal_details": json.dumps(details, separators=(",", ":")),
                    }
                )
                res_v1 = await page.evaluate(
                    """async (qs) => {
                        const r = await fetch(`/mod/v1/submitAppeals?${qs}`, {
                            method: 'POST',
                            credentials: 'include',
                        });
                        return await r.json().catch(() => ({}));
                    }""",
                    qs_params,
                )
                if res_v1.get("status_code") == 0:
                    return True, "browser_studio_v1(status_code=0)"
                return False, f"studio_resp={res_v1}"
            finally:
                await browser.close()


# ── 3. Unified 3-Channel Cascading Unbanner + Rejected Cleanup (Pooled & Fast) ──

async def _remove_restrictions_with_client(
    *,
    http: httpx.AsyncClient,
    account_id: str,
    username: str,
    device: Any,
    proxy: str,
    post_ids: Optional[List[str]] = None,
    appeal_text: str = DEFAULT_APPEAL_TEXT,
    dry_run: bool = False,
    hide_rejected: bool = False,
    stagger_appeals: bool = True,
    use_browser_fallback: bool = True,
    only_account_ineligible: bool = True,
    chrome_executable: Optional[str] = None,
    cached_meta: Optional[Dict[str, str]] = None,
    log_fn: Optional[Callable[[str], None]] = None,
) -> AccountAppealSummary:
    tag = f"@{username or account_id}"
    audit = await audit_account_restrictions(
        account_id=account_id,
        username=username,
        device=device,
        proxy=proxy,
        extra_post_ids=post_ids,
        shared_http=http,
        cached_meta=cached_meta,
        only_account_ineligible=only_account_ineligible,
    )
    summary = AccountAppealSummary(account_id=account_id, audit=audit)
    appeals_sent_count = 0

    # Cache reasons per punish_type so stacked 2048 notices don't repeat `/appeal/reason/` GETs
    reasons_cache: Dict[int, List[Dict[str, Any]]] = {}
    # Track `(object_id, punish_type)` where an HTTP appeal already succeeded this pass
    # so sibling stacked 2048 notices never waste 25s launching Headless Chromium on `-5000`
    succeeded_obj_types: set[Tuple[str, int]] = set()

    # A. Account / Inbox System Violations
    for vio in audit.notice_violations:
        is_appealable = vio.can_appeal or vio.status_code == 1
        if not is_appealable:
            summary.items.append(
                RestrictionActionReport(
                    account_id=account_id,
                    scope="account_or_inbox",
                    target_id=vio.object_id,
                    punish_key=vio.punish_id,
                    title=f"{vio.title} ({vio.punish_type_name})",
                    previous_state=vio.status_label,
                    action_taken="none",
                    appealed_now=False,
                    detail=(
                        f"Статус: {vio.status_label}"
                        + (f" | AppealId={vio.appeal_id}" if vio.appeal_id and vio.appeal_id != "0" else "")
                    ),
                )
            )
            continue

        if dry_run:
            summary.items.append(
                RestrictionActionReport(
                    account_id=account_id,
                    scope="account_or_inbox",
                    target_id=vio.object_id,
                    punish_key=vio.punish_id,
                    title=f"{vio.title} ({vio.punish_type_name})",
                    previous_state=vio.status_label,
                    action_taken="dry_run",
                    appealed_now=False,
                    detail=f"[АУДИТ] Активный огран (type={vio.punish_type}: {vio.reason_title or vio.punish_type_name}) — доступна апелляция",
                )
            )
            continue

        obj_type_key = (vio.object_id, vio.punish_type)
        # Fast refresh if a sibling notice on the exact same account/object was ALREADY appealed seconds ago!
        if obj_type_key in succeeded_obj_types:
            await _enrich_violation_detail(http, audit.idc_gateway, vio, audit.uid)
            if not (vio.can_appeal or vio.status_code == 1):
                summary.items.append(
                    RestrictionActionReport(
                        account_id=account_id,
                        scope="account_or_inbox",
                        target_id=vio.object_id,
                        punish_key=vio.punish_id,
                        title=f"{vio.title} ({vio.punish_type_name})",
                        previous_state="Effecting",
                        action_taken="covered_by_sibling_appeal",
                        appealed_now=True,
                        detail=f"Автоматически покрыто соседней апелляцией -> {vio.status_label}",
                    )
                )
                continue

        if stagger_appeals and appeals_sent_count > 0:
            delay = random.uniform(*APPEAL_STAGGER_SECONDS)
            await asyncio.sleep(delay)

        appeals_sent_count += 1
        prev_label = vio.status_label
        cur_appeal_text = expand_spintax(appeal_text or DEFAULT_APPEAL_TEXT)

        if vio.punish_type in reasons_cache:
            reasons = reasons_cache[vio.punish_type]
        else:
            reasons = []
            try:
                r_rsn = await http.get(
                    f"{audit.idc_gateway}/tiktok/v1/appeal/reason/",
                    params={
                        **MOBILE_BASE_PARAMS,
                        "object_id": vio.object_id,
                        "appeal_type": str(vio.punish_type),
                    },
                )
                if r_rsn.status_code == 200:
                    reasons = r_rsn.json().get("appeal_reasons") or []
                    reasons_cache[vio.punish_type] = reasons
            except Exception:
                pass

        selected_code = reasons[0].get("code") or reasons[0].get("id") if reasons else None
        reason_json = build_tns_appeal_reason_json(
            appeal_reasons_options=reasons or None,
            description_text=cur_appeal_text,
        )

        body_v1: Dict[str, Any] = {
            "ViolationId": vio.punish_id,
            "ViolationType": vio.punish_type,
            "UserId": audit.uid,
            "ObjectId": vio.object_id,
            "appeal_type": vio.punish_type,
            "object_id": vio.object_id,
            "punish_key": vio.punish_id,
            "appeal_uri": "",
            "extra": "",
        }
        if selected_code is not None:
            body_v1["AppealReasons"] = [str(selected_code)]
        if reason_json:
            body_v1["reason"] = reason_json
        if cur_appeal_text:
            body_v1["AppealDescription"] = cur_appeal_text

        ok_notice = False
        channel_used = ""
        err_note = ""

        # Channel 1: Pure-HTTP `/api/violation/v1/commit_appeal`
        try:
            r1 = await http.post(
                f"{audit.idc_gateway}/api/violation/v1/commit_appeal",
                params=MOBILE_BASE_PARAMS,
                json=body_v1,
            )
            if r1.status_code == 200:
                j1 = r1.json()
                sc = j1.get("status_code", (j1.get("BaseResp") or {}).get("StatusCode", -1))
                if sc == 0:
                    await asyncio.sleep(0.55)
                    await _enrich_violation_detail(http, audit.idc_gateway, vio, audit.uid)
                    if vio.status_code in (3, 4, 6) or not vio.can_appeal:
                        ok_notice = True
                        channel_used = "HTTP /api/violation/v1/commit_appeal"
                else:
                    err_note = f"commit_appeal={sc}"
        except Exception as exc:
            err_note = str(exc)

        # Channel 2: Pure-HTTP `/aweme/v2/appeal/commit/`
        if not ok_notice:
            try:
                legacy_params = {
                    **MOBILE_BASE_PARAMS,
                    "appeal_type": str(vio.punish_type),
                    "object_id": vio.object_id,
                    "punish_key": vio.punish_id,
                    "appeal_uri": "",
                    "extra": "",
                }
                if reason_json:
                    legacy_params["reason"] = reason_json
                r2 = await http.post(
                    f"{audit.idc_gateway}/aweme/v2/appeal/commit/",
                    params=legacy_params,
                )
                if r2.status_code == 200 and r2.json().get("status_code", -1) == 0:
                    await asyncio.sleep(0.55)
                    await _enrich_violation_detail(http, audit.idc_gateway, vio, audit.uid)
                    if vio.status_code in (3, 4, 6) or not vio.can_appeal:
                        ok_notice = True
                        channel_used = "HTTP /aweme/v2/appeal/commit/"
            except Exception:
                pass

        # Channel 3: Headless Chromium `BytedanceWebview` fallback (skip if a sibling on same object already succeeded!)
        if not ok_notice and use_browser_fallback and (obj_type_key not in succeeded_obj_types):
            if log_fn:
                log_fn(f"[{tag}] 🌐 HTTP-канал запросил подпись WebView — запускаю Headless Chromium для {vio.punish_id}...")
            try:
                ok_web, web_msg = await _submit_notice_via_browser_webview(
                    account_id=account_id,
                    device=device,
                    proxy=proxy,
                    vio=vio,
                    reason_options=reasons or None,
                    appeal_text=cur_appeal_text,
                    chrome_executable=chrome_executable,
                )
                if ok_web:
                    await asyncio.sleep(0.65)
                    await _enrich_violation_detail(http, audit.idc_gateway, vio, audit.uid)
                    ok_notice = True
                    channel_used = f"WebView ({web_msg})"
                else:
                    err_note = f"{err_note} | {web_msg}".strip(" |")
            except Exception as w_exc:
                err_note = f"{err_note} | {w_exc}".strip(" |")
        elif not ok_notice and (obj_type_key in succeeded_obj_types):
            # Sibling account appeal already accepted; mark covered if server returned -5000 duplicate lock
            await _enrich_violation_detail(http, audit.idc_gateway, vio, audit.uid)
            if not (vio.can_appeal or vio.status_code == 1) or "commit_appeal=-5000" in err_note:
                vio.can_appeal = False
                if vio.status_code == 1:
                    vio.status_code = 4
                    vio.status_label = VIOLATION_V1_STATUS[4]
                ok_notice = True
                channel_used = "covered_by_account_appeal"

        if ok_notice:
            succeeded_obj_types.add(obj_type_key)
            summary.notice_appeals_verified += 1
            # Fast 2-step check for instant auto-approval (many 2048 appeals flip 4 -> 6 AppealSuccess in 2–5s!)
            if vio.status_code == 4 and _is_account_ineligible_notice(vio):
                for wait_chk in (2.0, 3.0):
                    await asyncio.sleep(wait_chk)
                    await _enrich_violation_detail(http, audit.idc_gateway, vio, audit.uid)
                    if vio.status_code in (3, 6):
                        break
            if log_fn:
                if vio.status_code in (3, 6):
                    log_fn(
                        f"[{tag}] 🎉 Огран {vio.title} СНЯТ МГНОВЕННО ({channel_used}) -> {vio.status_label}!"
                    )
                else:
                    log_fn(
                        f"[{tag}] ✅ Апелляция принята ({channel_used}): {vio.title} -> {vio.status_label}"
                    )
        else:
            if log_fn:
                log_fn(f"[{tag}] ⚠️ Не удалось снять уведомление {vio.title}: {err_note}")

        summary.items.append(
            RestrictionActionReport(
                account_id=account_id,
                scope="account_or_inbox",
                target_id=vio.object_id,
                punish_key=vio.punish_id,
                title=f"{vio.title} ({vio.punish_type_name})",
                previous_state=prev_label,
                action_taken=channel_used or "failed",
                appealed_now=ok_notice,
                detail=(
                    f"Апелляция принята ({channel_used}) -> {vio.status_label}"
                    if ok_notice
                    else f"Не удалось подать апелляцию: {err_note}"
                ),
            )
        )

    # B. TikTok Studio Per-Post FYP Penalties (concurrent Semaphore(3) for 3x speed!)
    post_sem = asyncio.Semaphore(3)

    async def _handle_post_penalty(idx_p: int, pp: PostPenalty) -> None:
        can_submit_post = pp.appeal_status == 0 or pp.v2_can_appeal
        if can_submit_post:
            reasons_str = ",".join(pp.reason_labels) or ("V2" if pp.v2_can_appeal else "FYP_INELIGIBLE")
            if dry_run:
                summary.items.append(
                    RestrictionActionReport(
                        account_id=account_id,
                        scope="post_studio",
                        target_id=pp.item_id,
                        punish_key=reasons_str,
                        title=f"Пост {pp.item_id} ({reasons_str})",
                        previous_state=pp.appeal_status_label,
                        action_taken="dry_run",
                        appealed_now=False,
                        detail=f"[АУДИТ] Огран реков на посте ({reasons_str}, просм.={pp.play_count}) — доступна апелляция",
                    )
                )
                return

            async with post_sem:
                if stagger_appeals and idx_p > 0:
                    await asyncio.sleep(0.35 * (idx_p % 3))

                prev_post_state = pp.appeal_status_label
                ok_post = False
                post_channel = ""

                # Channel 1A: Pure-HTTP Studio V2
                if pp.v2_can_appeal and pp.v2_appeal_details is not None:
                    try:
                        rv2 = await http.post(
                            f"{WWW_BASE}/api/moderation/penalties/submitappeal",
                            params={"aid": "1988"},
                            json={"appealDetails": pp.v2_appeal_details, "itemId": pp.item_id},
                        )
                        if rv2.status_code == 200 and (rv2.json().get("BaseResp") or {}).get("StatusCode") == 0:
                            await asyncio.sleep(0.55)
                            await _check_single_post_penalty_http(http, pp)
                            ok_post = True
                            post_channel = "HTTP Studio V2"
                    except Exception:
                        pass

                # Channel 1B: Pure-HTTP Studio V1
                if not ok_post and pp.penalties:
                    details = [
                        {
                            "issuer": pen.get("issuer"),
                            "penalty_id": (pen.get("penalty_id") or {}).get("id")
                            if isinstance(pen.get("penalty_id"), dict)
                            else pen.get("penalty_id"),
                        }
                        for pen in pp.penalties
                        if pen.get("penalty_id")
                    ]
                    try:
                        rv1 = await http.post(
                            f"{WWW_BASE}/mod/v1/submitAppeals",
                            params={
                                "aid": "1988",
                                "app_name": "tiktok_creator_center",
                                "vid": pp.item_id,
                                "appeal_details": json.dumps(details, separators=(",", ":")),
                            },
                        )
                        if rv1.status_code == 200 and rv1.json().get("status_code") == 0:
                            await asyncio.sleep(0.55)
                            await _check_single_post_penalty_http(http, pp)
                            if pp.appeal_status != 0:
                                ok_post = True
                                post_channel = "HTTP Studio V1"
                    except Exception:
                        pass

                # Channel 2: Headless Chrome Studio `webmssdk` fallback
                if not ok_post and use_browser_fallback:
                    if log_fn:
                        log_fn(f"[{tag}] 🌐 Запуск Headless Studio фоллбэка для поста {pp.item_id}...")
                    try:
                        ok_br, br_msg = await _submit_post_via_browser_studio(
                            account_id=account_id,
                            device=device,
                            proxy=proxy,
                            pp=pp,
                            chrome_executable=chrome_executable,
                        )
                        if ok_br:
                            await asyncio.sleep(0.6)
                            await _check_single_post_penalty_http(http, pp)
                            ok_post = True
                            post_channel = br_msg
                        else:
                            post_channel = br_msg
                    except Exception as b_exc:
                        post_channel = str(b_exc)

                if ok_post:
                    summary.post_appeals_verified += 1
                    if log_fn:
                        log_fn(f"[{tag}] ✅ Апелляция на пост {pp.item_id} ({reasons_str}) отправлена ({post_channel}) -> {pp.appeal_status_label}")
                else:
                    if log_fn:
                        log_fn(f"[{tag}] ⚠️ Ошибка апелляции поста {pp.item_id}: {post_channel}")

                summary.items.append(
                    RestrictionActionReport(
                        account_id=account_id,
                        scope="post_studio",
                        target_id=pp.item_id,
                        punish_key=reasons_str,
                        title=f"Ineligible for For You ({reasons_str})",
                        previous_state=prev_post_state,
                        action_taken=post_channel or "failed",
                        appealed_now=ok_post,
                        detail=(
                            f"Апелляция на пост отправлена ({post_channel}) -> {pp.appeal_status_label}"
                            if ok_post
                            else f"Ошибка апелляции поста: {post_channel}"
                        ),
                    )
                )
        elif pp.appeal_status not in (2,):
            reasons_str = ",".join(pp.reason_labels) or "MODERATION"
            if hide_rejected and pp.appeal_status == 5:
                if dry_run:
                    summary.items.append(
                        RestrictionActionReport(
                            account_id=account_id,
                            scope="post_cleanup",
                            target_id=pp.item_id,
                            punish_key=reasons_str,
                            title=f"Отклонённый пост {pp.item_id} ({reasons_str})",
                            previous_state="FAILED",
                            action_taken="dry_run_private",
                            appealed_now=False,
                            detail="[АУДИТ] Скрыл бы отклонённый пост в Private (защита от бана 2048)",
                        )
                    )
                else:
                    ok_priv = False
                    priv_note = ""
                    try:
                        rp = await http.post(
                            f"{WWW_BASE}/tiktokstudio/api/web/item/visibility",
                            params={"aid": "1988"},
                            json={"item_id": pp.item_id, "visibility_type": 2},
                        )
                        rj = rp.json()
                        if rp.status_code == 200 and rj.get("statusCode", rj.get("status_code", -1)) == 0:
                            ok_priv = True
                            summary.posts_hidden += 1
                            priv_note = "Отклонённый пост переведён в Private (visibility_type=2)"
                            if log_fn:
                                log_fn(f"[{tag}] 🔒 Пост {pp.item_id} переведён в Private (защита от 2048)")
                        else:
                            priv_note = f"Ответ visibility: {rp.text[:140]}"
                    except Exception as exc:
                        priv_note = f"Ошибка visibility: {exc}"

                    summary.items.append(
                        RestrictionActionReport(
                            account_id=account_id,
                            scope="post_cleanup",
                            target_id=pp.item_id,
                            punish_key=reasons_str,
                            title=f"Отклонённый пост {pp.item_id} ({reasons_str})",
                            previous_state="FAILED",
                            action_taken="POST /tiktokstudio/api/web/item/visibility",
                            appealed_now=ok_priv,
                            detail=priv_note,
                        )
                    )
            else:
                summary.items.append(
                    RestrictionActionReport(
                        account_id=account_id,
                        scope="post_studio",
                        target_id=pp.item_id,
                        punish_key=reasons_str,
                        title=f"Пост {pp.item_id} ({reasons_str})",
                        previous_state=pp.appeal_status_label,
                        action_taken="none",
                        appealed_now=False,
                        detail=f"Статус поста: {pp.appeal_status_label} (просм.={pp.play_count})",
                    )
                )

    if (not only_account_ineligible) and audit.post_penalties:
        await asyncio.gather(*(_handle_post_penalty(i, p) for i, p in enumerate(audit.post_penalties)))

    return summary


async def remove_account_restrictions(
    *,
    account_id: str,
    username: str,
    device: Any,
    proxy: str,
    post_ids: Optional[List[str]] = None,
    appeal_text: str = DEFAULT_APPEAL_TEXT,
    dry_run: bool = False,
    hide_rejected: bool = False,
    stagger_appeals: bool = True,
    use_browser_fallback: bool = True,
    only_account_ineligible: bool = True,
    chrome_executable: Optional[str] = None,
    shared_http: Optional[httpx.AsyncClient] = None,
    cached_meta: Optional[Dict[str, str]] = None,
    log_fn: Optional[Callable[[str], None]] = None,
) -> AccountAppealSummary:
    if shared_http is not None:
        return await _remove_restrictions_with_client(
            http=shared_http,
            account_id=account_id,
            username=username,
            device=device,
            proxy=proxy,
            post_ids=post_ids,
            appeal_text=appeal_text,
            dry_run=dry_run,
            hide_rejected=hide_rejected,
            stagger_appeals=stagger_appeals,
            use_browser_fallback=use_browser_fallback,
            only_account_ineligible=only_account_ineligible,
            chrome_executable=chrome_executable,
            cached_meta=cached_meta,
            log_fn=log_fn,
        )

    cookies = extract_cookie_dict_from_device(device, account_id)
    headers = {
        "user-agent": DESKTOP_CHROME_UA,
        "accept": "application/json, text/plain, */*",
    }
    httpx_proxy = _resolve_httpx_proxy(proxy)
    async with httpx.AsyncClient(
        proxy=httpx_proxy,
        cookies=cookies,
        headers=headers,
        timeout=20.0,
        follow_redirects=True,
    ) as http:
        return await _remove_restrictions_with_client(
            http=http,
            account_id=account_id,
            username=username,
            device=device,
            proxy=proxy,
            post_ids=post_ids,
            appeal_text=appeal_text,
            dry_run=dry_run,
            hide_rejected=hide_rejected,
            stagger_appeals=stagger_appeals,
            use_browser_fallback=use_browser_fallback,
            only_account_ineligible=only_account_ineligible,
            chrome_executable=chrome_executable,
            cached_meta=cached_meta,
            log_fn=log_fn,
        )


# ── 4. Automatic 4-Folder Sorting System (`sorted_accounts/`) ────────────────

def classify_appeal_folder(res: Dict[str, Any]) -> Tuple[str, str]:
    """
    Maps an audit/unban result into one of 4 clear folders:
      - `errors`: login or session error
      - `ogran_ne_snyat`: `appealable_remaining > 0` OR `failed_count > 0` (active unappealed or rejected)
      - `ogran_na_proverke`: `appealable_remaining == 0` AND `reviewing_count > 0` (appeal pending TikTok review!)
      - `clean`: `appealable_remaining == 0` AND `reviewing_count == 0` AND `failed_count == 0` (0 restrictions / approved)
    """
    if res.get("verdict") == "error":
        return "errors", APPEAL_FOLDER_SPECS["errors"]["title"]
    rem = int(res.get("appealable_remaining") or 0)
    fld = int(res.get("failed_count") or 0)
    rev = int(res.get("reviewing_count") or 0)
    if rem > 0 or fld > 0:
        return "ogran_ne_snyat", APPEAL_FOLDER_SPECS["ogran_ne_snyat"]["title"]
    if rev > 0:
        return "ogran_na_proverke", APPEAL_FOLDER_SPECS["ogran_na_proverke"]["title"]
    return "clean", APPEAL_FOLDER_SPECS["clean"]["title"]


def place_account_in_sorted_folder(
    *,
    store: SessionStore,
    folder_key: str,
    session_file: str = "",
    username: str = "",
    raw_line: str = "",
    verdict_label: str = "",
) -> str:
    """
    Places the account into `sorted_accounts/<folder_key>/` (both `.txt` line and `.json` session copy),
    removes stale copies of the same account from all other folders, and updates `sess["appeal_folder"]`.
    """
    if folder_key not in APPEAL_FOLDER_SPECS:
        folder_key = "errors"

    sess_data = store.get_session(session_file) if session_file else None
    eff_uname = (username or (sess_data or {}).get("username") or session_file.replace(".json", "")).lstrip("@").strip()
    eff_raw = (raw_line or (sess_data or {}).get("raw_line") or "").strip()
    eff_email = ((sess_data or {}).get("email") or "").strip()

    if eff_raw:
        line_entry = eff_raw
    elif eff_uname and eff_email:
        line_entry = f"{eff_uname}:{eff_email}"
    else:
        line_entry = eff_uname or session_file or "unknown_account"

    match_tokens = {t.lower() for t in (eff_uname, eff_email, session_file.replace(".json", "")) if t}

    with _FOLDER_SORT_LOCK:
        for fk, spec in APPEAL_FOLDER_SPECS.items():
            fdir = SORTED_ACCOUNTS_DIR / spec["dir_name"]
            sdir = fdir / "sessions"
            fdir.mkdir(parents=True, exist_ok=True)
            sdir.mkdir(parents=True, exist_ok=True)
            txt_fp = fdir / spec["txt_name"]

            # Clean existing occurrences of this account from every folder's `.txt`
            kept_lines: List[str] = []
            if txt_fp.exists():
                for ln in txt_fp.read_text(encoding="utf-8").splitlines():
                    s_ln = ln.strip()
                    if not s_ln:
                        continue
                    low_ln = s_ln.lower()
                    if s_ln == line_entry or any(
                        (low_ln.startswith(f"{tok}:") or low_ln.startswith(f"@{tok}") or low_ln == tok or f":{tok}:" in low_ln)
                        for tok in match_tokens
                    ):
                        continue
                    kept_lines.append(s_ln)

            if fk == folder_key:
                kept_lines.append(line_entry)

            txt_fp.write_text(("\n".join(kept_lines) + ("\n" if kept_lines else "")), encoding="utf-8")

            # Sync `.json` session copy inside `sorted_accounts/<fk>/sessions/`
            if session_file:
                target_json = sdir / os.path.basename(session_file)
                if fk == folder_key:
                    src_json = store.sessions_dir / os.path.basename(session_file)
                    if src_json.exists():
                        shutil.copy2(src_json, target_json)
                else:
                    if target_json.exists():
                        try:
                            target_json.unlink()
                        except Exception:
                            pass

    if session_file and (store.sessions_dir / os.path.basename(session_file)).exists():
        def _upd_f(d: Dict[str, Any]) -> None:
            d["appeal_folder"] = folder_key
            d["appeal_folder_title"] = APPEAL_FOLDER_SPECS[folder_key]["title"]
            if verdict_label:
                d["appeal_verdict_label"] = verdict_label
            if eff_raw and not d.get("raw_line"):
                d["raw_line"] = eff_raw

        store.update_session_data(session_file, _upd_f)

    return APPEAL_FOLDER_SPECS[folder_key]["title"]


def get_sorted_folders_summary(store: Optional[SessionStore] = None) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    with _FOLDER_SORT_LOCK:
        for fk, spec in APPEAL_FOLDER_SPECS.items():
            fdir = SORTED_ACCOUNTS_DIR / spec["dir_name"]
            sdir = fdir / "sessions"
            txt_fp = fdir / spec["txt_name"]
            lines: List[str] = []
            if txt_fp.exists():
                lines = [ln.strip() for ln in txt_fp.read_text(encoding="utf-8").splitlines() if ln.strip()]
            sess_files = sorted(p.name for p in sdir.glob("*.json")) if sdir.exists() else []
            out[fk] = {
                "key": fk,
                "title": spec["title"],
                "subtitle": spec["subtitle"],
                "txt_name": spec["txt_name"],
                "path": f"sorted_accounts/{spec['dir_name']}/",
                "count": max(len(lines), len(sess_files)),
                "lines_count": len(lines),
                "sessions_count": len(sess_files),
                "session_files": sess_files,
                "lines_preview": lines[:50],
            }
    return out


def export_sorted_folder_archive(folder_key: str, fmt: str = "txt") -> Tuple[bytes, str, str]:
    spec = APPEAL_FOLDER_SPECS.get(folder_key)
    if not spec:
        raise ValueError(f"Неизвестная папка: {folder_key}")
    fdir = SORTED_ACCOUNTS_DIR / spec["dir_name"]
    sdir = fdir / "sessions"
    txt_fp = fdir / spec["txt_name"]

    if fmt == "txt":
        raw_txt = txt_fp.read_bytes() if txt_fp.exists() else b""
        return raw_txt, "text/plain; charset=utf-8", spec["txt_name"]

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        if txt_fp.exists():
            zf.write(txt_fp, arcname=spec["txt_name"])
        if sdir.exists():
            for jp in sorted(sdir.glob("*.json")):
                zf.write(jp, arcname=f"sessions/{jp.name}")
    return buf.getvalue(), "application/zip", f"{spec['dir_name']}.zip"


# ── 5. Synchronous Fast-Pooled Loop-Until-Clean Wrapper ──────────────────────

def _count_audit_states(audit: AccountAuditResult) -> Dict[str, int]:
    appealable_notices = sum(1 for v in audit.notice_violations if (v.can_appeal or v.status_code == 1))
    appealable_posts = sum(1 for p in audit.post_penalties if (p.appeal_status == 0 or p.v2_can_appeal))
    reviewing_notices = sum(1 for v in audit.notice_violations if v.status_code == 4)
    reviewing_posts = sum(1 for p in audit.post_penalties if p.appeal_status == 3)
    restored_notices = sum(1 for v in audit.notice_violations if v.status_code in (3, 6))
    restored_posts = sum(1 for p in audit.post_penalties if p.appeal_status == 4)
    failed_notices = sum(1 for v in audit.notice_violations if v.status_code == 7)
    failed_posts = sum(1 for p in audit.post_penalties if p.appeal_status == 5)
    return {
        "appealable_notices": appealable_notices,
        "appealable_posts": appealable_posts,
        "appealable_total": appealable_notices + appealable_posts,
        "reviewing_total": reviewing_notices + reviewing_posts,
        "restored_total": restored_notices + restored_posts,
        "failed_total": failed_notices + failed_posts,
    }


def ensure_session_clean_loop(
    *,
    store: SessionStore,
    session_file: str,
    proxy_override: str = "",
    dry_run: bool = False,
    appeal_text: str = DEFAULT_APPEAL_TEXT,
    hide_rejected: bool = False,
    stagger_appeals: bool = True,
    use_browser_fallback: bool = True,
    only_account_ineligible: bool = True,
    max_passes: int = 6,
    retry_pause_sec: float = 2.5,
    quiet_window_sec: float = 0.0,
    poll_interval_sec: float = 6.0,
    max_guard_sec: float = 600.0,
    extra_post_ids: Optional[List[str]] = None,
    sort_to_folder: bool = True,
    raw_line_hint: str = "",
    status_cb: Optional[Callable[[str, int], None]] = None,
    stop_check_fn: Optional[Callable[[], bool]] = None,
    log_fn: Optional[Callable[[str], None]] = None,
) -> Dict[str, Any]:
    """
    Ultra-fast pooled restriction scanner & unbanner:
      - Targets ONLY `Account ineligible for recommendation` (`punish_type=2048`) by default (1 single IDC GET per check!).
      - Keeps ONE warm `httpx.AsyncClient` SOCKS5+TLS pool open across all passes & quiet-window checks!
      - Automatically sorts the account into `sorted_accounts/{clean,ogran_na_proverke,ogran_ne_snyat}`!
    """
    sess = store.get_session(session_file)
    if not sess:
        raise RuntimeError(f"Файл сессии {session_file} не найден")

    uname = sess.get("username") or sess.get("email") or session_file.replace(".json", "")
    tag = f"@{uname}"
    eff_reg = (sess.get("region") or sess.get("phone_region") or "US").upper()
    px = (proxy_override or "").strip() or _resolve_session_proxy(sess, eff_reg)

    quiet_target = 0.0 if dry_run else max(0.0, float(quiet_window_sec or 0.0))
    poll_step = max(3.5, min(25.0, float(poll_interval_sec or 6.0)))
    passes_limit = 1 if dry_run else (45 if quiet_target > 0 else max(1, min(20, int(max_passes or 6))))
    guard_deadline = time.monotonic() + max(90.0, float(max_guard_sec or 600.0))

    cached_meta: Dict[str, str] = dict(sess.get("appeal_meta") or {})
    if sess.get("uid") and not cached_meta.get("uid"):
        cached_meta["uid"] = str(sess["uid"])
    if sess.get("region") and not cached_meta.get("current_region"):
        cached_meta["current_region"] = str(sess["region"])

    async def _run_pooled_loop() -> Tuple[Optional[AccountAuditResult], int, int, int, int, List[Dict[str, Any]]]:
        total_notice_ap = 0
        total_post_ap = 0
        total_hid = 0
        actions_acc: List[Dict[str, Any]] = []
        last_audit: Optional[AccountAuditResult] = None
        p_done = 0
        clean_since: Optional[float] = None
        review_confirm_checks = 0

        init_dev = sess.get("device") or sess.get("x_device")
        init_cookies = extract_cookie_dict_from_device(init_dev, uname)
        headers = {
            "user-agent": DESKTOP_CHROME_UA,
            "accept": "application/json, text/plain, */*",
        }
        httpx_proxy = _resolve_httpx_proxy(px)

        async def _async_sleep_interruptible(seconds: float) -> bool:
            end_t = time.monotonic() + max(0.0, seconds)
            while time.monotonic() < end_t:
                if stop_check_fn and stop_check_fn():
                    return False
                await asyncio.sleep(min(0.4, max(0.05, end_t - time.monotonic())))
            return True

        async with httpx.AsyncClient(
            proxy=httpx_proxy,
            cookies=init_cookies,
            headers=headers,
            timeout=20.0,
            follow_redirects=True,
        ) as shared_http:
            for pass_idx in range(1, passes_limit + 1):
                if stop_check_fn and stop_check_fn():
                    break
                if quiet_target > 0 and time.monotonic() > guard_deadline:
                    if log_fn:
                        log_fn(f"[{tag}] ⏱ Достигнут лимит сторожа ({int(max_guard_sec)}с) — завершаю проверку.")
                    break

                fresh_sess = store.get_session(session_file) or sess
                device = fresh_sess.get("device") or fresh_sess.get("x_device")
                fresh_cookies = extract_cookie_dict_from_device(device, uname)
                shared_http.cookies.update(fresh_cookies)

                known_ids: List[str] = [str(p.get("aweme_id")) for p in (fresh_sess.get("posts") or []) if p.get("aweme_id")]
                for eid in extra_post_ids or []:
                    if eid and str(eid) not in known_ids:
                        known_ids.append(str(eid))

                p_done = pass_idx
                scope_lbl = "2048 Account ineligible" if only_account_ineligible else "IDC + Studio"
                if log_fn:
                    if dry_run:
                        log_fn(f"[{tag}] ⚡ Быстрый чек {scope_lbl}...")
                    elif quiet_target > 0:
                        q_el = int(time.monotonic() - clean_since) if clean_since is not None else 0
                        log_fn(
                            f"[{tag}] ⚡ Чек #{pass_idx} ({scope_lbl}, снято={total_notice_ap + total_post_ap}, тишина={q_el}/{int(quiet_target)}с)..."
                        )
                    else:
                        log_fn(f"[{tag}] ⚡ Снятие #{pass_idx}/{passes_limit} ({scope_lbl})...")

                summary = await _remove_restrictions_with_client(
                    http=shared_http,
                    account_id=uname,
                    username=uname,
                    device=device,
                    proxy=px,
                    post_ids=known_ids,
                    appeal_text=appeal_text or DEFAULT_APPEAL_TEXT,
                    dry_run=dry_run,
                    hide_rejected=hide_rejected,
                    stagger_appeals=stagger_appeals,
                    use_browser_fallback=use_browser_fallback,
                    only_account_ineligible=only_account_ineligible,
                    cached_meta=cached_meta,
                    log_fn=log_fn,
                )
                last_audit = summary.audit
                total_notice_ap += summary.notice_appeals_verified
                total_post_ap += summary.post_appeals_verified
                total_hid += summary.posts_hidden
                total_sent_now = total_notice_ap + total_post_ap

                for item in summary.items:
                    d_it = asdict(item)
                    d_it["pass"] = pass_idx
                    actions_acc.append(d_it)

                if dry_run or last_audit is None:
                    break

                sent_this_pass = summary.notice_appeals_verified + summary.post_appeals_verified + summary.posts_hidden
                if sent_this_pass > 0:
                    clean_since = None
                    review_confirm_checks = 0

                counts = _count_audit_states(last_audit)

                if counts["appealable_total"] > 0:
                    clean_since = None
                    review_confirm_checks = 0
                    if status_cb:
                        status_cb(
                            f"🛡️ Дожим 2048 ({counts['appealable_total']}) | Снято: {total_sent_now}",
                            total_sent_now,
                        )
                    if pass_idx < passes_limit:
                        if log_fn:
                            log_fn(
                                f"[{tag}] 🔄 Осталось активных огранов: {counts['appealable_total']} — дожим через {retry_pause_sec:.1f}с..."
                            )
                        if not await _async_sleep_interruptible(max(1.0, retry_pause_sec)):
                            break
                    continue

                if quiet_target <= 0:
                    break

                # Smart 2048 shortcut during post-upload quiet window:
                # Only count quiet confirmations on passes with 0 newly arrived 2048 notices (`sent_this_pass == 0`),
                # so staggered waves from posts 5–6 (~25–35s later) are caught before moving to `ogran_na_proverke`!
                if only_account_ineligible and sent_this_pass == 0 and (total_notice_ap > 0 or counts["reviewing_total"] > 0):
                    if counts["reviewing_total"] == 0 and counts["restored_total"] > 0:
                        review_confirm_checks += 1
                        if review_confirm_checks >= 2:
                            if log_fn:
                                log_fn(f"[{tag}] 🎉 Account ineligible for recommendation одобрен и снят — завершаю ожидание!")
                            break
                        if not await _async_sleep_interruptible(10.0):
                            break
                        continue
                    if counts["reviewing_total"] > 0:
                        review_confirm_checks += 1
                        if review_confirm_checks >= 3:
                            if log_fn:
                                log_fn(
                                    f"[{tag}] ⏳ Новых волн 2048 больше нет, апелляция висит на проверке TikTok — "
                                    f"перемещаю в папку «Огран / На проверке»!"
                                )
                            break
                        if not await _async_sleep_interruptible(12.0):
                            break
                        continue

                if clean_since is None:
                    clean_since = time.monotonic()
                    if sent_this_pass > 0 and log_fn:
                        log_fn(
                            f"[{tag}] ⚡ Снято в проходе: {sent_this_pass} (всего: {total_sent_now}). "
                            f"Контроль тишины {int(quiet_target)}с..."
                        )

                elapsed_clean = time.monotonic() - clean_since
                if elapsed_clean >= quiet_target:
                    if log_fn:
                        log_fn(
                            f"[{tag}] ✅ {int(elapsed_clean)}с подряд новых огранов нет! Снято: {total_sent_now} | Активных: 0."
                        )
                    break

                rem_quiet = max(1.0, quiet_target - elapsed_clean)
                wait_now = min(poll_step, rem_quiet + 0.4)
                if status_cb:
                    status_cb(
                        f"🛡️ Тишина {int(elapsed_clean)}/{int(quiet_target)}с (снято: {total_sent_now})",
                        total_sent_now,
                    )
                if not await _async_sleep_interruptible(wait_now):
                    break

        return last_audit, total_notice_ap, total_post_ap, total_hid, p_done, actions_acc

    final_audit, total_notice_appeals, total_post_appeals, total_hidden, passes_done, all_actions = asyncio.run(
        _run_pooled_loop()
    )

    if cached_meta.get("idc_gateway"):
        store.update_session_data(
            session_file,
            lambda d: d.__setitem__("appeal_meta", dict(cached_meta)),
        )

    if final_audit is None:
        raise RuntimeError(f"[{tag}] Не удалось получить результат аудита")

    counts = _count_audit_states(final_audit)
    total_appealed = total_notice_appeals + total_post_appeals

    if counts["appealable_total"] > 0 or counts["failed_total"] > 0:
        verdict = "restricted"
        if counts["appealable_total"] > 0:
            verdict_label = f"🚨 Огран не снят ({counts['appealable_total']})"
        else:
            verdict_label = f"🚨 Огран отклонён / FAILED ({counts['failed_total']})"
    elif counts["reviewing_total"] > 0:
        verdict = "reviewing"
        verdict_label = (
            f"⏳ На проверке ({counts['reviewing_total']}) • подано: {total_appealed}"
            if total_appealed > 0
            else f"⏳ На проверке ({counts['reviewing_total']})"
        )
    elif total_appealed > 0 or counts["restored_total"] > 0:
        verdict = "restored"
        verdict_label = f"✅ Огран снят / Одобрено ({max(total_appealed, counts['restored_total'])})"
    else:
        verdict = "clean"
        verdict_label = "✅ Ограничений нет"

    flagged_posts_list = [
        {
            "item_id": p.item_id,
            "play_count": p.play_count,
            "appeal_status": p.appeal_status,
            "appeal_status_label": p.appeal_status_label,
            "reason_labels": p.reason_labels,
            "v2_can_appeal": p.v2_can_appeal,
            "url": f"https://www.tiktok.com/@{final_audit.username or uname}/video/{p.item_id}",
        }
        for p in final_audit.post_penalties
        if p.appeal_status != 2 or p.v2_can_appeal
    ]

    notices_list = [
        {
            "nid": v.nid,
            "group": v.group,
            "title": v.title,
            "punish_id": v.punish_id,
            "punish_type": v.punish_type,
            "punish_type_name": v.punish_type_name,
            "can_appeal": v.can_appeal,
            "status_code": v.status_code,
            "status_label": v.status_label,
            "appeal_id": v.appeal_id,
            "reason_title": v.reason_title,
        }
        for v in final_audit.notice_violations
    ]

    result_dict: Dict[str, Any] = {
        "session_file": session_file,
        "username": final_audit.username or uname,
        "uid": final_audit.uid,
        "reg_country": final_audit.reg_country,
        "current_region": final_audit.current_region or eff_reg,
        "idc_gateway": final_audit.idc_gateway.replace("https://", ""),
        "region_warning_present": final_audit.region_warning_present,
        "total_posts": final_audit.total_posts,
        "passes_executed": passes_done,
        "appeals_sent_total": total_appealed,
        "notice_appeals_verified": total_notice_appeals,
        "post_appeals_verified": total_post_appeals,
        "posts_hidden_total": total_hidden,
        "appealable_remaining": counts["appealable_total"],
        "appealable_notices": counts["appealable_notices"],
        "appealable_posts": counts["appealable_posts"],
        "reviewing_count": counts["reviewing_total"],
        "restored_count": counts["restored_total"],
        "failed_count": counts["failed_total"],
        "verdict": verdict,
        "verdict_label": verdict_label,
        "notices": notices_list,
        "flagged_posts": flagged_posts_list,
        "actions": all_actions,
        "checked_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }

    folder_key, folder_title = classify_appeal_folder(result_dict)
    result_dict["folder_key"] = folder_key
    result_dict["folder_title"] = folder_title

    if sort_to_folder:
        place_account_in_sorted_folder(
            store=store,
            folder_key=folder_key,
            session_file=session_file,
            username=result_dict["username"],
            raw_line=raw_line_hint,
            verdict_label=verdict_label,
        )

    if log_fn:
        log_fn(
            f"[{tag}] 🏁 Итог: {verdict_label} -> Папка: [{folder_title}] | "
            f"Неснятых: {counts['appealable_total']} | На проверке: {counts['reviewing_total']} | Снято/Подано: {total_appealed}"
        )

    return result_dict


# ── 6. Dedicated Login + Check/Unban + Folder Sorting Manager ────────────────

def _detect_login_mode_for_line(raw_line: str) -> str:
    low = raw_line.lower()
    if any(dom in low for dom in ("@outlook.", "@hotmail.", "@live.", "@msn.")):
        return "email_outlook"
    if "@" in raw_line:
        return "password_imap"
    return "username_totp"


class AutoAppealManager:
    def __init__(self, store: SessionStore, log_fn: Callable[[str], None]) -> None:
        self.store = store
        self.log_fn = log_fn
        self.lock = threading.Lock()
        self.running: bool = False
        self.stop_requested: bool = False
        self.mode: str = "unban"  # "audit" | "unban" | "watch"
        self.interval_min: int = 15
        self.cycles_completed: int = 0
        self.next_run_at: str = ""
        self.total_accounts: int = 0
        self.done_accounts: int = 0
        self.clean_accounts: int = 0
        self.restricted_accounts: int = 0
        self.appealed_accounts: int = 0
        self.error_accounts: int = 0
        self.appeals_sent_total: int = 0
        self.posts_hidden_total: int = 0
        self.rows: List[Dict[str, Any]] = []
        self.last_saved_at: str = ""
        self._load_saved_report()

    def _load_saved_report(self) -> None:
        if AUTO_APPEAL_REPORT_FILE.exists():
            try:
                data = json.loads(AUTO_APPEAL_REPORT_FILE.read_text(encoding="utf-8"))
                if isinstance(data, dict) and isinstance(data.get("rows"), list):
                    self.rows = data["rows"]
                    for r in self.rows:
                        if not r.get("folder_key"):
                            fk, ft = classify_appeal_folder(r)
                            r["folder_key"] = fk
                            r["folder_title"] = ft
                    self.last_saved_at = str(data.get("saved_at") or "")
                    self._recompute_kpis_unlocked()
            except Exception:
                pass

    def _recompute_kpis_unlocked(self) -> None:
        self.clean_accounts = sum(1 for r in self.rows if r.get("folder_key") == "clean")
        self.appealed_accounts = sum(1 for r in self.rows if r.get("folder_key") == "ogran_na_proverke")
        self.restricted_accounts = sum(1 for r in self.rows if r.get("folder_key") == "ogran_ne_snyat")
        self.error_accounts = sum(1 for r in self.rows if r.get("folder_key") == "errors")
        self.appeals_sent_total = sum(int(r.get("appeals_sent_total") or 0) for r in self.rows)
        self.posts_hidden_total = sum(int(r.get("posts_hidden_total") or 0) for r in self.rows)

    def _save_report_unlocked(self) -> None:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        self.last_saved_at = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        payload = {
            "saved_at": self.last_saved_at,
            "mode": self.mode,
            "cycles_completed": self.cycles_completed,
            "rows": self.rows,
        }
        AUTO_APPEAL_REPORT_FILE.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            rows_copy = [dict(r) for r in self.rows]
            base = {
                "running": self.running,
                "mode": self.mode,
                "interval_min": self.interval_min,
                "cycles_completed": self.cycles_completed,
                "next_run_at": self.next_run_at,
                "total_accounts": self.total_accounts,
                "done_accounts": self.done_accounts,
                "clean_accounts": self.clean_accounts,
                "restricted_accounts": self.restricted_accounts,
                "appealed_accounts": self.appealed_accounts,
                "error_accounts": self.error_accounts,
                "appeals_sent_total": self.appeals_sent_total,
                "posts_hidden_total": self.posts_hidden_total,
                "last_saved_at": self.last_saved_at,
                "rows": rows_copy,
            }
        base["folders"] = get_sorted_folders_summary(self.store)
        return base

    def stop(self) -> None:
        with self.lock:
            self.stop_requested = True
        self.log_fn("⏹ Запрошена остановка Снятия / Проверки ограничений...")

    def start(self, body: Dict[str, Any]) -> Tuple[bool, str]:
        with self.lock:
            if self.running:
                return False, "Проверка/снятие огранов уже выполняется — дождитесь завершения или нажмите Стоп."

            session_files = [os.path.basename(str(x)) for x in (body.get("session_files") or []) if x]
            raw_lines = [
                ln.strip()
                for ln in str(body.get("accounts_text") or "").splitlines()
                if ln.strip() and not ln.strip().startswith("#")
            ]

            work_items: List[Dict[str, str]] = []
            seen_sf: set[str] = set()

            default_reg = str(body.get("login_region") or "US").strip().upper() or "US"
            for rline in raw_lines:
                lmode = _detect_login_mode_for_line(rline)
                try:
                    t = parse_account_line(rline, login_mode=lmode, default_region=default_reg)
                except Exception:
                    t = None
                uname_guess = (t.username if t and t.username else (t.email.split("@")[0] if t and t.email else rline.split(":")[0])).lstrip("@")
                cand_sf = f"{safe_filename(uname_guess)}.json"
                seen_sf.add(cand_sf)
                work_items.append(
                    {
                        "row_id": cand_sf,
                        "session_file": cand_sf if (self.store.sessions_dir / cand_sf).exists() else "",
                        "username": uname_guess,
                        "raw_line": rline,
                        "login_mode": lmode,
                    }
                )

            for sf in session_files:
                if sf in seen_sf:
                    continue
                seen_sf.add(sf)
                s = self.store.get_session(sf) or {}
                uname = s.get("username") or s.get("email") or sf.replace(".json", "")
                work_items.append(
                    {
                        "row_id": sf,
                        "session_file": sf,
                        "username": uname,
                        "raw_line": str(s.get("raw_line") or ""),
                        "login_mode": "",
                    }
                )

            if not work_items:
                return False, "Вставьте строки аккаунтов (user:pass:mail:...) или выберите готовые сессии!"

            mode = str(body.get("mode") or "unban").strip().lower()
            if mode not in ("audit", "unban", "watch"):
                mode = "unban"

            self.running = True
            self.stop_requested = False
            self.mode = mode
            self.interval_min = max(2, min(360, int(body.get("interval_min") or 15)))
            self.cycles_completed = 0
            self.next_run_at = ""
            self.total_accounts = len(work_items)
            self.done_accounts = 0
            self.rows = []
            for wi in work_items:
                sf = wi["session_file"]
                s = self.store.get_session(sf) if sf else None
                self.rows.append(
                    {
                        "row_id": wi["row_id"],
                        "session_file": sf or wi["row_id"],
                        "username": wi["username"],
                        "reg_country": "",
                        "current_region": (s or {}).get("region") or default_reg,
                        "idc_gateway": "",
                        "total_posts": len((s or {}).get("posts") or []),
                        "appeals_sent_total": 0,
                        "posts_hidden_total": 0,
                        "appealable_remaining": 0,
                        "reviewing_count": 0,
                        "failed_count": 0,
                        "verdict": "queued",
                        "verdict_label": "⏳ В очереди..." if sf else "🔑 В очереди (авто-вход)...",
                        "folder_key": "",
                        "folder_title": "—",
                        "notices": [],
                        "flagged_posts": [],
                        "actions": [],
                        "checked_at": "",
                    }
                )
            self._recompute_kpis_unlocked()

        threading.Thread(
            target=self._run_worker_loop,
            args=(work_items, dict(body)),
            daemon=True,
        ).start()
        return True, f"Запущено ({mode}) для {len(work_items)} аккаунтов с авто-сортировкой по папкам"

    def _run_worker_loop(self, work_items: List[Dict[str, str]], body: Dict[str, Any]) -> None:
        threads = max(1, min(12, int(body.get("threads") or 4)))
        dry_run = self.mode == "audit"
        appeal_text = str(body.get("appeal_text") or DEFAULT_APPEAL_TEXT)
        hide_rejected = bool(body.get("hide_rejected", False))
        stagger_appeals = bool(body.get("stagger_appeals", True))
        use_browser_fallback = bool(body.get("use_browser_fallback", True))
        only_account_ineligible = bool(body.get("only_account_ineligible", True))
        max_passes = max(1, min(20, int(body.get("max_passes") or 4)))
        quiet_window_sec = max(0.0, min(300.0, float(body.get("quiet_window_sec") or 0.0)))
        force_relogin = bool(body.get("force_relogin", False))
        api_key = str(body.get("api_key") or "").strip()
        login_region = str(body.get("login_region") or "US").strip().upper() or "US"

        proxies_list = [
            ln.strip()
            for ln in str(body.get("proxies_text") or "").splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        ]

        try:
            while True:
                with self.lock:
                    if self.stop_requested:
                        break
                    self.done_accounts = 0
                    self.next_run_at = ""

                self.log_fn(
                    f"🛡️ Старт режима «{'ТОЛЬКО ПРОВЕРКА' if dry_run else 'СНЯТИЕ ОГРАНОВ + СОРТИРОВКА'}»: "
                    f"{len(work_items)} акк. | потоков={threads}"
                )

                def _one(idx: int, wi: Dict[str, str]) -> None:
                    row_id = wi["row_id"]
                    sf = wi["session_file"]
                    raw_line = wi["raw_line"]
                    uname = wi["username"]
                    px_override = proxies_list[idx % len(proxies_list)] if proxies_list else ""

                    with self.lock:
                        if self.stop_requested:
                            self.done_accounts += 1
                            return

                    def _upd_row_live(lbl: str, sent_cnt: int = 0) -> None:
                        with self.lock:
                            for r0 in self.rows:
                                if r0.get("row_id") == row_id or r0.get("session_file") == sf:
                                    r0["verdict"] = "running"
                                    r0["verdict_label"] = lbl
                                    if sent_cnt:
                                        r0["appeals_sent_total"] = sent_cnt
                                    break

                    try:
                        need_login = (not sf) or (not (self.store.sessions_dir / sf).exists()) or (force_relogin and bool(raw_line))
                        if need_login:
                            if not raw_line:
                                raise RuntimeError(f"Сессия {row_id} не найдена и строка для входа не указана")
                            if not api_key:
                                raise RuntimeError("Для авто-входа в новые аккаунты укажите Kintaro API Key сверху панели")
                            _upd_row_live(f"🔑 Вход в аккаунт ({login_region})...")
                            lmode = wi["login_mode"] or _detect_login_mode_for_line(raw_line)
                            task = parse_account_line(raw_line, login_mode=lmode, default_region=login_region)
                            if not task:
                                raise RuntimeError("Не удалось распознать формат строки аккаунта")
                            base_px = px_override or "socks5://bpuser-ZhHAgVLk:uwYPc4LCLOfjtKHE3UQo_country-US@residential-x.bpproxy.at:1002"
                            sticky_px = allocate_sticky_proxy(base_px, target_country=task.region or login_region)
                            opts = LoginOptions(
                                api_key=api_key,
                                login_mode=lmode,
                                default_region=login_region,
                                pre_register_device=True,
                                check_self_after_login=True,
                            )
                            lres = process_single_account(
                                task=task,
                                proxy_raw=sticky_px,
                                options=opts,
                                store=self.store,
                                log_fn=self.log_fn,
                            )
                            if lres.get("status") != "success":
                                raise RuntimeError(str(lres.get("error") or "Ошибка входа в аккаунт"))
                            saved_sess = lres.get("session") or {}
                            sf = str(saved_sess.get("session_file") or f"{safe_filename(saved_sess.get('username') or uname)}.json")
                            wi["session_file"] = sf
                            uname = str(saved_sess.get("username") or uname)

                        _upd_row_live("⚡ Быстрая проверка / снятие огранов...")
                        res = ensure_session_clean_loop(
                            store=self.store,
                            session_file=sf,
                            proxy_override=px_override,
                            dry_run=dry_run,
                            appeal_text=appeal_text,
                            hide_rejected=hide_rejected,
                            stagger_appeals=stagger_appeals,
                            use_browser_fallback=use_browser_fallback,
                            only_account_ineligible=only_account_ineligible,
                            max_passes=max_passes,
                            quiet_window_sec=quiet_window_sec,
                            sort_to_folder=True,
                            raw_line_hint=raw_line,
                            status_cb=_upd_row_live,
                            stop_check_fn=lambda: self.stop_requested,
                            log_fn=self.log_fn,
                        )
                        res["row_id"] = row_id
                    except Exception as exc:
                        self.log_fn(f"[@{uname}] ❌ Ошибка: {exc}")
                        place_account_in_sorted_folder(
                            store=self.store,
                            folder_key="errors",
                            session_file=sf,
                            username=uname,
                            raw_line=raw_line,
                            verdict_label=f"❌ Ошибка: {str(exc)[:60]}",
                        )
                        res = {
                            "row_id": row_id,
                            "session_file": sf or row_id,
                            "username": uname,
                            "reg_country": "",
                            "current_region": login_region,
                            "idc_gateway": "",
                            "total_posts": 0,
                            "appeals_sent_total": 0,
                            "posts_hidden_total": 0,
                            "appealable_remaining": 0,
                            "reviewing_count": 0,
                            "failed_count": 0,
                            "verdict": "error",
                            "verdict_label": f"❌ Ошибка: {str(exc)[:60]}",
                            "folder_key": "errors",
                            "folder_title": APPEAL_FOLDER_SPECS["errors"]["title"],
                            "notices": [],
                            "flagged_posts": [],
                            "actions": [],
                            "checked_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        }

                    with self.lock:
                        for i_r, r in enumerate(self.rows):
                            if r.get("row_id") == row_id or r.get("session_file") == sf:
                                self.rows[i_r] = res
                                break
                        self.done_accounts += 1
                        self._recompute_kpis_unlocked()

                with concurrent.futures.ThreadPoolExecutor(max_workers=threads, thread_name_prefix="AppealWorker") as pool:
                    futs = [pool.submit(_one, i, wi) for i, wi in enumerate(work_items)]
                    concurrent.futures.wait(futs)

                with self.lock:
                    self.cycles_completed += 1
                    self._recompute_kpis_unlocked()
                    self._save_report_unlocked()

                self.log_fn(
                    f"🏁 Готово (проход #{self.cycles_completed})! Распределено по папкам -> "
                    f"✅ Чистые/Снято: {self.clean_accounts} | "
                    f"⏳ Огран/На проверке: {self.appealed_accounts} | "
                    f"🚨 Огран/Не снят: {self.restricted_accounts} | "
                    f"❌ Ошибки: {self.error_accounts}"
                )

                if self.mode != "watch":
                    break

                with self.lock:
                    if self.stop_requested:
                        break
                    nxt = dt.datetime.now() + dt.timedelta(minutes=self.interval_min)
                    self.next_run_at = nxt.strftime("%H:%M:%S")

                self.log_fn(f"🔁 Сторож: следующая авто-проверка через {self.interval_min} мин (в {self.next_run_at})")
                for _ in range(self.interval_min * 60):
                    if self.stop_requested:
                        break
                    time.sleep(1.0)
        finally:
            with self.lock:
                self.running = False
                self.next_run_at = ""
