"""
Multi-threaded Session Campaign & Configuration Preset Manager for Kintaro Studio:
  - Manages saved upload/cleanup/uniquifier presets (`config_presets.json`)
  - Manages server media library (`media/*`)
  - Runs multi-threaded campaigns across selected `sessions/*.json`:
      1) `upload`: Check/delete old posts -> switch Geo/Locale/Sticky Proxy -> upload N uniquified carousels with tags, music, app restarts, and auto-retry recovery
      2) `clean_only`: Delete all existing videos/photo posts across selected sessions in N threads (zero uploads)
      3) `restart_check`: Restart TikTok app & verify session health (`/v1/account/self`) in N threads
      4) `set_bio`: Bulk update bio across selected sessions in N threads
"""

from __future__ import annotations

import base64
import concurrent.futures
import datetime as dt
import json
import os
import re
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from auth_worker import (
    BASE_DIR,
    MEDIA_DIR,
    OUTPUT_DIR,
    SessionStore,
    delete_all_posts_for_session,
    extract_profile_summary,
    load_saved_config,
    parse_delay_range,
    publish_photo_carousel_for_session,
    restart_tiktok_app_for_session,
)
from auto_appeal import DEFAULT_APPEAL_TEXT, ensure_session_clean_loop
from kintaro_client import KintaroClient, allocate_sticky_proxy, apply_device_geo_profile, normalize_proxy
from photo_uniquifier import PRESET_DEFAULTS, UniquifierSettings, expand_spintax
from spy_and_autopilot import uniquify_mp4_bytes
from studio_tools import warmup_single_session_fyp


PRESETS_FILE = BASE_DIR / "config_presets.json"

GEO_LOCALE_DEFAULTS: Dict[str, str] = {
    "US": "en_US",
    "GB": "en_GB",
    "CA": "en_CA",
    "AU": "en_AU",
    "IT": "it_IT",
    "DE": "de_DE",
    "FR": "fr_FR",
    "ES": "es_ES",
    "BR": "pt_BR",
    "PT": "pt_PT",
    "MX": "es_MX",
    "CL": "es_CL",
    "AR": "es_AR",
    "CO": "es_CO",
    "PE": "es_PE",
    "PL": "pl_PL",
    "KZ": "ru_KZ",
    "UA": "uk_UA",
    "PH": "en_PH",
    "ID": "id_ID",
    "VN": "vi_VN",
}


DEFAULT_BUILTIN_PRESETS: List[Dict[str, Any]] = [
    {
        "id": "us_6posts_min_uniq",
        "name": "🇺🇸 US Перезалив — 6 постов (Мин. уник + Очистка старых + Fortnite)",
        "action_mode": "upload",
        "threads": 3,
        "max_retries": 4,
        "geo_mode": "override",
        "region": "US",
        "phone_region": "US",
        "app_locale": "en_US",
        "auto_sticky_proxy": True,
        "verify_proxy_geo": True,
        "delete_old_posts": True,
        "copies_count": 6,
        "delay_range": "10",
        "restart_every_n": 3,
        "description": "#piratetoken #piratetokenshop #blackknight #pirateshop #fyp",
        "randomize_tags": True,
        "auto_music_query": "Fortnite",
        "music_id": "",
        "is_private": False,
        "is_story": False,
        "disable_comments": False,
        "uniquify_photos": True,
        "uniquifier": dict(PRESET_DEFAULTS["minimal"]),
        "server_media_files": ["IMG_7620.jpeg", "IMG_7621.jpeg"],
    },
    {
        "id": "it_6posts_boosted",
        "name": "🇮🇹 Италия — 6 постов (Усиленный снег + Fortnite + 3 потока)",
        "action_mode": "upload",
        "threads": 3,
        "max_retries": 4,
        "geo_mode": "override",
        "region": "IT",
        "phone_region": "IT",
        "app_locale": "it_IT",
        "auto_sticky_proxy": True,
        "verify_proxy_geo": True,
        "delete_old_posts": True,
        "copies_count": 6,
        "delay_range": "10",
        "restart_every_n": 3,
        "description": "#piratetoken #piratetokenshop #blackknight #pirateshop #fyp",
        "randomize_tags": True,
        "auto_music_query": "Fortnite",
        "music_id": "",
        "is_private": False,
        "is_story": False,
        "disable_comments": False,
        "uniquify_photos": True,
        "uniquifier": dict(PRESET_DEFAULTS["boosted"]),
        "server_media_files": ["IMG_7620.jpeg", "IMG_7621.jpeg"],
    },
    {
        "id": "clean_only_fast",
        "name": "🗑 Только удаление старых видео (4 потока, без залива)",
        "action_mode": "clean_only",
        "threads": 4,
        "max_retries": 3,
        "geo_mode": "session",
        "region": "",
        "phone_region": "",
        "app_locale": "",
        "auto_sticky_proxy": True,
        "verify_proxy_geo": False,
        "delete_old_posts": True,
        "copies_count": 1,
        "delay_range": "10",
        "restart_every_n": 0,
        "description": "",
        "randomize_tags": False,
        "auto_music_query": "",
        "music_id": "",
        "is_private": False,
        "is_story": False,
        "disable_comments": False,
        "uniquify_photos": True,
        "uniquifier": dict(PRESET_DEFAULTS["minimal"]),
        "server_media_files": [],
    },
]


_PRESET_LOCK = threading.Lock()


def load_presets() -> List[Dict[str, Any]]:
    with _PRESET_LOCK:
        if PRESETS_FILE.exists():
            try:
                items = json.loads(PRESETS_FILE.read_text(encoding="utf-8"))
                if isinstance(items, list) and items:
                    return items
            except Exception:
                pass
        PRESETS_FILE.write_text(
            json.dumps(DEFAULT_BUILTIN_PRESETS, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        return list(DEFAULT_BUILTIN_PRESETS)


def save_preset(preset: Dict[str, Any]) -> List[Dict[str, Any]]:
    items = load_presets()
    pid = re.sub(r"[^a-zA-Z0-9_-]", "_", str(preset.get("id") or "")).strip("_")
    if not pid:
        pid = f"preset_{int(time.time())}"
    preset["id"] = pid
    preset["updated_at"] = dt.datetime.now(dt.timezone.utc).isoformat()

    replaced = False
    for idx, existing in enumerate(items):
        if existing.get("id") == pid:
            items[idx] = preset
            replaced = True
            break
    if not replaced:
        items.insert(0, preset)

    with _PRESET_LOCK:
        PRESETS_FILE.write_text(json.dumps(items, indent=2, ensure_ascii=False), encoding="utf-8")
    return items


def delete_preset(preset_id: str) -> List[Dict[str, Any]]:
    items = [p for p in load_presets() if p.get("id") != preset_id]
    if not items:
        items = list(DEFAULT_BUILTIN_PRESETS)
    with _PRESET_LOCK:
        PRESETS_FILE.write_text(json.dumps(items, indent=2, ensure_ascii=False), encoding="utf-8")
    return items


def list_media_library() -> List[Dict[str, Any]]:
    MEDIA_DIR.mkdir(parents=True, exist_ok=True)
    files: List[Dict[str, Any]] = []
    for fp in sorted(MEDIA_DIR.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
        ext = fp.suffix.lower()
        if fp.is_file() and ext in (".jpg", ".jpeg", ".png", ".webp", ".mp4"):
            st = fp.stat()
            files.append(
                {
                    "name": fp.name,
                    "kind": "video" if ext == ".mp4" else "photo",
                    "size_kb": round(st.st_size / 1024.0, 1),
                    "mtime": int(st.st_mtime),
                }
            )
    return files


def save_media_files(items: List[Dict[str, str]]) -> List[str]:
    MEDIA_DIR.mkdir(parents=True, exist_ok=True)
    saved_names: List[str] = []
    for idx, item in enumerate(items, start=1):
        raw_name = os.path.basename(item.get("name") or f"creative_{int(time.time())}_{idx}.jpg")
        safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", raw_name)
        if not safe_name.lower().endswith((".jpg", ".jpeg", ".png", ".mp4")):
            safe_name += ".jpg"
        durl = item.get("data_url") or ""
        b64part = durl.split(",", 1)[1] if "," in durl else durl
        raw_bytes = base64.b64decode(b64part)
        (MEDIA_DIR / safe_name).write_bytes(raw_bytes)
        saved_names.append(safe_name)
    return saved_names


def _pick_sticky_proxy(
    base_proxy: str,
    target_iso2: str,
    verify_geo: bool,
    log_fn: Callable[[str], None],
    tag: str,
    preserve_existing: bool = True,
) -> str:
    px = normalize_proxy(base_proxy)
    if not px:
        return ""
    if "bpproxy." not in px.lower():
        return px
    if px.startswith("http://") and ":1000" in px:
        px = "socks5://" + px[len("http://") :].replace(":1000", ":1002")

    iso = (target_iso2 or "US").upper().strip()
    if not verify_geo:
        return allocate_sticky_proxy(px, target_country=iso, lifetime="60m", preserve_existing_session=preserve_existing)

    # 1) Try keeping the account's EXISTING sticky session IP first so IP NEVER changes between login & upload!
    existing_cand = allocate_sticky_proxy(px, target_country=iso, lifetime="60m", preserve_existing_session=True)
    had_existing = bool(re.search(r"_session-[a-zA-Z0-9]+", px))

    for idx_try in range(10):
        cand = (
            existing_cand
            if (preserve_existing and had_existing and idx_try == 0)
            else allocate_sticky_proxy(px, target_country=iso, lifetime="60m", preserve_existing_session=False)
        )
        px_curl = cand.replace("socks5://", "socks5h://", 1)
        r1 = subprocess.run(
            ["curl", "-sS", "--max-time", "4", "-x", px_curl, "http://ip-api.com/json"],
            capture_output=True,
            text=True,
        )
        if r1.returncode != 0:
            continue
        try:
            info = json.loads(r1.stdout)
        except Exception:
            continue
        if info.get("countryCode") != iso:
            continue
        r2 = subprocess.run(
            [
                "curl",
                "-sS",
                "-o",
                "/dev/null",
                "-w",
                "%{http_code}",
                "--max-time",
                "4",
                "-x",
                px_curl,
                "https://www.tiktok.com/robots.txt",
            ],
            capture_output=True,
            text=True,
        )
        if r2.returncode == 0 and r2.stdout.strip().startswith(("2", "3")):
            if preserve_existing and had_existing and idx_try == 0:
                log_fn(f"[{tag}] 🔒 IP закреплён без смены ({iso}): {info.get('query')} ({info.get('city')})")
            else:
                log_fn(f"[{tag}] 🌐 Выделен и закреплён постоянный IP ({iso}, 60m): {info.get('query')} ({info.get('city')})")
            return cand
    return allocate_sticky_proxy(px, target_country=iso, lifetime="60m", preserve_existing_session=preserve_existing)


class CampaignState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.running: bool = False
        self.stop_requested: bool = False
        self.action_mode: str = "upload"
        self.total_accounts: int = 0
        self.done_accounts: int = 0
        self.success_accounts: int = 0
        self.failed_accounts: int = 0
        self.target_posts_per_account: int = 0
        self.published_posts_total: int = 0
        self.deleted_posts_total: int = 0
        self.appeals_sent_total: int = 0
        self.items: Dict[str, Dict[str, Any]] = {}
        self.ordered_keys: List[str] = []
        self.published_urls: List[str] = []

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            rows = [dict(self.items[k]) for k in self.ordered_keys if k in self.items]
            return {
                "running": self.running,
                "action_mode": self.action_mode,
                "total_accounts": self.total_accounts,
                "done_accounts": self.done_accounts,
                "success_accounts": self.success_accounts,
                "failed_accounts": self.failed_accounts,
                "target_posts_total": (
                    self.total_accounts * self.target_posts_per_account
                    if self.action_mode == "upload"
                    else 0
                ),
                "published_posts_total": self.published_posts_total,
                "deleted_posts_total": self.deleted_posts_total,
                "appeals_sent_total": self.appeals_sent_total,
                "published_urls": list(self.published_urls),
                "rows": rows,
            }


def run_campaign_background(
    camp_state: CampaignState,
    store: SessionStore,
    config_body: Dict[str, Any],
    log_fn: Callable[[str], None],
) -> None:
    api_key = (config_body.get("api_key") or "").strip()
    action_mode = (config_body.get("action_mode") or "upload").strip()
    threads = max(1, min(20, int(config_body.get("threads") or 3)))
    max_retries = max(1, min(6, int(config_body.get("max_retries") or 4)))

    geo_mode = (config_body.get("geo_mode") or "override").strip()
    override_region = (config_body.get("region") or "US").upper().strip()
    override_phone_region = (config_body.get("phone_region") or override_region).upper().strip()
    override_locale = (config_body.get("app_locale") or GEO_LOCALE_DEFAULTS.get(override_phone_region, "en_US")).strip()

    auto_sticky_proxy = bool(config_body.get("auto_sticky_proxy", True))
    verify_proxy_geo = bool(config_body.get("verify_proxy_geo", True))
    proxies_list = [
        ln.strip()
        for ln in (config_body.get("proxies_text") or "").splitlines()
        if ln.strip() and not ln.strip().startswith("#")
    ]
    saved_cfg = load_saved_config()
    fallback_proxy_template = (
        (proxies_list[0] if proxies_list else "")
        or saved_cfg.get("default_signup_proxy")
        or ""
    )

    delete_old_posts = bool(config_body.get("delete_old_posts", True))
    copies_count = max(1, min(30, int(config_body.get("copies_count") or 6)))
    d_min, d_max = parse_delay_range(config_body.get("delay_range"), default_min=14.0, default_max=20.0)
    restart_every_n = max(0, int(config_body.get("restart_every_n") if config_body.get("restart_every_n") is not None else 3))
    description = config_body.get("description") or ""
    randomize_tags = bool(config_body.get("randomize_tags", True))
    auto_music_query = (config_body.get("auto_music_query") or "").strip()
    music_id = (config_body.get("music_id") or "").strip()
    is_private = bool(config_body.get("is_private", False))
    is_story = bool(config_body.get("is_story", False))
    disable_comments = bool(config_body.get("disable_comments", False))
    bio_text = config_body.get("bio_text") or ""
    warmup_before_upload = bool(config_body.get("warmup_before_upload", False))
    warmup_videos_count = max(1, min(10, int(config_body.get("warmup_videos_count") or 3)))

    # Auto Appeal integration settings for Mass Upload
    auto_appeal_on_upload = bool(config_body.get("auto_appeal_on_upload", False))
    auto_appeal_pre_upload = bool(config_body.get("auto_appeal_pre_upload", True))
    auto_appeal_during_upload = bool(config_body.get("auto_appeal_during_upload", True))
    auto_appeal_post_upload = bool(config_body.get("auto_appeal_post_upload", True))
    auto_appeal_post_wait_sec = max(0, min(180, int(config_body.get("auto_appeal_post_wait_sec") if config_body.get("auto_appeal_post_wait_sec") is not None else 8)))
    auto_appeal_quiet_window_sec = max(0, min(300, int(config_body.get("auto_appeal_quiet_window_sec") if config_body.get("auto_appeal_quiet_window_sec") is not None else 60)))
    auto_appeal_max_passes = max(1, min(20, int(config_body.get("auto_appeal_max_passes") or 6)))
    auto_appeal_hide_rejected = bool(config_body.get("auto_appeal_hide_rejected", False))
    auto_appeal_text = str(config_body.get("auto_appeal_text") or DEFAULT_APPEAL_TEXT)

    content_type = (config_body.get("content_type") or "photo").strip()  # 'photo' | 'video'
    uniquify_photos = bool(config_body.get("uniquify_photos", True))
    uniq_settings_obj = UniquifierSettings.from_dict(
        config_body.get("uniquifier") if isinstance(config_body.get("uniquifier"), dict) else None,
        fallback_mode=str(config_body.get("uniquify_mode") or "minimal"),
    )
    uniq_dict = uniq_settings_obj.to_dict()

    # Prepare slide or MP4 video inputs for upload mode
    photos_input: List[Any] = []
    video_raw_bytes: Optional[bytes] = None
    video_fname: str = "creative.mp4"
    if action_mode == "upload":
        if content_type == "video":
            v_item = config_body.get("uploaded_video") or {}
            if v_item.get("data_url"):
                durl = str(v_item["data_url"])
                video_fname = str(v_item.get("name") or "creative.mp4")
                video_raw_bytes = base64.b64decode(durl.split(",", 1)[1] if "," in durl else durl)
            else:
                for mname in config_body.get("server_media_files") or []:
                    fp = MEDIA_DIR / os.path.basename(mname)
                    if fp.exists() and fp.suffix.lower() == ".mp4":
                        video_fname = fp.name
                        video_raw_bytes = fp.read_bytes()
                        break
        else:
            for item in config_body.get("uploaded_photos") or []:
                durl = item.get("data_url") or ""
                fname = item.get("name") or "slide.jpg"
                b64part = durl.split(",", 1)[1] if "," in durl else durl
                photos_input.append((fname, base64.b64decode(b64part)))
            if not photos_input:
                for mname in config_body.get("server_media_files") or []:
                    fp = MEDIA_DIR / os.path.basename(mname)
                    if fp.exists() and fp.suffix.lower() != ".mp4":
                        photos_input.append(str(fp))

    selected_files: List[str] = list(camp_state.ordered_keys)

    def _update_row(fname: str, **kwargs: Any) -> None:
        with camp_state.lock:
            row = camp_state.items.get(fname)
            if row is not None:
                row.update(kwargs)

    def _worker(idx: int, session_file: str) -> Dict[str, Any]:
        if idx < threads and threads > 1:
            time.sleep(idx * 1.1)

        with camp_state.lock:
            if camp_state.stop_requested:
                _update_row(session_file, status="cancelled", detail="Остановлено")
                camp_state.done_accounts += 1
                return {"session_file": session_file, "status": "cancelled"}

        sess = store.get_session(session_file)
        if not sess:
            _update_row(session_file, status="error", detail="Файл сессии не найден")
            with camp_state.lock:
                camp_state.done_accounts += 1
                camp_state.failed_accounts += 1
            return {"session_file": session_file, "status": "error", "error": "Session missing"}

        uname = sess.get("username") or sess.get("email") or session_file.replace(".json", "")
        tag = f"@{uname}"

        eff_region = override_region if geo_mode == "override" else (sess.get("region") or "US").upper()
        eff_phone_region = override_phone_region if geo_mode == "override" else (sess.get("phone_region") or eff_region).upper()
        eff_locale = override_locale if geo_mode == "override" else (sess.get("app_locale") or GEO_LOCALE_DEFAULTS.get(eff_phone_region, "en_US"))

        raw_px = (
            proxies_list[idx % len(proxies_list)]
            if proxies_list
            else (sess.get("proxy") or fallback_proxy_template)
        )
        px = (
            _pick_sticky_proxy(raw_px, eff_region, verify_proxy_geo, log_fn, tag, preserve_existing=True)
            if auto_sticky_proxy
            else normalize_proxy(raw_px)
        )
        if px:
            store.update_session_data(session_file, lambda d, _p=px: d.__setitem__("proxy", _p))

        try:
            # ---------------- MODE 1: CLEAN ONLY ----------------
            if action_mode == "clean_only":
                _update_row(session_file, status="running", detail="Удаление старых видео...")
                deleted_cnt = 0
                last_err = ""
                for attempt in range(1, max_retries + 1):
                    try:
                        if attempt > 1 and auto_sticky_proxy:
                            px = _pick_sticky_proxy(raw_px, eff_region, False, log_fn, tag)
                        # Temporarily update session proxy if rotated
                        if px:
                            store.update_session_data(session_file, lambda d, _p=px: d.__setitem__("proxy", _p))
                        deleted_cnt = delete_all_posts_for_session(
                            api_key=api_key,
                            session_filename=session_file,
                            store=store,
                            log_fn=log_fn,
                        )
                        last_err = ""
                        break
                    except Exception as c_exc:
                        last_err = str(c_exc)
                        log_fn(f"[{tag}] Повтор очистки ({attempt}/{max_retries}): {c_exc}")
                        time.sleep(1.5)
                if last_err:
                    raise RuntimeError(last_err)
                with camp_state.lock:
                    camp_state.deleted_posts_total += deleted_cnt
                    camp_state.done_accounts += 1
                    camp_state.success_accounts += 1
                _update_row(
                    session_file,
                    status="completed",
                    deleted=deleted_cnt,
                    detail=f"Удалено: {deleted_cnt} шт. (осталось 0)",
                )
                return {"session_file": session_file, "username": uname, "status": "completed", "deleted": deleted_cnt}

            # ---------------- MODE 2: RESTART & CHECK ----------------
            if action_mode == "restart_check":
                _update_row(session_file, status="running", detail="Перезапуск TikTok и проверка...")
                restart_tiktok_app_for_session(
                    api_key=api_key,
                    session_filename=session_file,
                    proxy_override=px,
                    store=store,
                    log_fn=log_fn,
                )
                with camp_state.lock:
                    camp_state.done_accounts += 1
                    camp_state.success_accounts += 1
                _update_row(session_file, status="completed", detail="Сессия активна, перезапущена")
                return {"session_file": session_file, "username": uname, "status": "completed"}

            # ---------------- MODE 3: BULK SET BIO ----------------
            if action_mode == "set_bio":
                _update_row(session_file, status="running", detail="Обновление БИО...")
                cur_s = store.get_session(session_file) or sess
                with KintaroClient(api_key=api_key) as kt:
                    _, upd_dev = kt.set_bio(
                        proxy=px or cur_s.get("proxy") or "",
                        device=cur_s.get("device") or cur_s.get("x_device"),
                        text=bio_text,
                    )

                def _ub(d: Dict[str, Any]) -> None:
                    d["signature"] = bio_text
                    if upd_dev is not None:
                        d["device"] = upd_dev

                store.update_session_data(session_file, _ub)
                log_fn(f"[{tag}] ✏️ БИО обновлено: {bio_text!r}")
                with camp_state.lock:
                    camp_state.done_accounts += 1
                    camp_state.success_accounts += 1
                _update_row(session_file, status="completed", detail=f"БИО: {bio_text[:28]}")
                return {"session_file": session_file, "username": uname, "status": "completed"}

            # ---------------- MODE 3B: BULK AUTO APPEAL ----------------
            if action_mode == "auto_appeal":
                _update_row(session_file, status="running", detail="🛡️ Проверка и снятие ограничений...")
                ap_res = ensure_session_clean_loop(
                    store=store,
                    session_file=session_file,
                    proxy_override=px,
                    dry_run=False,
                    appeal_text=auto_appeal_text,
                    hide_rejected=auto_appeal_hide_rejected,
                    stagger_appeals=True,
                    use_browser_fallback=True,
                    max_passes=auto_appeal_max_passes,
                    stop_check_fn=lambda: camp_state.stop_requested,
                    log_fn=log_fn,
                )
                sent_n = int(ap_res.get("appeals_sent_total") or 0)
                with camp_state.lock:
                    camp_state.appeals_sent_total += sent_n
                    camp_state.done_accounts += 1
                    camp_state.success_accounts += 1
                _update_row(
                    session_file,
                    status="completed",
                    appeals_sent=sent_n,
                    detail=f"{ap_res.get('verdict_label')} (отправлено: {sent_n})",
                )
                return {
                    "session_file": session_file,
                    "username": uname,
                    "status": "completed",
                    "appeals_sent": sent_n,
                    "auto_appeal": ap_res,
                }

            # ---------------- MODE 4: MASS CAROUSEL / VIDEO UPLOAD ----------------
            prior_post_ids = [str(p.get("aweme_id")) for p in (sess.get("posts") or []) if p.get("aweme_id")]
            _update_row(
                session_file,
                status="running",
                detail=f"Старт ({eff_region}/{eff_locale})...",
            )
            store.update_session_data(session_file, lambda d: d.__setitem__("posts", []))

            acc_appeals_sent = 0
            did_clean = False
            deleted_total_acc = 0

            # Pre-clean before pre-upload Auto-Appeal so we don't waste appeals on posts about to be deleted
            if auto_appeal_on_upload and auto_appeal_pre_upload and delete_old_posts:
                _update_row(session_file, status="running", detail="🗑 Очистка старых постов перед Auto-Appeal...")
                try:
                    deleted_total_acc += delete_all_posts_for_session(
                        api_key=api_key,
                        session_filename=session_file,
                        store=store,
                        log_fn=log_fn,
                    )
                    did_clean = True
                    with camp_state.lock:
                        camp_state.deleted_posts_total += deleted_total_acc
                except Exception as cl_exc:
                    log_fn(f"[{tag}] Предупреждение пред-очистки: {cl_exc}")

            if auto_appeal_on_upload and auto_appeal_pre_upload:
                _update_row(session_file, status="running", detail="🛡️ Пред-залив Auto-Appeal (снятие огранов)...")
                try:
                    pre_ap = ensure_session_clean_loop(
                        store=store,
                        session_file=session_file,
                        proxy_override=px,
                        dry_run=False,
                        appeal_text=auto_appeal_text,
                        hide_rejected=auto_appeal_hide_rejected,
                        stagger_appeals=True,
                        use_browser_fallback=True,
                        max_passes=auto_appeal_max_passes,
                        extra_post_ids=([] if did_clean else prior_post_ids),
                        stop_check_fn=lambda: camp_state.stop_requested,
                        log_fn=log_fn,
                    )
                    s_pre = int(pre_ap.get("appeals_sent_total") or 0)
                    acc_appeals_sent += s_pre
                    if s_pre > 0:
                        with camp_state.lock:
                            camp_state.appeals_sent_total += s_pre
                    _update_row(session_file, appeals_sent=acc_appeals_sent)
                except Exception as ap_pre_exc:
                    log_fn(f"[{tag}] ⚠️ Предупреждение пред-залив Auto-Appeal: {ap_pre_exc}")

            if warmup_before_upload:
                _update_row(session_file, status="running", detail=f"🔥 Прогрев FYP ({eff_region})...")
                try:
                    cur_s0 = store.get_session(session_file) or sess
                    with KintaroClient(api_key=api_key) as kt_w:
                        _, _, w_dev = warmup_single_session_fyp(
                            kt=kt_w,
                            proxy=px,
                            device=cur_s0.get("device") or cur_s0.get("x_device"),
                            region=eff_region,
                            videos_to_watch=warmup_videos_count,
                            like_prob_pct=35,
                            collect_prob_pct=15,
                            tag=tag,
                            log_fn=log_fn,
                        )
                    store.update_session_data(
                        session_file,
                        lambda d, _wd=w_dev: d.__setitem__("device", _wd) if _wd else None,
                    )
                except Exception as w_exc:
                    log_fn(f"[{tag}] Предупреждение прогрева перед заливом: {w_exc}")

            collected: List[Dict[str, Any]] = []
            prev_counted = 0

            for attempt in range(1, max_retries + 1):
                with camp_state.lock:
                    if camp_state.stop_requested:
                        break
                remaining = copies_count - len(collected)
                if remaining <= 0:
                    break

                if attempt > 1:
                    if auto_sticky_proxy:
                        # Keep the exact same IP (`preserve_existing=True`); only replaces if the IP went completely offline
                        px = _pick_sticky_proxy(px or raw_px, eff_region, verify_proxy_geo, log_fn, tag, preserve_existing=True)
                    log_fn(f"[{tag}] 🔄 Дозалив оставшихся {remaining} постов на том же IP (попытка {attempt}/{max_retries})...")
                    if restart_every_n > 0 and len(collected) > 0 and len(collected) % restart_every_n == 0:
                        try:
                            restart_tiktok_app_for_session(
                                api_key=api_key,
                                session_filename=session_file,
                                proxy_override=px,
                                store=store,
                                log_fn=log_fn,
                            )
                        except Exception:
                            pass

                do_clean_now = delete_old_posts and (not did_clean) and len(collected) == 0
                restart_n = restart_every_n if (restart_every_n > 0 and len(collected) == 0 and remaining > restart_every_n) else 0
                _update_row(
                    session_file,
                    status="running",
                    published=len(collected),
                    detail=f"Залив {len(collected)}/{copies_count} ({eff_region})...",
                )

                try:
                    if content_type == "video" and video_raw_bytes:
                        if do_clean_now:
                            d_cnt = delete_all_posts_for_session(
                                api_key=api_key, session_filename=session_file, store=store, log_fn=log_fn
                            )
                            deleted_total_acc += d_cnt
                            did_clean = True
                        import random as _rnd
                        with KintaroClient(api_key=api_key) as kt_vid:
                            cur_s_v = store.get_session(session_file) or sess
                            cur_dev_v = apply_device_geo_profile(
                                cur_s_v.get("device") or cur_s_v.get("x_device"),
                                eff_phone_region,
                                app_locale=eff_locale,
                            )
                            for c_idx in range(remaining):
                                v_bytes = uniquify_mp4_bytes(video_raw_bytes) if uniquify_photos else video_raw_bytes
                                v_desc = expand_spintax(description)
                                if randomize_tags:
                                    tags = re.findall(r"#[\w\d_]+", v_desc)
                                    plain = re.sub(r"#[\w\d_]+", "", v_desc).strip()
                                    _rnd.shuffle(tags)
                                    v_desc = f"{plain} {' '.join(tags)}".strip()
                                resp_v, upd_v = kt_vid.create_video_post(
                                    proxy=px,
                                    device=cur_dev_v,
                                    video=(video_fname, v_bytes),
                                    description=v_desc,
                                    music_id=music_id,
                                    region=eff_region,
                                    is_private=is_private,
                                    disable_comments=disable_comments,
                                    is_story=is_story,
                                )
                                if upd_v is not None:
                                    cur_dev_v = upd_v
                                aw = (resp_v.get("aweme") if isinstance(resp_v, dict) else None) or {}
                                aid_v = str(aw.get("aweme_id") or "")
                                v_url = f"https://www.tiktok.com/@{uname}/video/{aid_v}" if aid_v else ""
                                rec_v = {"aweme_id": aid_v, "url": v_url, "region": eff_region, "deleted_old_posts": 0}
                                store.update_session_data(
                                    session_file,
                                    lambda d, _r=rec_v, _dv=cur_dev_v: (
                                        d.setdefault("posts", []).insert(0, _r),
                                        d.__setitem__("device", _dv) if _dv else None,
                                    ),
                                )
                                log_fn(f"[{tag}] 🎬 Видео #{len(collected) + c_idx + 1}/{copies_count} опубликовано: {v_url}")
                                if c_idx < remaining - 1:
                                    t_vh = time.monotonic()
                                    if auto_appeal_on_upload and auto_appeal_during_upload and not camp_state.stop_requested:
                                        _update_row(
                                            session_file,
                                            published=len(collected) + c_idx + 1,
                                            detail=f"🛡️ Проверка огранов между постами ({len(collected) + c_idx + 1}/{copies_count})...",
                                        )
                                        try:
                                            mid_v = ensure_session_clean_loop(
                                                store=store,
                                                session_file=session_file,
                                                proxy_override=px,
                                                dry_run=False,
                                                appeal_text=auto_appeal_text,
                                                hide_rejected=auto_appeal_hide_rejected,
                                                stagger_appeals=True,
                                                use_browser_fallback=True,
                                                max_passes=2,
                                                quiet_window_sec=0.0,
                                                stop_check_fn=lambda: camp_state.stop_requested,
                                                log_fn=log_fn,
                                            )
                                            sv_mid = int(mid_v.get("appeals_sent_total") or 0)
                                            if sv_mid > 0:
                                                acc_appeals_sent += sv_mid
                                                with camp_state.lock:
                                                    camp_state.appeals_sent_total += sv_mid
                                                _update_row(session_file, appeals_sent=acc_appeals_sent)
                                        except Exception as mv_exc:
                                            log_fn(f"[{tag}] ⚠️ Предупреждение межпостовой проверки: {mv_exc}")
                                    rem_vp = max(0.0, _rnd.uniform(d_min, d_max) - (time.monotonic() - t_vh)) if d_max > 0 else 0.0
                                    if rem_vp > 0.2:
                                        time.sleep(rem_vp)
                    else:
                        def _mid_upload_appeal_hook(done_idx: int, cur_aweme_ids: List[str]) -> None:
                            nonlocal acc_appeals_sent
                            pub_now = len(collected) + done_idx
                            _update_row(
                                session_file,
                                status="running",
                                published=pub_now,
                                appeals_sent=acc_appeals_sent,
                                detail=f"Залито {pub_now}/{copies_count} ({eff_region})"
                                + (f" · 🛡️ Снято: {acc_appeals_sent}" if acc_appeals_sent > 0 else ""),
                            )
                            if not (auto_appeal_on_upload and auto_appeal_during_upload) or camp_state.stop_requested:
                                return
                            # Brief 3s settle so TikTok registers any immediate moderation notice on the post just uploaded
                            time.sleep(3.0)
                            if camp_state.stop_requested:
                                return
                            _update_row(
                                session_file,
                                status="running",
                                published=pub_now,
                                appeals_sent=acc_appeals_sent,
                                detail=f"🛡️ Межпостовая проверка огранов ({pub_now}/{copies_count})...",
                            )
                            mid_ids = list(cur_aweme_ids)
                            if not delete_old_posts:
                                for pid0 in prior_post_ids:
                                    if pid0 not in mid_ids:
                                        mid_ids.append(pid0)
                            mid_ap = ensure_session_clean_loop(
                                store=store,
                                session_file=session_file,
                                proxy_override=px,
                                dry_run=False,
                                appeal_text=auto_appeal_text,
                                hide_rejected=auto_appeal_hide_rejected,
                                stagger_appeals=True,
                                use_browser_fallback=True,
                                only_account_ineligible=bool(config_body.get("only_account_ineligible", True)),
                                max_passes=2,
                                quiet_window_sec=0.0,
                                sort_to_folder=False,
                                extra_post_ids=mid_ids,
                                stop_check_fn=lambda: camp_state.stop_requested,
                                log_fn=log_fn,
                            )
                            s_mid = int(mid_ap.get("appeals_sent_total") or 0)
                            if s_mid > 0:
                                acc_appeals_sent += s_mid
                                with camp_state.lock:
                                    camp_state.appeals_sent_total += s_mid
                            _update_row(
                                session_file,
                                status="running",
                                published=pub_now,
                                appeals_sent=acc_appeals_sent,
                                detail=f"Залив {pub_now}/{copies_count} ({eff_region})"
                                + (f" · 🛡️ Снято: {acc_appeals_sent}" if acc_appeals_sent > 0 else ""),
                            )

                        publish_photo_carousel_for_session(
                            api_key=api_key,
                            session_filename=session_file,
                            photos=photos_input,
                            description=description,
                            region=eff_region,
                            phone_region=eff_phone_region,
                            app_locale=eff_locale,
                            proxy_override=px,
                            delete_old_posts=do_clean_now,
                            randomize_tags=randomize_tags,
                            uniquify_photos=uniquify_photos,
                            uniquify_mode=uniq_settings_obj.mode,
                            uniquifier_settings=uniq_dict,
                            copies_count=remaining,
                            delay_min_sec=d_min,
                            delay_max_sec=d_max,
                            restart_every_n=restart_n,
                            music_id=music_id,
                            auto_music_query=auto_music_query,
                            is_private=is_private,
                            disable_comments=disable_comments,
                            is_story=is_story,
                            inter_post_hook=_mid_upload_appeal_hook,
                            store=store,
                            log_fn=log_fn,
                        )
                        did_clean = True
                except Exception as u_exc:
                    log_fn(f"[{tag}] ⚠️ Сбой на попытке #{attempt}: {u_exc}")
                    time.sleep(2.0)

                fresh = store.get_session(session_file) or {}
                collected = list(reversed(fresh.get("posts") or []))
                if collected:
                    did_clean = True
                newly_added = max(0, len(collected) - prev_counted)
                if newly_added > 0:
                    new_urls = [p.get("url") for p in collected[prev_counted:] if p.get("url")]
                    del_acc = sum(int(p.get("deleted_old_posts") or 0) for p in collected)
                    if del_acc > deleted_total_acc:
                        del_delta = del_acc - deleted_total_acc
                        deleted_total_acc = del_acc
                    else:
                        del_delta = 0
                    prev_counted = len(collected)
                    with camp_state.lock:
                        camp_state.published_posts_total += newly_added
                        camp_state.deleted_posts_total += del_delta
                        camp_state.published_urls.extend(new_urls)
                _update_row(
                    session_file,
                    published=len(collected),
                    deleted=deleted_total_acc,
                    last_url=(collected[-1].get("url") if collected else ""),
                )

            post_appeal_label = ""
            if auto_appeal_on_upload and auto_appeal_post_upload and not camp_state.stop_requested:
                if auto_appeal_post_wait_sec > 0 and collected:
                    _update_row(
                        session_file,
                        status="running",
                        detail=f"🛡️ Ожидание модерации ({auto_appeal_post_wait_sec}с) перед снятием огранов...",
                    )
                    log_fn(
                        f"[{tag}] ⏱ Ожидание {auto_appeal_post_wait_sec}с после залива, чтобы модерация TikTok проверила посты перед Auto-Appeal..."
                    )
                    for _ in range(auto_appeal_post_wait_sec):
                        if camp_state.stop_requested:
                            break
                        time.sleep(1.0)

                if not camp_state.stop_requested:
                    _update_row(
                        session_file,
                        status="running",
                        detail=f"🛡️ Пост-залив Auto-Appeal (тишина {auto_appeal_quiet_window_sec}с без новых огранов)...",
                    )
                    try:
                        new_post_ids = [str(p.get("aweme_id")) for p in collected if p.get("aweme_id")]
                        if not delete_old_posts:
                            for pid0 in prior_post_ids:
                                if pid0 not in new_post_ids:
                                    new_post_ids.append(pid0)

                        base_sent_before_post = acc_appeals_sent

                        def _post_st_cb(lbl: str, post_loop_sent: int) -> None:
                            _update_row(
                                session_file,
                                status="running",
                                published=len(collected),
                                appeals_sent=base_sent_before_post + post_loop_sent,
                                detail=lbl,
                            )

                        post_ap = ensure_session_clean_loop(
                            store=store,
                            session_file=session_file,
                            proxy_override=px,
                            dry_run=False,
                            appeal_text=auto_appeal_text,
                            hide_rejected=auto_appeal_hide_rejected,
                            stagger_appeals=True,
                            use_browser_fallback=True,
                            only_account_ineligible=bool(config_body.get("only_account_ineligible", True)),
                            max_passes=auto_appeal_max_passes,
                            quiet_window_sec=float(auto_appeal_quiet_window_sec),
                            poll_interval_sec=6.0,
                            extra_post_ids=new_post_ids,
                            sort_to_folder=True,
                            status_cb=_post_st_cb,
                            stop_check_fn=lambda: camp_state.stop_requested,
                            log_fn=log_fn,
                        )
                        s_post = int(post_ap.get("appeals_sent_total") or 0)
                        acc_appeals_sent += s_post
                        if s_post > 0:
                            with camp_state.lock:
                                camp_state.appeals_sent_total += s_post
                        post_appeal_label = f" | 📁 {post_ap.get('folder_title') or post_ap.get('verdict_label')}"
                    except Exception as ap_post_exc:
                        log_fn(f"[{tag}] ⚠️ Предупреждение пост-залив Auto-Appeal: {ap_post_exc}")

            ok = len(collected) == copies_count
            with camp_state.lock:
                camp_state.done_accounts += 1
                if ok:
                    camp_state.success_accounts += 1
                else:
                    camp_state.failed_accounts += 1

            appeal_suffix = (
                f" | 🛡️ Снято: {acc_appeals_sent}" if acc_appeals_sent > 0 else post_appeal_label
            )
            _update_row(
                session_file,
                status="completed" if ok else "partial",
                published=len(collected),
                deleted=deleted_total_acc,
                appeals_sent=acc_appeals_sent,
                last_url=(collected[-1].get("url") if collected else ""),
                detail=f"Готово: {len(collected)}/{copies_count} постов ({eff_region}){appeal_suffix}",
            )
            return {
                "session_file": session_file,
                "username": uname,
                "status": "completed" if ok else "partial",
                "published": len(collected),
                "deleted_old": deleted_total_acc,
                "appeals_sent": acc_appeals_sent,
                "posts": collected,
            }

        except Exception as exc:
            log_fn(f"[{tag}] ❌ Ошибка кампании: {exc}")
            with camp_state.lock:
                camp_state.done_accounts += 1
                camp_state.failed_accounts += 1
            _update_row(session_file, status="error", detail=str(exc)[:120])
            return {"session_file": session_file, "username": uname, "status": "error", "error": str(exc)}

    results: List[Dict[str, Any]] = []
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=threads, thread_name_prefix="CampWorker") as pool:
            futs = [pool.submit(_worker, i, sf) for i, sf in enumerate(selected_files)]
            for f in concurrent.futures.as_completed(futs):
                try:
                    results.append(f.result())
                except Exception as exc:
                    results.append({"status": "error", "error": str(exc)})
    finally:
        with camp_state.lock:
            camp_state.running = False
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        report_path = OUTPUT_DIR / "last_campaign_report.json"
        report_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
        log_fn(
            f"🏁 Кампания завершена! Аккаунтов успешно: {camp_state.success_accounts}/{camp_state.total_accounts} | "
            f"Опубликовано постов: {camp_state.published_posts_total} | Удалено старых: {camp_state.deleted_posts_total}"
            + (f" | 🛡️ Отправлено апелляций: {camp_state.appeals_sent_total}" if camp_state.appeals_sent_total else "")
        )
