#!/usr/bin/env python3
"""
Консольный софт (CLI) для входа в аккаунты TikTok (Логин+Пароль+TOTP и Почта+IMAP),
смены БИО и публикации фото-каруселей через Kintaro API.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import datetime as dt
import sys
import threading
from pathlib import Path
from typing import List, Optional

from auth_worker import (
    BASE_DIR,
    AccountTask,
    LoginOptions,
    PendingCodeChallenge,
    SessionStore,
    load_saved_config,
    parse_account_line,
    parse_delay_range,
    process_single_account,
    publish_photo_carousel_for_session,
    save_config,
)
from auto_appeal import DEFAULT_APPEAL_TEXT, AutoAppealManager, ensure_session_clean_loop
from greedy_sms_client import GreedySMSClient, get_static_country_catalog
from signup_worker import MobileSignupOptions, run_batch_mobile_signup


_print_lock = threading.Lock()
_input_lock = threading.Lock()


def console_log(msg: str) -> None:
    ts = dt.datetime.now().strftime("%H:%M:%S")
    with _print_lock:
        print(f"[{ts}] {msg}", flush=True)


def cli_manual_code_prompt(challenge: PendingCodeChallenge) -> Optional[str]:
    with _input_lock:
        print(
            f"\n>>> [{challenge.task.identifier}] Введите 6-значный код подтверждения "
            f"(Enter чтобы пропустить): ",
            end="",
            flush=True,
        )
        try:
            code = input().strip()
            return code or None
        except EOFError:
            return None


def read_nonempty_lines(path: Path) -> List[str]:
    if not path.exists():
        return []
    return [
        ln.strip()
        for ln in path.read_text(encoding="utf-8", errors="replace").splitlines()
        if ln.strip() and not ln.strip().startswith("#")
    ]


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Kintaro API — Вход (Логин+Пароль+TOTP / Почта+IMAP), смена БИО и Фото-постинг каруселью"
    )
    p.add_argument("--api-key", help="Ваш x-api-key от Kintaro API")
    p.add_argument(
        "--accounts",
        default=str(BASE_DIR / "accounts.txt"),
        help="Путь к файлу с аккаунтами (по умолчанию: accounts.txt)",
    )
    p.add_argument(
        "--proxies",
        default=str(BASE_DIR / "proxies.txt"),
        help="Путь к файлу с прокси (по умолчанию: proxies.txt)",
    )
    p.add_argument(
        "--mode",
        choices=["username_totp", "password_imap", "otp_only", "password_only"],
        default=None,
        help="Режим входа: username_totp (логин+пароль+TOTP), password_imap (почта+пароль+IMAP), otp_only (без пароля по коду), password_only",
    )
    p.add_argument("--region", default=None, help="Регион по умолчанию (например DE, US, VN, GB)")
    p.add_argument("--threads", type=int, default=None, help="Количество потоков (по умолчанию 3)")
    p.add_argument("--set-bio", default="", help="Сразу установить указанное БИО после входа")
    p.add_argument("--no-register-device", action="store_true", help="Отключить /v1/device/register")
    p.add_argument("--no-check-self", action="store_true", help="Отключить /v1/account/self после входа")
    p.add_argument("--imap-host", default=None, help="Принудительный IMAP сервер")
    p.add_argument("--imap-timeout", type=int, default=90, help="Таймаут ожидания письма с кодом (сек)")
    p.add_argument("--no-manual-code", action="store_true", help="Не запрашивать ручной ввод кода")

    # Photo Carousel CLI options
    p.add_argument(
        "--post-photos",
        nargs="+",
        help="Пути к 1..10 изображениям (.jpg/.png) для загрузки каруселью (/v1/post/create/photo)",
    )
    p.add_argument("--caption", default="", help="Описание и хэштеги поста (например '#kintaro')")
    p.add_argument(
        "--session",
        default="",
        help="Имя файла сессии из sessions/ для публикации фото-поста (например ukolywnj2me.json)",
    )
    p.add_argument("--music-id", default="", help="Опциональный music_id для фото-поста")
    p.add_argument("--music-query", default="Fortnite", help="Авто-подбор треков по запросу (напр. 'Fortnite' или 'recommended', '' = выкл)")
    p.add_argument("--post-proxy", default="", help="Опциональный прокси для залива поста (переопределяет прокси сессии)")
    p.add_argument("--copies", type=int, default=1, help="Сколько одинаковых постов подряд залить (1..30)")
    p.add_argument("--delay", default="10", help="Пауза между постами в сек, например '10', '30-50' или '60'")
    p.add_argument("--restart-every", type=int, default=0, help="Перезапускать приложение TikTok каждые N постов (напр. 3)")
    p.add_argument("--phone-region", default="", help="Гео телефона / SIM (напр. US или KZ)")
    p.add_argument("--locale", default="", help="Язык/локаль приложения (напр. en_US)")
    p.add_argument("--randomize-tags", action="store_true", help="Рандомизировать порядок тегов в каждом посте")
    p.add_argument("--uniquify-photos", action="store_true", help="Уникализация фото на каждый пост (лёгкий снег + рандомный микро-кроп)")
    p.add_argument("--delete-old-posts", action="store_true", help="Удалить все старые ролики/посты на аккаунте")

    # Mobile SMS Registration (Greedy SMS + Kintaro /v1/auth/signup/mobile + TOTP)
    p.add_argument("--greedy-key", default="", help="API ключ Greedy SMS (https://api.greedy-sms.com)")
    p.add_argument(
        "--list-sms-countries",
        action="store_true",
        help="Показать удобный список стран Greedy SMS с ценами и количеством номеров под TikTok",
    )
    p.add_argument(
        "--signup-mobile",
        type=int,
        default=0,
        help="Зарегистрировать N аккаунтов TikTok по номеру телефона через Greedy SMS (0 = выкл)",
    )
    p.add_argument(
        "--sms-country",
        default="",
        help="Страна номера для регистрации: ID, ISO2 или название (напр. 'CL', 'Чили', '151', 'IT', 'US')",
    )
    p.add_argument(
        "--sms-max-price",
        type=float,
        default=0.0,
        help="Максимальная цена покупки номера в рублях (по умолчанию 3.5 ₽)",
    )
    p.add_argument("--sms-timeout", type=int, default=110, help="Таймаут ожидания SMS-кода в сек (по умолчанию 110)")
    p.add_argument("--signup-password", default="", help="Фиксированный пароль при регистрации (пусто = авто-генерация)")
    p.add_argument("--signup-username-prefix", default="", help="Опциональный префикс username после регистрации")
    p.add_argument("--no-enable-totp", action="store_true", help="Не включать TOTP 2FA в конце регистрации (по умолчанию TOTP включается)")

    # Auto Appeal CLI options
    p.add_argument(
        "--appeal",
        choices=["audit", "unban", "watch"],
        default="",
        help="Режим Auto-Appeal: audit (проверить ограничения), unban (снять все ограничения до 0), watch (фоновый сторож)",
    )
    p.add_argument("--appeal-passes", type=int, default=6, help="Макс. число проходов дожима на аккаунт (по умолчанию 6)")
    p.add_argument("--appeal-quiet-sec", type=int, default=75, help="Окно тишины в секундах без новых огранов после залива (по умолчанию 75)")
    p.add_argument("--appeal-hide-rejected", action="store_true", help="Скрывать отклонённые посты (FAILED) в Private")
    p.add_argument("--appeal-text", default="", help="Текст апелляции (поддерживает спинтакс {a|b})")
    p.add_argument("--appeal-interval", type=int, default=15, help="Интервал проверки в минутах для --appeal watch")
    p.add_argument("--auto-appeal", action="store_true", help="Автоматически снимать все ограничения при заливе")
    return p


def main() -> int:
    args = build_parser().parse_args()
    cfg = load_saved_config()
    greedy_key = (args.greedy_key or cfg.get("greedy_api_key") or "").strip()

    if args.list_sms_countries:
        if greedy_key:
            save_config({"greedy_api_key": greedy_key})
            with GreedySMSClient(api_key=greedy_key) as gs:
                me = gs.get_me()
                print(f"Greedy SMS баланс: {me.get('balance')} ₽ | Скидка: {me.get('discount', {}).get('percent', 0)}%\n")
                items = gs.get_countries_catalog()
        else:
            items = get_static_country_catalog()
        print(f"{'ID':<5} {'ISO':<4} {'Код':<6} {'Страна':<34} {'Мин. цена':<12} {'Доступно шт.'}")
        print("-" * 78)
        for c in items[:60]:
            pr = f"{c.min_price:.2f} ₽" if c.min_price is not None else "—"
            print(f"{c.id:<5} {c.iso2:<4} +{c.dial_code:<5} {c.flag} {(c.rus + ' / ' + c.eng)[:30]:<31} {pr:<12} {c.total_count}")
        return 0

    store = SessionStore()

    if args.appeal:
        if args.session:
            s_files = [args.session]
        else:
            s_files = [
                s["filename"]
                for s in store.list_sessions()
                if (s.get("username") or "").lower() != "user6961737737217"
            ]
        if not s_files:
            print("Нет сохранённых сессий в папке sessions/.")
            return 1
        mgr = AutoAppealManager(store=store, log_fn=console_log)
        ok_st, msg_st = mgr.start(
            {
                "session_files": s_files,
                "mode": args.appeal,
                "threads": args.threads or 3,
                "max_passes": args.appeal_passes,
                "hide_rejected": args.appeal_hide_rejected,
                "appeal_text": args.appeal_text or DEFAULT_APPEAL_TEXT,
                "interval_min": args.appeal_interval,
                "proxies_text": args.post_proxy or "",
            }
        )
        if not ok_st:
            print(msg_st)
            return 1
        try:
            import time as _t
            while mgr.snapshot().get("running"):
                _t.sleep(1.0)
        except KeyboardInterrupt:
            mgr.stop()
        return 0

    api_key = (args.api_key or cfg.get("api_key") or "").strip()
    if not api_key:
        try:
            api_key = input("Введите ваш Kintaro x-api-key: ").strip()
        except EOFError:
            api_key = ""
    if not api_key:
        print("Ошибка: не указан x-api-key.")
        return 1

    save_config({"api_key": api_key})

    if args.signup_mobile and args.signup_mobile > 0:
        if not greedy_key:
            print("Ошибка: укажите --greedy-key для регистрации через Greedy SMS.")
            return 1
        country_sel = args.sms_country or cfg.get("sms_country_id") or 151
        max_price = args.sms_max_price if args.sms_max_price > 0 else float(cfg.get("sms_max_price") or 3.5)
        save_config({"greedy_api_key": greedy_key, "sms_max_price": max_price})

        proxies_list = read_nonempty_lines(Path(args.proxies))
        if args.post_proxy:
            proxies_list = [args.post_proxy]
        elif not proxies_list and cfg.get("default_signup_proxy"):
            proxies_list = [cfg["default_signup_proxy"]]
        if not proxies_list:
            print("Ошибка: укажите прокси в proxies.txt или через --post-proxy.")
            return 1

        s_opts = MobileSignupOptions(
            kintaro_api_key=api_key,
            greedy_api_key=greedy_key,
            country=country_sel,
            max_price=max_price,
            sms_timeout_sec=args.sms_timeout,
            enable_totp_at_end=not args.no_enable_totp,
            fixed_password=args.signup_password,
            username_prefix=args.signup_username_prefix,
            bio_after_signup=args.set_bio or "",
            count=args.signup_mobile,
            threads=args.threads or 1,
        )
        results = run_batch_mobile_signup(
            proxies=proxies_list,
            options=s_opts,
            store=store,
            log_fn=console_log,
        )
        ok_regs = [r for r in results if r.get("status") == "success"]
        console_log(f"Регистрация завершена: успешно {len(ok_regs)}/{len(results)}")
        for r in ok_regs:
            print(f"  => {r.get('account_line')}")
        return 0 if ok_regs else 1

    # Standalone photo carousel posting mode if --post-photos + --session given
    if args.post_photos and args.session:
        if args.auto_appeal:
            ensure_session_clean_loop(
                store=store,
                session_file=args.session,
                proxy_override=args.post_proxy,
                dry_run=False,
                appeal_text=args.appeal_text or DEFAULT_APPEAL_TEXT,
                hide_rejected=args.appeal_hide_rejected,
                max_passes=args.appeal_passes,
                log_fn=console_log,
            )
        d_min, d_max = parse_delay_range(args.delay, default_min=30.0, default_max=50.0)
        res = publish_photo_carousel_for_session(
            api_key=api_key,
            session_filename=args.session,
            photos=args.post_photos,
            description=args.caption,
            region=args.region or "",
            phone_region=args.phone_region or "",
            app_locale=args.locale or "",
            proxy_override=args.post_proxy,
            delete_old_posts=args.delete_old_posts,
            randomize_tags=args.randomize_tags,
            uniquify_photos=args.uniquify_photos,
            copies_count=args.copies,
            delay_min_sec=d_min,
            delay_max_sec=d_max,
            restart_every_n=args.restart_every,
            inter_post_hook=(
                (lambda _idx, _ids: ensure_session_clean_loop(
                    store=store,
                    session_file=args.session,
                    proxy_override=args.post_proxy,
                    dry_run=False,
                    appeal_text=args.appeal_text or DEFAULT_APPEAL_TEXT,
                    hide_rejected=args.appeal_hide_rejected,
                    max_passes=2,
                    quiet_window_sec=0.0,
                    extra_post_ids=_ids,
                    log_fn=console_log,
                ))
                if args.auto_appeal
                else None
            ),
            store=store,
            log_fn=console_log,
            music_id=args.music_id,
            auto_music_query=args.music_query,
        )
        console_log(f"Успешно опубликовано (region={res.get('region')}): {res['url']}")
        if args.auto_appeal:
            import time as _t
            console_log("⏱ Ожидание 12с модерации TikTok перед финальным контролем тишины...")
            _t.sleep(12.0)
            new_ids = [str(p.get("aweme_id")) for p in (res.get("all_posts") or []) if p.get("aweme_id")]
            ensure_session_clean_loop(
                store=store,
                session_file=args.session,
                proxy_override=args.post_proxy,
                dry_run=False,
                appeal_text=args.appeal_text or DEFAULT_APPEAL_TEXT,
                hide_rejected=args.appeal_hide_rejected,
                max_passes=args.appeal_passes,
                quiet_window_sec=float(args.appeal_quiet_sec),
                extra_post_ids=new_ids,
                log_fn=console_log,
            )
        return 0

    login_mode = args.mode or cfg.get("login_mode", "username_totp")
    region = (args.region or cfg.get("default_region", "DE")).upper()
    threads = args.threads or int(cfg.get("threads", 3))
    pre_register = False if args.no_register_device else bool(cfg.get("pre_register_device", True))
    check_self = False if args.no_check_self else bool(cfg.get("check_self_after_login", True))
    imap_host = args.imap_host if args.imap_host is not None else cfg.get("custom_imap_host", "")

    accounts_path = Path(args.accounts)
    proxies_path = Path(args.proxies)

    raw_accounts = read_nonempty_lines(accounts_path)
    if not raw_accounts:
        print(f"Файл аккаунтов пуст или не найден: {accounts_path}")
        return 1

    proxies_list = read_nonempty_lines(proxies_path)
    tasks: List[AccountTask] = []
    for idx, line in enumerate(raw_accounts, start=1):
        try:
            t = parse_account_line(line, login_mode=login_mode, default_region=region)
            if t:
                tasks.append(t)
        except ValueError as exc:
            console_log(f"Строка #{idx} пропущена: {exc}")

    if not tasks:
        print("Нет валидных аккаунтов для обработки.")
        return 1

    if any(not t.proxy for t in tasks) and not proxies_list:
        print(f"Ошибка: укажите прокси в {proxies_path} или через |proxy в строке аккаунта.")
        return 1

    allow_manual = not args.no_manual_code and threads == 1
    options = LoginOptions(
        api_key=api_key,
        login_mode=login_mode,
        default_region=region,
        threads=threads,
        pre_register_device=pre_register,
        check_self_after_login=check_self,
        delete_old_posts=args.delete_old_posts,
        bio_after_login=args.set_bio or "",
        custom_imap_host=imap_host,
        imap_timeout_sec=args.imap_timeout,
        allow_manual_code=allow_manual,
    )

    console_log(
        f"Запуск входа: аккаунтов={len(tasks)}, потоков={threads}, режим={login_mode}, регион={region}"
    )

    ok_count = 0
    err_count = 0
    logged_sessions: List[str] = []

    def _worker(index: int, task: AccountTask) -> dict:
        px = task.proxy or proxies_list[index % len(proxies_list)]
        return process_single_account(
            task=task,
            proxy_raw=px,
            options=options,
            store=store,
            log_fn=console_log,
            manual_code_callback=cli_manual_code_prompt if allow_manual else None,
        )

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, threads)) as pool:
        futures = [pool.submit(_worker, i, t) for i, t in enumerate(tasks)]
        for fut in concurrent.futures.as_completed(futures):
            try:
                res = fut.result()
                if res.get("status") == "success":
                    ok_count += 1
                    sf = (res.get("session") or {}).get("session_file")
                    if sf:
                        logged_sessions.append(sf)
                else:
                    err_count += 1
            except Exception as exc:
                err_count += 1
                console_log(f"Критическая ошибка потока: {exc}")

    if args.post_photos and logged_sessions:
        d_min, d_max = parse_delay_range(args.delay, default_min=10.0, default_max=10.0)
        def _post_worker(sf: str) -> None:
            try:
                publish_photo_carousel_for_session(
                    api_key=api_key,
                    session_filename=sf,
                    photos=args.post_photos,
                    description=args.caption,
                    region=args.region or "",
                    phone_region=args.phone_region or "",
                    app_locale=args.locale or "",
                    proxy_override=args.post_proxy,
                    randomize_tags=args.randomize_tags,
                    uniquify_photos=args.uniquify_photos,
                    copies_count=args.copies,
                    delay_min_sec=d_min,
                    delay_max_sec=d_max,
                    restart_every_n=args.restart_every,
                    store=store,
                    log_fn=console_log,
                    music_id=args.music_id,
                    auto_music_query=args.music_query,
                )
            except Exception as exc:
                console_log(f"Ошибка публикации фото на {sf}: {exc}")

        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, threads)) as post_pool:
            list(post_pool.map(_post_worker, logged_sessions))

    console_log(
        f"Готово! Успешно: {ok_count} | Ошибок: {err_count} | Сессии сохранены в {store.sessions_dir}"
    )
    return 0 if ok_count > 0 or err_count == 0 else 2


if __name__ == "__main__":
    sys.exit(main())
