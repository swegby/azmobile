import concurrent.futures
import json
import threading
import time
from pathlib import Path
from typing import Any, Dict, List

from auth_worker import SessionStore
from kintaro_client import KintaroClient, allocate_sticky_proxy
from signup_worker import prepare_signup_proxy

TARGETS = [
    "user7286585870062",
    "user905631263403",
    "user4715658974451",
    "user6208587207492",
    "user6008317253556",
    "user5135430850465",
    "ariel94205",
    "user9410879704149",
    "saktijeni",
    "user9932079381598",
]
EXCLUDED = {"user6961737737217"}

cfg = json.loads(Path("/home/user/kintaro_auth/config.json").read_text(encoding="utf-8"))
API_KEY = cfg["api_key"]
print_lock = threading.Lock()


def log(msg: str) -> None:
    with print_lock:
        print(msg, flush=True)


def clean_one_account(username: str) -> Dict[str, Any]:
    assert username not in EXCLUDED, f"Refusing to touch excluded account {username}"
    store = SessionStore()
    sess_file = f"{username}.json"
    sess = store.get_session(sess_file)
    if not sess:
        return {"username": username, "status": "error", "error": "Session file not found"}

    device = sess.get("device")
    region = (sess.get("region") or "IT").upper()
    raw_proxy = sess.get("proxy") or cfg.get("default_signup_proxy") or ""
    proxy = prepare_signup_proxy(raw_proxy, region, auto_match_country=True)

    recorded_ids = [
        str(p.get("aweme_id"))
        for p in (sess.get("posts") or [])
        if isinstance(p, dict) and p.get("aweme_id")
    ]

    deleted_ids: List[str] = []
    errors: List[str] = []

    with KintaroClient(api_key=API_KEY) as kt:
        # 1. Verify existing session via get_self (with sticky proxy retry on transient 500)
        self_ok = False
        for attempt in range(3):
            try:
                self_body, upd_dev = kt.get_self(proxy=proxy, device=device)
                if upd_dev is not None:
                    device = upd_dev
                self_ok = True
                log(f"[{username}] Сессия активна (region={region})")
                break
            except Exception as exc:
                log(f"[{username}] Повтор проверки сессии ({attempt + 1}/3): {exc}")
                proxy = allocate_sticky_proxy(raw_proxy, region, lifetime="30m")
                time.sleep(1.5)

        if not self_ok:
            return {"username": username, "status": "error", "error": "Session get_self failed after 3 proxy retries"}

        # 2. Collect all live aweme_ids from /v1/account/posts across pages + recorded_ids
        to_delete_ordered: List[str] = []
        seen = set()

        cursor = "0"
        for _ in range(10):
            try:
                posts_body, upd_dev = kt.get_self_posts(proxy=proxy, device=device, count=20, max_cursor=cursor)
                if upd_dev is not None:
                    device = upd_dev
            except Exception as exc:
                proxy = allocate_sticky_proxy(raw_proxy, region, lifetime="30m")
                posts_body, upd_dev = kt.get_self_posts(proxy=proxy, device=device, count=20, max_cursor=cursor)
                if upd_dev is not None:
                    device = upd_dev

            aweme_list = (posts_body.get("aweme_list") if isinstance(posts_body, dict) else None) or []
            for item in aweme_list:
                if isinstance(item, dict) and item.get("aweme_id"):
                    aid = str(item["aweme_id"])
                    if aid not in seen:
                        seen.add(aid)
                        to_delete_ordered.append(aid)

            has_more = bool(posts_body.get("has_more")) if isinstance(posts_body, dict) else False
            next_cursor = str(posts_body.get("max_cursor") or "0") if isinstance(posts_body, dict) else "0"
            if not has_more or next_cursor in ("0", cursor) or not aweme_list:
                break
            cursor = next_cursor

        for aid in recorded_ids:
            if aid not in seen:
                seen.add(aid)
                to_delete_ordered.append(aid)

        log(f"[{username}] Найдено постов/видео к удалению: {len(to_delete_ordered)} шт.")

        # 3. Delete each post (with retry if transient proxy error)
        for aid in to_delete_ordered:
            ok_del = False
            last_err = ""
            for d_try in range(3):
                try:
                    _, upd_dev = kt.delete_post(proxy=proxy, device=device, aweme_id=aid)
                    if upd_dev is not None:
                        device = upd_dev
                    deleted_ids.append(aid)
                    ok_del = True
                    log(f"[{username}] 🗑 Удалён пост {aid} ({len(deleted_ids)}/{len(to_delete_ordered)})")
                    break
                except Exception as dexc:
                    last_err = str(dexc)
                    if d_try < 2:
                        proxy = allocate_sticky_proxy(raw_proxy, region, lifetime="30m")
                        time.sleep(1.0)
            if not ok_del:
                errors.append(f"{aid}: {last_err}")
                log(f"[{username}] ⚠ Не удалось удалить {aid}: {last_err}")

        # 4. Verify 0 posts remain via /v1/account/posts (and clean any stragglers if any)
        time.sleep(1.5)
        remaining_ids: List[str] = []
        try:
            chk_body, upd_dev = kt.get_self_posts(proxy=proxy, device=device, count=20, max_cursor="0")
            if upd_dev is not None:
                device = upd_dev
            rem_list = (chk_body.get("aweme_list") if isinstance(chk_body, dict) else None) or []
            for item in rem_list:
                if isinstance(item, dict) and item.get("aweme_id"):
                    raid = str(item["aweme_id"])
                    try:
                        _, upd_dev2 = kt.delete_post(proxy=proxy, device=device, aweme_id=raid)
                        if upd_dev2 is not None:
                            device = upd_dev2
                        if raid not in deleted_ids:
                            deleted_ids.append(raid)
                        log(f"[{username}] 🗑 Доудалён оставшийся пост {raid}")
                    except Exception:
                        remaining_ids.append(raid)
        except Exception as vexc:
            log(f"[{username}] Предупреждение финальной проверки get_self_posts: {vexc}")

    # 5. Persist updated device + cleared posts list in session store
    def _upd(data: Dict[str, Any]) -> None:
        data["device"] = device
        data["proxy"] = proxy
        data["posts"] = [p for p in (data.get("posts") or []) if str(p.get("aweme_id")) in remaining_ids]

    store.update_session_data(sess_file, _upd)
    log(f"[{username}] ✅ Готово! Удалено: {len(deleted_ids)} шт. | Осталось: {len(remaining_ids)} шт.")

    return {
        "username": username,
        "status": "success" if not errors and not remaining_ids else "partial",
        "found_count": len(to_delete_ordered),
        "deleted_count": len(deleted_ids),
        "deleted_ids": deleted_ids,
        "remaining_count": len(remaining_ids),
        "errors": errors,
    }


def main() -> None:
    log(f"Запуск очистки по готовым сессиям для {len(TARGETS)} аккаунтов (исключён: user6961737737217, залив отключён)...")
    results: List[Dict[str, Any]] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        fut_map = {pool.submit(clean_one_account, u): u for u in TARGETS}
        for fut in concurrent.futures.as_completed(fut_map):
            u = fut_map[fut]
            try:
                results.append(fut.result())
            except Exception as exc:
                log(f"[{u}] Критическая ошибка: {exc}")
                results.append({"username": u, "status": "error", "error": str(exc)})

    order = {u: i for i, u in enumerate(TARGETS)}
    results.sort(key=lambda r: order.get(r["username"], 999))

    out_path = Path("/home/user/kintaro_auth/output/delete_10_accounts_results.json")
    out_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")

    print("\n================ ИТОГ ОЧИСТКИ ================")
    total_del = 0
    for r in results:
        dc = r.get("deleted_count", 0)
        total_del += dc
        print(
            f"@{r['username']:20s} | status={r['status']} | удалено={dc} шт. | осталось={r.get('remaining_count', '?')} шт."
        )
    print(f"Всего удалено постов: {total_del} шт. | user6961737737217: НЕ ТРОНУТ (пропущен по ТЗ)")


if __name__ == "__main__":
    main()
