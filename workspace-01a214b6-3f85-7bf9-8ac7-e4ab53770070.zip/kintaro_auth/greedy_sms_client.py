"""
Greedy SMS API v2 Client (https://api.greedy-sms.com)
Official OpenAPI 3.0.3 implementation for TikTok ("lf") mobile number activation,
country catalog with ISO-3166-1 alpha-2 & E.164 dialing codes, live pricing, and SMS polling.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union

import httpx


DEFAULT_GREEDY_BASE_URL = "https://api.greedy-sms.com"
TIKTOK_SERVICE_CODE = "lf"


def iso2_to_flag(iso2: str) -> str:
    """Converts a 2-letter ISO country code (e.g. 'CL') into its regional indicator flag emoji ('🇨🇱')."""
    code = (iso2 or "").upper().strip()
    if len(code) != 2 or not code.isalpha():
        return "🌐"
    return chr(0x1F1E6 + ord(code[0]) - ord("A")) + chr(0x1F1E6 + ord(code[1]) - ord("A"))


# Complete 195-country Greedy SMS ID -> (ISO2, E.164 dialing digits without '+', Russian name, English name)
GREEDY_COUNTRY_MAP: Dict[int, Tuple[str, str, str, str]] = {
    0: ("RU", "7", "Россия", "Russia"),
    1: ("UA", "380", "Украина", "Ukraine"),
    2: ("KZ", "7", "Казахстан", "Kazakhstan"),
    3: ("CN", "86", "Китай", "China"),
    4: ("PH", "63", "Филиппины", "Philippines"),
    5: ("MM", "95", "Мьянма", "Myanmar"),
    6: ("ID", "62", "Индонезия", "Indonesia"),
    7: ("MY", "60", "Малайзия", "Malaysia"),
    8: ("KE", "254", "Кения", "Kenya"),
    9: ("TZ", "255", "Танзания", "Tanzania"),
    10: ("VN", "84", "Вьетнам", "Vietnam"),
    11: ("KG", "996", "Кыргызстан", "Kyrgyzstan"),
    13: ("IL", "972", "Израиль", "Israel"),
    14: ("HK", "852", "Гонконг", "Hong Kong"),
    15: ("PL", "48", "Польша", "Poland"),
    16: ("GB", "44", "Великобритания", "United Kingdom"),
    17: ("MG", "261", "Мадагаскар", "Madagascar"),
    18: ("CD", "243", "Дем. Конго", "DR Congo"),
    19: ("NG", "234", "Нигерия", "Nigeria"),
    20: ("MO", "853", "Макао", "Macao"),
    21: ("EG", "20", "Египет", "Egypt"),
    22: ("IN", "91", "Индия", "India"),
    23: ("IE", "353", "Ирландия", "Ireland"),
    24: ("KH", "855", "Камбоджа", "Cambodia"),
    25: ("LA", "856", "Лаос", "Laos"),
    26: ("HT", "509", "Гаити", "Haiti"),
    27: ("CI", "225", "Кот д'Ивуар", "Ivory Coast"),
    28: ("GM", "220", "Гамбия", "Gambia"),
    29: ("RS", "381", "Сербия", "Serbia"),
    30: ("YE", "967", "Йемен", "Yemen"),
    31: ("ZA", "27", "ЮАР", "South Africa"),
    32: ("RO", "40", "Румыния", "Romania"),
    33: ("CO", "57", "Колумбия", "Colombia"),
    34: ("EE", "372", "Эстония", "Estonia"),
    35: ("AZ", "994", "Азербайджан", "Azerbaijan"),
    36: ("CA", "1", "Канада", "Canada"),
    37: ("MA", "212", "Марокко", "Morocco"),
    38: ("GH", "233", "Гана", "Ghana"),
    39: ("AR", "54", "Аргентина", "Argentina"),
    40: ("UZ", "998", "Узбекистан", "Uzbekistan"),
    41: ("CM", "237", "Камерун", "Cameroon"),
    42: ("TD", "235", "Чад", "Chad"),
    43: ("DE", "49", "Германия", "Germany"),
    44: ("LT", "370", "Литва", "Lithuania"),
    45: ("HR", "385", "Хорватия", "Croatia"),
    46: ("SE", "46", "Швеция", "Sweden"),
    47: ("IQ", "964", "Ирак", "Iraq"),
    48: ("NL", "31", "Нидерланды", "Netherlands"),
    49: ("LV", "371", "Латвия", "Latvia"),
    50: ("AT", "43", "Австрия", "Austria"),
    51: ("BY", "375", "Беларусь", "Belarus"),
    52: ("TH", "66", "Таиланд", "Thailand"),
    53: ("SA", "966", "Сауд. Аравия", "Saudi Arabia"),
    54: ("MX", "52", "Мексика", "Mexico"),
    55: ("TW", "886", "Тайвань", "Taiwan"),
    56: ("ES", "34", "Испания", "Spain"),
    57: ("IR", "98", "Иран", "Iran"),
    58: ("DZ", "213", "Алжир", "Algeria"),
    59: ("SI", "386", "Словения", "Slovenia"),
    60: ("BD", "880", "Бангладеш", "Bangladesh"),
    61: ("SN", "221", "Сенегал", "Senegal"),
    62: ("TR", "90", "Турция", "Turkey"),
    63: ("CZ", "420", "Чехия", "Czech"),
    64: ("LK", "94", "Шри-Ланка", "Sri Lanka"),
    65: ("PE", "51", "Перу", "Peru"),
    66: ("PK", "92", "Пакистан", "Pakistan"),
    67: ("NZ", "64", "Новая Зеландия", "New Zealand"),
    68: ("GN", "224", "Гвинея", "Guinea"),
    69: ("ML", "223", "Мали", "Mali"),
    70: ("VE", "58", "Венесуэла", "Venezuela"),
    71: ("ET", "251", "Эфиопия", "Ethiopia"),
    72: ("MN", "976", "Монголия", "Mongolia"),
    73: ("BR", "55", "Бразилия", "Brazil"),
    74: ("AF", "93", "Афганистан", "Afghanistan"),
    75: ("UG", "256", "Уганда", "Uganda"),
    76: ("AO", "244", "Ангола", "Angola"),
    77: ("CY", "357", "Кипр", "Cyprus"),
    78: ("FR", "33", "Франция", "France"),
    79: ("PG", "675", "Папуа-Новая Гвинея", "Papua"),
    80: ("MZ", "258", "Мозамбик", "Mozambique"),
    81: ("NP", "977", "Непал", "Nepal"),
    82: ("BE", "32", "Бельгия", "Belgium"),
    83: ("BG", "359", "Болгария", "Bulgaria"),
    84: ("HU", "36", "Венгрия", "Hungary"),
    85: ("MD", "373", "Молдова", "Moldova"),
    86: ("IT", "39", "Италия", "Italy"),
    87: ("PY", "595", "Парагвай", "Paraguay"),
    88: ("HN", "504", "Гондурас", "Honduras"),
    89: ("TN", "216", "Тунис", "Tunisia"),
    90: ("NI", "505", "Никарагуа", "Nicaragua"),
    91: ("TL", "670", "Тимор-Лесте", "Timor-Leste"),
    92: ("BO", "591", "Боливия", "Bolivia"),
    93: ("CR", "506", "Коста Рика", "Costa Rica"),
    94: ("GT", "502", "Гватемала", "Guatemala"),
    95: ("AE", "971", "ОАЭ", "UAE"),
    96: ("ZW", "263", "Зимбабве", "Zimbabwe"),
    97: ("PR", "1", "Пуэрто-Рико", "Puerto Rico"),
    98: ("SD", "249", "Судан", "Sudan"),
    99: ("TG", "228", "Того", "Togo"),
    100: ("KW", "965", "Кувейт", "Kuwait"),
    101: ("SV", "503", "Сальвадор", "Salvador"),
    102: ("LY", "218", "Ливия", "Libya"),
    103: ("JM", "1", "Ямайка", "Jamaica"),
    104: ("TT", "1", "Тринидад и Тобаго", "Trinidad and Tobago"),
    105: ("EC", "593", "Эквадор", "Ecuador"),
    106: ("SZ", "268", "Свазиленд", "Swaziland"),
    107: ("OM", "968", "Оман", "Oman"),
    108: ("BA", "387", "Босния и Герцеговина", "Bosnia"),
    109: ("DO", "1", "Доминиканская Республика", "Dominican Republic"),
    110: ("SY", "963", "Сирия", "Syria"),
    111: ("QA", "974", "Катар", "Qatar"),
    112: ("PA", "507", "Панама", "Panama"),
    113: ("CU", "53", "Куба", "Cuba"),
    114: ("MR", "222", "Мавритания", "Mauritania"),
    115: ("SL", "232", "Сьерра-Леоне", "Sierra Leone"),
    116: ("JO", "962", "Иордания", "Jordan"),
    117: ("PT", "351", "Португалия", "Portugal"),
    118: ("BB", "1", "Барбадос", "Barbados"),
    119: ("BI", "257", "Бурунди", "Burundi"),
    120: ("BJ", "229", "Бенин", "Benin"),
    121: ("BN", "673", "Бруней", "Brunei"),
    122: ("BS", "1", "Багамы", "Bahamas"),
    123: ("BW", "267", "Ботсвана", "Botswana"),
    124: ("BZ", "501", "Белиз", "Belize"),
    125: ("CF", "236", "ЦАР", "Central African Republic"),
    126: ("DM", "1", "Доминика", "Dominica"),
    127: ("GD", "1", "Гренада", "Grenada"),
    128: ("GE", "995", "Грузия", "Georgia"),
    129: ("GR", "30", "Греция", "Greece"),
    130: ("GW", "245", "Гвинея-Бисау", "Guinea-Bissau"),
    131: ("GY", "592", "Гайана", "Guyana"),
    132: ("IS", "354", "Исландия", "Iceland"),
    133: ("KM", "269", "Коморы", "Comoros"),
    134: ("KN", "1", "Сент-Китс и Невис", "Saint Kitts and Nevis"),
    135: ("LR", "231", "Либерия", "Liberia"),
    136: ("LS", "266", "Лесото", "Lesotho"),
    137: ("MW", "265", "Малави", "Malawi"),
    138: ("NA", "264", "Намибия", "Namibia"),
    139: ("NE", "227", "Нигер", "Niger"),
    140: ("RW", "250", "Руанда", "Rwanda"),
    141: ("SK", "421", "Словакия", "Slovakia"),
    142: ("SR", "597", "Суринам", "Suriname"),
    143: ("TJ", "992", "Таджикистан", "Tajikistan"),
    144: ("MC", "377", "Монако", "Monaco"),
    145: ("BH", "973", "Бахрейн", "Bahrain"),
    146: ("RE", "262", "Реюньон", "Reunion"),
    147: ("ZM", "260", "Замбия", "Zambia"),
    148: ("AM", "374", "Армения", "Armenia"),
    149: ("SO", "252", "Сомали", "Somalia"),
    150: ("CG", "242", "Конго", "Congo"),
    151: ("CL", "56", "Чили", "Chile"),
    152: ("BF", "226", "Буркина-Фасо", "Burkina Faso"),
    153: ("LB", "961", "Ливан", "Lebanon"),
    154: ("GA", "241", "Габон", "Gabon"),
    155: ("AL", "355", "Албания", "Albania"),
    156: ("UY", "598", "Уругвай", "Uruguay"),
    157: ("MU", "230", "Маврикий", "Mauritius"),
    158: ("BT", "975", "Бутан", "Bhutan"),
    159: ("MV", "960", "Мальдивы", "Maldives"),
    160: ("GP", "590", "Гваделупа", "Guadeloupe"),
    161: ("TM", "993", "Туркменистан", "Turkmenistan"),
    162: ("GF", "594", "Французская Гвиана", "French Guiana"),
    163: ("FI", "358", "Финляндия", "Finland"),
    164: ("LC", "1", "Сент-Люсия", "Saint Lucia"),
    165: ("LU", "352", "Люксембург", "Luxembourg"),
    166: ("VC", "1", "Сент-Винсент и Гренадин", "Saint Vincent and the Grenadines"),
    167: ("GQ", "240", "Экваториальная Гвинея", "Equatorial Guinea"),
    168: ("DJ", "253", "Джибути", "Djibouti"),
    169: ("AG", "1", "Антигуа и Барбуда", "Antigua and Barbuda"),
    170: ("KY", "1", "Острова Кайман", "Cayman Islands"),
    171: ("ME", "382", "Черногория", "Montenegro"),
    172: ("DK", "45", "Дания", "Denmark"),
    173: ("CH", "41", "Швейцария", "Switzerland"),
    174: ("NO", "47", "Норвегия", "Norway"),
    175: ("AU", "61", "Австралия", "Australia"),
    176: ("ER", "291", "Эритрея", "Eritrea"),
    177: ("SS", "211", "Южный Судан", "South Sudan"),
    178: ("ST", "239", "Сан-Томе и Принсипи", "Sao Tome and Principe"),
    179: ("AW", "297", "Аруба", "Aruba"),
    180: ("MS", "1", "Монтсеррат", "Montserrat"),
    181: ("AI", "1", "Ангилья", "Anguilla"),
    182: ("JP", "81", "Япония", "Japan"),
    183: ("MK", "389", "Северная Македония", "North Macedonia"),
    184: ("SC", "248", "Республика Сейшелы", "Seychelles"),
    185: ("NC", "687", "Новая Каледония", "New Caledonia"),
    186: ("CV", "238", "Кабо-Верде", "Cape Verde"),
    187: ("US", "1", "США", "USA"),
    188: ("PS", "970", "Палестина", "Palestine"),
    189: ("FJ", "679", "Фиджи", "Fiji"),
    196: ("SG", "65", "Сингапур", "Singapore"),
    198: ("WS", "685", "Самоа", "Samoa"),
    199: ("MT", "356", "Мальта", "Malta"),
    200: ("LI", "423", "Лихтенштейн", "Liechtenstein"),
    201: ("GI", "350", "Гибралтар", "Gibraltar"),
    203: ("XK", "383", "Косово", "Kosovo"),
    204: ("NU", "683", "Ниуэ", "Niue"),
}

# Pinned popular TikTok registration countries shown at top of UI selector
PRIORITY_COUNTRY_IDS: List[int] = [
    151,  # Chile (Чили)
    187,  # USA (США)
    86,   # Italy (Италия)
    43,   # Germany (Германия)
    16,   # UK (Великобритания)
    2,    # Kazakhstan (Казахстан)
    4,    # Philippines (Филиппины)
    6,    # Indonesia (Индонезия)
    73,   # Brazil (Бразилия)
    54,   # Mexico (Мексика)
    39,   # Argentina (Аргентина)
    33,   # Colombia (Колумбия)
    65,   # Peru (Перу)
    78,   # France (Франция)
    56,   # Spain (Испания)
    15,   # Poland (Польша)
    48,   # Netherlands (Нидерланды)
    36,   # Canada (Канада)
    10,   # Vietnam (Вьетнам)
    52,   # Thailand (Таиланд)
    7,    # Malaysia (Малайзия)
    1,    # Ukraine (Украина)
]


class GreedySMSError(Exception):
    """Raised when Greedy SMS API returns an error or activation failure."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        error_code: Optional[str] = None,
        retry_after: Optional[float] = None,
        response_data: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.retry_after = retry_after
        self.response_data = response_data


@dataclass
class GreedyCountryOption:
    id: int
    iso2: str
    dial_code: str
    rus: str
    eng: str
    flag: str
    min_price: Optional[float] = None
    total_count: int = 0
    affordable_count: int = 0
    retry: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "iso2": self.iso2,
            "dial_code": f"+{self.dial_code}",
            "rus": self.rus,
            "eng": self.eng,
            "flag": self.flag,
            "min_price": self.min_price,
            "total_count": self.total_count,
            "affordable_count": self.affordable_count,
            "retry": self.retry,
            "label": self.display_label(),
        }

    def display_label(self) -> str:
        price_part = f" — от {self.min_price:.2f} ₽ ({self.total_count} шт.)" if self.min_price is not None else ""
        return f"{self.flag} {self.rus} / {self.eng} [{self.iso2}, +{self.dial_code}]{price_part}"


@dataclass
class PurchasedActivation:
    activation_id: int
    raw_phone: str
    kintaro_mobile: str
    e164_phone: str
    price: float
    country: GreedyCountryOption


def resolve_greedy_country(query: Union[int, str]) -> GreedyCountryOption:
    """
    Resolves a Greedy SMS country by integer ID (`151`), ISO2 (`'CL'`),
    Russian name (`'Чили'`), or English name (`'Chile'`).
    """
    if isinstance(query, int) or (isinstance(query, str) and query.strip().isdigit()):
        cid = int(str(query).strip())
        if cid in GREEDY_COUNTRY_MAP:
            iso2, dial, rus, eng = GREEDY_COUNTRY_MAP[cid]
            return GreedyCountryOption(
                id=cid, iso2=iso2, dial_code=dial, rus=rus, eng=eng, flag=iso2_to_flag(iso2)
            )
        raise ValueError(f"Неизвестный ID страны Greedy SMS: {cid}")

    q = str(query or "").strip().lower()
    if not q:
        return resolve_greedy_country(151)

    # Exact ISO2 match first (e.g. "cl", "us", "it")
    for cid, (iso2, dial, rus, eng) in GREEDY_COUNTRY_MAP.items():
        if iso2.lower() == q:
            return GreedyCountryOption(
                id=cid, iso2=iso2, dial_code=dial, rus=rus, eng=eng, flag=iso2_to_flag(iso2)
            )

    # Exact name match
    for cid, (iso2, dial, rus, eng) in GREEDY_COUNTRY_MAP.items():
        if rus.lower() == q or eng.lower() == q:
            return GreedyCountryOption(
                id=cid, iso2=iso2, dial_code=dial, rus=rus, eng=eng, flag=iso2_to_flag(iso2)
            )

    # Substring match
    for cid, (iso2, dial, rus, eng) in GREEDY_COUNTRY_MAP.items():
        if q in rus.lower() or q in eng.lower():
            return GreedyCountryOption(
                id=cid, iso2=iso2, dial_code=dial, rus=rus, eng=eng, flag=iso2_to_flag(iso2)
            )

    raise ValueError(f"Страна не найдена в каталоге Greedy SMS: {query!r}")


def format_kintaro_mobile(raw_phone: str, country: GreedyCountryOption) -> Tuple[str, str]:
    """
    Converts Greedy SMS raw phone digits (e.g. '56973639762' for Chile +56)
    into:
      - `kintaro_mobile`: '+56 973639762' (matches Kintaro OpenAPI `+1 4445550099` format)
      - `e164_phone`: '+56973639762'
    """
    digits = re.sub(r"\D+", "", raw_phone or "")
    if not digits:
        raise ValueError(f"Пустой номер телефона от Greedy SMS: {raw_phone!r}")

    cc = country.dial_code
    if digits.startswith(cc) and len(digits) > len(cc) + 4:
        subscriber = digits[len(cc) :]
    else:
        # Fallback longest-prefix match across known dial codes
        matched_cc = cc
        subscriber = digits
        for _, cand_cc, _, _ in sorted(GREEDY_COUNTRY_MAP.values(), key=lambda x: len(x[1]), reverse=True):
            if digits.startswith(cand_cc) and len(digits) > len(cand_cc) + 4:
                matched_cc = cand_cc
                subscriber = digits[len(cand_cc) :]
                break
        cc = matched_cc

    return f"+{cc} {subscriber}", f"+{cc}{subscriber}"


def get_static_country_catalog() -> List[GreedyCountryOption]:
    """Returns all 195 countries sorted with priority countries first, then Russian alphabetical."""
    prio_rank = {cid: idx for idx, cid in enumerate(PRIORITY_COUNTRY_IDS)}
    items: List[GreedyCountryOption] = []
    for cid, (iso2, dial, rus, eng) in GREEDY_COUNTRY_MAP.items():
        items.append(
            GreedyCountryOption(
                id=cid, iso2=iso2, dial_code=dial, rus=rus, eng=eng, flag=iso2_to_flag(iso2)
            )
        )
    items.sort(key=lambda c: (0 if c.id in prio_rank else 1, prio_rank.get(c.id, 9999), c.rus.lower()))
    return items


class GreedySMSClient:
    """HTTP client for Greedy SMS API v2 (`https://api.greedy-sms.com`)."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_GREEDY_BASE_URL,
        timeout: float = 20.0,
    ) -> None:
        self.api_key = (api_key or "").strip()
        if not self.api_key:
            raise ValueError("Не указан API ключ Greedy SMS.")
        self.base_url = (base_url or DEFAULT_GREEDY_BASE_URL).rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=httpx.Timeout(timeout),
            follow_redirects=True,
            headers={
                "x-api-key": self.api_key,
                "Accept": "application/json",
            },
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "GreedySMSClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _raise_for_error(self, resp: httpx.Response) -> None:
        if 200 <= resp.status_code < 300:
            return
        retry_hdr = resp.headers.get("Retry-After")
        retry_after = float(retry_hdr) if retry_hdr and retry_hdr.replace(".", "", 1).isdigit() else None
        try:
            body = resp.json()
        except ValueError:
            body = resp.text
        err_code = None
        msg = f"HTTP {resp.status_code}"
        if isinstance(body, dict):
            err_code = str(body.get("errorCode") or body.get("code") or "")
            msg = str(body.get("message") or body.get("error") or body)
        elif isinstance(body, str) and body.strip():
            msg = body.strip()
        raise GreedySMSError(
            f"Greedy SMS ({resp.status_code}): {msg}",
            status_code=resp.status_code,
            error_code=err_code,
            retry_after=retry_after,
            response_data=body,
        )

    def get_me(self) -> Dict[str, Any]:
        """GET /users/getMe — Returns balance, discount, and activation stats."""
        resp = self._client.get("/users/getMe")
        self._raise_for_error(resp)
        return resp.json()

    def get_balance(self) -> float:
        data = self.get_me()
        return float(data.get("balance", 0.0))

    def get_countries_catalog(
        self,
        service: str = TIKTOK_SERVICE_CODE,
        affordable_cap: float = 10.0,
    ) -> List[GreedyCountryOption]:
        """
        Fetches live countries + TikTok ('lf') prices & stock counts from Greedy SMS
        and merges them with ISO2/dial-code metadata for UI & CLI country selection.
        """
        live_meta: Dict[int, Dict[str, Any]] = {}
        page = 1
        while page <= 10:
            rc = self._client.post("/activations/getCountries", json={"page": page, "pageSize": 100})
            self._raise_for_error(rc)
            dc = rc.json()
            for item in dc.get("countries", []):
                cid = int(item["id"])
                live_meta[cid] = item
            if page >= int(dc.get("totalPages", 1)):
                break
            page += 1

        price_map: Dict[int, Dict[str, Any]] = {}
        page = 1
        while page <= 10:
            rp = self._client.post(
                "/activations/getPrices",
                json={"service": service, "page": page, "pageSize": 100},
            )
            self._raise_for_error(rp)
            dp = rp.json()
            for c_entry in dp.get("countries", []):
                cid = int(c_entry["country"])
                svcs = c_entry.get("services") or []
                svc = next((s for s in svcs if s.get("name") == service), svcs[0] if svcs else None)
                if svc:
                    affordable = 0
                    for pr in svc.get("priceRange") or []:
                        if float(pr.get("price", 999999)) <= affordable_cap:
                            # Note: Greedy SMS `count` in priceRange is cumulative!
                            affordable = max(affordable, int(pr.get("count", 0)))
                    if affordable == 0 and float(svc.get("price", 999999)) <= affordable_cap:
                        affordable = int(svc.get("count", 0))
                    price_map[cid] = {
                        "min_price": float(svc.get("price", 0.0)),
                        "total_count": int(svc.get("count", 0)),
                        "affordable_count": affordable,
                    }
            if page >= int(dp.get("totalPages", 1)):
                break
            page += 1

        all_ids = set(GREEDY_COUNTRY_MAP.keys()) | set(live_meta.keys())
        prio_rank = {cid: idx for idx, cid in enumerate(PRIORITY_COUNTRY_IDS)}
        catalog: List[GreedyCountryOption] = []

        for cid in all_ids:
            iso2, dial, rus, eng = GREEDY_COUNTRY_MAP.get(cid, ("", "", f"Страна #{cid}", f"Country #{cid}"))
            lm = live_meta.get(cid)
            if lm and isinstance(lm.get("title"), dict):
                rus = lm["title"].get("rus") or rus
                eng = lm["title"].get("eng") or eng
            pm = price_map.get(cid, {})
            catalog.append(
                GreedyCountryOption(
                    id=cid,
                    iso2=iso2,
                    dial_code=dial,
                    rus=rus,
                    eng=eng,
                    flag=iso2_to_flag(iso2),
                    min_price=pm.get("min_price"),
                    total_count=pm.get("total_count", 0),
                    affordable_count=pm.get("affordable_count", 0),
                    retry=bool(lm.get("retry", True)) if lm else True,
                )
            )

        catalog.sort(
            key=lambda c: (
                0 if c.id in prio_rank else 1,
                prio_rank.get(c.id, 9999),
                0 if (c.total_count > 0 and c.min_price is not None) else 1,
                c.rus.lower(),
            )
        )
        return catalog

    def buy_number(
        self,
        country: Union[int, str, GreedyCountryOption],
        service: str = TIKTOK_SERVICE_CODE,
        max_price: Optional[float] = 5.0,
        provider_id: Optional[int] = None,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> PurchasedActivation:
        """
        POST /activations/getNumber — Purchases a virtual phone number for TikTok ('lf').
        Uses `max=True, maxPrice=max_price` when specified so overpriced providers (e.g. 20+ RUB) are skipped.
        """
        country_opt = country if isinstance(country, GreedyCountryOption) else resolve_greedy_country(country)
        payload: Dict[str, Any] = {
            "service": service,
            "country": int(country_opt.id),
            "verificationType": 1,
        }
        if max_price is not None and max_price > 0:
            payload["max"] = True
            payload["maxPrice"] = round(float(max_price), 2)
        if provider_id is not None:
            payload["providerId"] = int(provider_id)

        last_err: Optional[Exception] = None
        for attempt in range(4):
            resp = self._client.post("/activations/getNumber", json=payload)
            if resp.status_code == 200:
                data = resp.json()
                act_id = int(data["activationId"])
                raw_phone = str(data["phone"]).strip()
                price = float(data.get("price", 0.0))
                kintaro_mobile, e164_phone = format_kintaro_mobile(raw_phone, country_opt)
                return PurchasedActivation(
                    activation_id=act_id,
                    raw_phone=raw_phone,
                    kintaro_mobile=kintaro_mobile,
                    e164_phone=e164_phone,
                    price=price,
                    country=country_opt,
                )

            try:
                self._raise_for_error(resp)
            except GreedySMSError as exc:
                last_err = exc
                # Retry transient ACTIVATION_IN_PROGRESS or 429
                if exc.status_code in (409, 429, 502, 503) and (
                    "IN_PROGRESS" in (exc.error_code or "").upper()
                    or " progress" in str(exc).lower()
                    or exc.status_code in (429, 502, 503)
                ):
                    wait_s = min(10.0, max(2.0, exc.retry_after or 3.0))
                    if log_fn:
                        log_fn(f"[GreedySMS] Ожидание {wait_s:.1f}с перед повтором покупки ({exc})...")
                    time.sleep(wait_s)
                    continue
                raise

        raise last_err or GreedySMSError("Не удалось купить номер в Greedy SMS")

    def poll_code_once(
        self,
        activation_id: int,
        seen_codes: Optional[Set[str]] = None,
    ) -> Tuple[str, Optional[str]]:
        """
        Checks activation status once via both SMS-Activate compatible `/stubs/handler_api.php`
        and JSON `/activations/getStatus` + `/activations/getHistory` fallback.
        Returns `(state, code)`:
          - state in {"waiting", "code", "cancelled"}
        """
        seen = seen_codes or set()

        # 1) Fast compatible endpoint: returns `STATUS_WAIT_CODE`, `STATUS_OK:476307`, `STATUS_CANCEL`
        try:
            r_stub = self._client.get(
                "/stubs/handler_api.php",
                params={
                    "api_key": self.api_key,
                    "action": "getStatus",
                    "id": int(activation_id),
                },
            )
            if r_stub.status_code == 200:
                txt = r_stub.text.strip()
                if txt.startswith("STATUS_OK:"):
                    raw_part = txt.split(":", 1)[1].strip()
                    m = re.search(r"\b(\d{4,8})\b", raw_part)
                    code = m.group(1) if m else (raw_part if raw_part.isdigit() else None)
                    if code and code not in seen:
                        return "code", code
                elif txt in ("STATUS_CANCEL", "NO_ACTIVATION"):
                    return "cancelled", None
        except Exception:
            pass

        # 2) Native JSON `/activations/getStatus`
        try:
            r_json = self._client.post(
                "/activations/getStatus",
                json={"activationId": int(activation_id)},
            )
            if r_json.status_code == 200:
                st = str(r_json.json().get("status") or "").strip()
                low = st.lower()
                if "cancel" in low:
                    return "cancelled", None
                m = re.search(r"\b(\d{4,8})\b", st)
                if m and m.group(1) not in seen:
                    return "code", m.group(1)
        except Exception:
            pass

        # 3) Active history check (`sms: [{"code": "476307", "date": "..."}]`)
        try:
            r_hist = self._client.post(
                "/activations/getHistory",
                json={"active": True, "page": 1, "pageSize": 25},
            )
            if r_hist.status_code == 200:
                for item in r_hist.json().get("activations") or []:
                    if abs(int(item.get("id", 0))) == int(activation_id) or int(item.get("sourceId", 0)) == int(activation_id):
                        for sms_obj in reversed(item.get("sms") or []):
                            raw_c = str(sms_obj.get("code") or "")
                            m = re.search(r"\b(\d{4,8})\b", raw_c)
                            c = m.group(1) if m else (raw_c.strip() if raw_c.strip().isdigit() else None)
                            if c and c not in seen:
                                return "code", c
                        if "cancel" in str(item.get("status") or "").lower():
                            return "cancelled", None
        except Exception:
            pass

        return "waiting", None

    def wait_for_sms_code(
        self,
        activation_id: int,
        timeout_sec: int = 120,
        poll_interval: float = 3.0,
        seen_codes: Optional[Set[str]] = None,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> Optional[str]:
        """Polls Greedy SMS until a new verification code arrives or `timeout_sec` elapses."""
        deadline = time.monotonic() + max(15, int(timeout_sec))
        started = time.monotonic()
        next_progress_log = started + 15.0

        while time.monotonic() < deadline:
            state, code = self.poll_code_once(activation_id, seen_codes=seen_codes)
            if state == "code" and code:
                return code
            if state == "cancelled":
                if log_fn:
                    log_fn(f"[GreedySMS] Активация #{activation_id} была отменена провайдером.")
                return None

            now = time.monotonic()
            if log_fn and now >= next_progress_log:
                elapsed = int(now - started)
                log_fn(f"[GreedySMS] Ожидание SMS на активацию #{activation_id}... ({elapsed}с/{timeout_sec}с)")
                next_progress_log = now + 15.0

            time.sleep(poll_interval)

        return None

    def set_status(
        self,
        activation_id: int,
        status: str,
        log_fn: Optional[Callable[[str], None]] = None,
        allow_cooldown_wait: bool = True,
    ) -> bool:
        """
        POST /activations/setStatus — `status` in {'Cancel', 'Finish', 'NewCode'}.
        If `Cancel` hits provider early-cancel cooldown (`Retry-After`), waits up to 125s so balance is refunded.
        """
        for attempt in range(4):
            resp = self._client.post(
                "/activations/setStatus",
                json={"activationId": int(activation_id), "status": status},
            )
            if resp.status_code == 200:
                return True

            retry_hdr = resp.headers.get("Retry-After")
            retry_after = float(retry_hdr) if retry_hdr and retry_hdr.replace(".", "", 1).isdigit() else None

            if status == "Cancel" and allow_cooldown_wait and resp.status_code in (400, 409, 429):
                wait_s = retry_after if retry_after is not None else (35.0 if attempt == 0 else 30.0)
                if wait_s <= 130.0 and attempt < 3:
                    if log_fn:
                        log_fn(
                            f"[GreedySMS] Кулдаун отмены номера #{activation_id}: ждём {wait_s:.0f}с для возврата средств..."
                        )
                    time.sleep(wait_s + 1.0)
                    continue

            # Fallback via compatible handler_api (`8`=Cancel, `6`=Finish, `3`=NewCode)
            stub_map = {"Cancel": 8, "Finish": 6, "NewCode": 3}
            if status in stub_map:
                try:
                    rs = self._client.get(
                        "/stubs/handler_api.php",
                        params={
                            "api_key": self.api_key,
                            "action": "setStatus",
                            "id": int(activation_id),
                            "status": stub_map[status],
                        },
                    )
                    if rs.status_code == 200 and "ACCESS_" in rs.text:
                        return True
                except Exception:
                    pass
            return False
        return False

    def cancel_activation(
        self,
        activation_id: int,
        log_fn: Optional[Callable[[str], None]] = None,
        allow_cooldown_wait: bool = True,
    ) -> bool:
        return self.set_status(
            activation_id, "Cancel", log_fn=log_fn, allow_cooldown_wait=allow_cooldown_wait
        )

    def finish_activation(
        self,
        activation_id: int,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> bool:
        return self.set_status(
            activation_id, "Finish", log_fn=log_fn, allow_cooldown_wait=False
        )

    def request_new_code(
        self,
        activation_id: int,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> bool:
        return self.set_status(
            activation_id, "NewCode", log_fn=log_fn, allow_cooldown_wait=False
        )
