"""
Kintaro API v1 Python SDK (https://service.kintaroapi.com)
Official OpenAPI 3.0 implementation for Device, Username+TOTP Signin, Email Signin, and Account management.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import struct
import threading
import time
import urllib.parse
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import httpx

_REGISTER_DEVICE_LOCK = threading.Lock()


DEFAULT_BASE_URL = "https://service.kintaroapi.com"

# Phone SIM / Locale / Timezone profiles for switching device geo after login (e.g. DE account -> US phone post)
DEVICE_GEO_PROFILES: Dict[str, Dict[str, Any]] = {
    "US": {
        "locale": "en_US",
        "language": "en",
        "timezone": -5,
        "region": "US",
        "tz_name": "America/New_York",
        "tz_offset": -18000,
        "sim_region": "us",
        "mcc": "310",
        "mnc": "150",
        "mcc_region": "US",
        "carrier": "AT&T Wireless Inc.",
    },
    "GB": {
        "locale": "en_GB",
        "language": "en",
        "timezone": 0,
        "region": "GB",
        "tz_name": "Europe/London",
        "tz_offset": 0,
        "sim_region": "gb",
        "mcc": "234",
        "mnc": "15",
        "mcc_region": "GB",
        "carrier": "Vodafone UK",
    },
    "DE": {
        "locale": "de_DE",
        "language": "de",
        "timezone": 1,
        "region": "DE",
        "tz_name": "Europe/Berlin",
        "tz_offset": 3600,
        "sim_region": "de",
        "mcc": "262",
        "mnc": "01",
        "mcc_region": "DE",
        "carrier": "Telekom.de",
    },
    "FR": {
        "locale": "fr_FR",
        "language": "fr",
        "timezone": 1,
        "region": "FR",
        "tz_name": "Europe/Paris",
        "tz_offset": 3600,
        "sim_region": "fr",
        "mcc": "208",
        "mnc": "01",
        "mcc_region": "FR",
        "carrier": "Orange F",
    },
    "CA": {
        "locale": "en_CA",
        "language": "en",
        "timezone": -5,
        "region": "CA",
        "tz_name": "America/Toronto",
        "tz_offset": -18000,
        "sim_region": "ca",
        "mcc": "302",
        "mnc": "720",
        "mcc_region": "CA",
        "carrier": "Rogers",
    },
    "VN": {
        "locale": "vi_VN",
        "language": "vi",
        "timezone": 7,
        "region": "VN",
        "tz_name": "Asia/Ho_Chi_Minh",
        "tz_offset": 25200,
        "sim_region": "vn",
        "mcc": "452",
        "mnc": "04",
        "mcc_region": "VN",
        "carrier": "Viettel Mobile",
    },
    "KZ": {
        "locale": "kk_KZ",
        "language": "kk",
        "timezone": 5,
        "region": "KZ",
        "tz_name": "Asia/Aqtobe",
        "tz_offset": 18000,
        "sim_region": "kz",
        "mcc": "401",
        "mnc": "02",
        "mcc_region": "KZ",
        "carrier": "K-Cell",
    },
    "IT": {
        "locale": "it_IT",
        "language": "it",
        "timezone": 1,
        "region": "IT",
        "tz_name": "Europe/Rome",
        "tz_offset": 3600,
        "sim_region": "it",
        "mcc": "222",
        "mnc": "10",
        "mcc_region": "IT",
        "carrier": "Vodafone",
    },
    "CL": {
        "locale": "es_CL",
        "language": "es",
        "timezone": -3,
        "region": "CL",
        "tz_name": "America/Santiago",
        "tz_offset": -10800,
        "sim_region": "cl",
        "mcc": "730",
        "mnc": "01",
        "mcc_region": "CL",
        "carrier": "Entel PCS",
    },
    "BR": {
        "locale": "pt_BR",
        "language": "pt",
        "timezone": -3,
        "region": "BR",
        "tz_name": "America/Sao_Paulo",
        "tz_offset": -10800,
        "sim_region": "br",
        "mcc": "724",
        "mnc": "05",
        "mcc_region": "BR",
        "carrier": "Claro BR",
    },
    "MX": {
        "locale": "es_MX",
        "language": "es",
        "timezone": -6,
        "region": "MX",
        "tz_name": "America/Mexico_City",
        "tz_offset": -21600,
        "sim_region": "mx",
        "mcc": "334",
        "mnc": "020",
        "mcc_region": "MX",
        "carrier": "Telcel",
    },
    "AR": {
        "locale": "es_AR",
        "language": "es",
        "timezone": -3,
        "region": "AR",
        "tz_name": "America/Argentina/Buenos_Aires",
        "tz_offset": -10800,
        "sim_region": "ar",
        "mcc": "722",
        "mnc": "310",
        "mcc_region": "AR",
        "carrier": "Claro AR",
    },
    "CO": {
        "locale": "es_CO",
        "language": "es",
        "timezone": -5,
        "region": "CO",
        "tz_name": "America/Bogota",
        "tz_offset": -18000,
        "sim_region": "co",
        "mcc": "732",
        "mnc": "101",
        "mcc_region": "CO",
        "carrier": "Claro CO",
    },
    "PE": {
        "locale": "es_PE",
        "language": "es",
        "timezone": -5,
        "region": "PE",
        "tz_name": "America/Lima",
        "tz_offset": -18000,
        "sim_region": "pe",
        "mcc": "716",
        "mnc": "10",
        "mcc_region": "PE",
        "carrier": "Claro PE",
    },
    "PH": {
        "locale": "en_PH",
        "language": "en",
        "timezone": 8,
        "region": "PH",
        "tz_name": "Asia/Manila",
        "tz_offset": 28800,
        "sim_region": "ph",
        "mcc": "515",
        "mnc": "02",
        "mcc_region": "PH",
        "carrier": "Globe",
    },
    "ID": {
        "locale": "id_ID",
        "language": "id",
        "timezone": 7,
        "region": "ID",
        "tz_name": "Asia/Jakarta",
        "tz_offset": 25200,
        "sim_region": "id",
        "mcc": "510",
        "mnc": "10",
        "mcc_region": "ID",
        "carrier": "Telkomsel",
    },
    "ES": {
        "locale": "es_ES",
        "language": "es",
        "timezone": 1,
        "region": "ES",
        "tz_name": "Europe/Madrid",
        "tz_offset": 3600,
        "sim_region": "es",
        "mcc": "214",
        "mnc": "07",
        "mcc_region": "ES",
        "carrier": "Movistar",
    },
    "PL": {
        "locale": "pl_PL",
        "language": "pl",
        "timezone": 1,
        "region": "PL",
        "tz_name": "Europe/Warsaw",
        "tz_offset": 3600,
        "sim_region": "pl",
        "mcc": "260",
        "mnc": "03",
        "mcc_region": "PL",
        "carrier": "Orange PL",
    },
    "UA": {
        "locale": "uk_UA",
        "language": "uk",
        "timezone": 2,
        "region": "UA",
        "tz_name": "Europe/Kyiv",
        "tz_offset": 7200,
        "sim_region": "ua",
        "mcc": "255",
        "mnc": "03",
        "mcc_region": "UA",
        "carrier": "Kyivstar",
    },
}


def apply_device_geo_profile(
    device: Union[Dict[str, Any], str],
    target_region: str = "",
    app_locale: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Applies target SIM/Phone region parameters (e.g. `KZ` K-Cell SIM or `US` AT&T SIM)
    and optional `app_locale` (e.g. `en_US` -> `language='en', locale='en_US'`)
    to an authenticated `device` while preserving session tokens (`tt_token`, `sec_uid`, `cookies`, `guard`).
    """
    dev_dict: Dict[str, Any] = (
        dict(json.loads(device)) if isinstance(device, str) else dict(device)
    )
    reg = (target_region or "").upper().strip()
    if reg:
        if reg in DEVICE_GEO_PROFILES:
            dev_dict.update(DEVICE_GEO_PROFILES[reg])
        else:
            dev_dict["region"] = reg
            dev_dict["sim_region"] = reg.lower()
            dev_dict["mcc_region"] = reg
    if app_locale and app_locale.strip():
        loc = app_locale.strip().replace("-", "_")
        lang = loc.split("_", 1)[0].lower()
        if "_" not in loc:
            loc = f"{lang}_{reg or 'US'}"
        else:
            p1, p2 = loc.split("_", 1)
            loc = f"{p1.lower()}_{p2.upper()}"
        dev_dict["language"] = lang
        dev_dict["locale"] = loc
    return dev_dict


def swap_proxy_country(proxy: str, target_country: str) -> str:
    """
    If a rotating residential proxy URL embeds a country selector (e.g. `_country-US`, `-country-US`,
    `country-US`, `cc-US`), returns a copy targeting `target_country` (e.g. `_country-DE` for domestic login).
    """
    cc = (target_country or "").upper().strip()
    if not proxy or not cc:
        return proxy
    patterns = [
        (r"([_-]country[_-])([A-Za-z]{2})(?=$|[^A-Za-z])", rf"\g<1>{cc}"),
        (r"(\bcountry[_-])([A-Za-z]{2})(?=$|[^A-Za-z])", rf"\g<1>{cc}"),
        (r"([_-]cc[_-])([A-Za-z]{2})(?=$|[^A-Za-z])", rf"\g<1>{cc}"),
    ]
    for pat, repl in patterns:
        updated, count = re.subn(pat, repl, proxy, flags=re.IGNORECASE)
        if count > 0:
            return updated
    return proxy


def allocate_sticky_proxy(
    proxy: str,
    target_country: str = "",
    lifetime: str = "60m",
    preserve_existing_session: bool = False,
) -> str:
    """
    For rotating residential proxies like `bpproxy.at` (`..._country-XX@...`), pins an
    8-char sticky session (`_session-xxxxxxxx_lifetime-60m`) so `register_device`, `signin`,
    uploads, and Auto-Appeal all exit from the EXACT same residential IP without mid-flow rotation.
    If `preserve_existing_session=True` and `proxy` already carries a `_session-...` for the same
    country, keeps the existing session token so the IP never changes.
    """
    if not proxy or "bpproxy." not in proxy.lower():
        return swap_proxy_country(proxy, target_country) if target_country else proxy

    if preserve_existing_session and re.search(r"_session-[a-zA-Z0-9]+", proxy):
        m_cc = re.search(r"[_-]country[_-]([A-Za-z]{2})(?=$|[^A-Za-z])", proxy, flags=re.IGNORECASE)
        cur_cc = m_cc.group(1).upper() if m_cc else ""
        req_cc = (target_country or "").strip().upper()
        if not req_cc or cur_cc == req_cc:
            return proxy

    px = swap_proxy_country(proxy, target_country) if target_country else proxy
    import secrets

    alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
    sid = "".join(secrets.choice(alphabet) for _ in range(8))
    px_clean = re.sub(r"_session-[a-zA-Z0-9]+(?:_lifetime-[a-zA-Z0-9]+)?", "", px)
    return re.sub(
        r"(_country-[A-Za-z]{2})",
        rf"\1_session-{sid}_lifetime-{lifetime}",
        px_clean,
        count=1,
    )


def is_valid_base32_totp(secret: Optional[str]) -> bool:
    """Checks whether a string is a valid RFC 4648 Base32 TOTP secret (`A-Z2-7`)."""
    if not secret:
        return False
    clean = re.sub(r"\s+", "", secret).upper()
    if len(clean) < 16:
        return False
    return bool(re.fullmatch(r"[A-Z2-7]+=*", clean))


class KintaroAPIError(Exception):
    """Raised when Kintaro API returns a transport or unexpected HTTP error."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_data: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data


def generate_totp_code(secret_b32: str, timestamp: Optional[float] = None) -> str:
    """Generates a 6-digit RFC 6238 TOTP code from a Base32 secret."""
    clean = re.sub(r"\s+", "", (secret_b32 or "")).upper()
    if not clean:
        raise ValueError("Пустой TOTP ключ")
    pad = (-len(clean)) % 8
    key = base64.b32decode(clean + ("=" * pad), casefold=True)
    ts = time.time() if timestamp is None else timestamp
    counter = int(ts // 30)
    msg = struct.pack(">Q", counter)
    digest = hmac.new(key, msg, hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = (struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF) % 1000000
    return f"{code:06d}"


def wait_for_fresh_totp_window(
    min_remaining_sec: float = 19.0,
    log_fn: Optional[Callable[[str], None]] = None,
) -> float:
    """
    Waits if the current 30s TOTP window has fewer than `min_remaining_sec` seconds left,
    preventing TOTP expiration mid-flight while Kintaro's server executes mobile requests.
    """
    rem = 30.0 - (time.time() % 30.0)
    if rem < min_remaining_sec:
        wait_s = rem + 0.4
        if log_fn:
            log_fn(f"Синхронизация окна TOTP: ждём {wait_s:.1f}с до нового 30-сек кода...")
        time.sleep(wait_s)
    return 30.0 - (time.time() % 30.0)


def detect_home_region_from_403(body: Any, current_region: str) -> Optional[str]:
    """
    Inspects a 403 `suspicious_login` response (`error_code: 2135`) for TikTok's `api_domain`
    hint (e.g. `api16-normal-no1a.tiktokv.eu`) and maps it to a matching device region so
    re-registering the device avoids IDC mismatch (`suspicious_login`) and allows clean TOTP login.
    """
    if not isinstance(body, dict):
        return None
    raw = json.dumps(body, ensure_ascii=False)
    decoded = urllib.parse.unquote(raw).lower()

    cur = (current_region or "").upper()
    eu_regions = {"DE", "GB", "FR", "IT", "ES", "PL", "NL"}
    us_regions = {"US"}
    asia_regions = {"VN", "SG", "MY", "TH", "ID", "PH", "JP", "KR"}

    if "tiktokv.eu" in decoded or "no1a" in decoded or "euw" in decoded:
        if cur not in eu_regions:
            return "DE"
    elif "useast" in decoded or "tiktokv.us" in decoded:
        if cur not in us_regions:
            return "US"
    elif "alisg" in decoded:
        if cur not in asia_regions:
            return "SG"
    elif "maliva" in decoded:
        if cur not in (eu_regions | {"BR", "CA", "AU"}):
            return "GB"
    return None


def normalize_proxy(proxy_raw: str, default_scheme: str = "http") -> str:
    """
    Normalizes common proxy string formats into Kintaro's required `x-proxy` header format:
        protocol://user:pass@host:port
    """
    s = (proxy_raw or "").strip()
    if not s:
        raise ValueError("Прокси не указан (заголовок x-proxy обязателен в Kintaro API).")

    scheme = default_scheme
    if "://" in s:
        scheme, s = s.split("://", 1)
        scheme = scheme.lower().strip()
        if scheme == "socks5h":
            scheme = "socks5"

    if "@" in s:
        auth, hostport = s.rsplit("@", 1)
        return f"{scheme}://{auth}@{hostport}"

    parts = s.split(":")
    if len(parts) == 2:
        host, port = parts
        return f"{scheme}://{host}:{port}"
    if len(parts) == 4:
        p0, p1, p2, p3 = parts
        if p1.isdigit() and not p3.isdigit():
            return f"{scheme}://{p2}:{p3}@{p0}:{p1}"
        if p3.isdigit() and not p1.isdigit():
            return f"{scheme}://{p0}:{p1}@{p2}:{p3}"
        return f"{scheme}://{p2}:{p3}@{p0}:{p1}"

    return f"{scheme}://{s}"


def extract_country_from_proxy(proxy_raw: str) -> Optional[str]:
    """Detects country hints like `country-VN` or `-country-de` inside proxy credentials if present."""
    m = re.search(r"country[-_]([a-zA-Z]{2})\b", proxy_raw or "", flags=re.IGNORECASE)
    if m:
        return m.group(1).upper()
    return None


def serialize_device_header(device: Union[str, Dict[str, Any]]) -> str:
    """Serializes device dict/string into pure ASCII compact JSON safe for HTTP headers."""
    if isinstance(device, str):
        stripped = device.strip()
        if not stripped:
            raise ValueError("Пустой x-device")
        try:
            parsed = json.loads(stripped)
            return json.dumps(parsed, separators=(",", ":"), ensure_ascii=True)
        except json.JSONDecodeError:
            return stripped.encode("ascii", errors="backslashreplace").decode("ascii")

    if isinstance(device, dict):
        return json.dumps(device, separators=(",", ":"), ensure_ascii=True)

    raise TypeError(f"Неподдерживаемый тип device: {type(device)}")


def extract_device_from_response(
    headers: httpx.Headers,
    body: Any,
    fallback_device: Optional[Union[Dict[str, Any], str]] = None,
    is_register_endpoint: bool = False,
) -> Optional[Union[Dict[str, Any], str]]:
    hdr_dev = headers.get("x-device")
    if hdr_dev:
        try:
            return json.loads(hdr_dev)
        except json.JSONDecodeError:
            return hdr_dev

    if isinstance(body, dict):
        for key in ("device", "x-device", "x_device"):
            val = body.get(key)
            if isinstance(val, dict) and val:
                return val
            if isinstance(val, str) and val.strip():
                try:
                    return json.loads(val)
                except json.JSONDecodeError:
                    return val

        data_sub = body.get("data")
        if isinstance(data_sub, dict):
            for key in ("device", "x-device", "x_device"):
                val = data_sub.get(key)
                if isinstance(val, dict) and val:
                    return val
                if isinstance(val, str) and val.strip():
                    try:
                        return json.loads(val)
                    except json.JSONDecodeError:
                        return val

        if is_register_endpoint:
            device_markers = {
                "device_id",
                "install_id",
                "iid",
                "cdid",
                "openudid",
                "device_model",
                "device_brand",
                "os_version",
            }
            if isinstance(data_sub, dict) and (device_markers & set(data_sub.keys())):
                return data_sub
            if device_markers & set(body.keys()):
                return body
            if body and "error" not in body:
                return body

    if isinstance(fallback_device, str):
        try:
            return json.loads(fallback_device)
        except json.JSONDecodeError:
            return fallback_device
    return fallback_device


def extract_verify_from_response(body: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(body, dict):
        return None
    if isinstance(body.get("verify"), dict):
        return body["verify"]
    data = body.get("data")
    if isinstance(data, dict) and isinstance(data.get("verify"), dict):
        return data["verify"]
    return None


def extract_error_message(body: Any, status_code: int) -> str:
    if isinstance(body, dict):
        for key in ("error", "detail", "msg", "description"):
            val = body.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
        data = body.get("data")
        if isinstance(data, dict):
            err_code = data.get("error_code")
            desc = data.get("description") or data.get("prompts") or ""
            if err_code and desc:
                return f"TikTok error_code={err_code}: {desc}"
            if err_code:
                return f"TikTok error_code={err_code}"
            if desc:
                return str(desc)
        msg = body.get("message")
        if isinstance(msg, str) and msg.strip() and msg != "error":
            return msg.strip()
        return json.dumps(body, ensure_ascii=False)[:400]
    if isinstance(body, str) and body.strip():
        return body.strip()[:400]
    return f"HTTP {status_code}"


@dataclass
class AuthStepResult:
    """Unified result of a Kintaro authentication request."""

    status: str  # "success" | "code_required" | "error"
    http_status: int
    device: Optional[Union[Dict[str, Any], str]] = None
    verify: Optional[Dict[str, Any]] = None
    response: Any = None
    message: str = ""
    elapsed_ms: int = 0
    detected_region: Optional[str] = None

    def device_json(self) -> Optional[str]:
        if self.device is None:
            return None
        return serialize_device_header(self.device)


class KintaroClient:
    """Synchronous HTTP client for Kintaro API (`https://service.kintaroapi.com`)."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 95.0,
        max_retries: int = 8,
    ) -> None:
        self.api_key = (api_key or "").strip()
        if not self.api_key:
            raise ValueError("Не указан API ключ Kintaro (x-api-key).")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=httpx.Timeout(timeout),
            follow_redirects=True,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "KintaroClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _request(
        self,
        method: str,
        path: str,
        proxy: Optional[str] = None,
        device: Optional[Union[Dict[str, Any], str]] = None,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Tuple[int, httpx.Headers, Any, int]:
        headers: Dict[str, str] = {
            "x-api-key": self.api_key,
            "Accept": "application/json",
        }
        if proxy is not None:
            headers["x-proxy"] = normalize_proxy(proxy)
        if device is not None:
            headers["x-device"] = serialize_device_header(device)

        last_exc: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            t0 = time.monotonic()
            try:
                resp = self._client.request(
                    method=method.upper(),
                    url=path,
                    headers=headers,
                    json=json_body,
                    params=params,
                )
                elapsed_ms = int((time.monotonic() - t0) * 1000)
                try:
                    parsed_body: Any = resp.json()
                except ValueError:
                    parsed_body = resp.text

                # Retry transient 500/502/503/504 errors (e.g. transient `Failed build ri_report.` or LB 502)
                if resp.status_code in (500, 502, 503, 504) and attempt < self.max_retries:
                    # Do not over-retry signin/signup endpoints if upstream already took >25s (it may have sent OTP/SMS)
                    if (
                        (path.startswith("/v1/auth/signin/") or path.startswith("/v1/auth/signup/"))
                        and not path.endswith("/send_code")
                        and elapsed_ms > 25000
                        and attempt >= 1
                    ):
                        return resp.status_code, resp.headers, parsed_body, elapsed_ms
                    time.sleep(min(4.0, 1.2 * (attempt + 1)))
                    continue

                return resp.status_code, resp.headers, parsed_body, elapsed_ms
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    time.sleep(min(4.0, 1.2 * (attempt + 1)))
                    continue
                raise KintaroAPIError(f"Ошибка соединения с Kintaro API: {exc}") from exc

        raise KintaroAPIError(f"Не удалось выполнить запрос: {last_exc}")

    # -------------------------------------------------------------------------
    # Device Endpoints
    # -------------------------------------------------------------------------

    def register_device(self, proxy: str, region: str = "DE") -> Dict[str, Any]:
        """POST /v1/device/register"""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/device/register",
            proxy=proxy,
            json_body={"region": region.upper().strip()},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка регистрации устройства ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        dev = extract_device_from_response(headers, body, is_register_endpoint=True)
        if isinstance(dev, str):
            dev = json.loads(dev)
        if not isinstance(dev, dict):
            raise KintaroAPIError(
                "Сервер не вернул объект device при /v1/device/register",
                status_code=status,
                response_data=body,
            )
        return dev

    def update_hosts(
        self, proxy: str, device: Union[Dict[str, Any], str]
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/device/update_hosts"""
        status, headers, body, _ = self._request(
            "POST", "/v1/device/update_hosts", proxy=proxy, device=device
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка update_hosts ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def new_session(
        self, proxy: str, device: Union[Dict[str, Any], str]
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/device/new_session"""
        status, headers, body, _ = self._request(
            "POST", "/v1/device/new_session", proxy=proxy, device=device
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка new_session ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def device_report(
        self, proxy: str, device: Union[Dict[str, Any], str], report_type: str = "launch"
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/device/report — Sends MSSDK app launch / cold_start report and refreshes report_tk."""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/device/report",
            proxy=proxy,
            device=device,
            json_body={"type": report_type},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка device/report ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    # -------------------------------------------------------------------------
    # Signin by Username (+ Password + TOTP / Code)
    # -------------------------------------------------------------------------

    def signin_username(
        self,
        username: str,
        password: str,
        proxy: str,
        region: str = "DE",
        totp_token: Optional[str] = None,
        device: Optional[Union[Dict[str, Any], str]] = None,
        sync_totp_window: bool = True,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> AuthStepResult:
        """
        POST /v1/auth/signin/username
        Logs in using `username` + `password` (+ optional Base32 `totp_token`).
        Synchronizes 30-second TOTP window so Kintaro's server solves 2FA cleanly.
        """
        clean_totp = re.sub(r"\s+", "", totp_token).upper() if totp_token else None
        if clean_totp and sync_totp_window:
            wait_for_fresh_totp_window(min_remaining_sec=19.0, log_fn=log_fn)

        payload: Dict[str, Any] = {
            "username": username.lstrip("@").strip(),
            "password": password,
            "region": (region or "DE").upper().strip(),
        }
        if clean_totp:
            payload["totp_token"] = clean_totp

        status, headers, body, elapsed_ms = self._request(
            "POST",
            "/v1/auth/signin/username",
            proxy=proxy,
            device=device,
            json_body=payload,
        )

        updated_device = extract_device_from_response(headers, body, fallback_device=device)
        verify_obj = extract_verify_from_response(body)

        if status == 200:
            return AuthStepResult(
                status="success",
                http_status=status,
                device=updated_device,
                verify=verify_obj,
                response=body,
                message="Успешный вход по логину и паролю (200 OK)",
                elapsed_ms=elapsed_ms,
            )

        if status == 403:
            err_msg = extract_error_message(body, status)
            if "invalid api key" in err_msg.lower() or "balance" in err_msg.lower():
                return AuthStepResult(
                    status="error",
                    http_status=status,
                    device=updated_device,
                    response=body,
                    message=f"Ошибка API ключа / баланса: {err_msg}",
                    elapsed_ms=elapsed_ms,
                )
            better_region = detect_home_region_from_403(body, payload["region"])
            return AuthStepResult(
                status="code_required",
                http_status=status,
                device=updated_device,
                verify=verify_obj,
                response=body,
                message="Требуется доп. подтверждение кодом (403)",
                elapsed_ms=elapsed_ms,
                detected_region=better_region,
            )

        return AuthStepResult(
            status="error",
            http_status=status,
            device=updated_device,
            verify=verify_obj,
            response=body,
            message=extract_error_message(body, status),
            elapsed_ms=elapsed_ms,
        )

    def signin_username_send_code(
        self,
        username: str,
        password: str,
        code: str,
        verify: Dict[str, Any],
        proxy: str,
        device: Union[Dict[str, Any], str],
    ) -> AuthStepResult:
        """POST /v1/auth/signin/username/send_code"""
        norm_verify = dict(verify or {})
        norm_verify.setdefault("device_redirect_info", "")
        norm_verify.setdefault("challenge_type", "2")
        payload: Dict[str, Any] = {
            "username": username.lstrip("@").strip(),
            "password": password,
            "code": re.sub(r"\s+", "", str(code)),
            "verify": norm_verify,
        }
        status, headers, body, elapsed_ms = self._request(
            "POST",
            "/v1/auth/signin/username/send_code",
            proxy=proxy,
            device=device,
            json_body=payload,
        )
        updated_device = extract_device_from_response(headers, body, fallback_device=device)
        if status == 200:
            return AuthStepResult(
                status="success",
                http_status=status,
                device=updated_device,
                response=body,
                message="Вход по логину успешно подтверждён кодом (200 OK)",
                elapsed_ms=elapsed_ms,
            )
        return AuthStepResult(
            status="error",
            http_status=status,
            device=updated_device,
            response=body,
            message=extract_error_message(body, status),
            elapsed_ms=elapsed_ms,
        )

    # -------------------------------------------------------------------------
    # Signin by Email
    # -------------------------------------------------------------------------

    def signin_email(
        self,
        email: str,
        proxy: str,
        region: str = "US",
        password: Optional[str] = None,
        totp_token: Optional[str] = None,
        device: Optional[Union[Dict[str, Any], str]] = None,
        sync_totp_window: bool = True,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> AuthStepResult:
        """POST /v1/auth/signin/email"""
        clean_totp = re.sub(r"\s+", "", totp_token).upper() if totp_token else None
        if clean_totp and sync_totp_window:
            wait_for_fresh_totp_window(min_remaining_sec=19.0, log_fn=log_fn)

        payload: Dict[str, Any] = {
            "email": email.strip(),
            "region": (region or "US").upper().strip(),
        }
        if password:
            payload["password"] = password
        if clean_totp:
            payload["totp_token"] = clean_totp

        status, headers, body, elapsed_ms = self._request(
            "POST",
            "/v1/auth/signin/email",
            proxy=proxy,
            device=device,
            json_body=payload,
        )

        updated_device = extract_device_from_response(headers, body, fallback_device=device)
        verify_obj = extract_verify_from_response(body)

        if status == 200:
            return AuthStepResult(
                status="success",
                http_status=status,
                device=updated_device,
                verify=verify_obj,
                response=body,
                message="Успешный вход по почте без доп. кода (200 OK)",
                elapsed_ms=elapsed_ms,
            )

        if status == 403:
            err_msg = extract_error_message(body, status)
            if "invalid api key" in err_msg.lower() or "balance" in err_msg.lower():
                return AuthStepResult(
                    status="error",
                    http_status=status,
                    device=updated_device,
                    response=body,
                    message=f"Ошибка API ключа / баланса: {err_msg}",
                    elapsed_ms=elapsed_ms,
                )
            better_region = detect_home_region_from_403(body, payload["region"])
            return AuthStepResult(
                status="code_required",
                http_status=status,
                device=updated_device,
                verify=verify_obj,
                response=body,
                message="Требуется подтверждение кодом с почты (403)",
                elapsed_ms=elapsed_ms,
                detected_region=better_region,
            )

        return AuthStepResult(
            status="error",
            http_status=status,
            device=updated_device,
            verify=verify_obj,
            response=body,
            message=extract_error_message(body, status),
            elapsed_ms=elapsed_ms,
        )

    def signin_email_send_code(
        self,
        email: str,
        code: str,
        proxy: str,
        device: Union[Dict[str, Any], str],
        password: Optional[str] = None,
        verify: Optional[Dict[str, Any]] = None,
    ) -> AuthStepResult:
        """POST /v1/auth/signin/email/send_code"""
        clean_code = re.sub(r"\s+", "", str(code))
        payload: Dict[str, Any] = {
            "email": email.strip(),
            "code": clean_code,
        }
        if password:
            payload["password"] = password

        status, headers, body, elapsed_ms = self._request(
            "POST",
            "/v1/auth/signin/email/send_code",
            proxy=proxy,
            device=device,
            json_body=payload,
        )

        if status != 200 and verify:
            norm_verify = dict(verify)
            norm_verify.setdefault("device_redirect_info", "")
            norm_verify.setdefault("challenge_type", "2")
            payload_with_verify = dict(payload)
            payload_with_verify["verify"] = norm_verify
            st2, hd2, bd2, elapsed_ms2 = self._request(
                "POST",
                "/v1/auth/signin/email/send_code",
                proxy=proxy,
                device=device,
                json_body=payload_with_verify,
            )
            elapsed_ms += elapsed_ms2
            if st2 == 200:
                status, headers, body = st2, hd2, bd2

        updated_device = extract_device_from_response(headers, body, fallback_device=device)
        if status == 200:
            return AuthStepResult(
                status="success",
                http_status=status,
                device=updated_device,
                response=body,
                message="Вход успешно подтверждён кодом с почты (200 OK)",
                elapsed_ms=elapsed_ms,
            )
        return AuthStepResult(
            status="error",
            http_status=status,
            device=updated_device,
            response=body,
            message=extract_error_message(body, status),
            elapsed_ms=elapsed_ms,
        )

    # -------------------------------------------------------------------------
    # Account Profile & Modification Endpoints
    # -------------------------------------------------------------------------

    def get_self(
        self, proxy: str, device: Union[Dict[str, Any], str]
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """GET /v1/account/self"""
        status, headers, body, _ = self._request(
            "GET", "/v1/account/self", proxy=proxy, device=device
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка /v1/account/self ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def token_beat(
        self, proxy: str, device: Union[Dict[str, Any], str]
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/account/token_beat"""
        status, headers, body, _ = self._request(
            "POST", "/v1/account/token_beat", proxy=proxy, device=device
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка /v1/account/token_beat ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def set_bio(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        text: str,
        mentions: Optional[List[str]] = None,
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/account/set_bio — Updates TikTok profile bio (`signature`)."""
        payload: Dict[str, Any] = {"text": text}
        if mentions:
            payload["mentions"] = mentions
        status, headers, body, _ = self._request(
            "POST", "/v1/account/set_bio", proxy=proxy, device=device, json_body=payload
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка смены БИО /v1/account/set_bio ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def set_nickname(
        self, proxy: str, device: Union[Dict[str, Any], str], nickname: str
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/account/set_nickname"""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/account/set_nickname",
            proxy=proxy,
            device=device,
            json_body={"nickname": nickname},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка смены имени ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def set_bio_url(
        self, proxy: str, device: Union[Dict[str, Any], str], url: str
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/account/set_bio_url"""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/account/set_bio_url",
            proxy=proxy,
            device=device,
            json_body={"url": url},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка установки ссылки БИО ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def set_avatar(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        image: Union[bytes, str],
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/account/set_avatar — Sets profile avatar from raw image bytes or Base64 string."""
        if isinstance(image, bytes):
            b64_img = base64.b64encode(image).decode("ascii")
        else:
            b64_img = image.split(",", 1)[1] if "," in image else image.strip()
        status, headers, body, _ = self._request(
            "POST",
            "/v1/account/set_avatar",
            proxy=proxy,
            device=device,
            json_body={"image": b64_img},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка установки аватара ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def change_username(
        self, proxy: str, device: Union[Dict[str, Any], str], username: str
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/account/change_username"""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/account/change_username",
            proxy=proxy,
            device=device,
            json_body={"username": username.lstrip("@").strip()},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка смены username ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def set_password(
        self, proxy: str, device: Union[Dict[str, Any], str], password: str
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/account/set_password"""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/account/set_password",
            proxy=proxy,
            device=device,
            json_body={"password": password},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка установки пароля /v1/account/set_password ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def enable_totp(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        additional_way: str = "pwd",
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """
        POST /v1/account/enable_totp
        Enables TOTP 2FA on the authenticated account (`additional_way`: 'pwd' | 'email' | 'mobile_sms' | 'oauth').
        """
        status, headers, body, _ = self._request(
            "POST",
            "/v1/account/enable_totp",
            proxy=proxy,
            device=device,
            json_body={"additional_way": additional_way},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка включения TOTP /v1/account/enable_totp ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    # -------------------------------------------------------------------------
    # Mobile Signup Endpoints (/v1/auth/signup/mobile)
    # -------------------------------------------------------------------------

    def signup_mobile(
        self,
        mobile: str,
        birthday: str,
        region: str,
        proxy: str,
        password: Optional[str] = None,
        device: Optional[Union[Dict[str, Any], str]] = None,
    ) -> AuthStepResult:
        """
        POST /v1/auth/signup/mobile
        Initiates TikTok registration by phone number (e.g. `mobile='+56 973639762'`, `region='CL'`).
        Returns `status='code_required'` (HTTP 403) when SMS code has been dispatched, or `status='success'` (HTTP 200).
        """
        payload: Dict[str, Any] = {
            "region": (region or "CL").upper().strip(),
            "mobile": mobile.strip(),
            "birthday": birthday.strip(),
        }
        if password:
            payload["password"] = password

        status, headers, body, elapsed_ms = self._request(
            "POST",
            "/v1/auth/signup/mobile",
            proxy=proxy,
            device=device,
            json_body=payload,
        )
        updated_device = extract_device_from_response(headers, body, fallback_device=device)
        verify_obj = extract_verify_from_response(body)

        if status == 200:
            return AuthStepResult(
                status="success",
                http_status=status,
                device=updated_device,
                verify=verify_obj,
                response=body,
                message="Регистрация по номеру завершена без доп. кода (200 OK)",
                elapsed_ms=elapsed_ms,
            )

        if status == 403:
            err_msg = extract_error_message(body, status)
            low = err_msg.lower()
            if "invalid api key" in low or "balance" in low:
                return AuthStepResult(
                    status="error",
                    http_status=status,
                    device=updated_device,
                    response=body,
                    message=f"Ошибка API ключа / баланса Kintaro: {err_msg}",
                    elapsed_ms=elapsed_ms,
                )
            return AuthStepResult(
                status="code_required",
                http_status=status,
                device=updated_device,
                verify=verify_obj,
                response=body,
                message="Код SMS отправлен на номер (403 Required confirmation by code)",
                elapsed_ms=elapsed_ms,
            )

        return AuthStepResult(
            status="error",
            http_status=status,
            device=updated_device,
            verify=verify_obj,
            response=body,
            message=extract_error_message(body, status),
            elapsed_ms=elapsed_ms,
        )

    def signup_mobile_send_code(
        self,
        mobile: str,
        birthday: str,
        code: str,
        proxy: str,
        device: Union[Dict[str, Any], str],
        password: Optional[str] = None,
    ) -> AuthStepResult:
        """
        POST /v1/auth/signup/mobile/send_code
        Confirms TikTok mobile registration with the 6-digit SMS verification code.
        """
        payload: Dict[str, Any] = {
            "mobile": mobile.strip(),
            "birthday": birthday.strip(),
            "code": re.sub(r"\s+", "", str(code)),
        }
        if password:
            payload["password"] = password

        status, headers, body, elapsed_ms = self._request(
            "POST",
            "/v1/auth/signup/mobile/send_code",
            proxy=proxy,
            device=device,
            json_body=payload,
        )
        updated_device = extract_device_from_response(headers, body, fallback_device=device)
        if status == 200:
            return AuthStepResult(
                status="success",
                http_status=status,
                device=updated_device,
                response=body,
                message="Регистрация по SMS-коду успешно завершена (200 OK)",
                elapsed_ms=elapsed_ms,
            )
        return AuthStepResult(
            status="error",
            http_status=status,
            device=updated_device,
            response=body,
            message=extract_error_message(body, status),
            elapsed_ms=elapsed_ms,
        )

    def get_self_posts(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        count: int = 9,
        max_cursor: str = "0",
        min_cursor: str = "0",
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """GET /v1/account/posts"""
        status, headers, body, _ = self._request(
            "GET",
            "/v1/account/posts",
            proxy=proxy,
            device=device,
            params={"count": str(count), "max_cursor": str(max_cursor), "min_cursor": str(min_cursor)},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка получения постов ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def delete_post(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        aweme_id: str,
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/post/delete — Deletes a TikTok video or photo post by aweme_id."""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/post/delete",
            proxy=proxy,
            device=device,
            json_body={"aweme_id": str(aweme_id).strip()},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка удаления поста {aweme_id} ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def get_user_posts(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        username: str,
        count: int = 15,
        region: str = "",
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """GET /v1/user/posts — Public profile posts check."""
        params: Dict[str, Any] = {"username": username.lstrip("@").strip(), "count": str(count)}
        if region:
            params["region"] = region.upper().strip()
        status, headers, body, _ = self._request(
            "GET",
            "/v1/user/posts",
            proxy=proxy,
            device=device,
            params=params,
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка /v1/user/posts ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    # -------------------------------------------------------------------------
    # Post Creation Endpoints (Photo Carousel & Video)
    # -------------------------------------------------------------------------

    def create_photo_post(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        photos: List[Union[str, bytes, Tuple[str, bytes]]],
        description: str = "",
        mentions: Optional[List[str]] = None,
        music_id: str = "",
        region: Optional[str] = None,
        is_private: bool = False,
        disable_comments: bool = False,
        disable_duet: bool = False,
        disable_react: bool = False,
        disable_stitch: bool = False,
        is_story: bool = False,
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """
        POST /v1/post/create/photo
        Uploads 1 to 10 photos (`image/jpeg` or `image/png`, <=10MB each) as a TikTok photo/carousel post.
        `photos` accepts file paths (`str`), raw `bytes`, or `(filename, bytes)` tuples.
        """
        if not photos:
            raise ValueError("Передайте хотя бы 1 изображение для фото-поста.")
        if len(photos) > 10:
            raise ValueError("Максимум 10 изображений в одной карусели TikTok.")

        multipart_files: List[Tuple[str, Tuple[str, bytes, str]]] = []
        for idx, item in enumerate(photos, start=1):
            if isinstance(item, (str, os.PathLike)):
                from pathlib import Path

                p = Path(item)
                raw = p.read_bytes()
                fname = p.name
            elif isinstance(item, bytes):
                raw = item
                fname = f"slide_{idx}.jpg"
            elif isinstance(item, tuple) and len(item) in (2, 3):
                fname, raw = item[0], item[1]
            else:
                raise TypeError(f"Неподдерживаемый формат фото #{idx}: {type(item)}")

            if len(raw) > 10 * 1024 * 1024:
                raise ValueError(f"Файл {fname} превышает лимит 10 МБ ({len(raw)} байт).")

            if raw.startswith(b"\x89PNG"):
                mime = "image/png"
                if not fname.lower().endswith(".png"):
                    fname = f"{fname.rsplit('.', 1)[0]}.png"
            else:
                mime = "image/jpeg"
                if not fname.lower().endswith((".jpg", ".jpeg")):
                    fname = f"{fname.rsplit('.', 1)[0]}.jpg"

            multipart_files.append(("photo", (fname, raw, mime)))

        desc_str = description or ""
        if ("#" in desc_str or "@" in desc_str) and not desc_str.endswith(" "):
            desc_str = f"{desc_str} "

        form_data: Dict[str, Any] = {
            "description": desc_str,
            "is_private": "1" if is_private else "0",
            "disable_comments": "1" if disable_comments else "0",
            "disable_duet": "1" if disable_duet else "0",
            "disable_react": "1" if disable_react else "0",
            "disable_stitch": "1" if disable_stitch else "0",
            "is_story": "1" if is_story else "0",
        }
        if region:
            form_data["region"] = region.upper().strip()
        if music_id:
            form_data["music_id"] = str(music_id).strip()
        if mentions:
            form_data["description_mentions"] = [m.lstrip("@").strip() for m in mentions if m.strip()]

        headers: Dict[str, str] = {
            "x-api-key": self.api_key,
            "x-proxy": normalize_proxy(proxy),
            "x-device": serialize_device_header(device),
            "Accept": "application/json",
        }

        last_exc: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = self._client.post(
                    "/v1/post/create/photo",
                    headers=headers,
                    data=form_data,
                    files=multipart_files,
                    timeout=httpx.Timeout(240.0),
                )
                try:
                    parsed_body: Any = resp.json()
                except ValueError:
                    parsed_body = resp.text

                if resp.status_code in (500, 502, 503, 504) and attempt < self.max_retries:
                    time.sleep(2.5 * (attempt + 1))
                    continue

                if resp.status_code != 200:
                    raise KintaroAPIError(
                        f"Ошибка публикации фото-поста ({resp.status_code}): {extract_error_message(parsed_body, resp.status_code)}",
                        status_code=resp.status_code,
                        response_data=parsed_body,
                    )
                updated_dev = extract_device_from_response(
                    resp.headers, parsed_body, fallback_device=device
                )
                return parsed_body, updated_dev
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    time.sleep(2.5 * (attempt + 1))
                    continue
                raise KintaroAPIError(f"Ошибка сети при публикации фото-поста: {exc}") from exc

        raise KintaroAPIError(f"Не удалось опубликовать фото-пост: {last_exc}")

    def search_music(
        self,
        keyword: str,
        proxy: Optional[str] = None,
        device: Optional[Union[Dict[str, Any], str]] = None,
        count: int = 20,
        region: str = "",
    ) -> Any:
        """GET /v1/music/search"""
        status, _, body, _ = self._request(
            "GET",
            "/v1/music/search",
            proxy=proxy,
            device=device,
            params={"keyword": keyword, "count": str(count), "cursor": "0", "region": region},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка поиска музыки ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body

    def build_music_pool(
        self,
        keyword: str = "Fortnite",
        proxy: Optional[str] = None,
        device: Optional[Union[Dict[str, Any], str]] = None,
        region: str = "",
    ) -> List[Dict[str, str]]:
        """
        Builds a deduplicated pool of playable TikTok tracks (`{"id": ..., "title": ..., "author": ...}`):
          1. Live search via `/v1/music/search` (e.g. `keyword="Fortnite"`)
          2. Suggested tracks from `/v1/feed/recommendations` if search yields few items or `keyword="recommended"`
          3. Verified Fortnite fallback tracks so every post always gets a valid sound.
        """
        pool: List[Dict[str, str]] = []
        seen_ids: set = set()

        def _add_music_dict(m: Any) -> None:
            if not isinstance(m, dict):
                return
            if "music" in m and isinstance(m["music"], dict):
                m = m["music"]
            mid = str(m.get("id_str") or m.get("mid") or m.get("id") or "").strip()
            if not mid or not mid.isdigit() or mid in seen_ids:
                return
            if m.get("mute_share") or m.get("prevent_download") is True and m.get("music_status") == 0:
                return
            dur = int(m.get("duration") or 15)
            if dur < 6:
                return
            title_str = str(m.get("title") or "Original Sound").strip()
            author_str = str(m.get("author") or "TikTok").strip()
            if (region or "").strip().upper() in ("US", "GB", "CA", "AU"):
                tl = title_str.lower()
                if any(
                    bad in tl
                    for bad in (
                        "alkuperäinen",
                        "оригинальный",
                        "orijinal",
                        "dźwięk",
                        "suono originale",
                        "son original",
                        "som original",
                        "originalton",
                        "sunet original",
                        "originální",
                    )
                ):
                    return
            seen_ids.add(mid)
            pool.append(
                {
                    "id": mid,
                    "title": title_str,
                    "author": author_str,
                }
            )

        kw = (keyword or "").strip()
        if kw and kw.lower() not in ("recommended", "chart", "auto", "предложенные"):
            try:
                res = self.search_music(keyword=kw, proxy=proxy, device=device, count=25, region=region)
                if isinstance(res, dict):
                    for entry in res.get("music_info_list") or res.get("music") or []:
                        if isinstance(entry, dict):
                            for sub in entry.get("musics") or []:
                                _add_music_dict(sub)
                            _add_music_dict(entry.get("music") or entry)
            except Exception:
                pass

        if len(pool) < 6:
            try:
                st, _, feed_body, _ = self._request(
                    "GET",
                    "/v1/feed/recommendations",
                    proxy=proxy,
                    device=device,
                    params={"region": region} if region else None,
                )
                if st == 200 and isinstance(feed_body, dict):
                    for aw in feed_body.get("aweme_list") or []:
                        if isinstance(aw, dict):
                            _add_music_dict(aw.get("music"))
            except Exception:
                pass

        # Verified Fortnite TikTok tracks fallback
        fallback_fortnite = [
            {"id": "7436971510241167377", "title": "Fortnite Og Mode", "author": "Aye Brown"},
            {"id": "6891415646903470081", "title": "Fortnite - Battle Royale - Original Main Theme", "author": "Geek Music"},
            {"id": "6782722012662990849", "title": "Smooth Moves", "author": "Fortnite"},
            {"id": "6902489124184262657", "title": "Fortnite", "author": "Trap Baby"},
            {"id": "7289836584265255686", "title": "OG music", "author": "Fortnite_MusicPack"},
            {"id": "7348501746953882401", "title": "sonido original", "author": "Fortnite ES"},
            {"id": "7439239198745463607", "title": "оригинальный звук", "author": "fort"},
        ]
        for fb in fallback_fortnite:
            if fb["id"] not in seen_ids:
                seen_ids.add(fb["id"])
                pool.append(fb)

        return pool

    # -------------------------------------------------------------------------
    # Video Post, Visibility & Social Engagement / Warmup Endpoints
    # -------------------------------------------------------------------------

    def create_video_post(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        video: Union[str, os.PathLike, bytes, Tuple[str, bytes]],
        description: str = "",
        mentions: Optional[List[str]] = None,
        music_id: str = "",
        region: Optional[str] = None,
        is_private: bool = False,
        disable_comments: bool = False,
        disable_duet: bool = False,
        disable_react: bool = False,
        disable_stitch: bool = False,
        is_story: bool = False,
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/post/create/video — Uploads an MP4 video post (<=50MB)."""
        if isinstance(video, (str, os.PathLike)):
            from pathlib import Path

            p = Path(video)
            raw = p.read_bytes()
            fname = p.name
        elif isinstance(video, bytes):
            raw = video
            fname = "video.mp4"
        elif isinstance(video, tuple) and len(video) >= 2:
            fname, raw = str(video[0]), video[1]
        else:
            raise TypeError(f"Неподдерживаемый формат видео: {type(video)}")

        if len(raw) > 50 * 1024 * 1024:
            raise ValueError(f"Видео {fname} превышает лимит 50 МБ.")
        if not fname.lower().endswith(".mp4"):
            fname = f"{fname.rsplit('.', 1)[0]}.mp4"

        desc_str = description or ""
        if ("#" in desc_str or "@" in desc_str) and not desc_str.endswith(" "):
            desc_str = f"{desc_str} "

        form_data: Dict[str, Any] = {
            "description": desc_str,
            "is_private": "1" if is_private else "0",
            "disable_comments": "1" if disable_comments else "0",
            "disable_duet": "1" if disable_duet else "0",
            "disable_react": "1" if disable_react else "0",
            "disable_stitch": "1" if disable_stitch else "0",
            "is_story": "1" if is_story else "0",
        }
        if region:
            form_data["region"] = region.upper().strip()
        if music_id:
            form_data["music_id"] = str(music_id).strip()
        if mentions:
            form_data["description_mentions"] = [m.lstrip("@").strip() for m in mentions if m.strip()]

        headers: Dict[str, str] = {
            "x-api-key": self.api_key,
            "x-proxy": normalize_proxy(proxy),
            "x-device": serialize_device_header(device),
            "Accept": "application/json",
        }
        resp = self._client.post(
            "/v1/post/create/video",
            headers=headers,
            data=form_data,
            files=[("video", (fname, raw, "video/mp4"))],
            timeout=httpx.Timeout(300.0),
        )
        try:
            parsed_body: Any = resp.json()
        except ValueError:
            parsed_body = resp.text
        if resp.status_code != 200:
            raise KintaroAPIError(
                f"Ошибка публикации видео ({resp.status_code}): {extract_error_message(parsed_body, resp.status_code)}",
                status_code=resp.status_code,
                response_data=parsed_body,
            )
        return parsed_body, extract_device_from_response(resp.headers, parsed_body, fallback_device=device)

    def change_post_visibility(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        aweme_id: str,
        vis_type: int = 1,
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/post/change_visibility (`1` = Public, `2` = Private/Only me, `3` = Friends)."""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/post/change_visibility",
            proxy=proxy,
            device=device,
            json_body={"aweme_id": str(aweme_id).strip(), "type": int(vis_type)},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка смены видимости поста ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def get_feed_recommendations(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        region: str = "",
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """GET /v1/feed/recommendations"""
        params = {"region": region.upper().strip()} if region else None
        status, headers, body, _ = self._request(
            "GET",
            "/v1/feed/recommendations",
            proxy=proxy,
            device=device,
            params=params,
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка получения ленты рекомендаций ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def view_post(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        aweme_id: str,
        playtime_ms: int = 5200,
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/post/view"""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/post/view",
            proxy=proxy,
            device=device,
            json_body={"aweme_id": str(aweme_id).strip(), "playtime": str(int(playtime_ms))},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка просмотра поста ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def like_post(
        self, proxy: str, device: Union[Dict[str, Any], str], aweme_id: str
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/post/like"""
        status, headers, body, _ = self._request(
            "POST", "/v1/post/like", proxy=proxy, device=device, json_body={"aweme_id": str(aweme_id).strip()}
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка лайка поста ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def collect_post(
        self, proxy: str, device: Union[Dict[str, Any], str], aweme_id: str
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/post/collect (bookmark/favorite)"""
        status, headers, body, _ = self._request(
            "POST", "/v1/post/collect", proxy=proxy, device=device, json_body={"aweme_id": str(aweme_id).strip()}
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка добавления в избранное ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def repost_post(
        self, proxy: str, device: Union[Dict[str, Any], str], aweme_id: str
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/post/repost"""
        status, headers, body, _ = self._request(
            "POST", "/v1/post/repost", proxy=proxy, device=device, json_body={"aweme_id": str(aweme_id).strip()}
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка репоста ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def publish_comment(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        aweme_id: str,
        text: str = "",
        mentions: Optional[List[str]] = None,
        reply_id: str = "",
        reply_to_reply_id: str = "",
        image_b64: str = "",
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/comment/publish (supports text, @mentions, replies, and base64 proof image)."""
        payload: Dict[str, Any] = {"aweme_id": str(aweme_id).strip()}
        if text:
            payload["text"] = text
        if mentions:
            payload["mentions"] = [m.lstrip("@").strip() for m in mentions if m.strip()]
        if reply_id:
            payload["reply_id"] = str(reply_id).strip()
        if reply_to_reply_id:
            payload["reply_to_reply_id"] = str(reply_to_reply_id).strip()
        if image_b64:
            payload["image"] = image_b64.split(",", 1)[1] if "," in image_b64 else image_b64

        status, headers, body, _ = self._request(
            "POST",
            "/v1/comment/publish",
            proxy=proxy,
            device=device,
            json_body=payload,
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка публикации комментария ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def like_comment(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        aweme_id: str,
        comment_id: str,
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/comment/like"""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/comment/like",
            proxy=proxy,
            device=device,
            json_body={"aweme_id": str(aweme_id).strip(), "comment_id": str(comment_id).strip()},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка лайка комментария ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def get_post_comments(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        aweme_id: str,
        cursor: str = "0",
        count: int = 20,
        region: str = "",
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """GET /v1/post/comments"""
        params: Dict[str, str] = {
            "aweme_id": str(aweme_id).strip(),
            "cursor": str(cursor),
            "count": str(max(1, min(50, int(count)))),
        }
        if region:
            params["region"] = region.upper().strip()
        status, headers, body, _ = self._request(
            "GET", "/v1/post/comments", proxy=proxy, device=device, params=params
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка получения комментариев ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def get_user_profile(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        username: str,
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """GET /v1/user/get"""
        status, headers, body, _ = self._request(
            "GET",
            "/v1/user/get",
            proxy=proxy,
            device=device,
            params={"username": username.lstrip("@").strip()},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка получения профиля @{username} ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def get_user_posts(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        username: str,
        count: int = 18,
        max_cursor: str = "0",
        region: str = "",
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """GET /v1/user/posts"""
        params: Dict[str, str] = {
            "username": username.lstrip("@").strip(),
            "count": str(max(1, min(35, int(count)))),
            "max_cursor": str(max_cursor),
        }
        if region:
            params["region"] = region.upper().strip()
        status, headers, body, _ = self._request(
            "GET", "/v1/user/posts", proxy=proxy, device=device, params=params
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка получения постов @{username} ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def get_post_detail(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        aweme_id: str,
        region: str = "",
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """GET /v1/post/get"""
        params: Dict[str, str] = {"aweme_id": str(aweme_id).strip()}
        if region:
            params["region"] = region.upper().strip()
        status, headers, body, _ = self._request(
            "GET", "/v1/post/get", proxy=proxy, device=device, params=params
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка получения поста {aweme_id} ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

    def get_trending_fyp_music(
        self,
        proxy: str,
        device: Union[Dict[str, Any], str],
        region: str = "US",
        rounds: int = 2,
    ) -> List[Dict[str, str]]:
        """Extracts trending TikTok music tracks directly from live regional FYP recommendations."""
        seen: set[str] = set()
        tracks: List[Dict[str, str]] = []
        cur_dev = apply_device_geo_profile(device, region)
        for _ in range(max(1, min(4, rounds))):
            fb, upd = self.get_feed_recommendations(proxy=proxy, device=cur_dev, region=region)
            if upd is not None:
                cur_dev = upd
            alist = (fb.get("aweme_list") if isinstance(fb, dict) else None) or []
            for aw in alist:
                if not isinstance(aw, dict):
                    continue
                m = aw.get("music") or {}
                mid = str(m.get("id_str") or m.get("id") or "").strip()
                if not mid or mid in seen or mid == "0":
                    continue
                seen.add(mid)
                tracks.append(
                    {
                        "id": mid,
                        "title": str(m.get("title") or "Original Sound"),
                        "author": str(m.get("author") or (aw.get("author") or {}).get("nickname") or ""),
                    }
                )
        return tracks

    def follow_user(
        self, proxy: str, device: Union[Dict[str, Any], str], username: str
    ) -> Tuple[Any, Optional[Union[Dict[str, Any], str]]]:
        """POST /v1/user/follow"""
        status, headers, body, _ = self._request(
            "POST",
            "/v1/user/follow",
            proxy=proxy,
            device=device,
            json_body={"username": username.lstrip("@").strip()},
        )
        if status != 200:
            raise KintaroAPIError(
                f"Ошибка подписки ({status}): {extract_error_message(body, status)}",
                status_code=status,
                response_data=body,
            )
        return body, extract_device_from_response(headers, body, fallback_device=device)

