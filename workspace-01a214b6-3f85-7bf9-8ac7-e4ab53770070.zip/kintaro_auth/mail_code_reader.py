"""
Automatic IMAP / POP3 email reader for TikTok 6-digit verification codes.
Supports 30+ standard providers + Firstmail / NotLetters custom domain auto-fallback.
"""

from __future__ import annotations

import email
import email.utils
import html
import imaplib
import poplib
import re
import socket
import ssl
import time
from email.header import decode_header
from typing import Callable, Dict, List, Optional, Tuple


# Known IMAP hosts mapped by domain
KNOWN_IMAP_SERVERS: Dict[str, Tuple[str, int]] = {
    # Firstmail known domains
    "firstmail.ltd": ("imap.firstmail.ltd", 993),
    "firstmailler.net": ("imap.firstmail.ltd", 993),
    "fmailler.com": ("imap.firstmail.ltd", 993),
    "fmaillerbox.com": ("imap.firstmail.ltd", 993),
    "fmaild.com": ("imap.firstmail.ltd", 993),
    "dfirstmail.com": ("imap.firstmail.ltd", 993),
    # NotLetters
    "notletters.com": ("imap.notletters.com", 993),
    # Rambler family
    "rambler.ru": ("imap.rambler.ru", 993),
    "rambler.ua": ("imap.rambler.ru", 993),
    "lenta.ru": ("imap.rambler.ru", 993),
    "autorambler.ru": ("imap.rambler.ru", 993),
    "myrambler.ru": ("imap.rambler.ru", 993),
    "ro.ru": ("imap.rambler.ru", 993),
    # Mail.ru family
    "mail.ru": ("imap.mail.ru", 993),
    "inbox.ru": ("imap.mail.ru", 993),
    "bk.ru": ("imap.mail.ru", 993),
    "list.ru": ("imap.mail.ru", 993),
    "internet.ru": ("imap.mail.ru", 993),
    # Yandex family
    "yandex.ru": ("imap.yandex.ru", 993),
    "yandex.com": ("imap.yandex.com", 993),
    "ya.ru": ("imap.yandex.ru", 993),
    "yandex.kz": ("imap.yandex.ru", 993),
    "yandex.by": ("imap.yandex.ru", 993),
    # Microsoft
    "outlook.com": ("outlook.office365.com", 993),
    "hotmail.com": ("outlook.office365.com", 993),
    "live.com": ("outlook.office365.com", 993),
    "msn.com": ("outlook.office365.com", 993),
    # Google
    "gmail.com": ("imap.gmail.com", 993),
    "googlemail.com": ("imap.gmail.com", 993),
    # European / International
    "gmx.com": ("imap.gmx.com", 993),
    "gmx.de": ("imap.gmx.net", 993),
    "gmx.net": ("imap.gmx.net", 993),
    "web.de": ("imap.web.de", 993),
    "yahoo.com": ("imap.mail.yahoo.com", 993),
    "aol.com": ("imap.aol.com", 993),
    "zoho.com": ("imap.zoho.com", 993),
    "icloud.com": ("imap.mail.me.com", 993),
    "fastmail.com": ("imap.fastmail.com", 993),
}


CANDIDATE_FOLDERS = [
    "INBOX",
    "Spam",
    "Junk",
    "Bulk",
    "[Gmail]/Spam",
    "Junk E-mail",
]


def _decode_mime_header(raw_header: Optional[str]) -> str:
    if not raw_header:
        return ""
    parts = decode_header(raw_header)
    decoded_chunks: List[str] = []
    for content, charset in parts:
        if isinstance(content, bytes):
            enc = charset or "utf-8"
            try:
                decoded_chunks.append(content.decode(enc, errors="replace"))
            except LookupError:
                decoded_chunks.append(content.decode("utf-8", errors="replace"))
        else:
            decoded_chunks.append(str(content))
    return "".join(decoded_chunks)


def _html_to_visible_text(raw_html: str) -> str:
    """Strips <style>, <script>, HTML tags, and unescapes entities so CSS numbers don't pollute regex."""
    cleaned = re.sub(r"(?is)<(style|script|head).*?>.*?</\1>", " ", raw_html)
    cleaned = re.sub(r"(?is)<[^>]+>", " ", cleaned)
    cleaned = html.unescape(cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned.strip()


def _extract_message_text(msg: email.message.Message) -> str:
    plain_parts: List[str] = []
    html_parts: List[str] = []

    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            disp = str(part.get("Content-Disposition") or "")
            if "attachment" in disp.lower():
                continue
            payload = part.get_payload(decode=True)
            if not payload:
                continue
            charset = part.get_content_charset() or "utf-8"
            try:
                text = payload.decode(charset, errors="replace")
            except LookupError:
                text = payload.decode("utf-8", errors="replace")
            if ctype == "text/plain":
                plain_parts.append(text)
            elif ctype == "text/html":
                html_parts.append(_html_to_visible_text(text))
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            try:
                text = payload.decode(charset, errors="replace")
            except LookupError:
                text = payload.decode("utf-8", errors="replace")
            if msg.get_content_type() == "text/html":
                html_parts.append(_html_to_visible_text(text))
            else:
                plain_parts.append(text)

    combined = "\n".join(plain_parts + html_parts)
    return combined


def extract_tiktok_code(subject: str, sender: str, body_text: str) -> Optional[str]:
    """
    Extracts 6-digit TikTok verification code from Subject or Body.
    Returns None if message is unrelated or no valid 6-digit code is found.
    """
    haystack_meta = f"{sender} {subject} {body_text[:1500]}".lower()
    is_tiktok = any(
        kw in haystack_meta
        for kw in ("tiktok", "тикток", "verification code", "код подтверждения", "account.tiktok")
    )
    if not is_tiktok:
        return None

    # 1. Check Subject first (TikTok puts "123456 is your verification code" in subject)
    subj_match = re.search(r"(?<!\d)(\d{6})(?!\d)", subject)
    if subj_match:
        return subj_match.group(1)

    # 2. Contextual match in body near "code" / "код"
    ctx_patterns = [
        r"(?:verification\s+code|код\s+подтверждения|your\s+code|ваш\s+код)[^\d]{0,40}(\d{6})(?!\d)",
        r"(?<!\d)(\d{6})[^\d]{0,30}(?:is\s+your\s+verification\s+code|ваш\s+код)",
    ]
    for pat in ctx_patterns:
        m = re.search(pat, body_text, flags=re.IGNORECASE)
        if m:
            return m.group(1)

    # 3. Fallback standalone 6-digit code (strip URLs and #hex colors first so hashes never false-match)
    clean_body = re.sub(r"https?://\S+", " ", body_text)
    clean_body = re.sub(r"#[0-9A-Fa-f]{4,64}\b", " ", clean_body)
    clean_body = re.sub(r"\b[0-9A-Fa-f]{12,}\b", " ", clean_body)
    for m in re.finditer(r"\b(\d{6})\b", clean_body):
        candidate = m.group(1)
        if candidate not in ("000000",):
            return candidate

    return None


def resolve_imap_candidates(
    email_addr: str, custom_imap_host: Optional[str] = None, custom_imap_port: int = 993
) -> List[Tuple[str, int]]:
    """Returns ordered list of (host, port) IMAP candidates to try for an email address."""
    if custom_imap_host and custom_imap_host.strip():
        h = custom_imap_host.strip()
        if ":" in h:
            host_part, port_part = h.rsplit(":", 1)
            if port_part.isdigit():
                return [(host_part, int(port_part))]
        return [(h, custom_imap_port)]

    domain = email_addr.split("@", 1)[-1].lower().strip()
    if domain in KNOWN_IMAP_SERVERS:
        return [KNOWN_IMAP_SERVERS[domain]]

    # Unknown / custom domain: try domain's own IMAP first, then Firstmail & NotLetters (very common for market mails)
    return [
        (f"imap.{domain}", 993),
        (f"mail.{domain}", 993),
        ("imap.firstmail.ltd", 993),
        ("imap.notletters.com", 993),
    ]


def _msg_fingerprint(folder: str, uid_bytes: bytes, msg: email.message.Message) -> str:
    mid = (msg.get("Message-ID") or "").strip()
    if mid:
        return mid
    return f"{folder}:{uid_bytes.decode(errors='ignore')}:{msg.get('Date') or ''}"


def prepare_imap_mailbox(
    email_addr: str,
    mail_password: str,
    custom_imap_host: Optional[str] = None,
    custom_imap_port: int = 993,
    log_fn: Optional[Callable[[str], None]] = None,
) -> Tuple[Tuple[str, int], set]:
    """
    Logs into the IMAP mailbox BEFORE triggering TikTok login and snapshots all existing recent messages
    so that `wait_for_email_code` accepts ONLY strictly new emails arriving after the snapshot.
    """
    candidates = resolve_imap_candidates(email_addr, custom_imap_host, custom_imap_port)
    ctx = ssl.create_default_context()
    last_err: Optional[str] = None

    for host, port in candidates:
        try:
            conn = imaplib.IMAP4_SSL(host=host, port=port, ssl_context=ctx, timeout=15)
            try:
                conn.login(email_addr, mail_password)
                old_ids: set = set()
                for folder in CANDIDATE_FOLDERS:
                    try:
                        status, _ = conn.select(f'"{folder}"' if " " in folder else folder, readonly=True)
                        if status != "OK":
                            continue
                        st, data = conn.uid("search", None, "ALL")
                        if st != "OK" or not data or not data[0]:
                            continue
                        uids = data[0].split()
                        for uid_b in uids[-20:]:
                            fst, fdata = conn.uid("fetch", uid_b, "(BODY.PEEK[HEADER.FIELDS (MESSAGE-ID DATE SUBJECT)])")
                            if fst == "OK" and fdata:
                                for item in fdata:
                                    if isinstance(item, tuple) and isinstance(item[1], bytes):
                                        hdr_msg = email.message_from_bytes(item[1])
                                        old_ids.add(_msg_fingerprint(folder, uid_b, hdr_msg))
                                        break
                    except Exception:
                        continue
                if log_fn:
                    log_fn(
                        f"Почта {email_addr} подключена по IMAP ({host}:{port}, запомнено {len(old_ids)} старых писем)"
                    )
                return (host, port), old_ids
            finally:
                try:
                    conn.logout()
                except Exception:
                    pass
        except Exception as exc:
            last_err = f"{host}:{port} -> {exc}"
            continue

    raise RuntimeError(f"Не удалось войти по IMAP в {email_addr} ({last_err})")


def _check_imap_once(
    email_addr: str,
    mail_password: str,
    host: str,
    port: int,
    min_timestamp: float,
    known_old_ids: Optional[set] = None,
    seen_skipped: Optional[set] = None,
    log_fn: Optional[Callable[[str], None]] = None,
) -> Optional[str]:
    ctx = ssl.create_default_context()
    conn = imaplib.IMAP4_SSL(host=host, port=port, ssl_context=ctx, timeout=15)
    try:
        conn.login(email_addr, mail_password)
        for folder in CANDIDATE_FOLDERS:
            try:
                status, _ = conn.select(f'"{folder}"' if " " in folder else folder, readonly=True)
                if status != "OK":
                    continue
            except imaplib.IMAP4.error:
                continue

            status, data = conn.uid("search", None, "ALL")
            if status != "OK" or not data or not data[0]:
                continue

            uids = data[0].split()
            for uid_b in reversed(uids[-12:]):
                st, msg_data = conn.uid("fetch", uid_b, "(RFC822)")
                if st != "OK" or not msg_data:
                    continue
                raw_bytes = None
                for item in msg_data:
                    if isinstance(item, tuple) and isinstance(item[1], bytes):
                        raw_bytes = item[1]
                        break
                if not raw_bytes:
                    continue

                msg = email.message_from_bytes(raw_bytes)
                fp = _msg_fingerprint(folder, uid_b, msg)
                subject = _decode_mime_header(msg.get("Subject"))
                sender = _decode_mime_header(msg.get("From"))

                if known_old_ids is not None and fp in known_old_ids:
                    if seen_skipped is not None and fp not in seen_skipped:
                        seen_skipped.add(fp)
                        body_tmp = _extract_message_text(msg)
                        old_c = extract_tiktok_code(subject, sender, body_tmp)
                        if old_c and log_fn:
                            log_fn(f"Пропущено старое письмо на IMAP с кодом {old_c} ({msg.get('Date')}), ждём новый код...")
                    continue

                date_hdr = msg.get("Date")
                if date_hdr:
                    try:
                        dt = email.utils.parsedate_to_datetime(date_hdr)
                        msg_ts = dt.timestamp()
                        skew = 15 if known_old_ids is not None else 90
                        if msg_ts < (min_timestamp - skew):
                            continue
                    except Exception:
                        pass

                body_text = _extract_message_text(msg)
                code = extract_tiktok_code(subject, sender, body_text)
                if code:
                    return code
        return None
    finally:
        try:
            conn.logout()
        except Exception:
            pass


def _check_pop3_once(
    email_addr: str,
    mail_password: str,
    host: str,
    port: int,
    min_timestamp: float,
) -> Optional[str]:
    ctx = ssl.create_default_context()
    pop = poplib.POP3_SSL(host=host, port=port, context=ctx, timeout=15)
    try:
        pop.user(email_addr)
        pop.pass_(mail_password)
        num_messages = len(pop.list()[1])
        start_idx = max(1, num_messages - 10)
        for i in range(num_messages, start_idx - 1, -1):
            resp, lines, _ = pop.retr(i)
            raw_bytes = b"\r\n".join(lines)
            msg = email.message_from_bytes(raw_bytes)
            date_hdr = msg.get("Date")
            if date_hdr:
                try:
                    dt = email.utils.parsedate_to_datetime(date_hdr)
                    if dt.timestamp() < (min_timestamp - 90):
                        continue
                except Exception:
                    pass
            subject = _decode_mime_header(msg.get("Subject"))
            sender = _decode_mime_header(msg.get("From"))
            body_text = _extract_message_text(msg)
            code = extract_tiktok_code(subject, sender, body_text)
            if code:
                return code
        return None
    finally:
        try:
            pop.quit()
        except Exception:
            pass


def wait_for_email_code(
    email_addr: str,
    mail_password: str,
    since_timestamp: Optional[float] = None,
    custom_imap_host: Optional[str] = None,
    custom_imap_port: int = 993,
    pre_server: Optional[Tuple[str, int]] = None,
    known_old_ids: Optional[set] = None,
    timeout_sec: int = 90,
    poll_interval_sec: float = 2.0,
    log_fn: Optional[Callable[[str], None]] = None,
) -> str:
    """
    Polls IMAP (with POP3 fallback) until a strictly NEW 6-digit TikTok verification code arrives.
    """
    start_ts = since_timestamp or time.time()
    deadline = time.time() + timeout_sec
    candidates = [pre_server] if pre_server else resolve_imap_candidates(email_addr, custom_imap_host, custom_imap_port)

    working_server: Optional[Tuple[str, int]] = pre_server
    last_error: Optional[str] = None
    seen_skipped: set = set()

    time.sleep(1.2)

    attempt = 0
    while time.time() < deadline:
        attempt += 1
        servers_to_try = [working_server] if working_server else candidates

        connected_any = False
        for host, port in servers_to_try:
            try:
                code = _check_imap_once(
                    email_addr=email_addr,
                    mail_password=mail_password,
                    host=host,
                    port=port,
                    min_timestamp=start_ts,
                    known_old_ids=known_old_ids,
                    seen_skipped=seen_skipped,
                    log_fn=log_fn,
                )
                connected_any = True
                working_server = (host, port)
                if code:
                    if log_fn:
                        log_fn(f"Получен НОВЫЙ код TikTok по IMAP ({host}): {code}")
                    return code
                break  # Connected & checked successfully; wait for next poll cycle
            except imaplib.IMAP4.error as auth_err:
                last_error = f"IMAP {host}:{port} -> {auth_err}"
                # If this was a known provider (single candidate), try POP3 fallback once
                if len(servers_to_try) == 1:
                    pop_host = host.replace("imap.", "pop.")
                    try:
                        code = _check_pop3_once(email_addr, mail_password, pop_host, 995, start_ts)
                        connected_any = True
                        if code:
                            if log_fn:
                                log_fn(f"[{email_addr}] Получен код по POP3 ({pop_host}): {code}")
                            return code
                        break
                    except Exception:
                        pass
                continue
            except (socket.gaierror, socket.timeout, ConnectionError, OSError) as net_err:
                last_error = f"Сеть {host}:{port} -> {net_err}"
                continue

        if not connected_any and attempt >= 2:
            raise RuntimeError(
                f"Не удалось подключиться/войти в почту {email_addr} ({last_error})"
            )

        remaining = int(deadline - time.time())
        if remaining <= 0:
            break
        if log_fn and attempt % 3 == 1:
            srv_label = working_server[0] if working_server else candidates[0][0]
            log_fn(f"[{email_addr}] Ожидание письма с кодом на {srv_label}... (осталось ~{remaining}с)")
        time.sleep(min(poll_interval_sec, max(1.0, remaining)))

    raise TimeoutError(
        f"Таймаут ({timeout_sec}с): письмо с кодом от TikTok не пришло на {email_addr}"
    )
