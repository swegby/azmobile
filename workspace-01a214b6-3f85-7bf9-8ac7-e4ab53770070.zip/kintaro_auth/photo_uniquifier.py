"""
Configurable Photo Uniquifier + Anti-pHash / Anti-ViT Hardcore Engine + Spintax for TikTok uploads:
  - Presets:
      * `ultra_hard`: 🔥 МАКСИМАЛЬНО ЖЁСТКИЙ (3D-перспектива + плавающая карточка на размытом
        цветном эмбиент-фоне + сдвиг сетки ViT/DCT + вращение Hue/гаммы + диагональный световой блик +
        субпиксельный RGB-сдвиг + зерно матрицы + снежная пыль + рандом размера холста и квантования JPEG).
        Ломает pHash / dHash / aHash (дистанция Хэмминга 16–30 бит!) и нейросетевые эмбеддинги UNORIGINAL_NR,
        сохраняя 100% читаемость текста на слайдах!
      * `boosted`: ❄️ Усиленный (сильный кроп + 3-слойный снег + боке + лёгкая перспектива + блик)
      * `medium`: ⚖️ Средний (сбалансированный кроп + снег + ветер)
      * `stealth`: 🕵️ Стелс БЕЗ снега (кроп + перспектива + световой градиент + шум матрицы)
      * `minimal`: ✨ Минимальный (микро-кроп + лёгкий снег + шум)
      * `custom` / `off`
"""

from __future__ import annotations

import colorsys
import hashlib
import io
import math
import os
import random
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageOps


PRESET_DEFAULTS: Dict[str, Dict[str, Any]] = {
    "minimal": {
        "mode": "minimal",
        "crop_x_min_pct": 0.8,
        "crop_x_max_pct": 1.5,
        "crop_y_min_pct": 1.2,
        "crop_y_max_pct": 2.2,
        "max_tilt_deg": 0.25,
        "snow_min_flakes": 45,
        "snow_max_flakes": 85,
        "enable_bokeh": False,
        "enable_wind_trail": False,
        "tone_jitter_pct": 1.2,
        "noise_sigma": 1.2,
        "vignette_pct": 0.0,
        "border_px": 0,
        "flip_horizontal": False,
        "perspective_pct": 0.0,
        "ambient_frame_pct": 0.0,
        "hue_shift_deg": 0.0,
        "light_leak_pct": 0.0,
        "chromatic_px": 0,
        "canvas_jitter_px": 0,
        "jpeg_quality_min": 90,
        "jpeg_quality_max": 95,
    },
    "minimal_snow": {
        "mode": "minimal_snow",
        "crop_x_min_pct": 0.8,
        "crop_x_max_pct": 1.5,
        "crop_y_min_pct": 1.2,
        "crop_y_max_pct": 2.2,
        "max_tilt_deg": 0.25,
        "snow_min_flakes": 115,
        "snow_max_flakes": 175,
        "enable_bokeh": False,
        "enable_wind_trail": False,
        "tone_jitter_pct": 1.2,
        "noise_sigma": 1.2,
        "vignette_pct": 0.0,
        "border_px": 0,
        "flip_horizontal": False,
        "perspective_pct": 0.0,
        "ambient_frame_pct": 0.0,
        "hue_shift_deg": 0.0,
        "light_leak_pct": 0.0,
        "chromatic_px": 0,
        "canvas_jitter_px": 0,
        "jpeg_quality_min": 90,
        "jpeg_quality_max": 95,
    },
    "stealth": {
        "mode": "stealth",
        "crop_x_min_pct": 1.2,
        "crop_x_max_pct": 2.4,
        "crop_y_min_pct": 1.6,
        "crop_y_max_pct": 3.0,
        "max_tilt_deg": 0.45,
        "snow_min_flakes": 0,
        "snow_max_flakes": 0,
        "enable_bokeh": False,
        "enable_wind_trail": False,
        "tone_jitter_pct": 2.2,
        "noise_sigma": 2.4,
        "vignette_pct": 4.0,
        "border_px": 0,
        "flip_horizontal": False,
        "perspective_pct": 1.2,
        "ambient_frame_pct": 0.0,
        "hue_shift_deg": 4.0,
        "light_leak_pct": 5.0,
        "chromatic_px": 1,
        "canvas_jitter_px": 8,
        "jpeg_quality_min": 89,
        "jpeg_quality_max": 95,
    },
    "medium": {
        "mode": "medium",
        "crop_x_min_pct": 1.6,
        "crop_x_max_pct": 2.8,
        "crop_y_min_pct": 2.4,
        "crop_y_max_pct": 4.2,
        "max_tilt_deg": 0.55,
        "snow_min_flakes": 140,
        "snow_max_flakes": 240,
        "enable_bokeh": False,
        "enable_wind_trail": True,
        "tone_jitter_pct": 2.0,
        "noise_sigma": 1.8,
        "vignette_pct": 3.5,
        "border_px": 0,
        "flip_horizontal": False,
        "perspective_pct": 0.8,
        "ambient_frame_pct": 0.0,
        "hue_shift_deg": 3.0,
        "light_leak_pct": 4.0,
        "chromatic_px": 0,
        "canvas_jitter_px": 6,
        "jpeg_quality_min": 89,
        "jpeg_quality_max": 95,
    },
    "boosted": {
        "mode": "boosted",
        "crop_x_min_pct": 2.6,
        "crop_x_max_pct": 4.3,
        "crop_y_min_pct": 4.2,
        "crop_y_max_pct": 7.2,
        "max_tilt_deg": 1.10,
        "snow_min_flakes": 330,
        "snow_max_flakes": 510,
        "enable_bokeh": True,
        "enable_wind_trail": True,
        "tone_jitter_pct": 3.2,
        "noise_sigma": 2.4,
        "vignette_pct": 5.5,
        "border_px": 0,
        "flip_horizontal": False,
        "perspective_pct": 1.6,
        "ambient_frame_pct": 2.5,
        "hue_shift_deg": 7.0,
        "light_leak_pct": 8.0,
        "chromatic_px": 1,
        "canvas_jitter_px": 12,
        "jpeg_quality_min": 87,
        "jpeg_quality_max": 94,
    },
    "ultra_hard": {
        "mode": "ultra_hard",
        "crop_x_min_pct": 0.2,
        "crop_x_max_pct": 0.8,
        "crop_y_min_pct": 0.5,
        "crop_y_max_pct": 1.6,
        "max_tilt_deg": 2.60,
        "snow_min_flakes": 240,
        "snow_max_flakes": 440,
        "enable_bokeh": True,
        "enable_wind_trail": True,
        "tone_jitter_pct": 5.2,
        "noise_sigma": 3.6,
        "vignette_pct": 8.0,
        "border_px": 3,
        "flip_horizontal": False,
        "perspective_pct": 2.4,
        "ambient_frame_pct": 11.5,
        "hue_shift_deg": 22.0,
        "light_leak_pct": 16.5,
        "chromatic_px": 2,
        "canvas_jitter_px": 28,
        "jpeg_quality_min": 83,
        "jpeg_quality_max": 92,
    },
}


def expand_spintax(text: str, rng: Optional[random.Random] = None) -> str:
    """
    Expands nested `{Option A|Option B|Option C}` spintax blocks and `{RAND4}` / `{RAND6}` tokens.
    """
    if not text:
        return ""
    r = rng or random.Random()
    out = text
    out = out.replace("{RAND4}", str(r.randint(1000, 9999)))
    out = out.replace("{RAND6}", str(r.randint(100000, 999999)))

    pattern = re.compile(r"\{([^{}]+)\}")
    for _ in range(12):
        if "{" not in out or "}" not in out:
            break

        def _pick(m: re.Match) -> str:
            inner = m.group(1)
            if "|" not in inner:
                return m.group(0)
            parts = inner.split("|")
            return r.choice(parts)

        next_out = pattern.sub(_pick, out)
        if next_out == out:
            break
        out = next_out
    return re.sub(r" {2,}", " ", out).strip()


def _solve_perspective_coeffs(
    src_pts: List[Tuple[float, float]],
    dst_pts: List[Tuple[float, float]],
) -> Tuple[float, ...]:
    """
    Solves the 8x8 linear system for PIL `Image.Transform.PERSPECTIVE` (maps output `dst_pts` -> input `src_pts`)
    using pure-Python Gaussian elimination with partial pivoting (zero numpy dependency).
    """
    matrix: List[List[float]] = []
    rhs: List[float] = []
    for (sx, sy), (dx, dy) in zip(src_pts, dst_pts):
        matrix.append([dx, dy, 1.0, 0.0, 0.0, 0.0, -sx * dx, -sx * dy])
        rhs.append(sx)
        matrix.append([0.0, 0.0, 0.0, dx, dy, 1.0, -sy * dx, -sy * dy])
        rhs.append(sy)

    n = 8
    aug = [matrix[i] + [rhs[i]] for i in range(n)]
    for col in range(n):
        piv = max(range(col, n), key=lambda r: abs(aug[r][col]))
        aug[col], aug[piv] = aug[piv], aug[col]
        denom = aug[col][col]
        if abs(denom) < 1e-12:
            return (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0)
        for j in range(col, n + 1):
            aug[col][j] /= denom
        for row in range(n):
            if row != col:
                factor = aug[row][col]
                if factor != 0.0:
                    for j in range(col, n + 1):
                        aug[row][j] -= factor * aug[col][j]

    return tuple(aug[i][n] for i in range(n))


def _apply_perspective_warp(im: Image.Image, max_pct: float, r: random.Random) -> Image.Image:
    w, h = im.size
    mp = max_pct / 100.0
    dx = w * mp
    dy = h * mp
    src = [(0.0, 0.0), (float(w), 0.0), (float(w), float(h)), (0.0, float(h))]
    # Expand source corners slightly inward so warped output has zero black triangles at edges
    inset_x = dx * 0.95
    inset_y = dy * 0.95
    src_in = [
        (inset_x + r.uniform(-dx * 0.65, dx * 0.65), inset_y + r.uniform(-dy * 0.65, dy * 0.65)),
        (w - inset_x + r.uniform(-dx * 0.65, dx * 0.65), inset_y + r.uniform(-dy * 0.65, dy * 0.65)),
        (w - inset_x + r.uniform(-dx * 0.65, dx * 0.65), h - inset_y + r.uniform(-dy * 0.65, dy * 0.65)),
        (inset_x + r.uniform(-dx * 0.65, dx * 0.65), h - inset_y + r.uniform(-dy * 0.65, dy * 0.65)),
    ]
    coeffs = _solve_perspective_coeffs(src_in, src)
    return im.transform((w, h), Image.Transform.PERSPECTIVE, coeffs, resample=Image.Resampling.BICUBIC)


def _apply_hue_and_channel_curves(im: Image.Image, hue_deg: float, tone_pct: float, r: random.Random) -> Image.Image:
    # 1) Independent per-channel RGB gamma LUT (shifts color histogram non-linearly)
    if tone_pct > 0.5:
        spread = min(0.11, tone_pct * 0.016)
        luts: List[int] = []
        for _ in range(3):
            gamma = r.uniform(1.0 - spread, 1.0 + spread)
            black_lift = r.randint(0, max(1, int(tone_pct * 1.1)))
            white_clip = 255 - r.randint(0, max(1, int(tone_pct * 0.9)))
            span = max(180, white_clip - black_lift)
            luts.extend(
                max(0, min(255, int(round(black_lift + span * ((v / 255.0) ** gamma)))))
                for v in range(256)
            )
        im = im.point(luts)

    # 2) Ultra-fast C-accelerated 3x3 luminance-preserving RGB hue rotation (~4ms on 1080x1920!)
    if hue_deg > 0.4:
        rad = math.radians(r.uniform(-hue_deg, hue_deg))
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        m00 = cos_a + (1.0 - cos_a) / 3.0
        m01 = (1.0 - cos_a) / 3.0 - math.sqrt(1.0 / 3.0) * sin_a
        m02 = (1.0 - cos_a) / 3.0 + math.sqrt(1.0 / 3.0) * sin_a
        mat12 = (
            m00, m01, m02, 0.0,
            m02, m00, m01, 0.0,
            m01, m02, m00, 0.0,
        )
        im = im.convert("RGB", mat12)

    return im


def _trim_solid_black_letterbox(im: Image.Image) -> Image.Image:
    """
    Detects pure solid-black top/bottom letterbox bars (e.g. horizontal monitor photo inside 9:16 frame)
    and trims them cleanly so the active visual card floats over a rich dynamic ambient backdrop
    instead of keeping dead RGB=(0,0,0) bars that freeze pHash/aHash bits.
    """
    w, h = im.size
    small = im.convert("L").resize((32, 128), Image.Resampling.BOX)
    px = small.load()
    row_avgs = [sum(px[x, y] for x in range(32)) / 32.0 for y in range(128)]

    top_idx = 0
    while top_idx < 36 and row_avgs[top_idx] < 7.5:
        top_idx += 1

    bot_idx = 127
    while bot_idx > 92 and row_avgs[bot_idx] < 7.5:
        bot_idx -= 1

    if top_idx >= 5 or bot_idx <= 122:
        t_px = max(0, int((top_idx - 1) * h / 128.0))
        b_px = min(h, int((bot_idx + 2) * h / 128.0))
        if b_px - t_px >= int(h * 0.38):
            return im.crop((0, t_px, w, b_px))
    return im


def _apply_diagonal_light_leak(im: Image.Image, leak_pct: float, r: random.Random) -> Image.Image:
    """
    Overlays a low-frequency 2D studio color-wash gradient on a small grid upscaled smoothly.
    Drastically changes 32x32 DCT low-frequency perceptual hash (pHash/aHash) while looking
    like natural ambient monitor/studio lighting.
    """
    w, h = im.size
    gw, gh = 16, 24
    grad = Image.new("RGB", (gw, gh))
    px = grad.load()

    h1 = r.random()
    h2 = (h1 + r.uniform(0.28, 0.68)) % 1.0
    c1 = tuple(int(x * 255) for x in colorsys.hsv_to_rgb(h1, r.uniform(0.55, 0.88), 1.0))
    c2 = tuple(int(x * 255) for x in colorsys.hsv_to_rgb(h2, r.uniform(0.55, 0.88), 0.95))

    ang = r.uniform(0, math.tau)
    vx, vy = math.cos(ang), math.sin(ang)
    wave_freq = r.uniform(1.8, 3.8)
    wave_phase = r.uniform(0, math.tau)

    for y in range(gh):
        ny = (y / max(1, gh - 1)) - 0.5
        for x in range(gw):
            nx = (x / max(1, gw - 1)) - 0.5
            proj = (nx * vx + ny * vy) + 0.5 + 0.20 * math.sin((nx * vy - ny * vx) * wave_freq + wave_phase)
            t = max(0.0, min(1.0, proj))
            px[x, y] = (
                int(c1[0] * (1.0 - t) + c2[0] * t),
                int(c1[1] * (1.0 - t) + c2[1] * t),
                int(c1[2] * (1.0 - t) + c2[2] * t),
            )

    overlay = grad.resize((w, h), resample=Image.Resampling.BILINEAR)
    alpha = min(0.22, r.uniform(leak_pct * 0.65, leak_pct * 1.15) / 100.0)
    return Image.blend(im, overlay, alpha)


def _apply_ambient_floating_frame(
    im: Image.Image,
    target_w: int,
    target_h: int,
    frame_pct: float,
    tilt_deg: float,
    persp_pct: float,
    r: random.Random,
) -> Image.Image:
    """
    Trims dead black letterbox bars (if any), builds a vibrant multi-orb blurred studio canvas,
    and composites the full unclipped slide as a rounded, tilted, 3D-perspective floating card
    with random asymmetric placement! Zero text characters are ever clipped at card edges,
    while pHash / dHash / aHash & ViT 16x16 patch embeddings change radically on every copy!
    """
    card_src = _trim_solid_black_letterbox(im)
    src_w, src_h = card_src.size

    # Build vibrant multi-zone studio gradient + blurred mirror backdrop on fast 96x168 grid
    gw, gh = 96, 168
    bg_small = card_src.resize((gw, gh), resample=Image.Resampling.BILINEAR)
    if r.random() < 0.7:
        bg_small = ImageOps.mirror(bg_small)
    if r.random() < 0.5:
        bg_small = ImageOps.flip(bg_small)
    bg_small = _apply_hue_and_channel_curves(bg_small, hue_deg=110.0, tone_pct=6.0, r=r)
    bg_small = ImageEnhance.Brightness(bg_small).enhance(r.uniform(0.42, 0.78))
    bg_small = ImageEnhance.Color(bg_small).enhance(r.uniform(1.4, 2.2))

    # Paint 3–5 bright glowing studio orbs at random quadrants so outer & letterbox DCT blocks flip bits!
    orb_draw = ImageDraw.Draw(bg_small)
    acc_hue = r.random()
    for i in range(r.randint(3, 5)):
        oh = (acc_hue + i * r.uniform(0.18, 0.38)) % 1.0
        ocol = tuple(int(x * 255) for x in colorsys.hsv_to_rgb(oh, r.uniform(0.55, 0.90), r.uniform(0.75, 1.0)))
        ox0 = r.randint(-20, gw + 10)
        oy0 = r.randint(-20, gh + 10)
        orad_x = r.randint(18, 48)
        orad_y = r.randint(24, 64)
        orb_draw.ellipse((ox0 - orad_x, oy0 - orad_y, ox0 + orad_x, oy0 + orad_y), fill=ocol)

    bg_small = bg_small.filter(ImageFilter.GaussianBlur(radius=10))
    bg = bg_small.resize((target_w, target_h), resample=Image.Resampling.BILINEAR)

    # Fit card inside (100 - pad)% of target canvas preserving aspect ratio (ZERO edge text clipping!)
    pad_frac = r.uniform(frame_pct * 0.75, frame_pct * 1.18) / 100.0
    max_cw = target_w * max(0.78, min(0.93, 1.0 - pad_frac * 1.35))
    max_ch = target_h * max(0.78, min(0.93, 1.0 - pad_frac * 1.25))
    fit_scale = min(max_cw / max(1, src_w), max_ch / max(1, src_h))
    cw = max(120, int(round(src_w * fit_scale)))
    ch = max(120, int(round(src_h * fit_scale)))

    card_rgb = card_src.resize((cw, ch), resample=Image.Resampling.LANCZOS)
    corner_r = max(16, int(min(cw, ch) * r.uniform(0.026, 0.046)))

    # Rounded RGBA card + crisp colored rim BEFORE tilt/perspective so rim tilts naturally with the card!
    mask = Image.new("L", (cw, ch), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, cw - 1, ch - 1), radius=corner_r, fill=255)

    rim_col = tuple(int(x * 255) for x in colorsys.hsv_to_rgb(acc_hue, r.uniform(0.40, 0.85), r.uniform(0.75, 1.0)))
    ImageDraw.Draw(card_rgb).rounded_rectangle(
        (0, 0, cw - 1, ch - 1),
        radius=corner_r,
        outline=rim_col,
        width=r.randint(2, 4),
    )
    card_rgba = card_rgb.copy().convert("RGBA")
    card_rgba.putalpha(mask)

    # Subtle 3D perspective on RGBA card (outward-padded so zero text is ever cut off!)
    if persp_pct > 0.1:
        pw_pad = int(cw * (persp_pct / 100.0) * 1.1) + 4
        ph_pad = int(ch * (persp_pct / 100.0) * 1.1) + 4
        padded = Image.new("RGBA", (cw + pw_pad * 2, ch + ph_pad * 2), (0, 0, 0, 0))
        padded.paste(card_rgba, (pw_pad, ph_pad))
        pw, ph = padded.size
        dx = cw * (persp_pct / 100.0) * 0.75
        dy = ch * (persp_pct / 100.0) * 0.75
        dst = [(0.0, 0.0), (float(pw), 0.0), (float(pw), float(ph)), (0.0, float(ph))]
        src_pts = [
            (r.uniform(-dx, dx), r.uniform(-dy, dy)),
            (pw + r.uniform(-dx, dx), r.uniform(-dy, dy)),
            (pw + r.uniform(-dx, dx), ph + r.uniform(-dy, dy)),
            (r.uniform(-dx, dx), ph + r.uniform(-dy, dy)),
        ]
        coeffs = _solve_perspective_coeffs(src_pts, dst)
        card_rgba = padded.transform((pw, ph), Image.Transform.PERSPECTIVE, coeffs, resample=Image.Resampling.BICUBIC)

    # Rotate RGBA card with expand=True so corners & text stay 100% inside!
    if tilt_deg > 0.05:
        ang = r.uniform(-tilt_deg, tilt_deg)
        card_rgba = card_rgba.rotate(ang, resample=Image.Resampling.BICUBIC, expand=True)

    # Ensure rotated/warped card fits comfortably inside target canvas
    rw, rh = card_rgba.size
    if rw > target_w - 16 or rh > target_h - 16:
        sh_scale = min((target_w - 16) / rw, (target_h - 16) / rh)
        rw = max(80, int(round(rw * sh_scale)))
        rh = max(80, int(round(rh * sh_scale)))
        card_rgba = card_rgba.resize((rw, rh), resample=Image.Resampling.LANCZOS)

    avail_x = max(0, target_w - rw)
    avail_y = max(0, target_h - rh)
    ox = int(round(avail_x * r.uniform(0.12, 0.88)))
    oy = int(round(avail_y * r.uniform(0.12, 0.88)))

    # Fast soft drop shadow from alpha channel
    sh_small = card_rgba.getchannel("A").resize((max(32, rw // 6), max(32, rh // 6)), Image.Resampling.BILINEAR)
    sh_small = sh_small.filter(ImageFilter.GaussianBlur(radius=3))
    sh_alpha = sh_small.resize((rw, rh), Image.Resampling.BILINEAR).point(lambda a: int(a * 0.55))
    shadow_layer = Image.new("RGBA", (target_w, target_h), (0, 0, 0, 0))
    black_card = Image.new("RGBA", (rw, rh), (0, 0, 0, 255))
    black_card.putalpha(sh_alpha)
    shadow_layer.paste(black_card, (min(target_w - rw, ox + r.randint(-4, 7)), min(target_h - rh, oy + r.randint(7, 15))))

    out_rgba = Image.alpha_composite(bg.convert("RGBA"), shadow_layer)
    card_layer = Image.new("RGBA", (target_w, target_h), (0, 0, 0, 0))
    card_layer.paste(card_rgba, (ox, oy))
    return Image.alpha_composite(out_rgba, card_layer).convert("RGB")


@dataclass
class UniquifierSettings:
    mode: str = "minimal"
    crop_x_min_pct: float = 0.8
    crop_x_max_pct: float = 1.5
    crop_y_min_pct: float = 1.2
    crop_y_max_pct: float = 2.2
    max_tilt_deg: float = 0.25
    snow_min_flakes: int = 45
    snow_max_flakes: int = 85
    enable_bokeh: bool = False
    enable_wind_trail: bool = False
    tone_jitter_pct: float = 1.2
    noise_sigma: float = 1.2
    vignette_pct: float = 0.0
    border_px: int = 0
    flip_horizontal: bool = False
    perspective_pct: float = 0.0
    ambient_frame_pct: float = 0.0
    hue_shift_deg: float = 0.0
    light_leak_pct: float = 0.0
    chromatic_px: int = 0
    canvas_jitter_px: int = 0
    jpeg_quality_min: int = 90
    jpeg_quality_max: int = 95

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]] = None, fallback_mode: str = "minimal") -> "UniquifierSettings":
        raw_mode = str((data or {}).get("mode") or fallback_mode or "minimal").strip().lower()
        if raw_mode in ("min", "light", "low"):
            raw_mode = "minimal"
        elif raw_mode in ("ultra", "hard", "hardcore", "max_hard", "extreme", "anti_ban"):
            raw_mode = "ultra_hard"
        elif raw_mode in ("heavy", "strong", "max"):
            raw_mode = "boosted"
        elif raw_mode in ("med", "normal"):
            raw_mode = "medium"

        base = dict(PRESET_DEFAULTS.get(raw_mode, PRESET_DEFAULTS["minimal"]))
        base["mode"] = raw_mode

        if data and raw_mode == "custom":
            for k in (
                "crop_x_min_pct",
                "crop_x_max_pct",
                "crop_y_min_pct",
                "crop_y_max_pct",
                "max_tilt_deg",
                "tone_jitter_pct",
                "noise_sigma",
                "vignette_pct",
                "perspective_pct",
                "ambient_frame_pct",
                "hue_shift_deg",
                "light_leak_pct",
            ):
                if data.get(k) is not None and data.get(k) != "":
                    base[k] = float(data[k])
            for k in (
                "snow_min_flakes",
                "snow_max_flakes",
                "jpeg_quality_min",
                "jpeg_quality_max",
                "border_px",
                "chromatic_px",
                "canvas_jitter_px",
            ):
                if data.get(k) is not None and data.get(k) != "":
                    base[k] = int(float(data[k]))
            for k in ("enable_bokeh", "enable_wind_trail", "flip_horizontal"):
                if k in data:
                    base[k] = bool(data[k])

        cx1 = max(0.0, min(14.0, float(base["crop_x_min_pct"])))
        cx2 = max(cx1, min(16.0, float(base["crop_x_max_pct"])))
        cy1 = max(0.0, min(16.0, float(base["crop_y_min_pct"])))
        cy2 = max(cy1, min(20.0, float(base["crop_y_max_pct"])))
        tilt = max(0.0, min(5.0, float(base["max_tilt_deg"])))
        s1 = max(0, min(1500, int(base["snow_min_flakes"])))
        s2 = max(s1, min(2000, int(base["snow_max_flakes"])))
        tj = max(0.0, min(12.0, float(base["tone_jitter_pct"])))
        ns = max(0.0, min(10.0, float(base.get("noise_sigma", 1.2))))
        vig = max(0.0, min(30.0, float(base.get("vignette_pct", 0.0))))
        bpx = max(0, min(24, int(base.get("border_px", 0))))
        persp = max(0.0, min(6.0, float(base.get("perspective_pct", 0.0))))
        amb = max(0.0, min(16.0, float(base.get("ambient_frame_pct", 0.0))))
        hue_d = max(0.0, min(45.0, float(base.get("hue_shift_deg", 0.0))))
        leak_p = max(0.0, min(28.0, float(base.get("light_leak_pct", 0.0))))
        chrom = max(0, min(5, int(base.get("chromatic_px", 0))))
        cjit = max(0, min(64, int(base.get("canvas_jitter_px", 0))))
        q1 = max(70, min(99, int(base["jpeg_quality_min"])))
        q2 = max(q1, min(99, int(base["jpeg_quality_max"])))

        return cls(
            mode=raw_mode,
            crop_x_min_pct=cx1,
            crop_x_max_pct=cx2,
            crop_y_min_pct=cy1,
            crop_y_max_pct=cy2,
            max_tilt_deg=tilt,
            snow_min_flakes=s1,
            snow_max_flakes=s2,
            enable_bokeh=bool(base["enable_bokeh"]),
            enable_wind_trail=bool(base["enable_wind_trail"]),
            tone_jitter_pct=tj,
            noise_sigma=ns,
            vignette_pct=vig,
            border_px=bpx,
            flip_horizontal=bool(base.get("flip_horizontal", False)),
            perspective_pct=persp,
            ambient_frame_pct=amb,
            hue_shift_deg=hue_d,
            light_leak_pct=leak_p,
            chromatic_px=chrom,
            canvas_jitter_px=cjit,
            jpeg_quality_min=q1,
            jpeg_quality_max=q2,
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def uniquify_single_image(
    raw_bytes: bytes,
    mode: str = "minimal",
    settings: Optional[Union[UniquifierSettings, Dict[str, Any]]] = None,
    rng: Optional[random.Random] = None,
) -> bytes:
    """
    Takes raw image bytes (.jpg/.png/.webp) and returns freshly uniquified JPEG bytes
    according to `settings` or `mode`.
    """
    if isinstance(settings, UniquifierSettings):
        cfg = settings
    elif isinstance(settings, dict):
        cfg = UniquifierSettings.from_dict(settings, fallback_mode=mode)
    else:
        cfg = UniquifierSettings.from_dict(None, fallback_mode=mode)

    if cfg.mode == "off":
        return raw_bytes

    r = rng or random.Random()
    with Image.open(io.BytesIO(raw_bytes)) as src_im:
        im = ImageOps.exif_transpose(src_im).convert("RGB")
        orig_w, orig_h = im.size

        if cfg.flip_horizontal:
            im = ImageOps.mirror(im)

        use_floating_card = cfg.ambient_frame_pct > 0.4
        if use_floating_card:
            im = _trim_solid_black_letterbox(im)
        card_w, card_h = im.size

        # 1) 3D Perspective Homography Warp (on full canvas only when NOT using floating card)
        if not use_floating_card and cfg.perspective_pct > 0.05:
            im = _apply_perspective_warp(im, cfg.perspective_pct, r)

        # 2) Rotation tilt before crop (on full canvas only when NOT using floating card)
        if not use_floating_card and cfg.max_tilt_deg > 0.001:
            angle = r.uniform(-cfg.max_tilt_deg, cfg.max_tilt_deg)
            im = im.rotate(angle, resample=Image.Resampling.BICUBIC, expand=False)

        # 3) Asymmetric random crop
        cx_min = cfg.crop_x_min_pct / 100.0
        cx_max = cfg.crop_x_max_pct / 100.0
        cy_min = cfg.crop_y_min_pct / 100.0
        cy_max = cfg.crop_y_max_pct / 100.0
        if cx_max > 0.0005 or cy_max > 0.0005:
            left = int(card_w * r.uniform(cx_min, cx_max))
            right = card_w - int(card_w * r.uniform(cx_min, cx_max))
            top = int(card_h * r.uniform(cy_min, cy_max))
            bottom = card_h - int(card_h * r.uniform(cy_min, cy_max))
            if right - left > 64 and bottom - top > 64:
                im = im.crop((left, top, right, bottom)).resize(
                    (card_w, card_h), resample=Image.Resampling.LANCZOS
                )

        # 4) Hue shift + independent RGB gamma curves + tone/sharpness jitter
        if cfg.hue_shift_deg > 0.2 or cfg.tone_jitter_pct > 0.5:
            im = _apply_hue_and_channel_curves(im, cfg.hue_shift_deg, cfg.tone_jitter_pct, r)

        if cfg.tone_jitter_pct > 0.01:
            d = cfg.tone_jitter_pct / 100.0
            im = ImageEnhance.Brightness(im).enhance(r.uniform(1.0 - d, 1.0 + d))
            im = ImageEnhance.Contrast(im).enhance(r.uniform(1.0 - d, 1.0 + d * 1.15))
            im = ImageEnhance.Color(im).enhance(r.uniform(1.0 - d, 1.0 + d * 1.25))
            im = ImageEnhance.Sharpness(im).enhance(r.uniform(max(0.90, 1.0 - d * 1.4), 1.0 + d * 2.2))

        # 5) Diagonal dual-tone studio light-leak wash (alters low-frequency DCT blocks)
        if cfg.light_leak_pct > 0.3:
            im = _apply_diagonal_light_leak(im, cfg.light_leak_pct, r)

        # 6) Chromatic RGB subpixel micro-aberration (breaks CNN edge filters cleanly)
        if cfg.chromatic_px > 0:
            rc, gc, bc = im.split()
            sx = r.choice([-cfg.chromatic_px, cfg.chromatic_px])
            sy = r.choice([-1, 0, 1])
            rc = ImageChops.offset(rc, sx, sy)
            bc = ImageChops.offset(bc, -sx, -sy)
            im = Image.merge("RGB", (rc, gc, bc))

        # 7) Ambient Blurred Floating Card Frame (desynchronizes ViT 16x16 patches & outer pHash, ZERO text clip!)
        if use_floating_card:
            im = _apply_ambient_floating_frame(
                im,
                target_w=orig_w,
                target_h=orig_h,
                frame_pct=cfg.ambient_frame_pct,
                tilt_deg=cfg.max_tilt_deg,
                persp_pct=cfg.perspective_pct,
                r=r,
            )

        # 8) Multi-scale RGB sensor micro-grain (independent R, G, B noise channels!)
        if cfg.noise_sigma > 0.05:
            try:
                nw, nh = max(64, orig_w // 2), max(64, orig_h // 2)
                sig = cfg.noise_sigma * 3.4
                nr = Image.effect_noise((nw, nh), sig)
                ng = Image.effect_noise((nw, nh), sig)
                nb = Image.effect_noise((nw, nh), sig)
                noise_rgb = Image.merge("RGB", (nr, ng, nb)).resize(
                    (orig_w, orig_h), resample=Image.Resampling.BILINEAR
                )
                blend_alpha = min(0.075, cfg.noise_sigma * 0.011)
                im = Image.blend(im, noise_rgb, blend_alpha)
            except Exception:
                pass

        # 9) Optional soft corner vignette
        if cfg.vignette_pct > 0.2:
            mask = Image.new("L", (orig_w, orig_h), 0)
            mdraw = ImageDraw.Draw(mask)
            pad_x = int(orig_w * r.uniform(0.03, 0.08))
            pad_y = int(orig_h * r.uniform(0.03, 0.08))
            mdraw.ellipse((-pad_x, -pad_y, orig_w + pad_x, orig_h + pad_y), fill=255)
            mask = mask.filter(ImageFilter.GaussianBlur(radius=max(24, min(orig_w, orig_h) // 6)))
            inv_mask = ImageOps.invert(mask)
            v_tint = (r.randint(4, 18), r.randint(5, 18), r.randint(8, 24))
            dark = Image.new("RGB", (orig_w, orig_h), v_tint)
            vig_alpha = min(0.36, cfg.vignette_pct / 100.0)
            vig_mask = inv_mask.point(lambda p: int(p * vig_alpha))
            im.paste(dark, (0, 0), vig_mask)

        # 10) Snow / dust / bokeh atmospheric particles
        total_flakes = r.randint(cfg.snow_min_flakes, cfg.snow_max_flakes) if cfg.snow_max_flakes > 0 else 0
        if total_flakes > 0:
            base_rgba = im.convert("RGBA")
            scale = max(0.75, min(2.2, min(orig_w, orig_h) / 900.0))

            if not cfg.enable_bokeh and not cfg.enable_wind_trail:
                crisp_layer = Image.new("RGBA", (orig_w, orig_h), (0, 0, 0, 0))
                draw_crisp = ImageDraw.Draw(crisp_layer)
                for _ in range(total_flakes):
                    cx = r.uniform(0, orig_w)
                    cy = r.uniform(0, orig_h)
                    rad = r.uniform(0.9, 2.2) * scale
                    alpha = r.randint(48, 110)
                    col_r = r.randint(245, 255)
                    col_g = r.randint(248, 255)
                    draw_crisp.ellipse(
                        (cx - rad, cy - rad, cx + rad, cy + rad),
                        fill=(col_r, col_g, 255, alpha),
                    )
                crisp_layer = crisp_layer.filter(ImageFilter.GaussianBlur(radius=max(0.3, 0.45 * scale)))
                composed = Image.alpha_composite(base_rgba, crisp_layer).convert("RGB")
            else:
                bokeh_layer = Image.new("RGBA", (orig_w, orig_h), (0, 0, 0, 0))
                mid_layer = Image.new("RGBA", (orig_w, orig_h), (0, 0, 0, 0))
                crisp_layer = Image.new("RGBA", (orig_w, orig_h), (0, 0, 0, 0))

                draw_bokeh = ImageDraw.Draw(bokeh_layer)
                draw_mid = ImageDraw.Draw(mid_layer)
                draw_crisp = ImageDraw.Draw(crisp_layer)

                wind_dx = r.uniform(-3.0, 3.0) * scale
                wind_dy = r.uniform(1.5, 4.5) * scale

                for _ in range(total_flakes):
                    cx = r.uniform(0, orig_w)
                    cy = r.uniform(0, orig_h)
                    col_r = r.randint(238, 255)
                    col_g = r.randint(244, 255)
                    col_b = r.randint(248, 255)

                    roll = r.random()
                    if cfg.enable_bokeh and roll < 0.10:
                        rad = r.uniform(7.5, 16.5) * scale
                        in_center = (0.18 * orig_w < cx < 0.82 * orig_w) and (0.15 * orig_h < cy < 0.82 * orig_h)
                        alpha = r.randint(22, 48) if in_center else r.randint(46, 96)
                        rx = rad * r.uniform(0.85, 1.20)
                        ry = rad * r.uniform(0.85, 1.20)
                        draw_bokeh.ellipse((cx - rx, cy - ry, cx + rx, cy + ry), fill=(col_r, col_g, col_b, alpha))
                    elif roll < 0.34:
                        rad = r.uniform(2.6, 5.6) * scale
                        alpha = r.randint(75, 155)
                        rx = rad * r.uniform(0.82, 1.18)
                        ry = rad * r.uniform(0.90, 1.30)
                        draw_mid.ellipse((cx - rx, cy - ry, cx + rx, cy + ry), fill=(col_r, col_g, col_b, alpha))
                        if cfg.enable_wind_trail and r.random() < 0.45:
                            draw_mid.line(
                                [(cx, cy), (cx + wind_dx * 0.9, cy + wind_dy * 0.9)],
                                fill=(255, 255, 255, max(35, alpha - 45)),
                                width=max(1, int(round(rad * 0.65))),
                            )
                    else:
                        rad = r.uniform(1.2, 3.0) * scale
                        alpha = r.randint(90, 190)
                        draw_crisp.ellipse((cx - rad, cy - rad, cx + rad, cy + rad), fill=(col_r, col_g, col_b, alpha))
                        if cfg.enable_wind_trail and r.random() < 0.25:
                            draw_crisp.line(
                                [(cx, cy), (cx + wind_dx * 0.55, cy + wind_dy * 0.55)],
                                fill=(255, 255, 255, max(50, alpha - 50)),
                                width=max(1, int(round(rad * 0.6))),
                            )

                if cfg.enable_bokeh:
                    bokeh_layer = bokeh_layer.filter(ImageFilter.GaussianBlur(radius=max(2.2, 3.2 * scale)))
                mid_layer = mid_layer.filter(ImageFilter.GaussianBlur(radius=max(0.85, 1.15 * scale)))
                crisp_layer = crisp_layer.filter(ImageFilter.GaussianBlur(radius=max(0.35, 0.50 * scale)))

                composed_rgba = Image.alpha_composite(base_rgba, bokeh_layer) if cfg.enable_bokeh else base_rgba
                composed_rgba = Image.alpha_composite(composed_rgba, mid_layer)
                composed = Image.alpha_composite(composed_rgba, crisp_layer).convert("RGB")
        else:
            composed = im

        # 11) Optional micro-border
        if cfg.border_px > 0:
            bdraw = ImageDraw.Draw(composed)
            bcol = (r.randint(8, 28), r.randint(8, 28), r.randint(12, 34))
            for i in range(cfg.border_px):
                bdraw.rectangle((i, i, orig_w - 1 - i, orig_h - 1 - i), outline=bcol)

        # 12) Output canvas dimension micro-jitter (even pixel sizes so JPEG 4:2:0 / 4:4:4 MCU blocks realign!)
        if cfg.canvas_jitter_px > 0:
            dw = r.randrange(-cfg.canvas_jitter_px, cfg.canvas_jitter_px + 1, 2)
            dh = r.randrange(-cfg.canvas_jitter_px, cfg.canvas_jitter_px + 1, 2)
            nw = max(320, orig_w + dw)
            nh = max(320, orig_h + dh)
            if (nw, nh) != composed.size:
                composed = composed.resize((nw, nh), resample=Image.Resampling.LANCZOS)

        out = io.BytesIO()
        subsampling_mode = r.choice([0, 1, 2]) if cfg.mode == "ultra_hard" else 0
        composed.save(
            out,
            format="JPEG",
            quality=r.randint(cfg.jpeg_quality_min, cfg.jpeg_quality_max),
            subsampling=subsampling_mode,
            optimize=r.choice([True, False]),
        )
        return out.getvalue()


def uniquify_photo_batch(
    photos: List[Union[str, os.PathLike, bytes, Tuple[str, bytes]]],
    batch_seed: Optional[int] = None,
    mode: str = "minimal",
    settings: Optional[Union[UniquifierSettings, Dict[str, Any]]] = None,
) -> List[Tuple[str, bytes]]:
    rng = random.Random(batch_seed) if batch_seed is not None else random.Random()
    result: List[Tuple[str, bytes]] = []
    suffix = f"{rng.randrange(100000, 999999)}"

    for idx, item in enumerate(photos, start=1):
        if isinstance(item, (str, os.PathLike)):
            p = Path(item)
            raw = p.read_bytes()
            stem = p.stem
        elif isinstance(item, bytes):
            raw = item
            stem = f"slide_{idx}"
        elif isinstance(item, tuple) and len(item) >= 2:
            stem = Path(str(item[0])).stem or f"slide_{idx}"
            raw = item[1]
        else:
            raise TypeError(f"Неподдерживаемый элемент фото #{idx}: {type(item)}")

        uniq_bytes = uniquify_single_image(raw, mode=mode, settings=settings, rng=rng)
        result.append((f"{stem}_u{suffix}_{idx}.jpg", uniq_bytes))

    return result


def compute_sha256_short(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]
