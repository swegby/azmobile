"""
Concurrent US (`US` / `en_US`) re-upload runner for the 10 existing sessions (excluding `user6961737737217`):
  - Uses existing saved sessions (`sessions/<username>.json`)
  - Checks for any old posts via `/v1/account/posts` before starting and deletes them if present
  - Switches proxy, phone geo, app locale, and upload geo to `US` (`en_US`)
  - Uploads 6 carousel posts (`IMG_7620.jpeg` + `IMG_7621.jpeg`) per session (`3 posts -> app restart -> 3 posts`)
  - Minimal uniquification (`uniquify_mode="minimal"`), randomized tags, and Fortnite / suggested music tracks
"""

from __future__ import annotations

import json
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List

from auth_worker import (
    SessionStore,
    publish_photo_carousel_for_session,
    restart_tiktok_app_for_session,
)
from kintaro_client import allocate_sticky_proxy

CFG = json.loads(Path("/home/user/kintaro_auth/config.json").read_text(encoding="utf-8"))
API_KEY = CFG["api_key"]
PROXY_BASE = "socks5://bpuser-ZhHAgVLk:uwYPc4LCLOfjtKHE3UQo_country-US@residential-x.bpproxy.at:1002"
TAGS_DESC = "#piratetoken #piratetokenshop #blackknight #pirateshop #fyp"
SLIDES = [
    "/home/user/kintaro_auth/media/IMG_7620.jpeg",
    "/home/user/kintaro_auth/media/IMG_7621.jpeg",
]
PROGRESS_FILE = Path("/home/user/kintaro_auth/output/batch10_us_results.json")

TARGET_USERS = [
    "user7286585870062",
    "user905631263403",
    "user4715658974451",
    "user6208587207492",
    "user6008317253556",
    "user5135430850465",
    "ariel94205",
    "user9410879704149",
    "saktijeni",
    "user9932079381598",
]
EXCLUDED = {"user6961737737217"}

print_lock = threading.Lock()
progress_lock = threading.Lock()
progress_map: Dict[str, Any] = {}


def tlog(acc_idx: int, uname: str, msg: str) -> None:
    wname = threading.current_thread().name
    with print_lock:
        print(f"[{wname} | #{acc_idx}/{len(TARGET_USERS)} @{uname}] {msg}", flush=True)


def save_progress(uname: str, payload: Dict[str, Any]) -> None:
    PROGRESS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with progress_lock:
        progress_map[uname] = payload
        PROGRESS_FILE.write_text(json.dumps(progress_map, indent=2, ensure_ascii=False), encoding="utf-8")


def pick_verified_fast_us_proxy(acc_idx: int, uname: str) -> str:
    for _ in range(15):
        cand = allocate_sticky_proxy(PROXY_BASE, target_country="US", lifetime="30m")
        px_curl = cand.replace("socks5://", "socks5h://", 1)
        t0 = time.time()
        r1 = subprocess.run(
            ["curl", "-sS", "--max-time", "4", "-x", px_curl, "http://ip-api.com/json"],
            capture_output=True,
            text=True,
        )
        if r1.returncode != 0:
            continue
        try:
            info = json.loads(r1.stdout)
        except Exception:
            continue
        if info.get("countryCode") != "US":
            continue
        r2 = subprocess.run(
            [
                "curl",
                "-sS",
                "-o",
                "/dev/null",
                "-w",
                "%{http_code}",
                "--max-time",
                "4",
                "-x",
                px_curl,
                "https://www.tiktok.com/robots.txt",
            ],
            capture_output=True,
            text=True,
        )
        dt = time.time() - t0
        if r2.returncode == 0 and r2.stdout.strip().startswith(("2", "3")):
            tlog(
                acc_idx,
                uname,
                f"🌐 Sticky-прокси US ({dt:.2f}с): {info.get('query')} ({info.get('city')} / {info.get('regionName')})",
            )
            return cand
    fallback = allocate_sticky_proxy(PROXY_BASE, target_country="US", lifetime="30m")
    tlog(acc_idx, uname, "🌐 Sticky-прокси US (fallback)")
    return fallback


def process_one_session(acc_idx: int, uname: str, store: SessionStore) -> Dict[str, Any]:
    assert uname not in EXCLUDED, f"Refusing to touch excluded account {uname}"
    target_posts = 6
    session_file = f"{uname}.json"

    if acc_idx <= 3:
        time.sleep((acc_idx - 1) * 1.3)

    sess = store.get_session(session_file)
    if not sess:
        fail_rec = {
            "acc_idx": acc_idx,
            "username": uname,
            "status": "session_missing",
            "posts_count": 0,
            "posts": [],
        }
        save_progress(uname, fail_rec)
        return fail_rec

    proxy_us = pick_verified_fast_us_proxy(acc_idx, uname)
    # Reset local posts tracking at start of fresh US 6-post run; TikTok-side check+delete runs on attempt 1
    store.update_session_data(session_file, lambda d: d.__setitem__("posts", []))

    collected_posts: List[Dict[str, Any]] = []
    did_initial_clean = False
    upload_attempt = 0

    while len(collected_posts) < target_posts and upload_attempt < 6:
        upload_attempt += 1
        remaining = target_posts - len(collected_posts)

        if upload_attempt > 1:
            proxy_us = pick_verified_fast_us_proxy(acc_idx, uname)
            tlog(
                acc_idx,
                uname,
                f"🔄 Дозалив оставшихся {remaining} постов на свежем US прокси (попытка {upload_attempt})...",
            )
            if len(collected_posts) == 3:
                try:
                    restart_tiktok_app_for_session(
                        api_key=API_KEY,
                        session_filename=session_file,
                        proxy_override=proxy_us,
                        store=store,
                        log_fn=lambda m: tlog(acc_idx, uname, m),
                    )
                except Exception:
                    pass

        check_and_delete_old = not did_initial_clean and len(collected_posts) == 0
        restart_n = 3 if remaining >= 4 and len(collected_posts) == 0 else 0

        try:
            publish_photo_carousel_for_session(
                api_key=API_KEY,
                session_filename=session_file,
                photos=SLIDES,
                description=TAGS_DESC,
                region="US",
                phone_region="US",
                app_locale="en_US",
                proxy_override=proxy_us,
                delete_old_posts=check_and_delete_old,
                randomize_tags=True,
                uniquify_photos=True,
                uniquify_mode="minimal",
                auto_music_query="Fortnite",
                copies_count=remaining,
                delay_min_sec=10.0,
                delay_max_sec=10.0,
                restart_every_n=restart_n,
                store=store,
                log_fn=lambda m: tlog(acc_idx, uname, m),
            )
            did_initial_clean = True
            fresh_sess = store.get_session(session_file) or {}
            collected_posts = list(reversed(fresh_sess.get("posts") or []))
        except Exception as exc:
            fresh_sess = store.get_session(session_file) or {}
            collected_posts = list(reversed(fresh_sess.get("posts") or []))
            if len(collected_posts) > 0:
                did_initial_clean = True
            tlog(
                acc_idx,
                uname,
                f"⚠️ Ошибка при публикации ({exc}) — уже опубликовано {len(collected_posts)}/{target_posts}, продолжаем...",
            )
            time.sleep(2.5)

    final_sess = store.get_session(session_file) or sess
    final_rec = {
        "acc_idx": acc_idx,
        "username": uname,
        "uid": final_sess.get("uid"),
        "status": "completed" if len(collected_posts) == target_posts else "partial",
        "posts_count": len(collected_posts),
        "region": "US",
        "phone_region": "US",
        "app_locale": "en_US",
        "uniquify_mode": "minimal",
        "posts": collected_posts,
    }
    save_progress(uname, final_rec)
    tlog(acc_idx, uname, f"🏁 ЗАВЕРШЕНО: {len(collected_posts)}/{target_posts} US-постов!")
    return final_rec


def main() -> None:
    store = SessionStore()
    print(
        f"Запуск перезалива на {len(TARGET_USERS)} готовых сессий (3 потока, регион=US/en_US, "
        f"проверка+удаление старых=ДА, уник=minimal, 6 постов с тегами и музыкой; user6961737737217 исключён)...",
        flush=True,
    )
    results: List[Dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=3, thread_name_prefix="USWorker") as pool:
        futs = {
            pool.submit(process_one_session, idx, u, store): (idx, u)
            for idx, u in enumerate(TARGET_USERS, start=1)
        }
        for fut in as_completed(futs):
            idx, u = futs[fut]
            try:
                results.append(fut.result())
            except Exception as exc:
                tlog(idx, u, f"💥 Критическая ошибка: {exc}")
                results.append({"acc_idx": idx, "username": u, "status": "error", "error": str(exc), "posts_count": 0})

    results.sort(key=lambda r: r.get("acc_idx", 999))
    PROGRESS_FILE.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")

    print("\n================ ИТОГ ПЕРЕЗАЛИВА (US, 10 СЕССИЙ) ================")
    total_posts = 0
    for r in results:
        pc = r.get("posts_count", 0)
        total_posts += pc
        sample_url = (r.get("posts") or [{}])[0].get("url", "")
        print(f"#{r['acc_idx']:02d} @{r['username']:20s} | status={r['status']} | постов={pc}/6 | пример={sample_url}")
    print(f"Всего опубликовано US-постов: {total_posts}/{len(TARGET_USERS) * 6} | user6961737737217: не тронут")


if __name__ == "__main__":
    main()
