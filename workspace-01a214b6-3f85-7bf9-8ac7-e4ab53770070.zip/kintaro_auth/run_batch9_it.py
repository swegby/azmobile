"""
3-thread concurrent Italy (`IT` / `it_IT`) batch runner for 9 accounts using the boosted
3-layer snow + stronger asymmetric crop photo uniquifier (`uniquify_photos=True`),
randomized tags, 10s pause, and `3 posts -> TikTok app restart -> 3 posts`.
"""

from __future__ import annotations

import json
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List

from auth_worker import (
    LoginOptions,
    SessionStore,
    parse_account_line,
    process_single_account,
    publish_photo_carousel_for_session,
    restart_tiktok_app_for_session,
)
from kintaro_client import allocate_sticky_proxy

API_KEY = "sYttEgX760VjQNN8rjtAEdZrKXxaSU0cPJqB"
PROXY_BASE = "socks5://bpuser-ZhHAgVLk:uwYPc4LCLOfjtKHE3UQo_country-US@residential-x.bpproxy.at:1002"
TAGS_DESC = "#piratetoken #piratetokenshop #blackknight #pirateshop #fyp"
SLIDES = [
    "/home/user/kintaro_auth/media/IMG_7610.jpeg",
    "/home/user/kintaro_auth/media/IMG_7611.jpeg",
]
PROGRESS_FILE = Path("/home/user/kintaro_auth/output/batch9_it_results.json")

RAW_ACCOUNTS = [
    "user4715658974451:1!qhZUe8!20iIQz:salvitppeanyxg@outlook.com:5lIuC945:ewpncdgj@vargosmail.com:yfnnvvtnY!6944:5uagofh6o26iq6uz",
    "user6208587207492:v7!!38K9E!x7C8!:oslundnzgainar@outlook.com:ixM0Ze75:unzzcomg@vargosmail.com:hbvniqzsX!6335:u3e52r2hbpqpvoem",
    "user6008317253556:4h!bui1!H24!!t!:lamedaaefichtw@outlook.com:8hWQPV54:fqgcppqj@tacoblastmail.com:zhfkrwhxY!6961:2geywkxeo4aorj57",
    "user5135430850465:!0!124J3r!!!!A!:laffinoohiottq4l@outlook.com:vPbykJ75:txcytcfg@fringmail.com:fmntocebA!3101:vxuaqlirrhpfucme",
    "ariel94205:7Ul2WGN!o4!5479:madduxykleprex@outlook.com:48Y1KY23:djvqjuzd@fringmail.com:arkvphgnX!3154:53fxptcqu5jhmwjr",
    "user9410879704149:4!B8m9!!529Tdh!:szabatmzbudkewl@outlook.com:KUoOOS17:dfjvewmw@tacoblastmail.com:gioqbokjS!9633:dc7en65otvdqtm4x",
    "saktijeni:r!!!!W7!E!6kn!9:revierdxbiggsauh@outlook.com:GNuAXs66:ojbxzeru@duhastmail.com:bjemwgroX!4519:h2jp7j6o2ka7zfhi",
    "user9932079381598:!!6!59ZUb!!k6s6:celmerfsputtwu4@outlook.com:NAS9Dr38:twxplsli@bekommenmail.com:aijugkpyA!5741:3cbqiatvbpxa3akw",
    "user6961737737217:310d7!!!Dc!b31!:totinfjsumeym@outlook.com:nRP8uQ55:fbtiidja@duhastmail.com:yvvbhrzrA!3970:O3SCMUV4IEK4WIU5",
]

print_lock = threading.Lock()
progress_lock = threading.Lock()
progress_map: Dict[str, Any] = {}


def tlog(acc_idx: int, uname: str, msg: str) -> None:
    wname = threading.current_thread().name
    with print_lock:
        print(f"[{wname} | #{acc_idx}/9 @{uname}] {msg}", flush=True)


def save_progress(uname: str, payload: Dict[str, Any]) -> None:
    PROGRESS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with progress_lock:
        progress_map[uname] = payload
        PROGRESS_FILE.write_text(json.dumps(progress_map, indent=2, ensure_ascii=False), encoding="utf-8")


def pick_verified_fast_it_proxy(acc_idx: int, uname: str) -> str:
    for _ in range(15):
        cand = allocate_sticky_proxy(PROXY_BASE, target_country="IT", lifetime="30m")
        px_curl = cand.replace("socks5://", "socks5h://", 1)
        t0 = time.time()
        r1 = subprocess.run(
            ["curl", "-sS", "--max-time", "4", "-x", px_curl, "http://ip-api.com/json"],
            capture_output=True,
            text=True,
        )
        if r1.returncode != 0:
            continue
        try:
            info = json.loads(r1.stdout)
        except Exception:
            continue
        if info.get("countryCode") != "IT":
            continue
        r2 = subprocess.run(
            [
                "curl",
                "-sS",
                "-o",
                "/dev/null",
                "-w",
                "%{http_code}",
                "--max-time",
                "4",
                "-x",
                px_curl,
                "https://www.tiktok.com/robots.txt",
            ],
            capture_output=True,
            text=True,
        )
        dt = time.time() - t0
        if r2.returncode == 0 and r2.stdout.strip().startswith(("2", "3")):
            tlog(
                acc_idx,
                uname,
                f"🌐 Sticky-прокси IT ({dt:.2f}с): {info.get('query')} ({info.get('city')} / {info.get('isp')})",
            )
            return cand
    fallback = allocate_sticky_proxy(PROXY_BASE, target_country="IT", lifetime="30m")
    tlog(acc_idx, uname, "🌐 Sticky-прокси IT (fallback)")
    return fallback


def process_one_account_full(acc_idx: int, raw_line: str, store: SessionStore) -> Dict[str, Any]:
    task = parse_account_line(raw_line, login_mode="password_imap", default_region="IT")
    uname = task.username or f"acc{acc_idx}"
    target_posts = 6

    # Stagger initial wave slightly (0s, 1.5s, 3.0s) so 3 threads start smoothly
    if acc_idx <= 3:
        time.sleep((acc_idx - 1) * 1.4)

    # Check if session already exists from an earlier partial run
    existing_sf = f"{uname}.json"
    sess = store.get_session(existing_sf)
    proxy_it = pick_verified_fast_it_proxy(acc_idx, uname)

    if not sess:
        opts = LoginOptions(
            api_key=API_KEY,
            login_mode="password_imap",
            default_region="IT",
            app_locale="it_IT",
            pre_register_device=True,
            reuse_existing_device=False,
            check_self_after_login=True,
            delete_old_posts=True,
            imap_timeout_sec=160,
            allow_manual_code=False,
        )
        res_login: Dict[str, Any] = {}
        for login_try in range(1, 5):
            if login_try > 1:
                proxy_it = pick_verified_fast_it_proxy(acc_idx, uname)
            tlog(acc_idx, uname, f"🚀 Вход (попытка {login_try}/4) | email={task.email}")
            res_login = process_single_account(
                task=task,
                proxy_raw=proxy_it,
                options=opts,
                store=store,
                log_fn=lambda m: tlog(acc_idx, uname, m),
            )
            if res_login.get("status") == "success":
                sess = res_login["session"]
                break
            err_txt = str(res_login.get("message") or res_login.get("error") or "")
            if "не существует" in err_txt.lower() or "doesn't exist" in err_txt.lower():
                tlog(acc_idx, uname, f"⛔ Аккаунт не существует в TikTok: {err_txt}")
                break
            tlog(acc_idx, uname, f"⚠️ Попытка входа #{login_try} не удалась ({err_txt}), смена IT прокси...")
            time.sleep(3.0)

        if not sess:
            fail_rec = {
                "acc_idx": acc_idx,
                "username": uname,
                "email": task.email,
                "status": "login_failed",
                "posts_count": 0,
                "error": (res_login or {}).get("message") or (res_login or {}).get("error"),
                "posts": [],
            }
            save_progress(uname, fail_rec)
            return fail_rec

    session_file = sess.get("session_file") or existing_sf
    actual_uname = sess.get("username") or uname
    dev = sess.get("device") or {}
    tlog(
        acc_idx,
        actual_uname,
        f"✅ Сессия активна (uid={sess.get('uid')}, sim={dev.get('sim_region')}/{dev.get('carrier')}, locale={dev.get('locale')})",
    )

    # Ensure all 6 uniquified posts get published (auto-recovering with a fresh IT sticky proxy if any post drops)
    collected_posts: List[Dict[str, Any]] = list((store.get_session(session_file) or {}).get("posts") or [])
    collected_posts.reverse()  # chronological order

    upload_attempt = 0
    while len(collected_posts) < target_posts and upload_attempt < 5:
        upload_attempt += 1
        remaining = target_posts - len(collected_posts)
        if upload_attempt > 1:
            proxy_it = pick_verified_fast_it_proxy(acc_idx, actual_uname)
            tlog(
                acc_idx,
                actual_uname,
                f"🔄 Дозалив оставшихся {remaining} постов на новом IT прокси (попытка {upload_attempt})...",
            )
            if len(collected_posts) == 3:
                try:
                    restart_tiktok_app_for_session(
                        api_key=API_KEY,
                        session_filename=session_file,
                        proxy_override=proxy_it,
                        store=store,
                        log_fn=lambda m: tlog(acc_idx, actual_uname, m),
                    )
                except Exception:
                    pass

        restart_n = 3 if remaining >= 4 and len(collected_posts) == 0 else 0
        try:
            publish_photo_carousel_for_session(
                api_key=API_KEY,
                session_filename=session_file,
                photos=SLIDES,
                description=TAGS_DESC,
                region="IT",
                phone_region="IT",
                app_locale="it_IT",
                proxy_override=proxy_it,
                delete_old_posts=False,
                randomize_tags=True,
                uniquify_photos=True,
                auto_music_query="Fortnite",
                copies_count=remaining,
                delay_min_sec=10.0,
                delay_max_sec=10.0,
                restart_every_n=restart_n,
                store=store,
                log_fn=lambda m: tlog(acc_idx, actual_uname, m),
            )
            fresh_sess = store.get_session(session_file) or {}
            collected_posts = list(reversed(fresh_sess.get("posts") or []))
        except Exception as exc:
            # Reload session to see how many posts succeeded before the exception
            fresh_sess = store.get_session(session_file) or {}
            collected_posts = list(reversed(fresh_sess.get("posts") or []))
            tlog(
                acc_idx,
                actual_uname,
                f"⚠️ Ошибка при публикации ({exc}) — уже опубликовано {len(collected_posts)}/{target_posts}, продолжаем...",
            )
            time.sleep(3.0)

    final_rec = {
        "acc_idx": acc_idx,
        "username": actual_uname,
        "uid": sess.get("uid"),
        "email": task.email,
        "session_file": session_file,
        "status": "success" if len(collected_posts) >= target_posts else "partial",
        "posts_count": len(collected_posts),
        "posts": collected_posts[:target_posts],
    }
    save_progress(actual_uname, final_rec)
    tlog(acc_idx, actual_uname, f"🏁 ГОТОВО: залито {len(collected_posts)}/{target_posts} постов на Италию!")
    return final_rec


def main() -> int:
    store = SessionStore()
    t_start = time.time()
    print(f"=== СТАРТ ТЕСТА 9 АККАУНТОВ В 3 ПОТОКА (ITALY + ENHANCED UNIQUIFIER) ===", flush=True)

    all_results: List[Dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=3, thread_name_prefix="W") as pool:
        futs = [
            pool.submit(process_one_account_full, idx, ln, store)
            for idx, ln in enumerate(RAW_ACCOUNTS, start=1)
        ]
        for fut in as_completed(futs):
            all_results.append(fut.result())

    all_results.sort(key=lambda r: r["acc_idx"])
    elapsed = time.time() - t_start
    total_posts = sum(r.get("posts_count", 0) for r in all_results)
    ok_accs = sum(1 for r in all_results if r.get("status") == "success")
    print(
        f"\n==================== ИТОГО: {ok_accs}/9 АККАУНТОВ | {total_posts} ПОСТОВ ЗА {elapsed:.1f} СЕК ====================",
        flush=True,
    )
    for r in all_results:
        print(
            f"\n#{r['acc_idx']} @{r['username']} ({r['email']}) -> status={r['status']} | posts={r['posts_count']}:",
            flush=True,
        )
        for pi, p in enumerate(r.get("posts") or [], start=1):
            print(f"  [{pi}] {p.get('url')} | 🎵 {p.get('music')} | {p.get('description')}", flush=True)
    return 0 if ok_accs == len(RAW_ACCOUNTS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
