"""
Automated TikTok Mobile Registration + TOTP 2FA Enablement Worker
Integrates Greedy SMS API v2 (`https://api.greedy-sms.com`) + Kintaro API v1 (`https://service.kintaroapi.com`).
"""

from __future__ import annotations

import concurrent.futures
import datetime as dt
import json
import random
import re
import secrets
import string
import subprocess
import threading
import time
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union

from auth_worker import (
    OUTPUT_DIR,
    AccountTask,
    SessionStore,
    extract_profile_summary,
)
from greedy_sms_client import (
    DEFAULT_GREEDY_BASE_URL,
    TIKTOK_SERVICE_CODE,
    GreedyCountryOption,
    GreedySMSClient,
    GreedySMSError,
    PurchasedActivation,
    resolve_greedy_country,
)
from kintaro_client import (
    DEFAULT_BASE_URL,
    KintaroAPIError,
    KintaroClient,
    allocate_sticky_proxy,
    apply_device_geo_profile,
    generate_totp_code,
    is_valid_base32_totp,
    normalize_proxy,
)


_REG_OUTPUT_LOCK = threading.Lock()


@dataclass
class MobileSignupOptions:
    kintaro_api_key: str
    greedy_api_key: str
    country: Union[int, str] = 151  # Default: 151 = Chile (CL)
    kintaro_base_url: str = DEFAULT_BASE_URL
    greedy_base_url: str = DEFAULT_GREEDY_BASE_URL
    max_price: float = 5.0
    sms_timeout_sec: int = 120
    max_number_attempts: int = 3
    enable_totp_at_end: bool = True
    auto_match_proxy_country: bool = True
    fixed_password: str = ""
    birthday: str = ""
    username_prefix: str = ""
    bio_after_signup: str = ""
    count: int = 1
    threads: int = 1


def generate_strong_tiktok_password() -> str:
    """Generates a compliant 12-char TikTok password (upper + lower + digits + special char)."""
    upper = secrets.choice(string.ascii_uppercase.replace("I", "").replace("O", ""))
    lower = "".join(secrets.choice(string.ascii_lowercase.replace("l", "")) for _ in range(5))
    digits = "".join(secrets.choice(string.digits) for _ in range(4))
    spec = secrets.choice("!@#$%")
    extra = secrets.choice(string.ascii_uppercase)
    return f"{upper}{lower}{digits}{spec}{extra}"


def generate_adult_birthday() -> str:
    """Generates a realistic adult birthday (1994..2002)."""
    year = random.randint(1994, 2002)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    return f"{year:04d}-{month:02d}-{day:02d}"


def extract_totp_secret_from_payload(body: Any, device: Any = None) -> Optional[str]:
    """
    Recursively inspects Kintaro's `/v1/account/enable_totp` response (and `device`)
    for the Base32 TOTP secret (`totp_token`, `totp_key`, `totp_secret`, `secret`, `key`, `seed`, `otpauth://...`).
    """
    if isinstance(body, dict):
        for direct_key in ("totp_token", "totp_key", "totp_secret", "secret"):
            val = body.get(direct_key)
            if isinstance(val, str) and is_valid_base32_totp(val):
                return re.sub(r"\s+", "", val).upper()

    candidates: List[str] = []

    def _walk(obj: Any, key_hint: str = "") -> None:
        if isinstance(obj, str):
            s = obj.strip()
            if "otpauth://" in s.lower():
                parsed = urllib.parse.urlparse(s)
                qs = urllib.parse.parse_qs(parsed.query)
                for sec_val in qs.get("secret", []):
                    if is_valid_base32_totp(sec_val):
                        candidates.insert(0, re.sub(r"\s+", "", sec_val).upper())
            cleaned = re.sub(r"\s+", "", s).upper()
            if is_valid_base32_totp(cleaned) and 16 <= len(cleaned) <= 64:
                # Prioritize explicit TOTP/secret keys over random tokens
                if any(k in key_hint.lower() for k in ("totp", "secret", "seed", "key", "otp", "2fa")):
                    candidates.insert(0, cleaned)
                elif len(cleaned) == 32:
                    candidates.append(cleaned)
        elif isinstance(obj, dict):
            for k, v in obj.items():
                # Skip device session/crypto fields that are not TOTP secrets
                if k in ("sec_uid", "tt_token", "tt_token_sign", "acc_key", "cloud_key", "lanusk", "lanusv", "device_token"):
                    continue
                _walk(v, key_hint=str(k))
        elif isinstance(obj, list):
            for item in obj:
                _walk(item, key_hint=key_hint)

    _walk(body, "totp")
    if not candidates and device is not None:
        _walk(device, "")

    for cand in candidates:
        try:
            _ = generate_totp_code(cand)
            return cand
        except Exception:
            continue
    return None


def prepare_signup_proxy(
    raw_proxy: str,
    target_iso2: str,
    auto_match_country: bool = True,
    log_fn: Optional[Callable[[str], None]] = None,
) -> str:
    """
    Allocates a verified sticky residential proxy for `target_iso2` (e.g. 'CL' for Chile)
    when using rotating residential gateways like `bpproxy.at`.
    """
    px_base = normalize_proxy(raw_proxy)
    if not auto_match_country or "bpproxy." not in px_base.lower():
        return px_base

    # Prefer SOCKS5 port 1002 on bpproxy.at to prevent HTTP proxy mid-flow drops
    if px_base.startswith("http://") and ":1000" in px_base:
        px_base = "socks5://" + px_base[len("http://") :].replace(":1000", ":1002")

    for attempt in range(5):
        cand = allocate_sticky_proxy(px_base, target_iso2, lifetime="30m")
        try:
            chk = subprocess.run(
                [
                    "curl",
                    "-sS",
                    "-o",
                    "/dev/null",
                    "-w",
                    "%{http_code}",
                    "-x",
                    cand,
                    "--max-time",
                    "10",
                    "https://www.tiktok.com/robots.txt",
                ],
                capture_output=True,
                text=True,
                timeout=12,
            )
            if chk.returncode == 0 and chk.stdout.strip() in ("200", "301", "302", "403"):
                return cand
        except Exception:
            pass
        if log_fn:
            log_fn(f"[Proxy] Перебор чистого sticky-прокси {target_iso2} (попытка {attempt + 1}/5)...")

    return allocate_sticky_proxy(px_base, target_iso2, lifetime="30m")


def _save_registered_account_artifact(record: Dict[str, Any], output_dir: Path = OUTPUT_DIR) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    line = (
        f"{record.get('username') or ''}|"
        f"{record.get('password') or ''}|"
        f"{record.get('e164_phone') or ''}|"
        f"{record.get('totp_secret') or ''}"
    )
    json_path = output_dir / "registered_accounts.json"
    txt_path = output_dir / "registered_accounts.txt"

    with _REG_OUTPUT_LOCK:
        with open(txt_path, "a", encoding="utf-8") as tf:
            tf.write(line + "\n")

        existing: List[Dict[str, Any]] = []
        if json_path.exists():
            try:
                existing = json.loads(json_path.read_text(encoding="utf-8"))
                if not isinstance(existing, list):
                    existing = []
            except Exception:
                existing = []
        existing.append(record)
        json_path.write_text(json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")


def register_single_mobile_account(
    proxy_raw: str,
    options: MobileSignupOptions,
    store: Optional[SessionStore] = None,
    worker_label: str = "#1",
    log_fn: Optional[Callable[[str], None]] = None,
) -> Dict[str, Any]:
    """
    Executes end-to-end TikTok mobile registration via Greedy SMS + Kintaro API:
      1) Resolves country (e.g. Chile 151 -> `CL`, `+56`) & prepares matching sticky proxy + Android device
      2) Buys number on Greedy SMS (`/activations/getNumber`) with `maxPrice` protection
      3) Calls `POST /v1/auth/signup/mobile` -> polls SMS code -> confirms via `POST /v1/auth/signup/mobile/send_code`
         (automatically cancels number for refund & retries if no SMS arrives or number is rejected)
      4) Enables TOTP 2FA (`POST /v1/account/enable_totp`) at the end of registration
      5) Fetches `/v1/account/self`, saves session in `sessions/<username>.json` + `output/registered_accounts.txt`
    """
    session_store = store or SessionStore()
    country_opt: GreedyCountryOption = resolve_greedy_country(options.country)
    region_iso2 = (country_opt.iso2 or "CL").upper()

    def _log(msg: str) -> None:
        if log_fn:
            log_fn(f"[Reg {worker_label} | {country_opt.flag} {region_iso2}] {msg}")

    password = (options.fixed_password or "").strip() or generate_strong_tiktok_password()
    birthday = (options.birthday or "").strip() or generate_adult_birthday()

    proxy = prepare_signup_proxy(
        raw_proxy=proxy_raw,
        target_iso2=region_iso2,
        auto_match_country=options.auto_match_proxy_country,
        log_fn=_log,
    )

    with GreedySMSClient(api_key=options.greedy_api_key, base_url=options.greedy_base_url) as sms_client, KintaroClient(
        api_key=options.kintaro_api_key, base_url=options.kintaro_base_url
    ) as kt_client:
        bal = sms_client.get_balance()
        _log(f"Баланс Greedy SMS: {bal:.2f} ₽ | Покупка номера {country_opt.rus} (+{country_opt.dial_code}, maxPrice={options.max_price} ₽)...")

        device: Optional[Any] = None
        final_activation: Optional[PurchasedActivation] = None
        signup_resp_body: Any = None
        seen_sms_codes: Set[str] = set()
        last_error_msg = ""

        max_attempts = max(1, int(options.max_number_attempts))
        for num_attempt in range(1, max_attempts + 1):
            # Register a clean Android device aligned with target country SIM/locale
            for dev_try in range(3):
                try:
                    _log(f"Регистрация Android-устройства Kintaro (region={region_iso2})...")
                    raw_dev = kt_client.register_device(proxy=proxy, region=region_iso2)
                    device = apply_device_geo_profile(raw_dev, target_region=region_iso2)
                    break
                except Exception as dev_exc:
                    if dev_try < 2:
                        _log(f"Повтор register_device со свежим прокси ({dev_exc})...")
                        proxy = prepare_signup_proxy(proxy_raw, region_iso2, options.auto_match_proxy_country)
                        continue
                    raise

            activation = sms_client.buy_number(
                country=country_opt,
                service=TIKTOK_SERVICE_CODE,
                max_price=options.max_price,
                log_fn=_log,
            )
            _log(
                f"Куплен номер #{num_attempt}/{max_attempts}: {activation.kintaro_mobile} "
                f"(ID={activation.activation_id}, цена={activation.price:.2f} ₽)"
            )

            # Initiate TikTok mobile signup
            step1 = kt_client.signup_mobile(
                mobile=activation.kintaro_mobile,
                birthday=birthday,
                region=region_iso2,
                proxy=proxy,
                password=password,
                device=device,
            )
            if step1.device is not None:
                device = step1.device

            if step1.status == "error":
                last_error_msg = f"signup/mobile ({step1.http_status}): {step1.message}"
                _log(f"TikTok отклонил номер {activation.kintaro_mobile}: {last_error_msg} -> отмена номера...")
                sms_client.cancel_activation(activation.activation_id, log_fn=_log, allow_cooldown_wait=True)
                if num_attempt < max_attempts:
                    proxy = prepare_signup_proxy(proxy_raw, region_iso2, options.auto_match_proxy_country)
                    continue
                return {
                    "status": "error",
                    "error": last_error_msg,
                    "country": country_opt.to_dict(),
                }

            if step1.status == "code_required":
                _log(f"TikTok запросил SMS-код на {activation.kintaro_mobile} — ожидаем код до {options.sms_timeout_sec}с...")
                sms_code = sms_client.wait_for_sms_code(
                    activation_id=activation.activation_id,
                    timeout_sec=options.sms_timeout_sec,
                    poll_interval=3.0,
                    seen_codes=seen_sms_codes,
                    log_fn=_log,
                )
                if not sms_code:
                    last_error_msg = f"SMS-код не пришёл за {options.sms_timeout_sec}с на {activation.kintaro_mobile}"
                    _log(f"{last_error_msg} -> отменяем активацию #{activation.activation_id} для возврата баланса...")
                    sms_client.cancel_activation(activation.activation_id, log_fn=_log, allow_cooldown_wait=True)
                    if num_attempt < max_attempts:
                        continue
                    return {
                        "status": "error",
                        "error": last_error_msg,
                        "country": country_opt.to_dict(),
                    }

                seen_sms_codes.add(sms_code)
                _log(f"Получен SMS-код: {sms_code}! Подтверждаем регистрацию (/v1/auth/signup/mobile/send_code)...")

                step2 = kt_client.signup_mobile_send_code(
                    mobile=activation.kintaro_mobile,
                    birthday=birthday,
                    code=sms_code,
                    proxy=proxy,
                    device=device,
                    password=password,
                )
                if step2.device is not None:
                    device = step2.device
                if step2.status != "success":
                    last_error_msg = f"signup/mobile/send_code ({step2.http_status}): {step2.message}"
                    _log(f"Ошибка подтверждения SMS-кода: {last_error_msg}")
                    sms_client.finish_activation(activation.activation_id)
                    if num_attempt < max_attempts:
                        proxy = prepare_signup_proxy(proxy_raw, region_iso2, options.auto_match_proxy_country)
                        continue
                    return {
                        "status": "error",
                        "error": last_error_msg,
                        "phone": activation.e164_phone,
                        "country": country_opt.to_dict(),
                    }
                signup_resp_body = step2.response
            else:
                signup_resp_body = step1.response

            final_activation = activation
            _log(f"Аккаунт успешно зарегистрирован на номер {activation.kintaro_mobile}!")
            break

        if final_activation is None or device is None:
            return {
                "status": "error",
                "error": last_error_msg or "Не удалось завершить регистрацию",
                "country": country_opt.to_dict(),
            }

        # Ensure password & enable TOTP 2FA if requested
        totp_secret: Optional[str] = None
        totp_raw_response: Any = None
        totp_error: Optional[str] = None

        if options.enable_totp_at_end:
            _log("Включаем двухфакторную аутентификацию TOTP (/v1/account/enable_totp, way=mobile_sms)...")
            time.sleep(1.0)

            for way in ("mobile_sms", "pwd", "pwd_after_set"):
                try:
                    actual_way = "pwd" if way.startswith("pwd") else way
                    if way == "pwd_after_set":
                        _, dev_pw = kt_client.set_password(proxy=proxy, device=device, password=password)
                        if dev_pw is not None:
                            device = dev_pw

                    totp_body, dev_totp = kt_client.enable_totp(
                        proxy=proxy,
                        device=device,
                        additional_way=actual_way,
                    )
                    if dev_totp is not None:
                        device = dev_totp
                    totp_raw_response = totp_body
                    totp_secret = extract_totp_secret_from_payload(totp_body, device)
                    if totp_secret:
                        sample_otp = generate_totp_code(totp_secret)
                        _log(f"TOTP 2FA успешно включён (way={actual_way})! Ключ: {totp_secret} (текущий код: {sample_otp})")
                        totp_error = None
                        break
                    else:
                        _log(f"Ответ enable_totp ({actual_way}): {json.dumps(totp_body, ensure_ascii=False)[:400]}")
                        totp_error = None
                        break
                except KintaroAPIError as te:
                    totp_error = str(te)
                    _log(f"Попытка enable_totp('{way}') вернула: {te}")

        # Ensure password is set on mobile-registered accounts so username+password login works
        try:
            _, dev_pw2 = kt_client.set_password(proxy=proxy, device=device, password=password)
            if dev_pw2 is not None:
                device = dev_pw2
        except Exception:
            pass

        # Finish activation on Greedy SMS now that signup + TOTP steps are done
        sms_client.finish_activation(final_activation.activation_id, log_fn=_log)

        # Always assign a real loginable username (mobile signup leaves `username` empty until change_username)
        raw_pref = (options.username_prefix or "").strip() or f"{region_iso2.lower()}_acc_"
        clean_pref = re.sub(r"[^a-z0-9_.]", "", raw_pref.lower())[:14] or "tt_acc_"
        cand_uname = f"{clean_pref}{random.randint(10000, 99999)}"
        try:
            _, dev_u = kt_client.change_username(proxy=proxy, device=device, username=cand_uname)
            if dev_u is not None:
                device = dev_u
            _log(f"Установлен логин аккаунта: @{cand_uname}")
        except Exception as u_exc:
            _log(f"Предупреждение change_username: {u_exc}")

        # Optional bio
        if options.bio_after_signup and options.bio_after_signup.strip():
            try:
                _, dev_b = kt_client.set_bio(proxy=proxy, device=device, text=options.bio_after_signup.strip())
                if dev_b is not None:
                    device = dev_b
                _log("БИО установлено на новом аккаунте.")
            except Exception as b_exc:
                _log(f"Предупреждение set_bio: {b_exc}")

        # Fetch profile via /v1/account/self
        self_body: Any = None
        try:
            self_body, dev_self = kt_client.get_self(proxy=proxy, device=device)
            if dev_self is not None:
                device = dev_self
        except Exception as s_exc:
            _log(f"Предупреждение /v1/account/self: {s_exc}")

        prof = extract_profile_summary(self_body, signup_resp_body)
        final_username = prof.get("username") or f"cl_user_{final_activation.raw_phone[-6:]}"

        # Save into Kintaro Studio SessionStore so account appears in UI & works with 1-click upload
        task = AccountTask(
            email="",
            username=final_username,
            tiktok_password=password,
            totp_token=totp_secret,
            proxy=proxy,
            region=region_iso2,
            raw_line=f"{final_username}|{password}|{final_activation.e164_phone}|{totp_secret or ''}",
        )
        saved_session = session_store.save_success(
            task=task,
            proxy_normalized=proxy,
            device=device,
            auth_response=signup_resp_body,
            self_response=self_body,
        )

        created_record: Dict[str, Any] = {
            "status": "success",
            "username": final_username,
            "uid": saved_session.get("uid"),
            "sec_uid": saved_session.get("sec_uid"),
            "password": password,
            "birthday": birthday,
            "e164_phone": final_activation.e164_phone,
            "kintaro_mobile": final_activation.kintaro_mobile,
            "activation_id": final_activation.activation_id,
            "sms_price_rub": final_activation.price,
            "country": country_opt.to_dict(),
            "region": region_iso2,
            "proxy": proxy,
            "totp_enabled": bool(totp_secret or (options.enable_totp_at_end and not totp_error)),
            "totp_secret": totp_secret,
            "totp_raw_response": totp_raw_response,
            "totp_error": totp_error,
            "account_line": f"{final_username}|{password}|{final_activation.e164_phone}|{totp_secret or ''}",
            "session_file": f"{final_username}.json",
            "created_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        }
        _save_registered_account_artifact(created_record)
        _log(
            f"ГОТОВО! @{final_username} | тел: {final_activation.e164_phone} | "
            f"пароль: {password} | TOTP: {totp_secret or 'см. лог'}"
        )
        return created_record


def run_batch_mobile_signup(
    proxies: List[str],
    options: MobileSignupOptions,
    store: Optional[SessionStore] = None,
    log_fn: Optional[Callable[[str], None]] = None,
    stop_check: Optional[Callable[[], bool]] = None,
) -> List[Dict[str, Any]]:
    """Runs `options.count` mobile registrations across `options.threads` worker threads."""
    if not proxies:
        raise ValueError("Не указан хотя бы один прокси для регистрации.")
    total = max(1, int(options.count))
    workers = max(1, min(int(options.threads), total))
    results: List[Dict[str, Any]] = []
    res_lock = threading.Lock()

    def _task(idx: int) -> Dict[str, Any]:
        if stop_check and stop_check():
            return {"status": "cancelled", "error": "Остановлено пользователем"}
        px = proxies[idx % len(proxies)]
        try:
            r = register_single_mobile_account(
                proxy_raw=px,
                options=options,
                store=store,
                worker_label=f"#{idx + 1}/{total}",
                log_fn=log_fn,
            )
        except Exception as exc:
            r = {"status": "error", "error": str(exc)}
            if log_fn:
                log_fn(f"[Reg #{idx + 1}/{total}] Критическая ошибка: {exc}")
        with res_lock:
            results.append(r)
        return r

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futs = [pool.submit(_task, i) for i in range(total)]
        concurrent.futures.wait(futs)

    return results
