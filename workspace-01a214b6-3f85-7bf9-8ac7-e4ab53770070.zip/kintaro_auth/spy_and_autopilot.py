"""
Enterprise Modules for Kintaro Studio v5:
  1) 🕵️ Competitor Spy & Watermark-Free Creative Cloner (`/v1/user/get`, `/v1/user/posts`, `/v1/post/get`)
     - Parses TikTok's component tree + post feed, computes total/avg/max views, viral Music IDs & hashtags
     - Downloads watermark-free carousel slides (auto-converting WebP -> crisp JPEG) & MP4 videos straight to `media/`
  2) 💬 Top-Comment Pinning & Comment Marketing (`/v1/post/comments`, `/v1/comment/publish`, `/v1/comment/like`)
     - Publishes lead/proof comment (with spintax, @mentions, or proof image) and boosts it to #1 TOP via multi-session comment likes & replies
  3) 🎬 MP4 Video Uniquifier (FFmpeg if available + pure-Python ISO-BMFF `free` atom SHA-256 randomizer)
  4) 🔐 Live TOTP 2FA Code Generator (6-digit code + countdown timer for quick manual phone login)
  5) ⏰ Auto-Pilot Scheduler & Smart Zero-View Watchdog (delayed campaigns, periodic analytics, auto-reupload of 0-view accounts)
"""

from __future__ import annotations

import base64
import concurrent.futures
import datetime as dt
import hashlib
import io
import json
import os
import random
import re
import shutil
import struct
import subprocess
import tempfile
import threading
import time
from collections import Counter
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import httpx
from PIL import Image

from auth_worker import MEDIA_DIR, OUTPUT_DIR, SessionStore, load_saved_config
from kintaro_client import KintaroClient, generate_totp_code
from photo_uniquifier import expand_spintax
from studio_tools import (
    AnalyticsState,
    ToolsJobState,
    _parse_aweme_stats,
    _resolve_session_proxy,
    extract_aweme_id_from_input,
    run_analytics_scan,
)


# =============================================================================
# 1. COMPETITOR SPY & CREATIVE CLONER
# =============================================================================


def _pick_donor_session(store: SessionStore, exclude: str = "user6961737737217") -> Optional[Dict[str, Any]]:
    """Prefers an Android `x-device` donor session so TikTok CDN returns native `.webp`/`.jpeg` URLs instead of iOS `.heic`."""
    sessions = store.list_sessions()
    fallback_any: Optional[Dict[str, Any]] = None
    for s in sessions:
        if (s.get("username") or "").lower() == exclude.lower():
            continue
        full = store.get_session(s["filename"])
        if not full:
            continue
        dev = full.get("device") or full.get("x_device")
        if not dev:
            continue
        if fallback_any is None:
            fallback_any = full
        dev_str = json.dumps(dev).lower() if isinstance(dev, dict) else str(dev).lower()
        if '"android"' in dev_str or "sm-" in dev_str or "pixel" in dev_str:
            return full
    if fallback_any is not None:
        return fallback_any
    if sessions:
        return store.get_session(sessions[0]["filename"])
    return None


def parse_username_from_input(raw: str) -> str:
    s = (raw or "").strip()
    m = re.search(r"tiktok\.com/@([A-Za-z0-9_.]+)", s)
    if m:
        return m.group(1)
    return s.lstrip("@").split("/")[0].split("?")[0].strip()


def parse_tiktok_profile_component_tree(body: Any, fallback_username: str = "") -> Dict[str, Any]:
    """Extracts profile metrics from TikTok's `/v1/user/get` response (both legacy `user` and new `header`/`common` tree)."""
    out: Dict[str, Any] = {
        "username": fallback_username,
        "nickname": "",
        "uid": "",
        "sec_uid": "",
        "avatar_url": "",
        "followers": 0,
        "following": 0,
        "likes": 0,
        "signature": "",
        "bio_url": "",
        "is_private": False,
    }
    if not isinstance(body, dict):
        return out

    # Legacy `user` dict support
    u = body.get("user")
    if isinstance(u, dict) and u:
        out["username"] = str(u.get("unique_id") or out["username"])
        out["nickname"] = str(u.get("nickname") or "")
        out["uid"] = str(u.get("uid") or "")
        out["sec_uid"] = str(u.get("sec_uid") or "")
        out["followers"] = int(u.get("follower_count") or 0)
        out["following"] = int(u.get("following_count") or 0)
        out["likes"] = int(u.get("total_favorited") or 0)
        out["signature"] = str(u.get("signature") or "")
        b_link = u.get("bio_url") or (u.get("bio_link") or {}).get("link") or ""
        out["bio_url"] = str(b_link)

    # New TikTok component tree (`common` + `header`)
    common = body.get("common") or {}
    upi = common.get("user_profile_info") or {}
    uai = common.get("user_account_info") or {}
    if upi:
        out["username"] = str(upi.get("username") or upi.get("unique_id") or out["username"])
        out["nickname"] = str(upi.get("nickname") or out["nickname"])
        out["uid"] = str(upi.get("uid") or out["uid"])
        out["sec_uid"] = str(upi.get("sec_uid") or out["sec_uid"])
        av_urls = (((upi.get("avatar") or {}).get("avatar_300x300") or {}).get("url_list") or [])
        if av_urls:
            out["avatar_url"] = str(av_urls[0])
    if uai:
        out["is_private"] = bool(uai.get("is_private_account"))

    def _walk(node: Any) -> None:
        if isinstance(node, dict):
            cid = str(node.get("component_id") or node.get("name") or "")
            bd = node.get("biz_data")
            if isinstance(bd, dict):
                if "follower_count" in bd and bd["follower_count"] is not None:
                    out["followers"] = max(out["followers"], int(bd["follower_count"] or 0))
                if "following_count" in bd and bd["following_count"] is not None:
                    out["following"] = max(out["following"], int(bd["following_count"] or 0))
                if "like_count" in bd and bd["like_count"] is not None:
                    out["likes"] = max(out["likes"], int(bd["like_count"] or 0))
                desc_txt = (bd.get("describe") or {}).get("text")
                if desc_txt and ("bio" in cid or "signature" in cid):
                    out["signature"] = str(desc_txt)
                if bd.get("link") or bd.get("url"):
                    link_val = str(bd.get("link") or bd.get("url") or "")
                    if link_val.startswith("http") and "tiktok.com/@" not in link_val:
                        out["bio_url"] = link_val
            for v in node.values():
                _walk(v)
        elif isinstance(node, list):
            for item in node:
                _walk(item)

    _walk(body.get("header"))
    return out


def _extract_rich_aweme_card(item: Dict[str, Any], fallback_uname: str = "") -> Dict[str, Any]:
    base = _parse_aweme_stats(item, fallback_uname)
    music = item.get("music") or {}
    mid = str(music.get("id_str") or music.get("id") or "")
    mtitle = str(music.get("title") or "")
    mauthor = str(music.get("author") or "")

    slides: List[str] = []
    img_info = item.get("image_post_info") or {}
    for im in img_info.get("images") or []:
        cand_urls: List[str] = []
        for k_img in ("thumbnail", "display_image", "owner_watermark_image"):
            for u in ((im.get(k_img) or {}).get("url_list") or []):
                if u:
                    cand_urls.append(str(u))
        non_heic = [u for u in cand_urls if ".heic" not in u.lower()]
        chosen = non_heic[0] if non_heic else (cand_urls[0] if cand_urls else "")
        if chosen:
            slides.append(chosen)

    video_url = ""
    vid = item.get("video") or {}
    v_urls = ((vid.get("play_addr") or {}).get("url_list") or []) or (
        (vid.get("download_addr") or {}).get("url_list") or []
    )
    if v_urls:
        video_url = str(v_urls[0])

    cover_url = slides[0] if slides else ""
    if not cover_url:
        c_urls = ((vid.get("cover") or {}).get("url_list") or []) or (
            (vid.get("origin_cover") or {}).get("url_list") or []
        )
        if c_urls:
            cover_url = str(c_urls[0])

    base.update(
        {
            "full_desc": str(item.get("desc") or ""),
            "music_id": mid if mid != "0" else "",
            "music_title": mtitle,
            "music_author": mauthor,
            "slides_count": len(slides),
            "slide_urls": slides,
            "video_url": video_url,
            "cover_url": cover_url,
        }
    )
    return base


def spy_competitor_or_post(
    api_key: str,
    store: SessionStore,
    target_input: str,
    region: str = "US",
    count: int = 12,
) -> Dict[str, Any]:
    donor = _pick_donor_session(store)
    if not donor:
        raise RuntimeError("Нет доступной донорской сессии для запроса к TikTok API.")
    px = _resolve_session_proxy(donor, region)
    dev = donor.get("device") or donor.get("x_device")

    aweme_id = extract_aweme_id_from_input(target_input)
    with KintaroClient(api_key=api_key) as kt:
        if aweme_id:
            p_body, _ = kt.get_post_detail(proxy=px, device=dev, aweme_id=aweme_id, region=region)
            details = (p_body.get("aweme_details") if isinstance(p_body, dict) else None) or []
            if not details and isinstance(p_body, dict) and p_body.get("aweme_detail"):
                details = [p_body["aweme_detail"]]
            if not details:
                raise RuntimeError(f"Пост {aweme_id} не найден или скрыт.")
            a0 = details[0]
            author = a0.get("author") or {}
            uname = str(author.get("unique_id") or "")
            card = _extract_rich_aweme_card(a0, uname)
            prof = {
                "username": uname,
                "nickname": str(author.get("nickname") or ""),
                "uid": str(author.get("uid") or ""),
                "followers": int(author.get("follower_count") or 0),
                "following": int(author.get("following_count") or 0),
                "likes": int(author.get("total_favorited") or 0),
                "signature": str(author.get("signature") or ""),
                "bio_url": "",
                "avatar_url": (((author.get("avatar_medium") or {}).get("url_list") or [""])[0]),
            }
            posts = [card]
        else:
            uname = parse_username_from_input(target_input)
            if not uname:
                raise ValueError("Укажите @username или ссылку на профиль/пост TikTok.")

            u_body, upd1 = kt.get_user_profile(proxy=px, device=dev, username=uname)
            if upd1 is not None:
                dev = upd1
            prof = parse_tiktok_profile_component_tree(u_body, fallback_username=uname)

            up_body, _ = kt.get_user_posts(
                proxy=px, device=dev, username=uname, count=max(1, min(30, count)), region=region
            )
            raw_list = (up_body.get("aweme_list") if isinstance(up_body, dict) else None) or []
            posts = [_extract_rich_aweme_card(it, prof["username"]) for it in raw_list if isinstance(it, dict)]

            if raw_list and isinstance(raw_list[0], dict):
                a_auth = raw_list[0].get("author") or {}
                if not prof.get("signature") and a_auth.get("signature"):
                    prof["signature"] = str(a_auth["signature"])
                if not prof.get("nickname") and a_auth.get("nickname"):
                    prof["nickname"] = str(a_auth["nickname"])

    total_views = sum(p["views"] for p in posts)
    avg_views = int(round(total_views / len(posts))) if posts else 0
    max_views = max((p["views"] for p in posts), default=0)

    tag_counter: Counter[str] = Counter()
    music_counter: Counter[str] = Counter()
    music_meta: Dict[str, Dict[str, str]] = {}
    for p in posts:
        for tg in re.findall(r"#[\w\d_]+", p.get("full_desc") or ""):
            tag_counter[tg.lower()] += 1
        mid = p.get("music_id") or ""
        if mid:
            music_counter[mid] += 1
            music_meta[mid] = {"id": mid, "title": p.get("music_title") or "", "author": p.get("music_author") or ""}

    top_tags = [t for t, _ in tag_counter.most_common(12)]
    top_music = [{**music_meta[mid], "uses": cnt} for mid, cnt in music_counter.most_common(6)]

    return {
        "profile": prof,
        "summary": {
            "posts_analyzed": len(posts),
            "total_views": total_views,
            "avg_views": avg_views,
            "max_views": max_views,
            "top_hashtags": top_tags,
            "top_music": top_music,
        },
        "posts": posts,
    }


def download_creative_to_media(
    api_key: str,
    store: SessionStore,
    aweme_id_or_url: str,
    region: str = "US",
) -> Dict[str, Any]:
    """Downloads watermark-free carousel slides (converted to crisp RGB JPEG) or MP4 video straight into `media/`."""
    aid = extract_aweme_id_from_input(aweme_id_or_url)
    if not aid:
        raise ValueError("Не удалось распознать ID поста TikTok.")
    donor = _pick_donor_session(store)
    if not donor:
        raise RuntimeError("Нет донорской сессии.")
    px = _resolve_session_proxy(donor, region)
    dev = donor.get("device") or donor.get("x_device")

    with KintaroClient(api_key=api_key) as kt:
        p_body, _ = kt.get_post_detail(proxy=px, device=dev, aweme_id=aid, region=region)
    details = (p_body.get("aweme_details") if isinstance(p_body, dict) else None) or []
    if not details:
        raise RuntimeError(f"Пост {aid} не найден.")

    card = _extract_rich_aweme_card(details[0])
    MEDIA_DIR.mkdir(parents=True, exist_ok=True)
    saved_files: List[str] = []

    headers = {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15"
    }
    with httpx.Client(timeout=35.0, follow_redirects=True, headers=headers) as dl:
        if card["slide_urls"]:
            for idx, surl in enumerate(card["slide_urls"][:10], start=1):
                r = dl.get(surl)
                r.raise_for_status()
                with Image.open(io.BytesIO(r.content)) as im:
                    rgb = im.convert("RGB")
                    fname = f"spy_{aid}_{idx:02d}.jpg"
                    out_fp = MEDIA_DIR / fname
                    rgb.save(out_fp, format="JPEG", quality=95, subsampling=0)
                    saved_files.append(fname)
        elif card["video_url"]:
            r = dl.get(card["video_url"])
            r.raise_for_status()
            fname = f"spy_{aid}.mp4"
            (MEDIA_DIR / fname).write_bytes(r.content)
            saved_files.append(fname)
        else:
            raise RuntimeError("В посте не найдены прямые ссылки на слайды или видео.")

    return {
        "aweme_id": aid,
        "kind": "photo" if card["slide_urls"] else "video",
        "saved_files": saved_files,
        "desc": card["full_desc"],
        "music_id": card["music_id"],
        "music_title": card["music_title"],
    }


# =============================================================================
# 2. TOP-COMMENT PINNING & COMMENT MODERATION
# =============================================================================


def _extract_cid_from_publish_response(body: Any) -> str:
    if not isinstance(body, dict):
        return ""
    c = body.get("comment")
    if isinstance(c, dict) and c.get("cid"):
        return str(c["cid"])
    if body.get("cid"):
        return str(body["cid"])
    data = body.get("data")
    if isinstance(data, dict):
        if isinstance(data.get("comment"), dict) and data["comment"].get("cid"):
            return str(data["comment"]["cid"])
        if data.get("cid"):
            return str(data["cid"])
    return ""


def fetch_post_comments_structured(
    api_key: str,
    store: SessionStore,
    aweme_id_or_url: str,
    region: str = "US",
    count: int = 30,
) -> Dict[str, Any]:
    aid = extract_aweme_id_from_input(aweme_id_or_url)
    if not aid:
        raise ValueError("Укажите корректную ссылку на пост или AWEME ID.")
    donor = _pick_donor_session(store)
    if not donor:
        raise RuntimeError("Нет донорской сессии.")
    px = _resolve_session_proxy(donor, region)
    dev = donor.get("device") or donor.get("x_device")

    with KintaroClient(api_key=api_key) as kt:
        c_body, _ = kt.get_post_comments(proxy=px, device=dev, aweme_id=aid, count=count, region=region)

    raw_comments = (c_body.get("comments") if isinstance(c_body, dict) else None) or []
    parsed: List[Dict[str, Any]] = []
    for cm in raw_comments:
        if not isinstance(cm, dict):
            continue
        u = cm.get("user") or {}
        ct = int(cm.get("create_time") or 0)
        parsed.append(
            {
                "cid": str(cm.get("cid") or ""),
                "text": str(cm.get("text") or ""),
                "username": str(u.get("unique_id") or u.get("nickname") or ""),
                "likes": int(cm.get("digg_count") or 0),
                "replies": int(cm.get("reply_comment_total") or 0),
                "created_at": dt.datetime.fromtimestamp(ct, tz=dt.timezone.utc).strftime("%d.%m %H:%M") if ct else "",
            }
        )
    return {"aweme_id": aid, "total": int((c_body or {}).get("total") or len(parsed)), "comments": parsed}


def run_top_comment_boost_background(
    job_state: ToolsJobState,
    store: SessionStore,
    body: Dict[str, Any],
    log_fn: Callable[[str], None],
) -> None:
    """
    Either publishes a new lead comment from `seed_session` (or uses `existing_cid`),
    then uses `session_files` in N threads to LIKE that comment (`/v1/comment/like`)
    and optionally post natural replies (`reply_id=cid`) to push it to #1 TOP!
    """
    api_key = (body.get("api_key") or "").strip()
    aid = extract_aweme_id_from_input(body.get("target_post") or "")
    existing_cid = str(body.get("comment_id") or "").strip()
    seed_sf = os.path.basename(str(body.get("seed_session") or ""))
    lead_text_tpl = (body.get("lead_comment_text") or "").strip()
    lead_image_b64 = (body.get("lead_image_data_url") or "").strip()
    booster_files = [os.path.basename(str(x)) for x in (body.get("session_files") or []) if x]
    reply_lines = [ln.strip() for ln in (body.get("reply_templates") or "").splitlines() if ln.strip()]
    reply_prob = max(0, min(100, int(body.get("reply_prob") or 0)))
    threads = max(1, min(15, int(body.get("threads") or 4)))
    region = (body.get("region") or "US").upper().strip()

    try:
        if not aid:
            raise ValueError("Не указан целевой пост (ссылка или AWEME ID).")

        target_cid = existing_cid
        if not target_cid:
            if not seed_sf or not (lead_text_tpl or lead_image_b64):
                raise ValueError("Укажите текст главного комментария (или выберите существующий CID).")
            seed_sess = store.get_session(seed_sf)
            if not seed_sess:
                raise RuntimeError(f"Сессия автора комментария {seed_sf} не найдена.")
            seed_px = _resolve_session_proxy(seed_sess)
            seed_dev = seed_sess.get("device") or seed_sess.get("x_device")
            final_lead_text = expand_spintax(lead_text_tpl) if lead_text_tpl else ""
            mentions = re.findall(r"@([A-Za-z0-9_.]+)", final_lead_text)

            with KintaroClient(api_key=api_key) as kt:
                # View post first for naturalness
                try:
                    _, u0 = kt.view_post(proxy=seed_px, device=seed_dev, aweme_id=aid, playtime_ms=random.randint(4500, 8500))
                    if u0 is not None:
                        seed_dev = u0
                except Exception:
                    pass
                try:
                    pub_body, upd_seed = kt.publish_comment(
                        proxy=seed_px,
                        device=seed_dev,
                        aweme_id=aid,
                        text=final_lead_text,
                        mentions=mentions or None,
                        image_b64=lead_image_b64,
                    )
                except Exception as pub_err:
                    err_s = str(pub_err)
                    if '"status": 2' in err_s or '"status":2' in err_s:
                        raise RuntimeError(
                            f"TikTok задержал коммент антиспам-фильтром (status=2) у @{seed_sess.get('username')}. "
                            "Используйте сессию того же ГЕО (например самого автора поста) и нейтральную формулировку."
                        ) from pub_err
                    raise
                if upd_seed is not None:
                    store.update_session_data(seed_sf, lambda d, _u=upd_seed: d.__setitem__("device", _u))
                target_cid = _extract_cid_from_publish_response(pub_body)

            if not target_cid:
                raise RuntimeError("Комментарий отправлен, но не удалось получить его CID из ответа.")
            log_fn(
                f"✅ [@{seed_sess.get('username')}] Главный коммент опубликован (CID={target_cid}): {final_lead_text!r}"
            )
            time.sleep(2.0)

        def _boost_one(sf: str) -> None:
            with job_state.lock:
                if job_state.stop_requested:
                    job_state.done += 1
                    return
            sess = store.get_session(sf)
            if not sess:
                with job_state.lock:
                    job_state.done += 1
                    job_state.failed += 1
                return
            uname = sess.get("username") or sf.replace(".json", "")
            px = _resolve_session_proxy(sess)
            cur_dev = sess.get("device") or sess.get("x_device")
            done_acts: List[str] = []
            try:
                with KintaroClient(api_key=api_key) as kt:
                    try:
                        _, uv = kt.view_post(proxy=px, device=cur_dev, aweme_id=aid, playtime_ms=random.randint(4000, 9500))
                        if uv is not None:
                            cur_dev = uv
                    except Exception:
                        pass
                    _, ul = kt.like_comment(proxy=px, device=cur_dev, aweme_id=aid, comment_id=target_cid)
                    if ul is not None:
                        cur_dev = ul
                    done_acts.append(f"❤️ коммент {target_cid}")

                    if reply_lines and random.randint(1, 100) <= reply_prob and sf != seed_sf:
                        r_txt = expand_spintax(random.choice(reply_lines))
                        _, ur = kt.publish_comment(
                            proxy=px, device=cur_dev, aweme_id=aid, text=r_txt, reply_id=target_cid
                        )
                        if ur is not None:
                            cur_dev = ur
                        done_acts.append(f"💬 ответ: {r_txt[:18]}")

                store.update_session_data(sf, lambda d, _dv=cur_dev: d.__setitem__("device", _dv) if _dv else None)
                s_act = ", ".join(done_acts)
                log_fn(f"👍 [@{uname}] Вывод в ТОП: {s_act}")
                with job_state.lock:
                    job_state.done += 1
                    job_state.success += 1
                    job_state.results.append(f"@{uname}: {s_act}")
            except Exception as exc:
                log_fn(f"⚠️ [@{uname}] Ошибка лайка коммента: {exc}")
                with job_state.lock:
                    job_state.done += 1
                    job_state.failed += 1
                    job_state.results.append(f"@{uname}: ОШИБКА ({exc})")

        with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as pool:
            futs = [pool.submit(_boost_one, sf) for sf in booster_files]
            concurrent.futures.wait(futs)

        log_fn(f"🏆 Вывод комментария CID={target_cid} в ТОП завершён! Успешно: {job_state.success}/{job_state.total}")
    except Exception as top_exc:
        log_fn(f"❌ Ошибка модуля Топ-Комментария: {top_exc}")
    finally:
        with job_state.lock:
            job_state.running = False


# =============================================================================
# 3. MP4 VIDEO UNIQUIFIER & LIVE TOTP GENERATOR
# =============================================================================


def uniquify_mp4_bytes(raw_mp4: bytes, rng: Optional[random.Random] = None) -> bytes:
    """
    Uniquifies an MP4 video creative for multi-account TikTok upload:
      - Uses FFmpeg (strip metadata, micro-crop/brightness/contrast, fresh encoding) if installed on host
      - Otherwise injects a valid ISO-BMFF top-level `free` box with 64–256 random entropy bytes,
        preserving 100% playback integrity while guaranteeing a unique SHA-256 hash on every post!
    """
    r = rng or random.Random()
    ffmpeg_bin = shutil.which("ffmpeg")
    if ffmpeg_bin:
        with tempfile.TemporaryDirectory() as td:
            in_p = Path(td) / "in.mp4"
            out_p = Path(td) / "out.mp4"
            in_p.write_bytes(raw_mp4)
            br = round(r.uniform(-0.025, 0.025), 4)
            ct = round(r.uniform(0.98, 1.03), 4)
            sat = round(r.uniform(0.98, 1.04), 4)
            vf = f"eq=brightness={br}:contrast={ct}:saturation={sat},crop=iw*0.985:ih*0.985,scale=trunc(iw/2)*2:trunc(ih/2)*2"
            proc = subprocess.run(
                [
                    ffmpeg_bin,
                    "-y",
                    "-i",
                    str(in_p),
                    "-map_metadata",
                    "-1",
                    "-vf",
                    vf,
                    "-c:v",
                    "libx264",
                    "-preset",
                    "veryfast",
                    "-crf",
                    str(r.randint(20, 23)),
                    "-c:a",
                    "aac",
                    "-b:a",
                    "128k",
                    str(out_p),
                ],
                capture_output=True,
                timeout=90,
            )
            if proc.returncode == 0 and out_p.exists() and out_p.stat().st_size > 0:
                return out_p.read_bytes()

    # Pure-Python ISO-BMFF compliant `free` atom injection
    payload_len = r.randint(64, 256)
    entropy = os.urandom(payload_len)
    box_size = 8 + payload_len
    free_atom = struct.pack(">I4s", box_size, b"free") + entropy
    return raw_mp4 + free_atom


def generate_live_totp_info(secret: str) -> Dict[str, Any]:
    clean = (secret or "").strip()
    if not clean:
        raise ValueError("У этой сессии нет сохранённого TOTP секрета.")
    now = int(time.time())
    code = generate_totp_code(clean, timestamp=now)
    rem = 30 - (now % 30)
    return {"code": code, "remaining_sec": rem, "secret": clean}


# =============================================================================
# 4. AUTO-PILOT SCHEDULER & SMART ZERO-VIEW WATCHDOG
# =============================================================================


class AutoPilotScheduler:
    """Background daemon scheduler for delayed campaigns, periodic analytics scans, and Zero-View auto-reuploads."""

    def __init__(
        self,
        store: SessionStore,
        analytics: AnalyticsState,
        start_campaign_cb: Callable[[Dict[str, Any]], bool],
        log_fn: Callable[[str], None],
    ) -> None:
        self.store = store
        self.analytics = analytics
        self.start_campaign_cb = start_campaign_cb
        self.log_fn = log_fn
        self.lock = threading.Lock()
        self.tasks: List[Dict[str, Any]] = []
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def add_task(self, body: Dict[str, Any]) -> Dict[str, Any]:
        kind = str(body.get("kind") or "delayed_campaign")
        delay_min = max(0.1, float(body.get("delay_minutes") or 10))
        repeat_min = max(0.0, float(body.get("repeat_minutes") or 0))
        min_post_age_min = max(0, int(body.get("min_post_age_minutes") or 20))
        exclude_raw = str(body.get("exclude_usernames") or "user6961737737217")
        tid = f"task_{int(time.time() * 1000)}_{random.randint(100,999)}"
        next_ts = time.time() + delay_min * 60.0

        rec = {
            "id": tid,
            "name": str(body.get("name") or kind),
            "kind": kind,  # 'delayed_campaign' | 'periodic_analytics' | 'zero_view_watchdog'
            "next_run_ts": next_ts,
            "next_run_str": dt.datetime.fromtimestamp(next_ts).strftime("%H:%M:%S"),
            "repeat_minutes": repeat_min,
            "min_post_age_minutes": min_post_age_min,
            "exclude_usernames": exclude_raw,
            "runs_count": 0,
            "status": "scheduled",
            "last_result": "Ожидает запуска",
            "campaign_payload": body.get("campaign_payload") or {},
        }
        with self.lock:
            self.tasks.append(rec)
        self.log_fn(
            f"⏰ Авто-Пилот: задача «{rec['name']}» запланирована на {rec['next_run_str']}"
            + (f" (повтор каждые {repeat_min:g} мин)" if repeat_min > 0 else "")
        )
        return rec

    def delete_task(self, tid: str) -> bool:
        with self.lock:
            before = len(self.tasks)
            self.tasks = [t for t in self.tasks if t["id"] != tid]
            return len(self.tasks) < before

    def snapshot(self) -> List[Dict[str, Any]]:
        now = time.time()
        with self.lock:
            out = []
            for t in self.tasks:
                c = {k: v for k, v in t.items() if k != "campaign_payload"}
                c["in_sec"] = max(0, int(t["next_run_ts"] - now)) if t["status"] == "scheduled" else 0
                out.append(c)
            return out

    def _loop(self) -> None:
        while True:
            time.sleep(2.0)
            now = time.time()
            due: List[Dict[str, Any]] = []
            with self.lock:
                for t in self.tasks:
                    if t["status"] == "scheduled" and now >= t["next_run_ts"]:
                        t["status"] = "running"
                        due.append(t)
            for t in due:
                try:
                    self._execute_task(t)
                except Exception as exc:
                    self.log_fn(f"❌ Авто-Пилот «{t['name']}» ошибка: {exc}")
                    with self.lock:
                        t["last_result"] = f"Ошибка: {exc}"
                finally:
                    with self.lock:
                        t["runs_count"] += 1
                        if t["repeat_minutes"] > 0:
                            nxt = time.time() + t["repeat_minutes"] * 60.0
                            t["next_run_ts"] = nxt
                            t["next_run_str"] = dt.datetime.fromtimestamp(nxt).strftime("%H:%M:%S")
                            t["status"] = "scheduled"
                        else:
                            t["status"] = "completed"

    def _execute_task(self, task: Dict[str, Any]) -> None:
        kind = task["kind"]
        cfg = load_saved_config()
        api_key = (task.get("campaign_payload") or {}).get("api_key") or cfg.get("api_key") or ""
        excl = {
            x.strip().lstrip("@").lower()
            for x in re.split(r"[\s,;]+", task.get("exclude_usernames") or "")
            if x.strip()
        }

        if kind == "delayed_campaign":
            payload = dict(task.get("campaign_payload") or {})
            ok = self.start_campaign_cb(payload)
            task["last_result"] = "Кампания запущена" if ok else "Кампания занята (пропуск)"
            return

        all_files = [
            s["filename"]
            for s in self.store.list_sessions()
            if (s.get("username") or "").lower() not in excl
        ]
        if not all_files or not api_key:
            task["last_result"] = "Нет сессий или API ключа"
            return

        if kind == "periodic_analytics":
            if not self.analytics.running:
                with self.analytics.lock:
                    self.analytics.running = True
                    self.analytics.total = len(all_files)
                    self.analytics.done = 0
                run_analytics_scan(self.analytics, self.store, api_key, all_files, 4, self.log_fn)
                task["last_result"] = f"Просканировано {len(all_files)} сессий"
            else:
                task["last_result"] = "Скан уже шёл"
            return

        if kind == "zero_view_watchdog":
            if not self.analytics.running:
                with self.analytics.lock:
                    self.analytics.running = True
                    self.analytics.total = len(all_files)
                    self.analytics.done = 0
                run_analytics_scan(self.analytics, self.store, api_key, all_files, 4, self.log_fn)

            min_age_sec = int(task.get("min_post_age_minutes") or 20) * 60
            now_utc = int(time.time())
            zero_files: List[str] = []
            with self.analytics.lock:
                for acc in self.analytics.accounts:
                    uname = str(acc.get("username") or "").lower()
                    if uname in excl or acc.get("verdict") != "zero":
                        continue
                    posts = acc.get("posts") or []
                    if not posts:
                        continue
                    oldest_ts = min((int(p.get("create_ts") or now_utc) for p in posts), default=now_utc)
                    if (now_utc - oldest_ts) >= min_age_sec:
                        zero_files.append(acc["session_file"])

            if not zero_files:
                task["last_result"] = "Нулевых старше порога не найдено"
                self.log_fn("⏰ Сторож Нулей: все аккаунты в норме (или посты ещё свежие).")
                return

            payload = dict(task.get("campaign_payload") or {})
            payload["api_key"] = api_key
            payload["session_files"] = zero_files
            payload["action_mode"] = "upload"
            payload["delete_old_posts"] = True
            ok = self.start_campaign_cb(payload)
            task["last_result"] = (
                f"Отправлено в перезалив {len(zero_files)} акк." if ok else "Кампания занята"
            )
