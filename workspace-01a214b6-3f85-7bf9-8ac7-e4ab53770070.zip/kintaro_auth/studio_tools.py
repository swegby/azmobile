"""
Powerhouse Arbitrage & Account Farm Tools for Kintaro Studio ULTIMATE:
  1) Live Multi-Session Post Analytics & Shadowban Checker (`/v1/account/posts` + `/v1/account/self`)
     - Collects real-time views (`play_count`), likes (`digg_count`), comments, shares, bookmarks, post region & status
     - Identifies accounts with traffic (`🔥 В реках`), starting views, or 0-view shadowbans (`⚠️ 0 просм.`)
     - Supports 1-click post visibility toggle (`/v1/post/change_visibility`) and single post deletion (`/v1/post/delete`)
  2) Geo FYP Warmup & Mutual Engagement Boost (`/v1/feed/recommendations`, `/v1/post/view`, `like`, `collect`, `repost`, `comment`, `follow`)
  3) Bulk Profile Branding Studio (`set_avatar` with uniquification, `set_nickname`, `change_username`, `set_bio`, `set_bio_url`, `set_password`, `enable_totp`)
  4) Multi-threaded Proxy Geo/Speed Checker & Bulk `x-device` Session Importer
"""

from __future__ import annotations

import base64
import concurrent.futures
import datetime as dt
import json
import os
import random
import re
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from auth_worker import (
    OUTPUT_DIR,
    AccountTask,
    SessionStore,
    extract_profile_summary,
    load_saved_config,
)
from kintaro_client import (
    KintaroClient,
    allocate_sticky_proxy,
    apply_device_geo_profile,
    normalize_proxy,
)
from photo_uniquifier import expand_spintax, uniquify_single_image
from signup_worker import extract_totp_secret_from_payload


def extract_aweme_id_from_input(raw: str) -> str:
    """Extracts numeric TikTok `aweme_id` from a full TikTok URL or raw ID string."""
    s = (raw or "").strip()
    if s.isdigit():
        return s
    m = re.search(r"/(?:video|photo)/(\d{15,22})", s)
    if m:
        return m.group(1)
    m2 = re.search(r"\b(\d{18,20})\b", s)
    return m2.group(1) if m2 else ""


def _resolve_session_proxy(sess: Dict[str, Any], override_region: str = "") -> str:
    saved_cfg = load_saved_config()
    raw_px = sess.get("proxy") or saved_cfg.get("default_signup_proxy") or ""
    px = normalize_proxy(raw_px)
    if not px:
        return ""
    if "bpproxy." in px.lower():
        if px.startswith("http://") and ":1000" in px:
            px = "socks5://" + px[len("http://") :].replace(":1000", ":1002")
        iso = (override_region or sess.get("region") or "US").upper().strip()
        return allocate_sticky_proxy(px, target_country=iso, lifetime="60m", preserve_existing_session=True)
    return px


# =============================================================================
# 1. LIVE ANALYTICS & SHADOWBAN CHECKER
# =============================================================================


class AnalyticsState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.running: bool = False
        self.total: int = 0
        self.done: int = 0
        self.updated_at: str = ""
        self.accounts: List[Dict[str, Any]] = []
        self.totals_kpi: Dict[str, int] = {
            "accounts_scanned": 0,
            "posts_total": 0,
            "views_total": 0,
            "views_delta": 0,
            "likes_total": 0,
            "comments_total": 0,
            "shares_total": 0,
            "collects_total": 0,
            "zero_view_accounts": 0,
            "active_traffic_accounts": 0,
        }
        self._load_cached_report()

    def _load_cached_report(self) -> None:
        rp = OUTPUT_DIR / "analytics_report.json"
        if rp.exists():
            try:
                data = json.loads(rp.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    self.accounts = list(data.get("accounts") or [])
                    if isinstance(data.get("kpi"), dict):
                        self.totals_kpi.update(data["kpi"])
                    self.updated_at = str(data.get("updated_at") or "из кэша")
            except Exception:
                pass

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "running": self.running,
                "total": self.total,
                "done": self.done,
                "updated_at": self.updated_at,
                "kpi": dict(self.totals_kpi),
                "accounts": list(self.accounts),
            }

    def export_csv_bytes(self) -> bytes:
        with self.lock:
            accs = list(self.accounts)
        lines = ["username,region,followers,posts_count,views,views_delta,likes,comments,shares,collects,verdict"]
        for a in accs:
            lines.append(
                f"{a.get('username','')},{a.get('region','')},{a.get('followers',0)},{a.get('posts_count',0)},"
                f"{a.get('views',0)},{a.get('views_delta',0)},{a.get('likes',0)},{a.get('comments',0)},"
                f"{a.get('shares',0)},{a.get('collects',0)},{a.get('verdict','')}"
            )
        return ("\ufeff" + "\n".join(lines) + "\n").encode("utf-8")


def _parse_aweme_stats(item: Dict[str, Any], fallback_uname: str) -> Dict[str, Any]:
    aid = str(item.get("aweme_id") or "")
    st = item.get("statistics") or {}
    author = item.get("author") or {}
    uname = author.get("unique_id") or fallback_uname
    views = int(st.get("play_count") or 0)
    likes = int(st.get("digg_count") or 0)
    comments = int(st.get("comment_count") or 0)
    shares = int(st.get("share_count") or 0)
    collects = int(st.get("collect_count") or 0)
    status_obj = item.get("status") or {}
    priv_status = int(status_obj.get("private_status") or 0)  # 0=public, 1=private, 2=friends
    is_reviewing = bool(status_obj.get("in_reviewing"))
    ctime = int(item.get("create_time") or 0)
    created_str = (
        dt.datetime.fromtimestamp(ctime, tz=dt.timezone.utc).strftime("%d.%m %H:%M")
        if ctime > 0
        else ""
    )
    is_photo = bool(item.get("image_post_info")) or int(item.get("aweme_type") or 0) in (68, 150)
    kind = "photo" if is_photo else "video"
    url = f"https://www.tiktok.com/@{uname}/{kind}/{aid}" if uname and aid else ""

    return {
        "aweme_id": aid,
        "kind": kind,
        "desc": str(item.get("desc") or "")[:90],
        "region": str(item.get("region") or ""),
        "views": views,
        "likes": likes,
        "comments": comments,
        "shares": shares,
        "collects": collects,
        "private_status": priv_status,
        "in_reviewing": is_reviewing,
        "create_ts": ctime,
        "created_at": created_str,
        "url": url,
    }


def run_analytics_scan(
    an_state: AnalyticsState,
    store: SessionStore,
    api_key: str,
    session_files: List[str],
    threads: int,
    log_fn: Callable[[str], None],
) -> None:
    log_fn(f"📊 Старт сбора живой аналитики TikTok: {len(session_files)} сессий в {threads} поток(ах)...")
    with an_state.lock:
        prev_views_map = {str(a.get("session_file")): int(a.get("views") or 0) for a in an_state.accounts}
    rows_out: List[Dict[str, Any]] = []
    rows_lock = threading.Lock()

    def _scan_one(sf: str) -> None:
        sess = store.get_session(sf)
        if not sess:
            with an_state.lock:
                an_state.done += 1
            return
        uname = sess.get("username") or sf.replace(".json", "")
        device = sess.get("device") or sess.get("x_device")
        region = (sess.get("region") or "US").upper()
        px = _resolve_session_proxy(sess, region)

        try:
            with KintaroClient(api_key=api_key) as kt:
                posts_body = None
                self_body = None
                for attempt in range(3):
                    try:
                        self_body, upd_d = kt.get_self(proxy=px, device=device)
                        if upd_d is not None:
                            device = upd_d
                        posts_body, upd_d2 = kt.get_self_posts(proxy=px, device=device, count=20, max_cursor="0")
                        if upd_d2 is not None:
                            device = upd_d2
                        break
                    except Exception:
                        if attempt < 2:
                            px = _resolve_session_proxy(sess, region)
                            time.sleep(1.0)
                        else:
                            raise

                prof = extract_profile_summary(self_body)
                final_uname = prof.get("username") or uname
                followers = int(prof.get("follower_count") or sess.get("follower_count") or 0)

                raw_list = (posts_body.get("aweme_list") if isinstance(posts_body, dict) else None) or []
                parsed_posts = [_parse_aweme_stats(it, final_uname) for it in raw_list if isinstance(it, dict)]

                v_sum = sum(p["views"] for p in parsed_posts)
                l_sum = sum(p["likes"] for p in parsed_posts)
                c_sum = sum(p["comments"] for p in parsed_posts)
                s_sum = sum(p["shares"] for p in parsed_posts)
                b_sum = sum(p["collects"] for p in parsed_posts)

                if len(parsed_posts) == 0:
                    verdict = "empty"
                    verdict_label = "📭 0 постов"
                elif v_sum >= 100:
                    verdict = "hot"
                    verdict_label = "🔥 Идут реки"
                elif v_sum > 0:
                    verdict = "warm"
                    verdict_label = "📈 Старт просм."
                else:
                    verdict = "zero"
                    verdict_label = "⚠️ 0 просм."

                def _upd_s(d: Dict[str, Any]) -> None:
                    if device is not None:
                        d["device"] = device
                    d["follower_count"] = followers
                    if prof.get("signature") is not None:
                        d["signature"] = prof["signature"]

                store.update_session_data(sf, _upd_s)

                prev_v = prev_views_map.get(sf)
                v_delta = (v_sum - prev_v) if prev_v is not None else 0

                acc_rec = {
                    "session_file": sf,
                    "username": final_uname,
                    "region": region,
                    "followers": followers,
                    "posts_count": len(parsed_posts),
                    "views": v_sum,
                    "views_delta": v_delta,
                    "likes": l_sum,
                    "comments": c_sum,
                    "shares": s_sum,
                    "collects": b_sum,
                    "verdict": verdict,
                    "verdict_label": verdict_label,
                    "posts": parsed_posts,
                }
                with rows_lock:
                    rows_out.append(acc_rec)
                delta_str = f" (+{v_delta})" if v_delta > 0 else ""
                log_fn(
                    f"📊 [@{final_uname}] Постов: {len(parsed_posts)} | 👁 Просм: {v_sum}{delta_str} | ❤️ Лайков: {l_sum} | {verdict_label}"
                )
        except Exception as exc:
            log_fn(f"📊 [@{uname}] Ошибка чека аналитики: {exc}")
            with rows_lock:
                rows_out.append(
                    {
                        "session_file": sf,
                        "username": uname,
                        "region": region,
                        "followers": 0,
                        "posts_count": 0,
                        "views": 0,
                        "views_delta": 0,
                        "likes": 0,
                        "comments": 0,
                        "shares": 0,
                        "collects": 0,
                        "verdict": "error",
                        "verdict_label": f"❌ Ошибка: {str(exc)[:40]}",
                        "posts": [],
                    }
                )
        finally:
            with an_state.lock:
                an_state.done += 1

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, min(15, threads))) as pool:
            futs = [pool.submit(_scan_one, sf) for sf in session_files]
            concurrent.futures.wait(futs)

        rows_out.sort(key=lambda r: (r.get("views", 0), r.get("posts_count", 0)), reverse=True)
        kpi = {
            "accounts_scanned": len(rows_out),
            "posts_total": sum(r["posts_count"] for r in rows_out),
            "views_total": sum(r["views"] for r in rows_out),
            "views_delta": sum(max(0, int(r.get("views_delta", 0))) for r in rows_out),
            "likes_total": sum(r["likes"] for r in rows_out),
            "comments_total": sum(r["comments"] for r in rows_out),
            "shares_total": sum(r["shares"] for r in rows_out),
            "collects_total": sum(r["collects"] for r in rows_out),
            "zero_view_accounts": sum(1 for r in rows_out if r["verdict"] == "zero"),
            "active_traffic_accounts": sum(1 for r in rows_out if r["verdict"] in ("hot", "warm")),
        }
        now_str = dt.datetime.now().strftime("%H:%M:%S")
        with an_state.lock:
            an_state.accounts = rows_out
            an_state.totals_kpi = kpi
            an_state.updated_at = now_str
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        (OUTPUT_DIR / "analytics_report.json").write_text(
            json.dumps({"updated_at": now_str, "kpi": kpi, "accounts": rows_out}, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        log_fn(
            f"✅ Аналитика собрана! Постов: {kpi['posts_total']} | 👁 Всего просмотров: {kpi['views_total']} | "
            f"❤️ Лайков: {kpi['likes_total']} | Аккаунтов с трафиком: {kpi['active_traffic_accounts']}"
        )
    finally:
        with an_state.lock:
            an_state.running = False


# =============================================================================
# 2. GEO FYP WARMUP & ENGAGEMENT BOOST + BULK PROFILE BRANDING
# =============================================================================


class ToolsJobState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.running: bool = False
        self.stop_requested: bool = False
        self.job_type: str = ""
        self.total: int = 0
        self.done: int = 0
        self.success: int = 0
        self.failed: int = 0
        self.results: List[str] = []

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "running": self.running,
                "job_type": self.job_type,
                "total": self.total,
                "done": self.done,
                "success": self.success,
                "failed": self.failed,
                "results": list(self.results[-100:]),
            }


def warmup_single_session_fyp(
    kt: KintaroClient,
    proxy: str,
    device: Any,
    region: str,
    videos_to_watch: int,
    like_prob_pct: int,
    collect_prob_pct: int,
    tag: str,
    log_fn: Callable[[str], None],
) -> Tuple[int, int, Any]:
    """Watches N recommended FYP videos in `region` with realistic playtime + random likes/bookmarks."""
    cur_dev = apply_device_geo_profile(device, region)
    feed_body, upd = kt.get_feed_recommendations(proxy=proxy, device=cur_dev, region=region)
    if upd is not None:
        cur_dev = upd
    aweme_list = (feed_body.get("aweme_list") if isinstance(feed_body, dict) else None) or []
    ids = [str(a.get("aweme_id")) for a in aweme_list if isinstance(a, dict) and a.get("aweme_id")]
    random.shuffle(ids)
    targets = ids[: max(1, min(15, videos_to_watch))]

    watched = 0
    liked = 0
    for aid in targets:
        play_ms = random.randint(3800, 11500)
        try:
            _, upd_v = kt.view_post(proxy=proxy, device=cur_dev, aweme_id=aid, playtime_ms=play_ms)
            if upd_v is not None:
                cur_dev = upd_v
            watched += 1
        except Exception:
            continue

        if random.randint(1, 100) <= like_prob_pct:
            try:
                _, upd_l = kt.like_post(proxy=proxy, device=cur_dev, aweme_id=aid)
                if upd_l is not None:
                    cur_dev = upd_l
                liked += 1
            except Exception:
                pass

        if random.randint(1, 100) <= collect_prob_pct:
            try:
                _, upd_c = kt.collect_post(proxy=proxy, device=cur_dev, aweme_id=aid)
                if upd_c is not None:
                    cur_dev = upd_c
            except Exception:
                pass
        time.sleep(random.uniform(1.2, 2.8))

    log_fn(f"🔥 [{tag}] Прогрев FYP ({region}): просмотрено {watched} видео, поставлено {liked} ❤️")
    return watched, liked, cur_dev


def run_warmup_or_boost_background(
    job_state: ToolsJobState,
    store: SessionStore,
    body: Dict[str, Any],
    log_fn: Callable[[str], None],
) -> None:
    api_key = (body.get("api_key") or "").strip()
    mode = (body.get("mode") or "warmup_fyp").strip()  # 'warmup_fyp' | 'boost_target'
    session_files = [os.path.basename(str(x)) for x in (body.get("session_files") or []) if x]
    threads = max(1, min(15, int(body.get("threads") or 3)))
    region = (body.get("region") or "US").upper().strip()

    videos_count = max(1, min(15, int(body.get("videos_count") or 5)))
    like_prob = max(0, min(100, int(body.get("like_prob") or 35)))
    collect_prob = max(0, min(100, int(body.get("collect_prob") or 15)))

    target_post_raw = (body.get("target_post") or "").strip()
    target_aweme_id = extract_aweme_id_from_input(target_post_raw)
    target_username = (body.get("target_username") or "").strip().lstrip("@")
    do_view = bool(body.get("do_view", True))
    do_like = bool(body.get("do_like", True))
    do_collect = bool(body.get("do_collect", False))
    do_repost = bool(body.get("do_repost", False))
    do_follow = bool(body.get("do_follow", False))
    comments_lines = [ln.strip() for ln in (body.get("comments_text") or "").splitlines() if ln.strip()]

    def _worker(sf: str) -> None:
        with job_state.lock:
            if job_state.stop_requested:
                job_state.done += 1
                return
        sess = store.get_session(sf)
        if not sess:
            with job_state.lock:
                job_state.done += 1
                job_state.failed += 1
            return
        uname = sess.get("username") or sf.replace(".json", "")
        tag = f"@{uname}"
        dev = sess.get("device") or sess.get("x_device")
        px = _resolve_session_proxy(sess, region)

        try:
            with KintaroClient(api_key=api_key) as kt:
                if mode == "warmup_fyp":
                    w, lk, new_dev = warmup_single_session_fyp(
                        kt=kt,
                        proxy=px,
                        device=dev,
                        region=region,
                        videos_to_watch=videos_count,
                        like_prob_pct=like_prob,
                        collect_prob_pct=collect_prob,
                        tag=tag,
                        log_fn=log_fn,
                    )
                    store.update_session_data(
                        sf,
                        lambda d, _dv=new_dev: d.__setitem__("device", _dv) if _dv else None,
                    )
                    with job_state.lock:
                        job_state.done += 1
                        job_state.success += 1
                        job_state.results.append(f"{tag}: прогрев {region} ({w} просм, {lk} лайков)")
                else:
                    actions_done: List[str] = []
                    cur_dev = dev
                    if target_username and do_follow:
                        _, upd = kt.follow_user(proxy=px, device=cur_dev, username=target_username)
                        if upd is not None:
                            cur_dev = upd
                        actions_done.append(f"подписка @{target_username}")

                    if target_aweme_id:
                        if do_view:
                            _, upd = kt.view_post(
                                proxy=px,
                                device=cur_dev,
                                aweme_id=target_aweme_id,
                                playtime_ms=random.randint(6000, 14500),
                            )
                            if upd is not None:
                                cur_dev = upd
                            actions_done.append("просм")
                        if do_like:
                            _, upd = kt.like_post(proxy=px, device=cur_dev, aweme_id=target_aweme_id)
                            if upd is not None:
                                cur_dev = upd
                            actions_done.append("лайк")
                        if do_collect:
                            _, upd = kt.collect_post(proxy=px, device=cur_dev, aweme_id=target_aweme_id)
                            if upd is not None:
                                cur_dev = upd
                            actions_done.append("избранное")
                        if do_repost:
                            _, upd = kt.repost_post(proxy=px, device=cur_dev, aweme_id=target_aweme_id)
                            if upd is not None:
                                cur_dev = upd
                            actions_done.append("репост")
                        if comments_lines:
                            chosen_cmt = expand_spintax(random.choice(comments_lines))
                            _, upd = kt.publish_comment(
                                proxy=px, device=cur_dev, aweme_id=target_aweme_id, text=chosen_cmt
                            )
                            if upd is not None:
                                cur_dev = upd
                            actions_done.append(f"коммент: {chosen_cmt[:20]}")

                    store.update_session_data(
                        sf,
                        lambda d, _dv=cur_dev: d.__setitem__("device", _dv) if _dv else None,
                    )
                    summary_str = ", ".join(actions_done) or "нет действий"
                    log_fn(f"🚀 [{tag}] Буст выполнен: {summary_str}")
                    with job_state.lock:
                        job_state.done += 1
                        job_state.success += 1
                        job_state.results.append(f"{tag}: {summary_str}")
        except Exception as exc:
            log_fn(f"⚠️ [{tag}] Ошибка ({mode}): {exc}")
            with job_state.lock:
                job_state.done += 1
                job_state.failed += 1
                job_state.results.append(f"{tag}: ОШИБКА ({exc})")

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as pool:
            futs = [pool.submit(_worker, sf) for sf in session_files]
            concurrent.futures.wait(futs)
        log_fn(f"🏁 Задача ({mode}) завершена: успешно {job_state.success}/{job_state.total}")
    finally:
        with job_state.lock:
            job_state.running = False


def run_profile_branding_background(
    job_state: ToolsJobState,
    store: SessionStore,
    body: Dict[str, Any],
    log_fn: Callable[[str], None],
) -> None:
    api_key = (body.get("api_key") or "").strip()
    session_files = [os.path.basename(str(x)) for x in (body.get("session_files") or []) if x]
    threads = max(1, min(15, int(body.get("threads") or 3)))

    avatar_durl = (body.get("avatar_data_url") or "").strip()
    uniquify_avatar = bool(body.get("uniquify_avatar", True))
    nickname_tpl = (body.get("nickname_template") or "").strip()
    username_prefix = re.sub(r"[^a-z0-9_.]", "", (body.get("username_prefix") or "").strip().lower())[:14]
    bio_tpl = (body.get("bio_template") or "").strip()
    bio_url = (body.get("bio_url") or "").strip()
    new_password = (body.get("new_password") or "").strip()
    enable_totp_flag = bool(body.get("enable_totp", False))

    raw_avatar_bytes: Optional[bytes] = None
    if avatar_durl:
        b64p = avatar_durl.split(",", 1)[1] if "," in avatar_durl else avatar_durl
        raw_avatar_bytes = base64.b64decode(b64p)

    def _worker(sf: str) -> None:
        with job_state.lock:
            if job_state.stop_requested:
                job_state.done += 1
                return
        sess = store.get_session(sf)
        if not sess:
            with job_state.lock:
                job_state.done += 1
                job_state.failed += 1
            return
        uname = sess.get("username") or sf.replace(".json", "")
        tag = f"@{uname}"
        cur_dev = sess.get("device") or sess.get("x_device")
        px = _resolve_session_proxy(sess)
        done_parts: List[str] = []
        new_uname_val: Optional[str] = None
        new_nick_val: Optional[str] = None
        new_bio_val: Optional[str] = None
        new_totp_val: Optional[str] = None

        try:
            with KintaroClient(api_key=api_key) as kt:
                if raw_avatar_bytes:
                    av_bytes = (
                        uniquify_single_image(raw_avatar_bytes, mode="stealth")
                        if uniquify_avatar
                        else raw_avatar_bytes
                    )
                    _, upd = kt.set_avatar(proxy=px, device=cur_dev, image=av_bytes)
                    if upd is not None:
                        cur_dev = upd
                    done_parts.append("аватар")

                if nickname_tpl:
                    new_nick_val = expand_spintax(nickname_tpl)
                    _, upd = kt.set_nickname(proxy=px, device=cur_dev, nickname=new_nick_val)
                    if upd is not None:
                        cur_dev = upd
                    done_parts.append(f"имя={new_nick_val}")

                if username_prefix:
                    cand_u = f"{username_prefix}{random.randint(1000, 99999)}"
                    _, upd = kt.change_username(proxy=px, device=cur_dev, username=cand_u)
                    if upd is not None:
                        cur_dev = upd
                    new_uname_val = cand_u
                    done_parts.append(f"@{cand_u}")

                if bio_tpl:
                    new_bio_val = expand_spintax(bio_tpl)
                    _, upd = kt.set_bio(proxy=px, device=cur_dev, text=new_bio_val)
                    if upd is not None:
                        cur_dev = upd
                    done_parts.append("БИО")

                if bio_url:
                    _, upd = kt.set_bio_url(proxy=px, device=cur_dev, url=bio_url)
                    if upd is not None:
                        cur_dev = upd
                    done_parts.append("ссылка")

                if new_password:
                    _, upd = kt.set_password(proxy=px, device=cur_dev, password=new_password)
                    if upd is not None:
                        cur_dev = upd
                    done_parts.append("пароль")

                if enable_totp_flag:
                    for way in ("email", "mobile_sms", "pwd"):
                        try:
                            tb, upd = kt.enable_totp(proxy=px, device=cur_dev, additional_way=way)
                            if upd is not None:
                                cur_dev = upd
                            sec = extract_totp_secret_from_payload(tb, cur_dev)
                            if sec:
                                new_totp_val = sec
                                done_parts.append(f"TOTP={sec}")
                                break
                        except Exception:
                            continue

            def _upd_s(d: Dict[str, Any]) -> None:
                if cur_dev is not None:
                    d["device"] = cur_dev
                if new_uname_val:
                    d["username"] = new_uname_val
                if new_nick_val:
                    d["nickname"] = new_nick_val
                if new_bio_val is not None:
                    d["signature"] = new_bio_val
                if new_password:
                    d["tiktok_password"] = new_password
                if new_totp_val:
                    d["totp_token"] = new_totp_val

            store.update_session_data(sf, _upd_s)
            msg_out = ", ".join(done_parts) or "без изменений"
            log_fn(f"🎨 [{tag}] Профиль обновлён: {msg_out}")
            with job_state.lock:
                job_state.done += 1
                job_state.success += 1
                job_state.results.append(f"{tag} -> {msg_out}")
        except Exception as exc:
            log_fn(f"❌ [{tag}] Ошибка оформления профиля: {exc}")
            with job_state.lock:
                job_state.done += 1
                job_state.failed += 1
                job_state.results.append(f"{tag} -> ОШИБКА: {exc}")

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as pool:
            futs = [pool.submit(_worker, sf) for sf in session_files]
            concurrent.futures.wait(futs)
        log_fn(f"🏁 Оформление профилей завершено: {job_state.success}/{job_state.total}")
    finally:
        with job_state.lock:
            job_state.running = False


# =============================================================================
# 3. PROXY MULTI-CHECKER & BULK SESSION IMPORTER
# =============================================================================


def check_proxies_batch(proxies_lines: List[str]) -> List[Dict[str, Any]]:
    clean = [normalize_proxy(p) for p in proxies_lines if p.strip() and not p.strip().startswith("#")][:30]

    def _chk(px: str) -> Dict[str, Any]:
        px_curl = px.replace("socks5://", "socks5h://", 1)
        t0 = time.time()
        try:
            r1 = subprocess.run(
                ["curl", "-sS", "--max-time", "6", "-x", px_curl, "http://ip-api.com/json"],
                capture_output=True,
                text=True,
            )
            if r1.returncode != 0:
                return {"proxy": px, "ok": False, "error": (r1.stderr or "Таймаут соединения")[:80]}
            info = json.loads(r1.stdout)
            r2 = subprocess.run(
                [
                    "curl",
                    "-sS",
                    "-o",
                    "/dev/null",
                    "-w",
                    "%{http_code}",
                    "--max-time",
                    "6",
                    "-x",
                    px_curl,
                    "https://www.tiktok.com/robots.txt",
                ],
                capture_output=True,
                text=True,
            )
            ms = int((time.time() - t0) * 1000)
            tt_code = r2.stdout.strip()
            return {
                "proxy": px,
                "ok": r2.returncode == 0 and tt_code.startswith(("2", "3", "4")),
                "ip": info.get("query"),
                "country": info.get("countryCode"),
                "city": info.get("city"),
                "isp": info.get("isp"),
                "tiktok_http": tt_code,
                "latency_ms": ms,
            }
        except Exception as exc:
            return {"proxy": px, "ok": False, "error": str(exc)[:80]}

    with concurrent.futures.ThreadPoolExecutor(max_workers=min(10, max(1, len(clean)))) as pool:
        return list(pool.map(_chk, clean))


def import_sessions_bulk(
    store: SessionStore,
    raw_text: str,
    default_proxy: str,
    default_region: str = "US",
) -> int:
    """
    Imports sessions from JSONL lines (`{"username": ..., "x_device": ...}`),
    full session JSON objects, or raw `x-device` JSON strings (1 per line).
    """
    imported = 0
    txt = (raw_text or "").strip()
    if not txt:
        return 0

    candidates: List[Any] = []
    try:
        parsed_whole = json.loads(txt)
        if isinstance(parsed_whole, list):
            candidates.extend(parsed_whole)
        elif isinstance(parsed_whole, dict):
            candidates.append(parsed_whole)
    except Exception:
        for ln in txt.splitlines():
            s = ln.strip()
            if not s:
                continue
            try:
                candidates.append(json.loads(s))
            except Exception:
                continue

    for idx, obj in enumerate(candidates, start=1):
        if not isinstance(obj, dict):
            continue
        dev = obj.get("device")
        if not dev and obj.get("x_device"):
            try:
                dev = json.loads(obj["x_device"]) if isinstance(obj["x_device"], str) else obj["x_device"]
            except Exception:
                dev = obj["x_device"]
        if not dev and ("device_id" in obj or "install_id" in obj):
            dev = obj

        if not dev:
            continue

        uname = obj.get("username") or f"imported_{int(time.time())}_{idx}"
        px = normalize_proxy(obj.get("proxy") or default_proxy or "")
        reg = (obj.get("region") or default_region or "US").upper()
        task = AccountTask(
            email=obj.get("email") or "",
            username=uname,
            tiktok_password=obj.get("tiktok_password"),
            totp_token=obj.get("totp_token"),
            proxy=px,
            region=reg,
        )
        store.save_success(
            task=task,
            proxy_normalized=px,
            device=dev,
            auth_response=obj.get("auth_response"),
            self_response=obj.get("self_info"),
        )
        imported += 1

    return imported
