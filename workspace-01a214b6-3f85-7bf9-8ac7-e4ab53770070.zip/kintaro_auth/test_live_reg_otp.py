import json
import random
import time
from pathlib import Path

from auth_worker import AccountTask, SessionStore, extract_profile_summary
from greedy_sms_client import GreedySMSClient, TIKTOK_SERVICE_CODE, resolve_greedy_country
from kintaro_client import (
    KintaroAPIError,
    KintaroClient,
    apply_device_geo_profile,
    generate_totp_code,
)
from signup_worker import (
    extract_totp_secret_from_payload,
    generate_adult_birthday,
    generate_strong_tiktok_password,
    prepare_signup_proxy,
    _save_registered_account_artifact,
)

cfg = json.loads(Path("/home/user/kintaro_auth/config.json").read_text(encoding="utf-8"))
KINTARO_KEY = cfg["api_key"]
GREEDY_KEY = cfg["greedy_api_key"]
RAW_PROXY = cfg["default_signup_proxy"]

country_opt = resolve_greedy_country(151)  # Chile (CL)
region = "CL"
password = generate_strong_tiktok_password()
birthday = generate_adult_birthday()

proxy = prepare_signup_proxy(RAW_PROXY, region, auto_match_country=True, log_fn=print)
print(f"[1] Sticky proxy ({region}): {proxy}")
print(f"[1] Generated password={password} | birthday={birthday}")

with GreedySMSClient(api_key=GREEDY_KEY) as sms, KintaroClient(api_key=KINTARO_KEY) as kt:
    bal = sms.get_balance()
    print(f"[2] Greedy SMS balance: {bal:.2f} RUB")

    activation = None
    device = None
    signup_resp = None
    seen_codes = set()

    for attempt in range(1, 4):
        print(f"[3] Registering Kintaro Android device (attempt {attempt})...")
        raw_dev = kt.register_device(proxy=proxy, region=region)
        device = apply_device_geo_profile(raw_dev, target_region=region)

        activation = sms.buy_number(
            country=country_opt,
            service=TIKTOK_SERVICE_CODE,
            max_price=4.0,
            log_fn=print,
        )
        print(f"[4] Bought number: {activation.kintaro_mobile} (id={activation.activation_id}, price={activation.price} RUB)")

        step1 = kt.signup_mobile(
            mobile=activation.kintaro_mobile,
            birthday=birthday,
            region=region,
            proxy=proxy,
            password=password,
            device=device,
        )
        if step1.device is not None:
            device = step1.device
        print(f"[5] signup_mobile -> status={step1.status} http={step1.http_status} msg={step1.message}")
        if step1.status == "error":
            print("    signup_mobile error body:", json.dumps(step1.response, ensure_ascii=False)[:500])
            sms.cancel_activation(activation.activation_id, log_fn=print, allow_cooldown_wait=True)
            proxy = prepare_signup_proxy(RAW_PROXY, region, auto_match_country=True, log_fn=print)
            continue

        if step1.status == "code_required":
            code = sms.wait_for_sms_code(
                activation_id=activation.activation_id,
                timeout_sec=110,
                poll_interval=3.0,
                seen_codes=seen_codes,
                log_fn=print,
            )
            if not code:
                print("[!] No SMS code received -> cancelling number for refund...")
                sms.cancel_activation(activation.activation_id, log_fn=print, allow_cooldown_wait=True)
                continue
            seen_codes.add(code)
            print(f"[6] Got SMS code: {code} -> calling signup_mobile_send_code...")
            step2 = kt.signup_mobile_send_code(
                mobile=activation.kintaro_mobile,
                birthday=birthday,
                code=code,
                proxy=proxy,
                device=device,
                password=password,
            )
            if step2.device is not None:
                device = step2.device
            print(f"[7] signup_mobile_send_code -> status={step2.status} http={step2.http_status} msg={step2.message}")
            if step2.status != "success":
                print("    send_code error body:", json.dumps(step2.response, ensure_ascii=False)[:600])
                sms.finish_activation(activation.activation_id)
                proxy = prepare_signup_proxy(RAW_PROXY, region, auto_match_country=True, log_fn=print)
                continue
            signup_resp = step2.response
            break
        else:
            signup_resp = step1.response
            break
    else:
        raise RuntimeError("Failed to complete mobile signup in 3 attempts")

    # Immediately enable TOTP with additional_way="mobile_sms" FIRST while SMS signup ticket is fresh!
    print("\n[8] Calling POST /v1/account/enable_totp with additional_way='mobile_sms'...")
    totp_body = None
    totp_secret = None
    used_way = None
    try:
        totp_body, dev_t = kt.enable_totp(proxy=proxy, device=device, additional_way="mobile_sms")
        if dev_t is not None:
            device = dev_t
        used_way = "mobile_sms"
        print("[8a] enable_totp('mobile_sms') SUCCESS! Response:")
        print(json.dumps(totp_body, indent=2, ensure_ascii=False))
        totp_secret = extract_totp_secret_from_payload(totp_body, device)
    except KintaroAPIError as e:
        print(f"[8a] enable_totp('mobile_sms') FAILED: {e}")
        print("     Error response_data:", json.dumps(e.response_data, indent=2, ensure_ascii=False))
        print("[8b] Trying enable_totp('pwd') as comparison...")
        totp_body, dev_t = kt.enable_totp(proxy=proxy, device=device, additional_way="pwd")
        if dev_t is not None:
            device = dev_t
        used_way = "pwd"
        print("[8b] enable_totp('pwd') SUCCESS! Response:")
        print(json.dumps(totp_body, indent=2, ensure_ascii=False))
        totp_secret = extract_totp_secret_from_payload(totp_body, device)

    # Set an explicit username so username+password+TOTP login works immediately!
    target_username = f"chile_otp_{random.randint(10000, 99999)}"
    print(f"\n[9] Setting explicit username via POST /v1/account/change_username -> {target_username}...")
    try:
        u_body, dev_u = kt.change_username(proxy=proxy, device=device, username=target_username)
        if dev_u is not None:
            device = dev_u
        print("[9] change_username SUCCESS:", json.dumps(u_body, ensure_ascii=False)[:300])
    except Exception as ue:
        print(f"[9] change_username warning: {ue}")

    self_body, dev_s = kt.get_self(proxy=proxy, device=device)
    if dev_s is not None:
        device = dev_s
    prof = extract_profile_summary(self_body, signup_resp)
    final_username = prof.get("username") or target_username
    print(f"[10] Profile summary: username=@{final_username} uid={prof.get('uid')} sec_uid={prof.get('sec_uid')}")
    print(f"[10] TOTP secret ({used_way}): {totp_secret} | current code: {generate_totp_code(totp_secret) if totp_secret else None}")

    # Save session right away so nothing is lost
    store = SessionStore()
    task = AccountTask(
        email="",
        username=final_username,
        tiktok_password=password,
        totp_token=totp_secret,
        proxy=proxy,
        region=region,
        raw_line=f"{final_username}|{password}|{activation.e164_phone}|{totp_secret or ''}",
    )
    saved = store.save_success(
        task=task,
        proxy_normalized=proxy,
        device=device,
        auth_response=signup_resp,
        self_response=self_body,
    )
    print(f"[11] Saved session for @{final_username} (uid={saved.get('uid')})")

    # Finish activation on Greedy SMS only AFTER we test login below (in case SMS is needed)
    print("\n[12] VERIFYING LOGIN ON A BRAND-NEW DEVICE VIA KINTARO API (POST /v1/auth/signin/username)...")
    time.sleep(3)
    login_dev_raw = kt.register_device(proxy=proxy, region=region)
    login_dev = apply_device_geo_profile(login_dev_raw, target_region=region)

    print("[12a] Test 1: signin_username WITHOUT totp_token (checking what 2FA challenge TikTok returns)...")
    res_no_totp = kt.signin_username(
        username=final_username,
        password=password,
        proxy=proxy,
        region=region,
        totp_token=None,
        device=login_dev,
        sync_totp_window=False,
    )
    print(f"      -> status={res_no_totp.status} http={res_no_totp.http_status} msg={res_no_totp.message}")
    print("      -> response:", json.dumps(res_no_totp.response, indent=2, ensure_ascii=False)[:1500])

    print("\n[12b] Test 2: signin_username WITH totp_token on fresh device...")
    login_dev_raw2 = kt.register_device(proxy=proxy, region=region)
    login_dev2 = apply_device_geo_profile(login_dev_raw2, target_region=region)
    res_with_totp = kt.signin_username(
        username=final_username,
        password=password,
        proxy=proxy,
        region=region,
        totp_token=totp_secret,
        device=login_dev2,
        sync_totp_window=True,
        log_fn=print,
    )
    print(f"      -> status={res_with_totp.status} http={res_with_totp.http_status} msg={res_with_totp.message}")
    print("      -> response:", json.dumps(res_with_totp.response, indent=2, ensure_ascii=False)[:1200])

    sms.finish_activation(activation.activation_id, log_fn=print)

    rec = {
        "status": "success",
        "username": final_username,
        "uid": saved.get("uid"),
        "sec_uid": saved.get("sec_uid"),
        "password": password,
        "birthday": birthday,
        "e164_phone": activation.e164_phone,
        "kintaro_mobile": activation.kintaro_mobile,
        "activation_id": activation.activation_id,
        "sms_price_rub": activation.price,
        "country": country_opt.to_dict(),
        "region": region,
        "proxy": proxy,
        "totp_enabled": bool(totp_secret),
        "totp_way": used_way,
        "totp_secret": totp_secret,
        "totp_raw_response": totp_body,
        "login_verified_status": res_with_totp.status,
        "account_line": f"{final_username}|{password}|{activation.e164_phone}|{totp_secret or ''}",
        "session_file": f"{final_username}.json",
    }
    _save_registered_account_artifact(rec)
    print("\n[DONE] Account line:", rec["account_line"])
