#!/usr/bin/env python3
"""
Kintaro Studio v5 (ENTERPRISE) — Полный комбайн для фермы аккаунтов и арбитража трафика TikTok:
  1) 🎯 Массовый Залив (Фото-карусели + Видео MP4, пресеты, N потоков, предпрогрев FYP, спинтакс, музыка + тренды ГЕО, уникализатор с Live Preview)
  2) 📊 Аналитика v2 и Чекер Теневого бана (KPI, дельта роста +просмотров, экспорт CSV, управление видимостью и удалением постов, 1-клик перезалив нулей)
  3) 🕵️ Шпион Конкурентов и Клонирование Связок (анализ любого @username или поста, скачивание слайдов/MP4 без водяного знака в media/, перенос связки с Music ID в 1 клик)
  4) 💬 Коммент-Маркетинг и Вывод в ТОП #1 (чтение комментов, публикация коммента со спинтаксом/картинкой-пруфом + авто-вывод в ТОП лайками и ответами своих сессий)
  5) 🔥 Прогрев ГЕО-ленты (FYP) и Взаимный Буст сессиями
  6) 🎨 Массовый Оформитель Профилей (уникализированные аватарки, никнеймы, @username, БИО, ссылка, пароль, TOTP)
  7) ⏰ Авто-Пилот и Сторож Нулей (отложенный залив, периодический чек просмотров, авто-перезалив нулевых аккаунтов)
  8) 🔑 Менеджер Сессий (генератор живых 2FA TOTP кодов в 1 клик, импорт/экспорт, групповые операции)
  9) 📸 Одиночный Пост (Фото/MP4), 📱 Авто-рег SMS (Greedy + TOTP), 📥 Вход в аккаунты, ⚙️ Настройки & Мульти-Чекер Прокси
"""

from __future__ import annotations

import base64
import concurrent.futures
import datetime as dt
import io
import json
import os
import re
import threading
import traceback
import urllib.parse
import zipfile
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional

from auth_worker import (
    MEDIA_DIR,
    OUTPUT_DIR,
    SESSIONS_DIR,
    AccountTask,
    LoginOptions,
    PendingCodeChallenge,
    SessionStore,
    delete_all_posts_for_session,
    extract_profile_summary,
    load_saved_config,
    parse_account_line,
    parse_delay_range,
    process_single_account,
    publish_photo_carousel_for_session,
    restart_tiktok_app_for_session,
    save_config,
)
from auto_appeal import (
    AUTO_APPEAL_REPORT_FILE,
    DEFAULT_APPEAL_TEXT,
    AutoAppealManager,
    ensure_session_clean_loop,
    export_sorted_folder_archive,
    get_sorted_folders_summary,
)
from campaign_manager import (
    GEO_LOCALE_DEFAULTS,
    CampaignState,
    delete_preset,
    list_media_library,
    load_presets,
    run_campaign_background,
    save_media_files,
    save_preset,
)
from greedy_sms_client import GreedySMSClient, get_static_country_catalog
from kintaro_client import KintaroClient, apply_device_geo_profile, normalize_proxy
from photo_uniquifier import (
    PRESET_DEFAULTS,
    UniquifierSettings,
    compute_sha256_short,
    expand_spintax,
    uniquify_single_image,
)
from signup_worker import MobileSignupOptions, register_single_mobile_account
from spy_and_autopilot import (
    AutoPilotScheduler,
    download_creative_to_media,
    fetch_post_comments_structured,
    generate_live_totp_info,
    run_top_comment_boost_background,
    spy_competitor_or_post,
)
from studio_tools import (
    AnalyticsState,
    ToolsJobState,
    _resolve_session_proxy,
    check_proxies_batch,
    import_sessions_bulk,
    run_analytics_scan,
    run_profile_branding_background,
    run_warmup_or_boost_background,
)


STORE = SessionStore()
CAMPAIGN = CampaignState()
ANALYTICS = AnalyticsState()
TOOLS_JOB = ToolsJobState()


class AppState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.logs: List[Dict[str, str]] = []
        self.batch_running: bool = False
        self.batch_stop_requested: bool = False
        self.batch_total: int = 0
        self.batch_done: int = 0
        self.batch_success: int = 0
        self.batch_failed: int = 0
        self.batch_pending_codes: Dict[str, PendingCodeChallenge] = {}

        self.signup_running: bool = False
        self.signup_stop_requested: bool = False
        self.signup_total: int = 0
        self.signup_done: int = 0
        self.signup_success: int = 0
        self.signup_failed: int = 0

    def log(self, message: str, level: str = "info") -> None:
        lvl = level
        low = message.lower()
        if "ошибка" in low or "error" in low or "таймаут" in low or "❌" in low:
            lvl = "error"
        elif (
            "успешн" in low
            or "готово" in low
            or "сохранена" in low
            or "принят" in low
            or "опубликован" in low
            or "изменено" in low
            or "завершена" in low
            or "собрана" in low
            or "завершён" in low
            or "✅" in low
            or "🏁" in low
            or "🏆" in low
        ):
            lvl = "success"
        elif (
            bool(re.search(r"\b403\b", low))
            or "ожидание кода" in low
            or "предупреждение" in low
            or "повтор очистки" in low
            or "повтор попытки" in low
            or "⚠️" in low
        ):
            lvl = "warn"

        entry = {
            "time": dt.datetime.now().strftime("%H:%M:%S"),
            "level": lvl,
            "text": message,
        }
        with self.lock:
            self.logs.append(entry)
            if len(self.logs) > 900:
                self.logs = self.logs[-900:]


STATE = AppState()
AUTO_APPEAL = AutoAppealManager(store=STORE, log_fn=STATE.log)


def _trigger_campaign_programmatically(body: Dict[str, Any]) -> bool:
    with CAMPAIGN.lock:
        if CAMPAIGN.running:
            return False
        action_mode = str(body.get("action_mode") or "upload")
        api_key = (body.get("api_key") or load_saved_config().get("api_key") or "").strip()
        session_files = [os.path.basename(str(x)) for x in (body.get("session_files") or []) if x]
        if (not api_key and action_mode != "auto_appeal") or not session_files:
            return False
        body["api_key"] = api_key
        body["session_files"] = session_files
        copies_count = max(1, min(30, int(body.get("copies_count") or 6)))

        CAMPAIGN.running = True
        CAMPAIGN.stop_requested = False
        CAMPAIGN.action_mode = action_mode
        CAMPAIGN.total_accounts = len(session_files)
        CAMPAIGN.done_accounts = 0
        CAMPAIGN.success_accounts = 0
        CAMPAIGN.failed_accounts = 0
        CAMPAIGN.target_posts_per_account = copies_count if action_mode == "upload" else 0
        CAMPAIGN.published_posts_total = 0
        CAMPAIGN.deleted_posts_total = 0
        CAMPAIGN.appeals_sent_total = 0
        CAMPAIGN.published_urls = []
        CAMPAIGN.ordered_keys = list(session_files)
        CAMPAIGN.items = {}
        for sf in session_files:
            s = STORE.get_session(sf) or {}
            uname = s.get("username") or s.get("email") or sf.replace(".json", "")
            CAMPAIGN.items[sf] = {
                "session_file": sf,
                "username": uname,
                "status": "queued",
                "detail": "В очереди",
                "published": 0,
                "deleted": 0,
                "appeals_sent": 0,
                "last_url": "",
            }

    STATE.log(
        f"🚀 Старт кампании ({body.get('action_mode', 'upload')}): {len(session_files)} сессий | потоков={body.get('threads', 3)} | ГЕО={body.get('region') or 'session'}"
    )
    threading.Thread(target=run_campaign_background, args=(CAMPAIGN, STORE, body, STATE.log), daemon=True).start()
    return True


AUTOPILOT = AutoPilotScheduler(
    store=STORE,
    analytics=ANALYTICS,
    start_campaign_cb=_trigger_campaign_programmatically,
    log_fn=STATE.log,
)


def _run_batch_job(tasks: List[AccountTask], proxies: List[str], options: LoginOptions) -> None:
    STATE.log(
        f"Старт массового входа: {len(tasks)} акк. | потоков: {options.threads} | режим: {options.login_mode} | регион: {options.default_region}"
    )

    def worker(idx: int, task: AccountTask) -> None:
        if STATE.batch_stop_requested:
            with STATE.lock:
                STATE.batch_done += 1
            return
        px = task.proxy or proxies[idx % len(proxies)]
        try:
            res = process_single_account(
                task=task,
                proxy_raw=px,
                options=options,
                store=STORE,
                log_fn=STATE.log,
            )
            with STATE.lock:
                STATE.batch_done += 1
                if res.get("status") == "success":
                    STATE.batch_success += 1
                else:
                    STATE.batch_failed += 1
        except Exception as exc:
            STATE.log(f"[{task.identifier}] Ошибка выполнения: {exc}", "error")
            STORE.save_failure(task, str(exc))
            with STATE.lock:
                STATE.batch_done += 1
                STATE.batch_failed += 1

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, options.threads)) as pool:
            futs = [pool.submit(worker, i, t) for i, t in enumerate(tasks)]
            concurrent.futures.wait(futs)
    finally:
        with STATE.lock:
            STATE.batch_running = False
        STATE.log(f"Массовый вход завершён. Успешно: {STATE.batch_success} | Ошибок: {STATE.batch_failed}")


def _run_signup_job(proxies: List[str], options: MobileSignupOptions) -> None:
    STATE.log(
        f"Старт авто-регистрации SMS: {options.count} акк. | страна={options.country} | потоков={options.threads} | TOTP={'ВКЛ' if options.enable_totp_at_end else 'ВЫКЛ'}"
    )

    def _worker(idx: int) -> None:
        with STATE.lock:
            if STATE.signup_stop_requested:
                STATE.signup_done += 1
                return
        px = proxies[idx % len(proxies)]
        try:
            res = register_single_mobile_account(
                proxy_raw=px,
                options=options,
                store=STORE,
                worker_label=f"#{idx + 1}/{options.count}",
                log_fn=STATE.log,
            )
            with STATE.lock:
                STATE.signup_done += 1
                if res.get("status") == "success":
                    STATE.signup_success += 1
                else:
                    STATE.signup_failed += 1
        except Exception as exc:
            STATE.log(f"[Reg #{idx + 1}] Ошибка регистрации: {exc}", "error")
            with STATE.lock:
                STATE.signup_done += 1
                STATE.signup_failed += 1

    try:
        workers = max(1, min(int(options.threads), int(options.count)))
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            futs = [pool.submit(_worker, i) for i in range(int(options.count))]
            concurrent.futures.wait(futs)
    finally:
        with STATE.lock:
            STATE.signup_running = False
        STATE.log(
            f"Авто-регистрация завершена! Создано аккаунтов: {STATE.signup_success} | Ошибок: {STATE.signup_failed}"
        )


DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Kintaro Studio v5 ENTERPRISE — Панель управления TikTok</title>
<style>
  :root {
    --bg: #0a0c11;
    --panel: #121620;
    --panel-2: #191f2d;
    --border: #273146;
    --text: #eef2f9;
    --muted: #919db7;
    --accent: #f26b21;
    --accent-2: #ff8f45;
    --ok: #22c55e;
    --warn: #f59e0b;
    --err: #ef4444;
    --radius: 12px;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: var(--bg); color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, sans-serif;
    font-size: 13.5px; line-height: 1.45;
  }
  header {
    background: linear-gradient(180deg, #161b27 0%, #0f131c 100%);
    border-bottom: 1px solid var(--border);
    padding: 10px 20px; display: flex; flex-wrap: wrap; gap: 12px;
    align-items: center; justify-content: space-between;
    position: sticky; top: 0; z-index: 50;
  }
  .brand { display: flex; align-items: center; gap: 11px; }
  .brand-badge {
    width: 38px; height: 38px; border-radius: 10px;
    background: linear-gradient(135deg, var(--accent-2), #dd4207);
    display: grid; place-items: center; font-weight: 800; font-size: 18px; color: #fff;
    box-shadow: 0 4px 16px rgba(242, 107, 33, 0.35);
  }
  .brand h1 { margin: 0; font-size: 16px; font-weight: 800; letter-spacing: -0.2px; }
  .brand small { color: var(--muted); font-size: 11.4px; display: block; }
  .apikey-bar { display: flex; align-items: center; gap: 7px; flex-wrap: wrap; }
  .apikey-bar input { width: 225px; max-width: 55vw; }
  .container { max-width: 1500px; margin: 0 auto; padding: 14px 18px 54px; }

  .tabs {
    display: flex; gap: 5px; margin-bottom: 14px;
    border-bottom: 1px solid var(--border); padding-bottom: 9px; flex-wrap: wrap;
  }
  .tab-btn {
    background: var(--panel); color: var(--muted); border: 1px solid var(--border);
    padding: 7.5px 11.5px; border-radius: 9px; cursor: pointer; font-weight: 600; font-size: 12.5px;
    transition: all 0.14s;
  }
  .tab-btn:hover { color: var(--text); border-color: #3d4b69; }
  .tab-btn.active {
    color: #fff; background: rgba(242, 107, 33, 0.19); border-color: var(--accent);
    box-shadow: 0 2px 10px rgba(242, 107, 33, 0.16);
  }
  .tab-pane { display: none; }
  .tab-pane.active { display: block; }

  .grid-camp { display: grid; grid-template-columns: 1.18fr 0.82fr; gap: 16px; align-items: start; }
  .grid-2 { display: grid; grid-template-columns: 1.08fr 0.92fr; gap: 16px; align-items: start; }
  @media (max-width: 1040px) { .grid-camp, .grid-2 { grid-template-columns: 1fr; } }

  .card {
    background: var(--panel); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 15px 17px; margin-bottom: 14px;
  }
  .card h2 {
    margin: 0 0 11px; font-size: 14.6px; display: flex;
    align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap;
  }
  .section-box {
    background: rgba(255,255,255,0.015); border: 1px solid var(--border);
    border-radius: 10px; padding: 11px 13px; margin-bottom: 11px;
  }
  .section-title {
    font-size: 12.9px; font-weight: 700; color: #f8fafc;
    margin: 0 0 8px; display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap;
  }

  .kpi-grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; margin-bottom: 14px; }
  @media (max-width: 1100px) { .kpi-grid { grid-template-columns: repeat(3, 1fr); } }
  @media (max-width: 600px) { .kpi-grid { grid-template-columns: repeat(2, 1fr); } }
  .kpi-card { background: var(--panel); border: 1px solid var(--border); border-radius: 11px; padding: 12px 14px; }
  .kpi-card .kpi-label { font-size: 11.5px; color: var(--muted); margin-bottom: 4px; }
  .kpi-card .kpi-val { font-size: 21px; font-weight: 800; color: #fff; letter-spacing: -0.4px; }

  .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px; }
  .form-row-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 10px; }
  .form-row-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 9px; }
  @media (max-width: 700px) { .form-row, .form-row-3, .form-row-4 { grid-template-columns: 1fr; } }
  .field { margin-bottom: 10px; }
  label { display: block; font-size: 11.8px; color: var(--muted); margin-bottom: 4px; font-weight: 500; }

  input[type="text"], input[type="password"], input[type="email"], input[type="number"], select, textarea {
    width: 100%; background: var(--panel-2); border: 1px solid var(--border);
    color: var(--text); border-radius: 8px; padding: 7.5px 10px; font-size: 13px;
    outline: none; font-family: inherit;
  }
  textarea { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12px; resize: vertical; }
  input:focus, select:focus, textarea:focus { border-color: var(--accent); }

  .mode-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 11px; }
  @media (max-width: 820px) { .mode-cards { grid-template-columns: 1fr 1fr; } }
  .mode-card {
    background: var(--panel-2); border: 1.5px solid var(--border); border-radius: 10px;
    padding: 9px 11px; cursor: pointer; transition: all 0.14s;
  }
  .mode-card:hover { border-color: #415172; }
  .mode-card.active { background: rgba(242, 107, 33, 0.15); border-color: var(--accent); }
  .mode-card strong { display: block; font-size: 12.8px; color: #fff; margin-bottom: 2px; }
  .mode-card span { display: block; font-size: 11.2px; color: var(--muted); line-height: 1.3; }

  .switch-row {
    display: flex; align-items: center; justify-content: space-between; gap: 12px;
    background: var(--panel-2); border: 1px solid var(--border); border-radius: 9px;
    padding: 8px 12px; margin: 6px 0; cursor: pointer;
  }
  .switch-row strong { font-size: 12.7px; display: block; color: var(--text); }
  .switch-row small { font-size: 11.2px; color: var(--muted); }
  .toggle-switch { position: relative; display: inline-block; width: 44px; height: 24px; flex-shrink: 0; }
  .toggle-switch input { opacity: 0; width: 0; height: 0; }
  .toggle-slider {
    position: absolute; cursor: pointer; inset: 0; background-color: #2b3245;
    transition: .18s; border-radius: 999px; border: 1px solid var(--border);
  }
  .toggle-slider:before {
    position: absolute; content: ""; height: 18px; width: 18px; left: 2px; bottom: 2px;
    background-color: #fff; transition: .18s; border-radius: 50%;
  }
  .toggle-switch input:checked + .toggle-slider { background: linear-gradient(135deg, var(--accent-2), #e54d0e); border-color: var(--accent); }
  .toggle-switch input:checked + .toggle-slider:before { transform: translateX(20px); }

  .checks { display: flex; flex-wrap: wrap; gap: 13px; margin: 8px 0; align-items: center; }
  .check-item { display: flex; align-items: center; gap: 6px; font-size: 12.5px; cursor: pointer; }

  .btn {
    background: linear-gradient(135deg, var(--accent-2), #e54d0e); color: #fff;
    border: none; border-radius: 8px; padding: 7.5px 13.5px; font-weight: 600; font-size: 12.7px;
    cursor: pointer; transition: opacity 0.14s, transform 0.05s; display: inline-flex; align-items: center; gap: 5px;
  }
  .btn:hover { opacity: 0.93; }
  .btn:active { transform: translateY(1px); }
  .btn:disabled { opacity: 0.45; cursor: not-allowed; }
  .btn-sec { background: var(--panel-2); border: 1px solid var(--border); color: var(--text); }
  .btn-sec:hover { border-color: #455577; }
  .btn-danger { background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.45); color: #fca5a5; }
  .btn-ok { background: rgba(34, 197, 94, 0.16); border: 1px solid rgba(34, 197, 94, 0.45); color: #86efac; }
  .btn-sm { padding: 4.5px 9.5px; font-size: 11.7px; border-radius: 6px; }

  .pill {
    display: inline-flex; align-items: center; gap: 5px; padding: 2.5px 8.5px;
    border-radius: 999px; font-size: 11.4px; font-weight: 600;
    background: var(--panel-2); border: 1px solid var(--border);
  }
  .pill.ok { color: #86efac; border-color: rgba(34,197,94,0.4); background: rgba(34,197,94,0.1); }
  .pill.warn { color: #fcd34d; border-color: rgba(245,158,11,0.4); background: rgba(245,158,11,0.1); }
  .pill.err { color: #fca5a5; border-color: rgba(239,68,68,0.4); background: rgba(239,68,68,0.1); }

  .country-chips { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 8px; }
  .country-chip {
    background: var(--panel-2); border: 1px solid var(--border); color: var(--text);
    border-radius: 999px; padding: 4px 10px; font-size: 12px; cursor: pointer;
    transition: all 0.14s; display: inline-flex; align-items: center; gap: 4px; font-weight: 500;
  }
  .country-chip:hover { border-color: var(--accent); background: rgba(242,107,33,0.1); }
  .country-chip.active { background: rgba(242, 107, 33, 0.22); border-color: var(--accent); color: #fff; font-weight: 700; }

  .session-picker-list {
    max-height: 190px; overflow-y: auto; background: #0b0e15;
    border: 1px solid var(--border); border-radius: 8px; padding: 6px;
    display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 5px;
  }
  .sess-check-item {
    display: flex; align-items: center; justify-content: space-between; gap: 6px;
    padding: 4.5px 8px; border-radius: 6px; background: var(--panel-2);
    border: 1px solid transparent; cursor: pointer; font-size: 11.8px;
  }
  .sess-check-item:hover { border-color: #3a4968; }
  .sess-check-item.checked { border-color: rgba(242,107,33,0.55); background: rgba(242,107,33,0.09); }
  .sess-check-item.excluded { opacity: 0.4; text-decoration: line-through; }

  .media-lib-grid {
    display: flex; gap: 7px; flex-wrap: wrap; margin-top: 7px;
    max-height: 165px; overflow-y: auto; padding: 3px;
  }
  .media-item {
    width: 78px; border-radius: 8px; overflow: hidden; border: 2px solid var(--border);
    background: #090b10; cursor: pointer; position: relative; transition: all 0.14s;
  }
  .media-item.selected { border-color: var(--accent); box-shadow: 0 0 0 2px rgba(242,107,33,0.28); }
  .media-item img { width: 100%; height: 96px; object-fit: cover; display: block; }
  .media-item .vid-box { width: 100%; height: 96px; display: grid; place-items: center; font-size: 24px; background: #141926; }
  .media-item .m-name {
    font-size: 9.8px; padding: 2px 4px; white-space: nowrap; overflow: hidden;
    text-overflow: ellipsis; color: var(--muted); background: var(--panel-2);
  }
  .media-order-badge {
    position: absolute; top: 4px; right: 4px; background: var(--accent); color: #fff;
    font-size: 10px; font-weight: 800; padding: 1px 5.5px; border-radius: 999px;
  }

  .spy-cards-grid {
    display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 12px; margin-top: 12px;
  }
  .spy-post-card {
    background: var(--panel-2); border: 1px solid var(--border); border-radius: 11px;
    overflow: hidden; display: flex; flex-direction: column;
  }
  .spy-post-card img { width: 100%; height: 210px; object-fit: cover; background: #090b10; }
  .spy-post-body { padding: 10px 12px; flex: 1; display: flex; flex-direction: column; justify-content: space-between; gap: 7px; }

  .log-box {
    background: #080a0f; border: 1px solid var(--border); border-radius: 9px;
    height: 275px; overflow-y: auto; padding: 9px 11px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 11.6px;
  }
  .log-line { margin-bottom: 3px; word-break: break-word; }
  .log-time { color: #64748b; margin-right: 6px; }
  .log-info { color: #cbd5e1; }
  .log-success { color: #4ade80; }
  .log-warn { color: #fbbf24; }
  .log-error { color: #f87171; }

  .progress-wrap {
    background: #090b10; border: 1px solid var(--border); border-radius: 999px;
    height: 10px; overflow: hidden; margin: 8px 0 11px;
  }
  .progress-bar { height: 100%; width: 0%; background: linear-gradient(90deg, var(--accent), var(--ok)); transition: width 0.25s; }

  table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
  th, td { text-align: left; padding: 8px 9px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  th { color: var(--muted); font-weight: 600; font-size: 11.5px; }
  code.inline {
    background: #090b10; padding: 1px 5px; border-radius: 5px;
    border: 1px solid var(--border); font-size: 11.3px; color: #fdba74;
  }
  .hint { font-size: 11.3px; color: var(--muted); margin-top: 3px; }
  .thumbs { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 8px; }
  .thumb-card {
    width: 80px; height: 118px; border-radius: 8px; overflow: hidden;
    border: 1px solid var(--border); position: relative; background: #090b10;
  }
  .thumb-card img { width: 100%; height: 100%; object-fit: cover; }
  .thumb-badge {
    position: absolute; top: 4px; left: 4px; background: rgba(0,0,0,0.78);
    color: #fff; font-size: 10px; padding: 1px 5px; border-radius: 4px; font-weight: 700;
  }
  .dropzone {
    border: 1.5px dashed var(--border); border-radius: 9px; padding: 11px;
    text-align: center; background: rgba(255,255,255,0.015); cursor: pointer;
    transition: border-color 0.14s;
  }
  .dropzone:hover { border-color: var(--accent); }
  .result-box {
    margin-top: 11px; padding: 12px; border-radius: 10px;
    border: 1px solid rgba(34, 197, 94, 0.45); background: rgba(34, 197, 94, 0.07); display: none;
  }
  .result-box.visible { display: block; }

  .modal-backdrop {
    position: fixed; inset: 0; background: rgba(0,0,0,0.78);
    display: none; place-items: center; z-index: 100; padding: 18px;
  }
  .modal-backdrop.open { display: grid; }
  .modal {
    background: var(--panel); border: 1px solid var(--border); border-radius: 12px;
    max-width: 880px; width: 100%; max-height: 88vh; display: flex; flex-direction: column; padding: 17px;
  }
  .modal pre {
    background: #090b10; border: 1px solid var(--border); border-radius: 8px;
    padding: 12px; overflow: auto; font-size: 12px; color: #e2e8f0; flex: 1;
  }
  .preview-compare { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; overflow: auto; padding: 4px; }
  @media (max-width: 680px) { .preview-compare { grid-template-columns: 1fr; } }
  .preview-pane { background: #090b10; border: 1px solid var(--border); border-radius: 10px; padding: 10px; text-align: center; }
  .preview-pane img { max-width: 100%; max-height: 54vh; border-radius: 8px; object-fit: contain; }

  #toastContainer {
    position: fixed; bottom: 20px; right: 20px; z-index: 200;
    display: flex; flex-direction: column; gap: 8px; max-width: 380px;
  }
  .toast-item {
    background: #182032; border: 1px solid #354463; border-left: 4px solid var(--accent);
    color: #fff; padding: 10px 14px; border-radius: 10px; font-size: 12.8px; font-weight: 600;
    box-shadow: 0 8px 24px rgba(0,0,0,0.45); animation: fadeIn 0.18s ease;
  }
  .toast-item.ok { border-left-color: var(--ok); }
  .toast-item.err { border-left-color: var(--err); }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
  a.link { color: #fb923c; text-decoration: none; }
  a.link:hover { text-decoration: underline; }
</style>
</head>
<body>

<header>
  <div class="brand">
    <div class="brand-badge">K</div>
    <div>
      <h1>Kintaro Studio <span style="font-size:11.5px; color:var(--accent-2); font-weight:700;">v6 ENTERPRISE • AUTO APPEAL</span></h1>
      <small>Массовый Залив • Авто-Апелляция 3-Канала • Аналитика • Шпион Связок • Топ-Комменты • Авто-Пилот • SMS Рег</small>
    </div>
  </div>

  <div class="apikey-bar">
    <span class="pill ok" id="statSessions">Сессий: 0</span>
    <span class="pill" id="statAutopilot">⏰ Авто-Пилот: 0</span>
    <span class="pill" id="statActiveJob">Потоки: ожидание</span>
    <input type="password" id="apiKeyInput" placeholder="Kintaro x-api-key..." />
    <button class="btn btn-sec btn-sm" onclick="toggleKeyVis()" title="Показать/скрыть ключ">👁</button>
    <button class="btn btn-sm" onclick="saveApiKey()">💾 Ключ</button>
  </div>
</header>

<div id="toastContainer"></div>

<div class="container">
  <div class="tabs">
    <button class="tab-btn active" id="btn-tab-campaign" onclick="switchTab('campaign', this)">🎯 Массовый Залив</button>
    <button class="tab-btn" id="btn-tab-appeal" onclick="switchTab('appeal', this)">🛡️ Авто-Апелляция</button>
    <button class="tab-btn" id="btn-tab-analytics" onclick="switchTab('analytics', this)">📊 Аналитика</button>
    <button class="tab-btn" id="btn-tab-spy" onclick="switchTab('spy', this)">🕵️ Шпион & Связки</button>
    <button class="tab-btn" id="btn-tab-comments" onclick="switchTab('comments', this)">💬 Комменты в ТОП</button>
    <button class="tab-btn" id="btn-tab-warmup" onclick="switchTab('warmup', this)">🔥 Прогрев & Буст</button>
    <button class="tab-btn" id="btn-tab-branding" onclick="switchTab('branding', this)">🎨 Оформитель</button>
    <button class="tab-btn" id="btn-tab-autopilot" onclick="switchTab('autopilot', this)">⏰ Авто-Пилот</button>
    <button class="tab-btn" id="btn-tab-sessions" onclick="switchTab('sessions', this)">🔑 Сессии</button>
    <button class="tab-btn" id="btn-tab-photo" onclick="switchTab('photo', this)">📸 1 Пост</button>
    <button class="tab-btn" id="btn-tab-signup" onclick="switchTab('signup', this)">📱 SMS Рег</button>
    <button class="tab-btn" id="btn-tab-auth" onclick="switchTab('auth', this)">📥 Вход</button>
    <button class="tab-btn" id="btn-tab-settings" onclick="switchTab('settings', this)">⚙️ Настройки & Прокси</button>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 1: MASS CAMPAIGN STUDIO                                           -->
  <!-- ===================================================================== -->
  <div id="tab-campaign" class="tab-pane active">
    <div class="card" style="padding:11px 16px;">
      <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center; justify-content:space-between;">
        <div style="display:flex; align-items:center; gap:8px; flex:1; min-width:260px;">
          <strong style="white-space:nowrap;">🎛 Профиль конфига:</strong>
          <select id="c_preset_select" style="max-width:430px;" onchange="applySelectedPreset()"></select>
          <button class="btn btn-sec btn-sm" onclick="applySelectedPreset()">📂 Применить</button>
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
          <button class="btn btn-ok btn-sm" onclick="promptSaveCurrentPreset()">💾 Сохранить пресет</button>
          <button class="btn btn-sec btn-sm" onclick="exportCurrentPresetJson()">⬇ JSON</button>
          <button class="btn btn-danger btn-sm" onclick="deleteSelectedPreset()">🗑 Удалить</button>
        </div>
      </div>
    </div>

    <div class="grid-camp">
      <div>
        <div class="card">
          <h2>1. Режим работы и Потоки</h2>
          <div class="mode-cards" id="c_mode_cards">
            <div class="mode-card active" data-mode="upload" onclick="setCampaignMode('upload')">
              <strong>📸 Залив / Перезалив</strong>
              <span>Фото-карусели или Видео MP4 + очистка</span>
            </div>
            <div class="mode-card" data-mode="auto_appeal" onclick="setCampaignMode('auto_appeal')">
              <strong>🛡️ Снять ограны</strong>
              <span>Auto-Appeal до 0 огранов (без залива)</span>
            </div>
            <div class="mode-card" data-mode="clean_only" onclick="setCampaignMode('clean_only')">
              <strong>🗑 Только очистка</strong>
              <span>Удалить все старые видео без залива</span>
            </div>
            <div class="mode-card" data-mode="restart_check" onclick="setCampaignMode('restart_check')">
              <strong>🔄 Рестарт и чек</strong>
              <span>Перезапуск TikTok + проверка сессий</span>
            </div>
            <div class="mode-card" data-mode="set_bio" onclick="setCampaignMode('set_bio')">
              <strong>✏️ Смена БИО</strong>
              <span>Быстрая смена описания на сессиях</span>
            </div>
          </div>

          <div class="form-row">
            <div><label>⚡ Одновременных потоков (1–20)</label><input type="number" id="c_threads" value="3" min="1" max="20" /></div>
            <div><label>🛡 Попыток авто-дозалива при сбое прокси (1–6)</label><input type="number" id="c_retries" value="4" min="1" max="6" /></div>
          </div>

          <div class="field" id="c_bio_only_wrap" style="display:none;">
            <label>Новый текст БИО (спинтакс <code class="inline">{Вариант 1|Вариант 2}</code>)</label>
            <input type="text" id="c_bio_text" placeholder="Введите текст БИО..." />
          </div>

          <div class="section-box">
            <div class="section-title">
              <span>2. Выбор аккаунтов: <span class="pill ok" id="c_sel_count_pill">0 выбрано</span></span>
              <div style="display:flex; gap:5px; flex-wrap:wrap;">
                <button type="button" class="btn btn-sec btn-sm" onclick="selectCampaignSessions('all')">Все</button>
                <button type="button" class="btn btn-sec btn-sm" onclick="selectCampaignSessions('with_posts')">С постами</button>
                <button type="button" class="btn btn-sec btn-sm" onclick="selectCampaignSessions('empty')">Пустые (0)</button>
                <button type="button" class="btn btn-sec btn-sm" onclick="selectCampaignSessions('invert')">Инверт.</button>
                <button type="button" class="btn btn-sec btn-sm" onclick="selectCampaignSessions('none')">Снять</button>
              </div>
            </div>
            <div class="form-row" style="margin-bottom:8px;">
              <div><input type="text" id="c_sess_filter" placeholder="🔍 Фильтр по @username, email или региону..." oninput="renderCampaignSessionList()" /></div>
              <div><input type="text" id="c_exclude_list" value="user6961737737217" placeholder="⛔ Исключить (напр. user6961737737217)" oninput="renderCampaignSessionList()" /></div>
            </div>
            <div class="session-picker-list" id="c_session_list"></div>
          </div>

          <div class="section-box">
            <div class="section-title">
              <span>3. ГЕО, Прокси и Предпрогрев</span>
              <select id="c_geo_mode" style="width:auto; padding:4px 9px; font-size:12px;" onchange="toggleCampaignGeoMode()">
                <option value="override">Переключить все под выбранное ГЕО</option>
                <option value="session">Оставить родное ГЕО каждой сессии</option>
              </select>
            </div>

            <div id="c_geo_override_box">
              <div class="country-chips" id="c_geo_chips">
                <button type="button" class="country-chip active" data-iso="US" data-loc="en_US" onclick="pickCampaignGeo('US','en_US')">🇺🇸 США (US)</button>
                <button type="button" class="country-chip" data-iso="IT" data-loc="it_IT" onclick="pickCampaignGeo('IT','it_IT')">🇮🇹 Италия (IT)</button>
                <button type="button" class="country-chip" data-iso="DE" data-loc="de_DE" onclick="pickCampaignGeo('DE','de_DE')">🇩🇪 Германия (DE)</button>
                <button type="button" class="country-chip" data-iso="GB" data-loc="en_GB" onclick="pickCampaignGeo('GB','en_GB')">🇬🇧 Британия (GB)</button>
                <button type="button" class="country-chip" data-iso="FR" data-loc="fr_FR" onclick="pickCampaignGeo('FR','fr_FR')">🇫🇷 Франция (FR)</button>
                <button type="button" class="country-chip" data-iso="ES" data-loc="es_ES" onclick="pickCampaignGeo('ES','es_ES')">🇪🇸 Испания (ES)</button>
                <button type="button" class="country-chip" data-iso="CL" data-loc="es_CL" onclick="pickCampaignGeo('CL','es_CL')">🇨🇱 Чили (CL)</button>
                <button type="button" class="country-chip" data-iso="BR" data-loc="pt_BR" onclick="pickCampaignGeo('BR','pt_BR')">🇧🇷 Бразилия (BR)</button>
                <button type="button" class="country-chip" data-iso="MX" data-loc="es_MX" onclick="pickCampaignGeo('MX','es_MX')">🇲🇽 Мексика (MX)</button>
                <button type="button" class="country-chip" data-iso="PL" data-loc="pl_PL" onclick="pickCampaignGeo('PL','pl_PL')">🇵🇱 Польша (PL)</button>
                <button type="button" class="country-chip" data-iso="KZ" data-loc="ru_KZ" onclick="pickCampaignGeo('KZ','ru_KZ')">🇰🇿 Казахстан (KZ)</button>
              </div>
              <div class="form-row-3">
                <div><label>Гео публикации</label><input type="text" id="c_region" value="US" /></div>
                <div><label>Гео телефона / SIM</label><input type="text" id="c_phone_region" value="US" /></div>
                <div><label>Локаль</label><input type="text" id="c_locale" value="en_US" /></div>
              </div>
            </div>

            <label class="switch-row" for="c_auto_sticky">
              <div><strong>🌐 Авто-подбор чистого sticky-прокси под выбранное ГЕО</strong><small>Новая сессия <code class="inline">_country-XX_session-...</code> на SOCKS5</small></div>
              <span class="toggle-switch"><input type="checkbox" id="c_auto_sticky" checked /><span class="toggle-slider"></span></span>
            </label>
            <label class="switch-row" for="c_verify_proxy">
              <div><strong>⚡ Проверять IP и пинг прокси перед стартом аккаунта</strong></div>
              <span class="toggle-switch"><input type="checkbox" id="c_verify_proxy" checked /><span class="toggle-slider"></span></span>
            </label>

            <div style="display:grid; grid-template-columns:1fr auto; gap:10px; align-items:center; margin:6px 0;">
              <label class="switch-row" for="c_warmup_before" style="margin:0;">
                <div><strong>🔥 Мини-прогрев ленты FYP целевого ГЕО перед 1-м постом</strong></div>
                <span class="toggle-switch"><input type="checkbox" id="c_warmup_before" /><span class="toggle-slider"></span></span>
              </label>
              <div style="width:100px;"><label>Роликов</label><input type="number" id="c_warmup_count" value="3" min="1" max="10" /></div>
            </div>

            <div class="field" style="margin-top:6px; margin-bottom:0;">
              <label>Свой список прокси (пусто = базовый прокси)</label>
              <textarea id="c_proxies" rows="2" placeholder="Оставьте пустым для авто-использования базового прокси"></textarea>
            </div>
          </div>

          <div id="c_upload_only_sections">
            <div class="section-box">
              <div class="section-title">
                <span>4. Формат креатива, Очистка, Спинтакс и Музыка</span>
                <div style="display:flex; gap:6px; align-items:center;">
                  <select id="c_content_type" style="width:auto; padding:4px 9px; font-size:12px;" onchange="toggleCampaignContentType()">
                    <option value="photo">📸 Фото-карусель (1–10 фото)</option>
                    <option value="video">🎬 Видео MP4 (до 50 МБ)</option>
                  </select>
                  <button type="button" class="btn btn-sec btn-sm" onclick="clearCampaignMedia()">Очистить</button>
                </div>
              </div>

              <div id="c_photo_upload_zone">
                <div class="dropzone" onclick="document.getElementById('c_files').click()">
                  <input type="file" id="c_files" accept="image/jpeg,image/png" multiple style="display:none;" onchange="handleCampaignFiles(this.files)" />
                  <div style="font-weight:600;">➕ Загрузить новые фото (1–10 слайдов) или выбрать ниже из <code class="inline">media/</code></div>
                </div>
                <div class="thumbs" id="c_upload_thumbs"></div>
              </div>

              <div id="c_video_upload_zone" style="display:none;">
                <input type="file" id="c_video_file" accept="video/mp4" onchange="handleCampaignVideoFile(this.files)" />
                <div class="hint" id="c_video_info">Или кликните по <code class="inline">.mp4</code> файлу в библиотеке ниже</div>
              </div>

              <div style="margin-top:8px;">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                  <label style="margin:0;">📂 Библиотека креативов на сервере (<code class="inline">media/</code>):</label>
                  <button type="button" class="btn btn-sec btn-sm" onclick="loadMediaLibrary()">🔄 Обновить</button>
                </div>
                <div class="media-lib-grid" id="c_media_lib"></div>
              </div>

              <label class="switch-row" for="c_del_old" style="margin-top:9px;">
                <div><strong>🗑 Проверять и удалять старые видео перед заливом</strong></div>
                <span class="toggle-switch"><input type="checkbox" id="c_del_old" checked /><span class="toggle-slider"></span></span>
              </label>

              <div class="form-row-3" style="margin-top:8px;">
                <div><label>Постов на аккаунт</label><input type="number" id="c_copies" value="6" min="1" max="30" /></div>
                <div><label>⏱ Пауза (сек)</label><input type="text" id="c_delay" value="14-20" placeholder="14-20 или 30" /></div>
                <div><label>🔄 Рестарт каждые N</label><input type="number" id="c_restart_n" value="3" min="0" max="20" /></div>
              </div>

              <div class="field">
                <label>Описание и хэштеги (спинтакс <code class="inline">{Check this|Look here}</code> + <code class="inline">{RAND4}</code>)</label>
                <textarea id="c_desc" rows="2">#piratetoken #piratetokenshop #blackknight #pirateshop #fyp</textarea>
              </div>

              <label class="switch-row" for="c_rand_tags">
                <div><strong>🎲 Рандомизировать порядок хэштегов на каждый пост</strong></div>
                <span class="toggle-switch"><input type="checkbox" id="c_rand_tags" checked /><span class="toggle-slider"></span></span>
              </label>

              <div class="form-row">
                <div>
                  <label>🎵 Музыка (поиск или тренды ГЕО)</label>
                  <div style="display:flex; gap:5px;">
                    <input type="text" id="c_music_query" value="Fortnite" placeholder="Fortnite, recommended..." />
                    <button type="button" class="btn btn-sec btn-sm" onclick="openMusicSearchModal('c_music_id', 'c_music_query')" style="white-space:nowrap;">🔍 Найти / Тренды</button>
                  </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                  <div><label>Точный Music ID</label><input type="text" id="c_music_id" placeholder="Пусто = авто-пул" /></div>
                  <div><label>Видимость</label><select id="c_private"><option value="0">Публичный</option><option value="1">Приватный</option></select></div>
                </div>
              </div>

              <div class="checks">
                <label class="check-item"><input type="checkbox" id="c_story" /> Как Story</label>
                <label class="check-item"><input type="checkbox" id="c_nocomments" /> Отключить комментарии</label>
              </div>
            </div>

            <div class="section-box">
              <div class="section-title">
                <span>5. ❄️ Профессиональный Уникализатор</span>
                <button type="button" class="btn btn-sec btn-sm" onclick="previewUniquifier()">👁 Предпросмотр До / После</button>
              </div>

              <label class="switch-row" for="c_uniq_on">
                <div><strong>Уникализировать каждый пост отдельно</strong><small>Для фото — кроп/снег/шум матрицы/виньетка; для MP4 — метаданные + контейнерный хэш</small></div>
                <span class="toggle-switch"><input type="checkbox" id="c_uniq_on" checked onchange="syncUniqControlsVisibility()" /><span class="toggle-slider"></span></span>
              </label>

              <div id="c_uniq_details">
                <div class="field">
                  <label>Пресет уникализации фото</label>
                  <select id="c_uniq_mode" onchange="onUniqPresetChange()">
                    <option value="ultra_hard">🔥 МАКСИМАЛЬНО ЖЁСТКИЙ (Anti-Duplicate: 3D-перспектива + плавающая карточка + смена фона/Hue)</option>
                    <option value="minimal_snow" selected>❄️ Минимальный + Больше снега (микро-кроп 0.8–1.5%, снег 115–175 шт.)</option>
                    <option value="minimal">✨ Минимальный (микро-кроп 0.8–1.5%, лёгкий снег 45–85 шт.)</option>
                    <option value="medium">⚖️ Средний (кроп 1.6–2.8%, снег 140–240 шт. + ветер)</option>
                    <option value="boosted">❄️ Усиленный (кроп 2.6–4.3%, 3-слойный снег 330–510 шт. + боке)</option>
                    <option value="stealth">🕵️ Стелс БЕЗ снега (микро-кроп + шум матрицы)</option>
                    <option value="custom">🛠 Свой кастомный (ручная настройка)</option>
                  </select>
                </div>

                <div class="form-row-4">
                  <div><label>3D Перспектива (%)</label><input type="number" id="u_persp" value="2.4" step="0.2" oninput="markUniqCustom()" /></div>
                  <div><label>Плавающий фон (%)</label><input type="number" id="u_ambient" value="11.5" step="0.5" oninput="markUniqCustom()" /></div>
                  <div><label>Сдвиг Hue (°)</label><input type="number" id="u_hue" value="22" step="1" oninput="markUniqCustom()" /></div>
                  <div><label>Световой блик (%)</label><input type="number" id="u_leak" value="16.5" step="0.5" oninput="markUniqCustom()" /></div>
                </div>

                <div class="form-row-4">
                  <div><label>Кроп X мин (%)</label><input type="number" id="u_cx_min" value="0.2" step="0.1" oninput="markUniqCustom()" /></div>
                  <div><label>Кроп X макс (%)</label><input type="number" id="u_cx_max" value="0.8" step="0.1" oninput="markUniqCustom()" /></div>
                  <div><label>Кроп Y мин (%)</label><input type="number" id="u_cy_min" value="0.5" step="0.1" oninput="markUniqCustom()" /></div>
                  <div><label>Кроп Y макс (%)</label><input type="number" id="u_cy_max" value="1.6" step="0.1" oninput="markUniqCustom()" /></div>
                </div>

                <div class="form-row-4">
                  <div><label>Снежинок мин</label><input type="number" id="u_snow_min" value="240" step="10" oninput="markUniqCustom()" /></div>
                  <div><label>Снежинок макс</label><input type="number" id="u_snow_max" value="440" step="10" oninput="markUniqCustom()" /></div>
                  <div><label>Наклон макс (°)</label><input type="number" id="u_tilt" value="2.60" step="0.1" oninput="markUniqCustom()" /></div>
                  <div><label>Сдвиг тона (%)</label><input type="number" id="u_tone" value="5.2" step="0.2" oninput="markUniqCustom()" /></div>
                </div>

                <div class="form-row-4">
                  <div><label>Шум матрицы</label><input type="number" id="u_noise" value="3.6" step="0.2" oninput="markUniqCustom()" /></div>
                  <div><label>Виньетка (%)</label><input type="number" id="u_vignette" value="8.0" step="0.5" oninput="markUniqCustom()" /></div>
                  <div><label>Рамка (px)</label><input type="number" id="u_border" value="3" oninput="markUniqCustom()" /></div>
                  <div><label>JPEG мин/макс</label>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:4px;">
                      <input type="number" id="u_q_min" value="83" oninput="markUniqCustom()" />
                      <input type="number" id="u_q_max" value="92" oninput="markUniqCustom()" />
                    </div>
                  </div>
                </div>

                <div class="checks">
                  <label class="check-item"><input type="checkbox" id="u_bokeh" checked onchange="markUniqCustom()" /> Крупное боке снега</label>
                  <label class="check-item"><input type="checkbox" id="u_wind" checked onchange="markUniqCustom()" /> След ветра</label>
                  <label class="check-item"><input type="checkbox" id="u_flip" onchange="markUniqCustom()" /> Зеркально по горизонтали</label>
                </div>
              </div>
            </div>

            <div class="section-box" id="c_appeal_section_box" style="border-color:rgba(249,115,22,0.45);">
              <div class="section-title">
                <span>6. ⚡ Авто-Снятие <code class="inline">Account ineligible for recommendation</code> (2048)</span>
                <span class="pill ok" style="font-size:11px;">1 IDC запрос • Мгновенно</span>
              </div>

              <label class="switch-row" for="c_appeal_on">
                <div>
                  <strong>🛡️ Снимать <code class="inline">Account ineligible for recommendation</code> при заливе + раскладывать по папкам</strong>
                  <small>Не тратит время на отдельные посты — бьёт прицельно только в бан реков аккаунта (<code class="inline">2048</code>) за 1 секунду и сортирует в <code class="inline">clean / ogran_na_proverke / ogran_ne_snyat</code></small>
                </div>
                <span class="toggle-switch"><input type="checkbox" id="c_appeal_on" checked onchange="syncAppealCampaignControls()" /><span class="toggle-slider"></span></span>
              </label>

              <div id="c_appeal_details">
                <div class="checks" style="margin-top:6px; margin-bottom:8px;">
                  <label class="check-item"><input type="checkbox" id="c_only_2048" checked /> 🎯 ТОЛЬКО <code class="inline">Account ineligible for recommendation</code></label>
                  <label class="check-item"><input type="checkbox" id="c_appeal_pre" checked /> 1) Чек/снятие 2048 ДО залива</label>
                  <label class="check-item"><input type="checkbox" id="c_appeal_during" checked /> 2) Снимать 2048 МЕЖДУ постами (защита 5–6 поста от 0 просм.!)</label>
                  <label class="check-item"><input type="checkbox" id="c_appeal_post" checked /> 3) Ловля 2048 ПОСЛЕ залива + папка</label>
                  <input type="checkbox" id="c_appeal_hide_rej" style="display:none;" />
                </div>

                <div class="form-row-4">
                  <div>
                    <label>⏱ Пауза перед финал-чеком (сек)</label>
                    <input type="number" id="c_appeal_wait" value="8" min="0" max="180" />
                  </div>
                  <div>
                    <label>🛡️ Тишина без новых огранов (сек)</label>
                    <input type="number" id="c_appeal_quiet" value="60" min="0" max="300" title="Если в течение 60 сек не прилетает ни одного нового ограничения — залив считается чистым. Каждое снятое ограничение сбрасывает таймер!" />
                  </div>
                  <div>
                    <label>🔁 Макс. проходов дожима</label>
                    <input type="number" id="c_appeal_passes" value="6" min="1" max="20" />
                  </div>
                  <div>
                    <label>Текст апелляции (спинтакс)</label>
                    <input type="text" id="c_appeal_text" value="{Our content is original, authentic, and strictly follows all TikTok Community Guidelines.|Original content created and edited exclusively by our team.}" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <button class="btn" id="c_start_btn" onclick="startCampaign()" style="padding:11px 22px; font-size:14px;">🚀 Запустить сейчас</button>
            <button class="btn btn-sec" onclick="scheduleCurrentCampaignFromMain()" style="padding:11px 15px;">⏰ Запланировать</button>
            <button class="btn btn-danger" id="c_stop_btn" onclick="stopCampaign()" disabled style="padding:11px 18px;">⏹ Остановить</button>
          </div>
        </div>
      </div>

      <!-- RIGHT: LIVE MONITOR -->
      <div>
        <div class="card">
          <h2><span>Монитор выполнения</span><span class="pill" id="c_status_pill">Ожидание</span></h2>
          <div style="display:flex; gap:7px; flex-wrap:wrap; margin-bottom:6px;">
            <span class="pill" id="c_stat_acc">Аккаунты: 0 / 0</span>
            <span class="pill ok" id="c_stat_posts">Постов: 0</span>
            <span class="pill warn" id="c_stat_del">Удалено: 0</span>
            <span class="pill ok" id="c_stat_appeals">🛡️ Снято огранов: 0</span>
            <span class="pill err" id="c_stat_err">Ошибок: 0</span>
          </div>
          <div class="progress-wrap"><div class="progress-bar" id="c_progress"></div></div>

          <div style="max-height:260px; overflow-y:auto; border:1px solid var(--border); border-radius:8px; margin-bottom:11px;">
            <table>
              <thead><tr><th>Аккаунт</th><th>Статус</th><th>Посты / Очистка / Апелл.</th><th>Ссылка</th></tr></thead>
              <tbody id="c_rows_tbody"><tr><td colspan="4" style="color:var(--muted);">Готов к запуску.</td></tr></tbody>
            </table>
          </div>

          <div class="field">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
              <label style="margin:0;">Ссылки опубликованных постов (<span id="c_urls_count">0</span>)</label>
              <div style="display:flex; gap:6px;">
                <button class="btn btn-sec btn-sm" onclick="copyCampaignUrls()">📋 Копировать</button>
                <a class="btn btn-sec btn-sm" href="/api/campaign/report" target="_blank" style="text-decoration:none;">⬇ JSON</a>
              </div>
            </div>
            <textarea id="c_urls_box" rows="4" readonly></textarea>
          </div>

          <h2><span>Живой лог</span><button class="btn btn-sec btn-sm" onclick="clearLogs()">Очистить</button></h2>
          <div class="log-box" id="logBoxCampaign"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 1B: STANDALONE AUTO APPEAL & 4-FOLDER RESTRICTION SORTER          -->
  <!-- ===================================================================== -->
  <div id="tab-appeal" class="tab-pane">
    <div class="kpi-grid">
      <div class="kpi-card"><div class="kpi-label">🔍 Проверено акк.</div><div class="kpi-val" id="ap_kpi_done">0 / 0</div></div>
      <div class="kpi-card"><div class="kpi-label">✅ Чистые / Снят огран</div><div class="kpi-val" style="color:#4ade80;" id="ap_kpi_clean">0</div></div>
      <div class="kpi-card"><div class="kpi-label">⏳ Огран / На проверке</div><div class="kpi-val" style="color:#38bdf8;" id="ap_kpi_appealed">0</div></div>
      <div class="kpi-card"><div class="kpi-label">🚨 Огран / Не снят</div><div class="kpi-val" style="color:#f87171;" id="ap_kpi_restricted">0</div></div>
      <div class="kpi-card"><div class="kpi-label">🛡️ Отправлено апелляций</div><div class="kpi-val" style="color:#fb923c;" id="ap_kpi_sent">0</div></div>
      <div class="kpi-card"><div class="kpi-label">🔒 Скрыто FAILED в Private</div><div class="kpi-val" style="color:#fbbf24;" id="ap_kpi_hidden">0</div></div>
    </div>

    <!-- 4 SORTED FOLDERS BAR -->
    <div class="card" style="margin-bottom:14px; border-color:rgba(56,189,248,0.35);">
      <h2 style="margin-bottom:8px;">
        <span>📁 Авто-Сортировка по Папкам (<code class="inline">sorted_accounts/</code>)</span>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <button type="button" class="btn btn-sm" onclick="recheckFolderAccounts('ogran_na_proverke', 'audit')" title="Быстро перепроверить все аккаунты из папки «На проверке» и переложить одобренные в «Без ограна»">🔄 Перепроверить «⏳ На проверке»</button>
          <button type="button" class="btn btn-sec btn-sm" onclick="recheckFolderAccounts('ogran_ne_snyat', 'unban')" title="Повторно пробить апелляции для папки «Огран / Не снят»">⚡ Дожать «🚨 Не снят»</button>
        </div>
      </h2>
      <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:10px;" id="ap_folders_grid">
        <div class="section-box" style="margin:0; border-color:rgba(74,222,128,0.4);">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <strong style="color:#4ade80;">✅ Без ограна / Снят</strong>
            <span class="pill ok" id="ap_fld_cnt_clean">0</span>
          </div>
          <div class="hint" style="margin:4px 0 8px;">sorted_accounts/clean/</div>
          <div style="display:flex; gap:6px; flex-wrap:wrap;">
            <a class="btn btn-sec btn-sm" href="/api/appeal/folder_export?folder=clean&fmt=txt" style="text-decoration:none;">⬇ TXT</a>
            <a class="btn btn-sec btn-sm" href="/api/appeal/folder_export?folder=clean&fmt=zip" style="text-decoration:none;">⬇ ZIP + сессии</a>
          </div>
        </div>

        <div class="section-box" style="margin:0; border-color:rgba(56,189,248,0.5); background:rgba(56,189,248,0.06);">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <strong style="color:#38bdf8;">⏳ Огран / На проверке</strong>
            <span class="pill warn" id="ap_fld_cnt_review">0</span>
          </div>
          <div class="hint" style="margin:4px 0 8px;">Снять сразу не вышло — висит на проверке TikTok (<code class="inline">ogran_na_proverke/</code>)</div>
          <div style="display:flex; gap:6px; flex-wrap:wrap;">
            <a class="btn btn-sec btn-sm" href="/api/appeal/folder_export?folder=ogran_na_proverke&fmt=txt" style="text-decoration:none;">⬇ TXT</a>
            <a class="btn btn-sec btn-sm" href="/api/appeal/folder_export?folder=ogran_na_proverke&fmt=zip" style="text-decoration:none;">⬇ ZIP + сессии</a>
          </div>
        </div>

        <div class="section-box" style="margin:0; border-color:rgba(248,113,113,0.45);">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <strong style="color:#f87171;">🚨 Огран / Не снят</strong>
            <span class="pill err" id="ap_fld_cnt_restricted">0</span>
          </div>
          <div class="hint" style="margin:4px 0 8px;">Активный огран или отказ апелляции (<code class="inline">ogran_ne_snyat/</code>)</div>
          <div style="display:flex; gap:6px; flex-wrap:wrap;">
            <a class="btn btn-sec btn-sm" href="/api/appeal/folder_export?folder=ogran_ne_snyat&fmt=txt" style="text-decoration:none;">⬇ TXT</a>
            <a class="btn btn-sec btn-sm" href="/api/appeal/folder_export?folder=ogran_ne_snyat&fmt=zip" style="text-decoration:none;">⬇ ZIP + сессии</a>
          </div>
        </div>

        <div class="section-box" style="margin:0; border-color:rgba(148,163,184,0.35);">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <strong style="color:#cbd5e1;">❌ Ошибки входа</strong>
            <span class="pill" id="ap_fld_cnt_errors">0</span>
          </div>
          <div class="hint" style="margin:4px 0 8px;">sorted_accounts/errors/</div>
          <div style="display:flex; gap:6px; flex-wrap:wrap;">
            <a class="btn btn-sec btn-sm" href="/api/appeal/folder_export?folder=errors&fmt=txt" style="text-decoration:none;">⬇ TXT</a>
            <a class="btn btn-sec btn-sm" href="/api/appeal/folder_export?folder=errors&fmt=zip" style="text-decoration:none;">⬇ ZIP</a>
          </div>
        </div>
      </div>
    </div>

    <div class="grid-camp">
      <div>
        <div class="card">
          <h2>
            <span>🛡️ Вход + Снятие Ограна / Проверка Ограна</span>
            <span class="pill" id="ap_status_pill">Ожидание</span>
          </h2>
          <div class="hint" style="margin-bottom:10px;">
            Заходит на аккаунты (или берёт готовые сессии), быстро проверяет и пробивает апелляции в <strong>тёплом пуле соединений (5x быстрее)</strong>. Если огран не снялся мгновенно и ушёл на модерацию — автоматически кладёт аккаунт в папку <strong>«⏳ Огран / На проверке»</strong>!
          </div>

          <div class="mode-cards" id="ap_mode_cards">
            <div class="mode-card active" data-apmode="unban" onclick="setAppealTabMode('unban')">
              <strong>⚡ Снятие ограна (Вход + Апелляция)</strong>
              <span>Входит, снимает все ограны и сортирует по 4 папкам</span>
            </div>
            <div class="mode-card" data-apmode="audit" onclick="setAppealTabMode('audit')">
              <strong>🔍 Проверка ограна (Вход + Чек)</strong>
              <span>Входит, проверяет статус без подачи и сортирует</span>
            </div>
            <div class="mode-card" data-apmode="watch" onclick="setAppealTabMode('watch')">
              <strong>🔁 Сторож «На проверке» 24/7</strong>
              <span>Перепроверяет каждые N мин и перекладывает в Чистые</span>
            </div>
          </div>

          <div class="section-box">
            <div class="field" style="margin-bottom:8px;">
              <label>📥 Вставить сырые аккаунты для входа + чека/снятия (по 1 на строку — если уже есть сессия, возьмёт её мгновенно):</label>
              <textarea id="ap_accounts_text" rows="3" placeholder="user:pass:mail@outlook.com:mailpass:rec@mail.com:recpass:2fa (или оставьте пустым, чтобы работать по выбранным ниже сессиям)"></textarea>
            </div>

            <div class="form-row-3" style="margin-bottom:8px;">
              <div>
                <label>🌍 ГЕО для входа новых акков</label>
                <input type="text" id="ap_login_region" value="US" placeholder="US / IT / DE / CL" />
              </div>
              <div style="display:flex; align-items:end;">
                <label class="check-item" style="margin-bottom:6px;"><input type="checkbox" id="ap_include_selected" checked /> + Выбранные сессии (<span id="ap_sel_lbl">0</span> шт.)</label>
              </div>
              <div style="display:flex; align-items:end;">
                <label class="check-item" style="margin-bottom:6px;"><input type="checkbox" id="ap_force_relogin" /> Принудительный перевход</label>
              </div>
            </div>

            <div class="section-title" style="margin-top:4px;">
              <span>Быстрый выбор готовых сессий из базы:</span>
              <div style="display:flex; gap:6px; flex-wrap:wrap;">
                <button type="button" class="btn btn-sec btn-sm" onclick="selectCampaignSessions('all'); document.getElementById('ap_include_selected').checked=true; showToast('Выбраны все рабочие сессии', 'ok');">Все сессии</button>
                <button type="button" class="btn btn-sec btn-sm" onclick="selectCampaignSessions('none'); showToast('Выбор сессий снят — будут обработаны только строки выше', 'info');">Сбросить выбор</button>
                <button type="button" class="btn btn-sec btn-sm" onclick="selectZeroViewSessionsForAppeal()">⚠️ С 0 просм.</button>
                <button type="button" class="btn btn-sec btn-sm" onclick="switchTab('campaign', document.getElementById('btn-tab-campaign'))">✏️ Точный выбор</button>
              </div>
            </div>

            <div class="form-row-4">
              <div><label>⚡ Потоков (1–12)</label><input type="number" id="ap_threads" value="4" min="1" max="12" /></div>
              <div><label>🔁 Циклов дожима</label><input type="number" id="ap_max_passes" value="4" min="1" max="20" /></div>
              <div><label>🛡️ Окно тишины (сек, 0=быстро)</label><input type="number" id="ap_quiet_sec" value="0" min="0" max="300" title="0 = мгновенное снятие и раскладка по папкам за ~5–8 сек/акк; 60 = ждать 60 сек без новых волн (после свежего залива)" /></div>
              <div id="ap_interval_wrap" style="display:none;"><label>⏰ Интервал сторожа (мин)</label><input type="number" id="ap_interval" value="15" min="2" max="360" /></div>
            </div>

            <label class="switch-row" for="ap_only_2048" style="border-color:rgba(74,222,128,0.45); background:rgba(74,222,128,0.06);">
              <div><strong>🎯 Снимать и проверять ТОЛЬКО <code class="inline">Account ineligible for recommendation</code> (2048)</strong><small>Игнорирует мелкие постовые плашки — чекает аккаунт за ~1 сек одним прямым IDC-запросом!</small></div>
              <span class="toggle-switch"><input type="checkbox" id="ap_only_2048" checked /><span class="toggle-slider"></span></span>
            </label>

            <label class="switch-row" for="ap_browser_fb">
              <div><strong>🌐 Браузерный фоллбэк <code class="inline">BytedanceWebview</code></strong><small>Авто-запуск Chromium только если чистый HTTP <code class="inline">commit_appeal</code> запросил подпись</small></div>
              <span class="toggle-switch"><input type="checkbox" id="ap_browser_fb" checked /><span class="toggle-slider"></span></span>
            </label>
            <input type="checkbox" id="ap_hide_rejected" style="display:none;" />
            <input type="checkbox" id="ap_stagger" checked style="display:none;" />

            <div class="field" style="margin-top:8px;">
              <label>Текст апелляции (поддерживает спинтакс <code class="inline">{Вариант 1|Вариант 2}</code>)</label>
              <textarea id="ap_text" rows="2">{Our content is original, authentic, and strictly follows all TikTok Community Guidelines.|Original content created and edited exclusively by our team in full compliance with TikTok rules.|All slides and edits in this post are original creative work made specifically for our TikTok audience.}</textarea>
            </div>

            <div class="field" style="margin-bottom:0;">
              <label>Прокси для входа / чека (пусто = авто-прокси из настроек или родной sticky-прокси сессии)</label>
              <textarea id="ap_proxies" rows="2" placeholder="Оставьте пустым для использования родного прокси сессии / дефолтного прокси"></textarea>
            </div>
          </div>

          <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <button class="btn" id="ap_start_btn" onclick="startStandaloneAppeal()" style="padding:11px 22px; font-size:14px;">🚀 Запустить Снятие / Чек + Сортировку</button>
            <button class="btn btn-danger" id="ap_stop_btn" onclick="stopStandaloneAppeal()" disabled style="padding:11px 18px;">⏹ Остановить</button>
            <a class="btn btn-sec" href="/api/appeal/report" target="_blank" style="text-decoration:none; padding:10px 14px;">⬇ JSON Отчёт</a>
          </div>
        </div>
      </div>

      <div>
        <div class="card">
          <h2>
            <span>Результаты и Папки аккаунтов</span>
            <div style="display:flex; gap:6px; align-items:center;">
              <span class="hint" id="ap_saved_lbl"></span>
              <select id="ap_filter" style="width:auto; padding:4px 8px; font-size:12px;" onchange="renderAppealTable()">
                <option value="all">Все папки</option>
                <option value="clean">📁 ✅ Без ограна / Снят</option>
                <option value="ogran_na_proverke">📁 ⏳ Огран / На проверке</option>
                <option value="ogran_ne_snyat">📁 🚨 Огран / Не снят</option>
                <option value="errors">📁 ❌ Ошибки входа</option>
              </select>
            </div>
          </h2>
          <div class="progress-wrap"><div class="progress-bar" id="ap_progress"></div></div>

          <div style="max-height:410px; overflow-y:auto; border:1px solid var(--border); border-radius:8px; margin-bottom:12px;">
            <table>
              <thead>
                <tr>
                  <th>Аккаунт / ГЕО</th>
                  <th>Папка / Вердикт</th>
                  <th>Системные уведомления и Посты</th>
                  <th>Действия</th>
                </tr>
              </thead>
              <tbody id="appeal_rows_tbody">
                <tr><td colspan="4" style="color:var(--muted);">Вставьте аккаунты или выберите сессии слева и нажмите «🚀 Запустить Снятие / Чек + Сортировку».</td></tr>
              </tbody>
            </table>
          </div>

          <h2><span>Живой лог Снятия / Чека</span><button class="btn btn-sec btn-sm" onclick="clearLogs()">Очистить</button></h2>
          <div class="log-box" id="logBoxAppeal"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 2: LIVE ANALYTICS v2 & SHADOWBAN CHECKER                          -->
  <!-- ===================================================================== -->
  <div id="tab-analytics" class="tab-pane">
    <div class="kpi-grid">
      <div class="kpi-card"><div class="kpi-label">👁 Просмотров (+Δ рост)</div><div class="kpi-val" id="an_kpi_views">0</div></div>
      <div class="kpi-card"><div class="kpi-label">❤️ Лайков</div><div class="kpi-val" id="an_kpi_likes">0</div></div>
      <div class="kpi-card"><div class="kpi-label">💬 Комментариев</div><div class="kpi-val" id="an_kpi_comments">0</div></div>
      <div class="kpi-card"><div class="kpi-label">🔖 Репостов + Избр.</div><div class="kpi-val" id="an_kpi_shares">0</div></div>
      <div class="kpi-card"><div class="kpi-label">🔥 Аккаунтов в реках</div><div class="kpi-val" style="color:#4ade80;" id="an_kpi_hot">0</div></div>
      <div class="kpi-card"><div class="kpi-label">⚠️ 0 просм. (Теневой бан)</div><div class="kpi-val" style="color:#fbbf24;" id="an_kpi_zero">0</div></div>
    </div>

    <div class="card">
      <h2>
        <span>📊 Живой чекер просмотров, прироста (+Δ) и теневого бана</span>
        <div style="display:flex; gap:7px; align-items:center; flex-wrap:wrap;">
          <span class="hint" id="an_updated_lbl">Не обновлялось</span>
          <input type="number" id="an_threads" value="4" min="1" max="15" style="width:68px;" title="Потоков" />
          <button class="btn" id="an_scan_btn" onclick="startAnalyticsScan('all')">🔄 Скан всех сессий</button>
          <button class="btn btn-ok" onclick="appealZeroViewAccounts()">🛡️ Снять ограны 0 просм.</button>
          <button class="btn btn-sec" onclick="reuploadZeroViewAccounts()">♻️ Перезалить 0 просм.</button>
          <a class="btn btn-sec btn-sm" href="/api/analytics/export.csv" target="_blank" style="text-decoration:none;">⬇ CSV (Excel)</a>
        </div>
      </h2>

      <div style="display:flex; gap:8px; margin-bottom:10px; flex-wrap:wrap;">
        <select id="an_filter" style="width:auto;" onchange="renderAnalyticsTable()">
          <option value="all">Все аккаунты</option>
          <option value="hot">🔥 Только с просмотрами (&gt;0)</option>
          <option value="zero">⚠️ Только нули (0 просм.)</option>
          <option value="empty">📭 Без постов</option>
        </select>
      </div>

      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr>
              <th>Аккаунт</th><th>Подписчики</th><th>Постов</th>
              <th>👁 Просмотры (+Δ)</th><th>❤️ Лайки</th><th>💬 / 🔁 / 🔖</th><th>Вердикт</th><th>Действия</th>
            </tr>
          </thead>
          <tbody id="an_tbody">
            <tr><td colspan="8" style="color:var(--muted);">Нажмите «🔄 Скан всех сессий», чтобы собрать живую статистику TikTok.</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 3: COMPETITOR SPY & CREATIVE CLONER                               -->
  <!-- ===================================================================== -->
  <div id="tab-spy" class="tab-pane">
    <div class="card">
      <h2>🕵️ Шпион Конкурентов, Анализатор Чужих Аккаунтов и Скачивание Связок без водяного знака</h2>
      <div class="form-row-3">
        <div style="grid-column: span 2;">
          <label>Введите @username конкурента или ссылку на любой профиль / пост TikTok</label>
          <input type="text" id="spy_query" placeholder="@username или https://www.tiktok.com/@.../photo/..." />
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr auto; gap:8px; align-items:end;">
          <div><label>ГЕО</label><input type="text" id="spy_region" value="US" /></div>
          <div><label>Постов</label><input type="number" id="spy_count" value="12" min="1" max="30" /></div>
          <button class="btn" id="spy_btn" onclick="runCompetitorSpy()">🔍 Разведка</button>
        </div>
      </div>

      <div id="spy_summary_box" style="display:none; margin-top:12px;">
        <div class="section-box" id="spy_profile_header"></div>
        <div class="spy-cards-grid" id="spy_posts_grid"></div>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 4: TOP-COMMENT MARKETING & COMMENT PARSER                         -->
  <!-- ===================================================================== -->
  <div id="tab-comments" class="tab-pane">
    <div class="grid-2">
      <div class="card">
        <h2>🏆 Вывод Комментария в ТОП #1 («Первонах / Пруф под ролик»)</h2>
        <div class="hint" style="margin-bottom:10px;">Публикует продающий коммент от выбранной сессии (или берёт существующий CID), а затем остальные выбранные сессии (<strong id="cm_sel_lbl">0</strong> шт.) ставят на него лайки <code class="inline">/v1/comment/like</code> и пишут ответы, закрепляя в ТОПе!</div>

        <div class="form-row">
          <div>
            <label>Целевой пост TikTok (ссылка или AWEME ID) *</label>
            <input type="text" id="cm_target_post" placeholder="https://www.tiktok.com/@user/photo/7712..." />
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
            <div><label>ГЕО</label><input type="text" id="cm_region" value="US" /></div>
            <div><label>Потоков</label><input type="number" id="cm_threads" value="4" min="1" max="15" /></div>
          </div>
        </div>

        <div class="section-box">
          <div class="section-title">Шаг 1. Главный комментарий (или существующий CID)</div>
          <div class="form-row">
            <div><label>Сессия-автор главного коммента</label><select id="cm_seed_session"></select></div>
            <div><label>Или готовый Comment ID (пусто = написать новый)</label><input type="text" id="cm_existing_cid" placeholder="Пусто = создать новый коммент" /></div>
          </div>
          <div class="field">
            <label>Текст главного комментария (поддерживает спинтакс и @упоминания)</label>
            <textarea id="cm_lead_text" rows="2" placeholder="{OMG it actually gave me Black Knight 😱|Just claimed mine on pirate shop 🔥}"></textarea>
          </div>
          <div class="field" style="margin-bottom:0;">
            <label>Прикрепить картинку-пруф в комментарий (JPEG/PNG, опц.)</label>
            <input type="file" id="cm_proof_img" accept="image/jpeg,image/png" onchange="handleCommentProofImg(this.files)" />
          </div>
        </div>

        <div class="section-box">
          <div class="section-title">Шаг 2. Ответы под главным комментом для буста ветки (опц.)</div>
          <div class="form-row">
            <div><label>Шанс ответа от сессии-бустера (%)</label><input type="number" id="cm_reply_prob" value="30" min="0" max="100" /></div>
            <div><label>Сессий-лайкеров выбрано</label><button class="btn btn-sec btn-sm" style="margin-top:2px;" onclick="selectCampaignSessions('all'); updateToolsCounts();">Выбрать все сессии</button></div>
          </div>
          <textarea id="cm_replies" rows="2" placeholder="{fr?? checking rn|worked for me too!|thanks bro 🔥}"></textarea>
        </div>

        <div style="display:flex; gap:10px;">
          <button class="btn" id="cm_start_btn" onclick="startTopCommentBoost()">🚀 Опубликовать и Вывести в ТОП</button>
          <button class="btn btn-danger" onclick="stopToolsJob()">⏹ Стоп</button>
        </div>
      </div>

      <div class="card">
        <h2>
          <span>💬 Живые комментарии под постом</span>
          <button class="btn btn-sec btn-sm" onclick="loadPostCommentsLive()">🔍 Загрузить комменты поста</button>
        </h2>
        <div style="max-height:250px; overflow-y:auto; border:1px solid var(--border); border-radius:8px; margin-bottom:10px;">
          <table>
            <thead><tr><th>Автор / Дата</th><th>Текст</th><th>❤️ / 💬</th><th>В ТОП</th></tr></thead>
            <tbody id="cm_live_tbody"><tr><td colspan="4" style="color:var(--muted);">Вставьте ссылку на пост слева и нажмите «Загрузить комменты».</td></tr></tbody>
          </table>
        </div>
        <h2>Лог коммент-маркетинга</h2>
        <div class="log-box" id="logBoxComments" style="height:200px;"></div>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 5: WARMUP FYP & MUTUAL ENGAGEMENT BOOST                           -->
  <!-- ===================================================================== -->
  <div id="tab-warmup" class="tab-pane">
    <div class="grid-2">
      <div class="card">
        <h2>🔥 Прогрев ГЕО-ленты (FYP) и Взаимный Буст сессиями</h2>
        <div class="form-row">
          <div>
            <label>Режим работы</label>
            <select id="w_mode" onchange="toggleWarmupMode()">
              <option value="warmup_fyp">🔥 Прогрев рекомендаций FYP под целевое ГЕО</option>
              <option value="boost_target">🚀 Взаимный Буст поста / аккаунта своими сессиями</option>
            </select>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
            <div><label>Потоков</label><input type="number" id="w_threads" value="4" min="1" max="15" /></div>
            <div><label>ГЕО (ISO2)</label><input type="text" id="w_region" value="US" /></div>
          </div>
        </div>

        <div id="w_fyp_box" class="section-box">
          <div class="section-title">Параметры прогрева ленты рекомендаций</div>
          <div class="form-row-3">
            <div><label>Смотреть роликов</label><input type="number" id="w_videos" value="5" min="1" max="15" /></div>
            <div><label>Шанс лайка (%)</label><input type="number" id="w_like_prob" value="35" min="0" max="100" /></div>
            <div><label>Шанс избранного (%)</label><input type="number" id="w_collect_prob" value="15" min="0" max="100" /></div>
          </div>
        </div>

        <div id="w_boost_box" class="section-box" style="display:none;">
          <div class="section-title">Цель для буста выбранными сессиями</div>
          <div class="form-row">
            <div><label>Ссылка на пост TikTok или AWEME ID</label><input type="text" id="w_target_post" /></div>
            <div><label>Целевой @username (для подписки)</label><input type="text" id="w_target_user" /></div>
          </div>
          <div class="checks">
            <label class="check-item"><input type="checkbox" id="w_do_view" checked /> 👁 Просмотр</label>
            <label class="check-item"><input type="checkbox" id="w_do_like" checked /> ❤️ Лайк</label>
            <label class="check-item"><input type="checkbox" id="w_do_collect" checked /> 🔖 Избранное</label>
            <label class="check-item"><input type="checkbox" id="w_do_repost" /> 🔁 Репост</label>
            <label class="check-item"><input type="checkbox" id="w_do_follow" /> ➕ Подписка</label>
          </div>
          <div class="field"><label>Комментарии под пост (спинтакс)</label><textarea id="w_comments" rows="2"></textarea></div>
        </div>

        <div class="field">
          <span>Выбрано сессий: <strong id="w_sel_lbl">0</strong> шт. (защищённые исключения соблюдаются)</span>
        </div>
        <div style="display:flex; gap:10px;">
          <button class="btn" id="w_start_btn" onclick="startWarmupOrBoost()">🚀 Запустить</button>
          <button class="btn btn-danger" id="w_stop_btn" onclick="stopToolsJob()" disabled>⏹ Остановить</button>
        </div>
      </div>

      <div class="card">
        <h2><span>Статус</span><span class="pill" id="t_job_pill">Ожидание</span></h2>
        <div class="progress-wrap"><div class="progress-bar" id="t_job_prog"></div></div>
        <textarea id="t_job_results" rows="5" readonly></textarea>
        <h2 style="margin-top:10px;">Лог</h2>
        <div class="log-box" id="logBoxWarmup" style="height:220px;"></div>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 6: BULK PROFILE BRANDING                                          -->
  <!-- ===================================================================== -->
  <div id="tab-branding" class="tab-pane">
    <div class="grid-2">
      <div class="card">
        <h2>🎨 Массовый Оформитель Профилей (<span id="br_sel_lbl">0</span> сессий)</h2>
        <div class="section-box">
          <div class="section-title">1. Аватарка профиля (<code class="inline">/v1/account/set_avatar</code>)</div>
          <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
            <input type="file" id="br_avatar_file" accept="image/jpeg,image/png" onchange="handleBrandAvatar(this.files)" style="max-width:250px;" />
            <label class="check-item"><input type="checkbox" id="br_uniq_avatar" checked /> ❄️ Авто-уникализация</label>
            <button class="btn btn-sec btn-sm" onclick="clearBrandAvatar()">Сбросить</button>
          </div>
          <div id="br_avatar_preview" style="margin-top:6px;"></div>
        </div>
        <div class="form-row">
          <div><label>Nickname (спинтакс <code class="inline">{Alex|Max} FN</code>)</label><input type="text" id="br_nickname" /></div>
          <div><label>Префикс @username (+ рандом цифры)</label><input type="text" id="br_uname_prefix" /></div>
        </div>
        <div class="form-row">
          <div><label>Текст БИО (спинтакс)</label><input type="text" id="br_bio" /></div>
          <div><label>Кликабельная ссылка БИО</label><input type="text" id="br_bio_url" /></div>
        </div>
        <div class="form-row">
          <div><label>Новый пароль (опц.)</label><input type="text" id="br_password" /></div>
          <div><label>Потоков</label><input type="number" id="br_threads" value="3" min="1" max="15" /></div>
        </div>
        <label class="switch-row" for="br_enable_totp"><div><strong>🔐 Включить TOTP 2FA на свежих сессиях</strong></div><span class="toggle-switch"><input type="checkbox" id="br_enable_totp" /><span class="toggle-slider"></span></span></label>
        <div style="display:flex; gap:10px;">
          <button class="btn" id="br_start_btn" onclick="startBrandingJob()">🎨 Применить оформление</button>
          <button class="btn btn-danger" onclick="stopToolsJob()">⏹ Стоп</button>
        </div>
      </div>
      <div class="card">
        <h2>Лог оформления</h2>
        <div class="log-box" id="logBoxBranding" style="height:370px;"></div>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 7: AUTO-PILOT SCHEDULER & ZERO-VIEW WATCHDOG                      -->
  <!-- ===================================================================== -->
  <div id="tab-autopilot" class="tab-pane">
    <div class="grid-2">
      <div class="card">
        <h2>⏰ Авто-Пилот, Планировщик Заливов и Сторож Нулей (Watchdog)</h2>
        <div class="field">
          <label>Тип автоматической задачи</label>
          <select id="ap_kind" onchange="toggleAutopilotFields()">
            <option value="zero_view_watchdog">♻️ Сторож Нулей: авто-скан и перезалив аккаунтов с 0 просм.</option>
            <option value="periodic_analytics">📊 Авто-Мониторинг: регулярный сбор просмотров всей фермы</option>
            <option value="delayed_campaign">🚀 Отложенный старт текущих настроек Массового Залива</option>
          </select>
        </div>
        <div class="field">
          <label>Название задачи</label>
          <input type="text" id="ap_name" value="Сторож Нулей (авто-перезалив)" />
        </div>
        <div class="form-row-3">
          <div><label>Старт через (мин)</label><input type="number" id="ap_delay" value="15" step="0.5" min="0.1" /></div>
          <div><label>Повтор каждые (мин, 0=1 раз)</label><input type="number" id="ap_repeat" value="30" step="1" min="0" /></div>
          <div id="ap_age_wrap"><label>Мин. возраст поста (мин)</label><input type="number" id="ap_min_age" value="25" min="0" /></div>
        </div>
        <div class="field">
          <label>⛔ Неприкасаемые аккаунты (никогда не трогать)</label>
          <input type="text" id="ap_exclude" value="user6961737737217" />
        </div>
        <button class="btn" onclick="createAutopilotTask()">➕ Добавить задачу в Авто-Пилот</button>
      </div>

      <div class="card">
        <h2>Активные и выполненные задачи Авто-Пилота</h2>
        <div style="overflow-x:auto;">
          <table>
            <thead><tr><th>Задача</th><th>След. запуск</th><th>Циклов</th><th>Статус / Итог</th><th></th></tr></thead>
            <tbody id="ap_tbody"><tr><td colspan="5" style="color:var(--muted);">Нет запланированных задач.</td></tr></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 8: SESSIONS MANAGER + LIVE 2FA TOTP                               -->
  <!-- ===================================================================== -->
  <div id="tab-sessions" class="tab-pane">
    <div class="card">
      <h2>
        <span>Менеджер сохранённых сессий (<code class="inline">sessions/*.json</code>)</span>
        <div style="display:flex; gap:7px; flex-wrap:wrap;">
          <button class="btn btn-sec btn-sm" onclick="openImportSessionsModal()">📥 Импорт x-device / JSON</button>
          <button class="btn btn-sec btn-sm" onclick="loadSessions()">🔄 Обновить</button>
          <a class="btn btn-sec btn-sm" href="/api/sessions/export/jsonl" target="_blank" style="text-decoration:none;">⬇ sessions.jsonl</a>
          <a class="btn btn-sm" href="/api/sessions/export/zip" target="_blank" style="text-decoration:none;">📦 Скачать ZIP</a>
        </div>
      </h2>

      <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center; justify-content:space-between; margin-bottom:12px; padding:10px 12px; background:var(--panel-2); border:1px solid var(--border); border-radius:9px;">
        <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
          <input type="text" id="sess_table_search" placeholder="🔍 Поиск по @username, email, региону..." style="width:235px;" oninput="renderSessionsTable()" />
          <select id="sess_table_filter" style="width:auto;" onchange="renderSessionsTable()">
            <option value="all">Все сессии</option>
            <option value="with_posts">С постами (&gt;0)</option>
            <option value="no_posts">Без постов (0)</option>
          </select>
          <span class="pill" id="sess_checked_pill">Отмечено: 0</span>
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
          <button class="btn btn-sm" onclick="sendCheckedToCampaign('upload')">🎯 В Массовый Залив</button>
          <button class="btn btn-sec btn-sm" onclick="sendCheckedToCampaign('clean_only')">🗑 Удалить видео</button>
          <button class="btn btn-sec btn-sm" onclick="scanCheckedAnalytics()">📊 Чек просмотров</button>
          <button class="btn btn-danger btn-sm" onclick="deleteCheckedSessionFiles()">❌ Удалить с диска</button>
        </div>
      </div>

      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr>
              <th style="width:32px;"><input type="checkbox" id="sess_check_all" onchange="toggleAllSessionTableChecks(this.checked)" /></th>
              <th>Профиль TikTok</th><th>Email / 2FA</th><th>БИО</th><th>Посты</th><th>Регион / Прокси</th><th>Действия</th>
            </tr>
          </thead>
          <tbody id="sessionsTableBody"></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 9: SINGLE POST (PHOTO + MP4)                                      -->
  <!-- ===================================================================== -->
  <div id="tab-photo" class="tab-pane">
    <div class="grid-2">
      <div class="card">
        <h2>Одиночный залив: Фото-карусель или Видео MP4</h2>
        <div class="form-row">
          <div><label>Выберите сессию *</label><select id="p_session"></select></div>
          <div>
            <label>Тип публикации</label>
            <select id="p_media_type" onchange="toggleSinglePostMediaType()">
              <option value="photo">📸 Фото-карусель (/v1/post/create/photo)</option>
              <option value="video">🎬 Видео MP4 (/v1/post/create/video)</option>
            </select>
          </div>
        </div>
        <div id="p_photo_box" class="field">
          <div class="dropzone" onclick="document.getElementById('p_files').click()">
            <input type="file" id="p_files" accept="image/jpeg,image/png" multiple style="display:none;" onchange="handlePhotoFiles(this.files)" />
            <div style="font-weight:600;">Выбрать 1–10 фото (JPEG / PNG)</div>
          </div>
          <div style="margin-top:7px; display:flex; gap:8px; flex-wrap:wrap;">
            <button class="btn btn-sec btn-sm" onclick="useLatestPirateSlides()">🏴‍☠️ IMG_7620 + IMG_7621</button>
            <button class="btn btn-sec btn-sm" onclick="clearSelectedPhotos()">Очистить</button>
          </div>
          <div class="thumbs" id="p_thumbs"></div>
        </div>
        <div id="p_video_box" class="field" style="display:none;">
          <label>Выберите MP4 видео (до 50 МБ)</label>
          <input type="file" id="p_video_file" accept="video/mp4" onchange="handleSingleVideoFile(this.files)" />
          <div class="hint" id="p_video_info"></div>
        </div>
        <div class="field"><label>Описание и хэштеги (спинтакс)</label><textarea id="p_desc" rows="2">#piratetoken #piratetokenshop #blackknight #pirateshop #fyp</textarea></div>
        <div class="form-row-3">
          <div><label>Гео залива</label><input type="text" id="p_region" value="US" /></div>
          <div><label>Гео SIM</label><input type="text" id="p_phone_region" value="US" /></div>
          <div><label>Локаль</label><input type="text" id="p_locale" value="en_US" /></div>
        </div>
        <div class="field"><label>Прокси (пусто = прокси сессии)</label><input type="text" id="p_proxy" /></div>
        <div class="form-row-3">
          <div><label>Копий</label><input type="number" id="p_copies" value="1" min="1" max="30" /></div>
          <div><label>Пауза, сек</label><input type="text" id="p_delay" value="10" /></div>
          <div><label>Рестарт каждые N</label><input type="number" id="p_restart_every" value="3" min="0" max="20" /></div>
        </div>
        <div class="form-row">
          <div><label>🎵 Музыка</label><div style="display:flex; gap:6px;"><input type="text" id="p_music_query" value="Fortnite" /><button type="button" class="btn btn-sec btn-sm" onclick="openMusicSearchModal('p_music', 'p_music_query')">🔍</button></div></div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
            <div><label>Music ID</label><input type="text" id="p_music" /></div>
            <div><label>Уник</label><select id="p_uniq_mode"><option value="minimal">Минимальный</option><option value="stealth">Стелс</option><option value="medium">Средний</option><option value="boosted">Усиленный</option><option value="off">Выкл</option></select></div>
          </div>
        </div>
        <label class="switch-row" for="p_rand_tags"><div><strong>🎲 Рандомизировать теги</strong></div><span class="toggle-switch"><input type="checkbox" id="p_rand_tags" checked /><span class="toggle-slider"></span></span></label>
        <label class="switch-row" for="p_del_old"><div><strong>🗑 Удалить старые ролики перед заливом</strong></div><span class="toggle-switch"><input type="checkbox" id="p_del_old" /><span class="toggle-slider"></span></span></label>
        <div class="checks"><label class="check-item"><input type="checkbox" id="p_story" /> Story</label><label class="check-item"><input type="checkbox" id="p_nocomments" /> Без комментариев</label></div>
        <button class="btn" id="p_submit_btn" onclick="submitSinglePost()">🚀 Опубликовать</button>
        <div class="result-box" id="p_result_box"><div style="font-weight:700; color:#4ade80;">✅ Опубликовано!</div><div id="p_result_links"></div></div>
      </div>
      <div class="card"><h2>Лог публикации</h2><div class="log-box" id="logBoxPhoto" style="height:430px;"></div></div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 10: SMS REGISTRATION                                              -->
  <!-- ===================================================================== -->
  <div id="tab-signup" class="tab-pane">
    <div class="grid-2">
      <div class="card">
        <h2><span>📱 Авто-регистрация по SMS (<code class="inline">Greedy SMS + TOTP</code>)</span><span class="pill ok" id="reg_balance_pill">Greedy SMS: —</span></h2>
        <div class="field">
          <label>API ключ Greedy SMS *</label>
          <div style="display:flex; gap:8px;">
            <input type="password" id="reg_greedy_key" />
            <button class="btn btn-sec btn-sm" onclick="const el=document.getElementById('reg_greedy_key'); el.type=el.type==='password'?'text':'password'">👁</button>
            <button class="btn btn-sec btn-sm" onclick="loadSignupCountries(true)">🔄 Баланс и цены</button>
          </div>
        </div>
        <div class="field">
          <label>🌎 Страна номера (195 стран)</label>
          <div class="country-chips" id="reg_quick_chips">
            <button type="button" class="country-chip active" data-cid="151" onclick="pickQuickCountry(151)">🇨🇱 Чили (+56)</button>
            <button type="button" class="country-chip" data-cid="187" onclick="pickQuickCountry(187)">🇺🇸 США (+1)</button>
            <button type="button" class="country-chip" data-cid="86" onclick="pickQuickCountry(86)">🇮🇹 Италия (+39)</button>
            <button type="button" class="country-chip" data-cid="43" onclick="pickQuickCountry(43)">🇩🇪 Германия (+49)</button>
            <button type="button" class="country-chip" data-cid="16" onclick="pickQuickCountry(16)">🇬🇧 Британия (+44)</button>
            <button type="button" class="country-chip" data-cid="2" onclick="pickQuickCountry(2)">🇰🇿 Казахстан (+7)</button>
          </div>
          <div style="display:grid; grid-template-columns:0.85fr 1.15fr; gap:8px;">
            <input type="text" id="reg_country_search" placeholder="🔍 Поиск страны..." oninput="filterSignupCountries()" />
            <select id="reg_country" onchange="syncCountryChipHighlight()"></select>
          </div>
        </div>
        <div class="form-row-3">
          <div><label>Аккаунтов</label><input type="number" id="reg_count" value="1" min="1" max="100" /></div>
          <div><label>Потоков</label><input type="number" id="reg_threads" value="1" min="1" max="15" /></div>
          <div><label>Макс. цена (₽)</label><input type="number" id="reg_max_price" value="3.5" step="0.1" /></div>
        </div>
        <div class="field"><label>Прокси *</label><textarea id="reg_proxies" rows="2"></textarea></div>
        <label class="switch-row" for="reg_enable_totp"><div><strong>🔐 Включать TOTP 2FA + @username в конце регистрации</strong></div><span class="toggle-switch"><input type="checkbox" id="reg_enable_totp" checked /><span class="toggle-slider"></span></span></label>
        <label class="switch-row" for="reg_match_proxy"><div><strong>🌍 Авто-подбор страны прокси под номер</strong></div><span class="toggle-switch"><input type="checkbox" id="reg_match_proxy" checked /><span class="toggle-slider"></span></span></label>
        <div class="form-row-3">
          <div><label>Пароль (пусто=авто)</label><input type="text" id="reg_password" /></div>
          <div><label>Префикс username</label><input type="text" id="reg_uname_prefix" /></div>
          <div><label>Таймаут SMS (сек)</label><input type="number" id="reg_sms_timeout" value="110" /></div>
        </div>
        <div style="display:flex; gap:10px;">
          <button class="btn" id="reg_start_btn" onclick="startSignupJob()">🚀 Запустить регистрацию</button>
          <button class="btn btn-danger" id="reg_stop_btn" onclick="stopSignupJob()" disabled>⏹ Остановить</button>
        </div>
      </div>
      <div class="card">
        <h2><span>Готовые аккаунты</span><span class="pill" id="reg_status_pill">Ожидание</span></h2>
        <div style="display:flex; gap:8px; margin-bottom:6px;">
          <span class="pill" id="reg_stat_done">0 / 0</span><span class="pill ok" id="reg_stat_ok">Создано: 0</span><span class="pill err" id="reg_stat_err">Ошибок: 0</span>
        </div>
        <div class="progress-wrap"><div class="progress-bar" id="reg_progress"></div></div>
        <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
          <label style="margin:0;"><code class="inline">username|password|phone|totp_secret</code></label>
          <div style="display:flex; gap:6px;"><button class="btn btn-sec btn-sm" onclick="copyRegisteredLines()">📋 Копировать</button><a class="btn btn-sec btn-sm" href="/api/signup/export/txt" target="_blank" style="text-decoration:none;">⬇ .txt</a></div>
        </div>
        <textarea id="reg_output_lines" rows="5" readonly></textarea>
        <div class="log-box" id="logBoxSignup" style="height:230px; margin-top:8px;"></div>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 11: UNIFIED LOGIN                                                 -->
  <!-- ===================================================================== -->
  <div id="tab-auth" class="tab-pane">
    <div class="grid-2">
      <div class="card">
        <h2>📥 Массовый многопоточный вход в аккаунты</h2>
        <div class="form-row">
          <div>
            <label>Формат и режим входа</label>
            <select id="b_mode">
              <option value="password_imap">Через почту (Outlook Hub 7/8-полей + IMAP авто-код)</option>
              <option value="username_totp">Логин+Пароль+TOTP (login|pass|email|totp)</option>
              <option value="otp_only">Через почту БЕЗ пароля TikTok</option>
              <option value="password_only">Почта:ПарольTikTok (без писем)</option>
            </select>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
            <div><label>Потоков</label><input type="number" id="b_threads" value="3" min="1" max="30" /></div>
            <div><label>Регион</label><input type="text" id="b_region" value="US" /></div>
          </div>
        </div>
        <div class="field"><label>Список аккаунтов</label><textarea id="b_accounts" rows="6"></textarea></div>
        <div class="field"><label>Список прокси</label><textarea id="b_proxies" rows="2"></textarea></div>
        <div class="field"><label>БИО после входа (опц.)</label><input type="text" id="b_bio" /></div>
        <label class="switch-row" for="b_del_old"><div><strong>🗑 Удалять старые ролики сразу после входа</strong></div><span class="toggle-switch"><input type="checkbox" id="b_del_old" /><span class="toggle-slider"></span></span></label>
        <div style="display:flex; gap:10px;">
          <button class="btn" id="b_start_btn" onclick="startBatch()">▶ Запустить вход</button>
          <button class="btn btn-danger" id="b_stop_btn" onclick="stopBatch()" disabled>⏹ Стоп</button>
        </div>
        <div style="display:flex; gap:8px; margin-top:10px;">
          <span class="pill" id="b_status_pill">Ожидание</span><span class="pill" id="b_stat_done">0 / 0</span><span class="pill ok" id="b_stat_ok">Успешно: 0</span><span class="pill err" id="b_stat_err">Ошибок: 0</span>
        </div>
        <div class="progress-wrap"><div class="progress-bar" id="b_progress"></div></div>
      </div>

      <div class="card">
        <h2>⚡ Ручной вход в 1 аккаунт</h2>
        <div class="form-row">
          <div><label>Способ входа</label><select id="s_flow" onchange="toggleSingleFlow()"><option value="username_totp">Username + Пароль + TOTP</option><option value="email">Почта (Outlook Hub / IMAP)</option></select></div>
          <div><label>Регион</label><input type="text" id="s_region" value="US" /></div>
        </div>
        <div class="field"><label>Полная строка (авто-парсинг, опц.)</label><input type="text" id="s_raw_line" /></div>
        <div class="form-row"><div id="s_username_wrap"><label>Username</label><input type="text" id="s_username" /></div><div><label>Email</label><input type="email" id="s_email" /></div></div>
        <div class="form-row"><div><label>Пароль TikTok</label><input type="text" id="s_tt_pass" /></div><div><label>TOTP Secret</label><input type="text" id="s_totp" /></div></div>
        <div class="field" id="s_imap_wrap" style="display:none;"><label>Пароль почты IMAP</label><input type="text" id="s_mail_pass" /></div>
        <div class="field"><label>Прокси *</label><input type="text" id="s_proxy" /></div>
        <label class="switch-row" for="s_del_old"><div><strong>🗑 Удалить старые ролики после входа</strong></div><span class="toggle-switch"><input type="checkbox" id="s_del_old" /><span class="toggle-slider"></span></span></label>
        <button class="btn" id="s_submit_btn" onclick="startSingleLogin()">Войти</button>
        <div class="result-box" id="s_result_box"><strong style="color:#4ade80;" id="s_res_title">✅</strong><textarea id="s_res_device" rows="2" readonly style="margin-top:6px;"></textarea></div>
        <h2 style="margin-top:12px;">Лог входа</h2>
        <div class="log-box" id="logBoxBatch" style="height:175px;"></div>
      </div>
    </div>
  </div>

  <!-- ===================================================================== -->
  <!-- TAB 12: SETTINGS & MULTI-PROXY CHECKER                                -->
  <!-- ===================================================================== -->
  <div id="tab-settings" class="tab-pane">
    <div class="grid-2">
      <div class="card">
        <h2>⚙️ Глобальный конфиг (<code class="inline">config.json</code>)</h2>
        <div class="field"><label>Kintaro API Key</label><input type="text" id="cfg_api_key" /></div>
        <div class="field"><label>Greedy SMS API Key</label><input type="text" id="cfg_greedy_key" /></div>
        <div class="field"><label>Базовый резидентский прокси</label><input type="text" id="cfg_default_proxy" /></div>
        <div class="form-row">
          <div><label>Дефолтное ГЕО</label><input type="text" id="cfg_default_region" value="US" /></div>
          <div><label>Дефолтное число потоков</label><input type="number" id="cfg_default_threads" value="3" min="1" max="20" /></div>
        </div>
        <button class="btn" onclick="saveGlobalSettings()">💾 Сохранить глобальный конфиг</button>

        <div class="section-box" style="margin-top:14px;">
          <div class="section-title">📥 Импорт профиля конфигурации залива (JSON)</div>
          <textarea id="cfg_import_preset_json" rows="4"></textarea>
          <button class="btn btn-sec btn-sm" style="margin-top:6px;" onclick="importPresetJson()">➕ Импортировать пресет</button>
        </div>
      </div>

      <div class="card">
        <h2>🌐 Мульти-Чекер Прокси (IP, Страна, Город, Провайдер, Пинг TikTok)</h2>
        <div class="field"><label>Список прокси (до 30 шт.)</label><textarea id="px_check_input" rows="4"></textarea></div>
        <button class="btn" id="px_check_btn" onclick="runProxyChecker()">⚡ Проверить прокси</button>
        <div style="overflow-x:auto; margin-top:10px;">
          <table>
            <thead><tr><th>Статус</th><th>IP / Гео</th><th>Провайдер</th><th>Пинг</th></tr></thead>
            <tbody id="px_check_tbody"><tr><td colspan="4" style="color:var(--muted);">Вставьте прокси и нажмите «Проверить».</td></tr></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modals -->
<div class="modal-backdrop" id="jsonModal" onclick="if(event.target===this)closeModal()">
  <div class="modal">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
      <strong id="modalTitle">Просмотр</strong>
      <button class="btn btn-sec btn-sm" onclick="closeModal()">Закрыть</button>
    </div>
    <div id="modalHtmlBody" style="overflow:auto; display:none;"></div>
    <pre id="modalContent"></pre>
  </div>
</div>

<div class="modal-backdrop" id="uniqPreviewModal" onclick="if(event.target===this)closeUniqModal()">
  <div class="modal">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; flex-wrap:wrap; gap:8px;">
      <strong>👁 Живой предпросмотр уникализации</strong>
      <div style="display:flex; gap:6px;">
        <button class="btn btn-sm" onclick="previewUniquifier()">🎲 Ещё вариант</button>
        <button class="btn btn-sec btn-sm" onclick="closeUniqModal()">Закрыть</button>
      </div>
    </div>
    <div id="uniqModalMeta" class="hint" style="margin-bottom:8px;"></div>
    <div class="preview-compare">
      <div class="preview-pane"><div style="font-weight:700; margin-bottom:6px; color:var(--muted);">Оригинал</div><img id="uniqOrigImg" /></div>
      <div class="preview-pane"><div style="font-weight:700; margin-bottom:6px; color:#4ade80;">После уникализатора</div><img id="uniqAfterImg" /></div>
    </div>
  </div>
</div>

<div class="modal-backdrop" id="musicModal" onclick="if(event.target===this)closeMusicModal()">
  <div class="modal" style="max-width:720px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
      <strong>🎵 Поиск треков и Живые Тренды ГЕО в TikTok</strong>
      <button class="btn btn-sec btn-sm" onclick="closeMusicModal()">Закрыть</button>
    </div>
    <div style="display:flex; gap:8px; margin-bottom:10px; flex-wrap:wrap;">
      <input type="text" id="ms_query_inp" value="Fortnite" placeholder="Название трека или исполнителя..." style="flex:1;" />
      <button class="btn" id="ms_search_btn" onclick="executeMusicSearch()">🔍 Поиск по слову</button>
      <button class="btn btn-ok" id="ms_trend_btn" onclick="executeTrendingMusic()">📈 Тренды FYP ГЕО</button>
    </div>
    <div style="overflow:auto; max-height:55vh;">
      <table>
        <thead><tr><th>Трек</th><th>Автор</th><th>Music ID</th><th>Выбор</th></tr></thead>
        <tbody id="ms_results_tbody"></tbody>
      </table>
    </div>
  </div>
</div>

<div class="modal-backdrop" id="importSessModal" onclick="if(event.target===this)document.getElementById('importSessModal').classList.remove('open')">
  <div class="modal" style="max-width:680px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
      <strong>📥 Массовый импорт сессий (JSON / JSONL / x-device)</strong>
      <button class="btn btn-sec btn-sm" onclick="document.getElementById('importSessModal').classList.remove('open')">Закрыть</button>
    </div>
    <textarea id="imp_sess_text" rows="8"></textarea>
    <button class="btn" style="margin-top:10px;" onclick="submitImportSessions()">📥 Импортировать в sessions/</button>
  </div>
</div>

<script>
const UNIQ_PRESETS = {
  ultra_hard: { crop_x_min_pct: 0.2, crop_x_max_pct: 0.8, crop_y_min_pct: 0.5, crop_y_max_pct: 1.6, max_tilt_deg: 2.60, perspective_pct: 2.4, ambient_frame_pct: 11.5, hue_shift_deg: 22.0, light_leak_pct: 16.5, snow_min_flakes: 240, snow_max_flakes: 440, enable_bokeh: true, enable_wind_trail: true, tone_jitter_pct: 5.2, noise_sigma: 3.6, vignette_pct: 8.0, border_px: 3, flip_horizontal: false, jpeg_quality_min: 83, jpeg_quality_max: 92 },
  boosted:    { crop_x_min_pct: 2.2, crop_x_max_pct: 3.8, crop_y_min_pct: 3.6, crop_y_max_pct: 6.4, max_tilt_deg: 0.85, perspective_pct: 1.6, ambient_frame_pct: 0.0, hue_shift_deg: 8.0, light_leak_pct: 9.0, snow_min_flakes: 330, snow_max_flakes: 510, enable_bokeh: true, enable_wind_trail: true, tone_jitter_pct: 2.8, noise_sigma: 2.2, vignette_pct: 4.5, border_px: 0, flip_horizontal: false, jpeg_quality_min: 88, jpeg_quality_max: 95 },
  medium:     { crop_x_min_pct: 1.6, crop_x_max_pct: 2.8, crop_y_min_pct: 2.4, crop_y_max_pct: 4.2, max_tilt_deg: 0.50, perspective_pct: 0.8, ambient_frame_pct: 0.0, hue_shift_deg: 3.5, light_leak_pct: 4.0, snow_min_flakes: 140, snow_max_flakes: 240, enable_bokeh: false, enable_wind_trail: true, tone_jitter_pct: 1.8, noise_sigma: 1.6, vignette_pct: 3.0, border_px: 0, flip_horizontal: false, jpeg_quality_min: 89, jpeg_quality_max: 95 },
  stealth:    { crop_x_min_pct: 0.9, crop_x_max_pct: 1.8, crop_y_min_pct: 1.3, crop_y_max_pct: 2.5, max_tilt_deg: 0.35, perspective_pct: 1.2, ambient_frame_pct: 0.0, hue_shift_deg: 5.0, light_leak_pct: 7.0, snow_min_flakes: 0, snow_max_flakes: 0, enable_bokeh: false, enable_wind_trail: false, tone_jitter_pct: 1.8, noise_sigma: 2.2, vignette_pct: 3.5, border_px: 0, flip_horizontal: false, jpeg_quality_min: 90, jpeg_quality_max: 96 },
  minimal_snow: { crop_x_min_pct: 0.8, crop_x_max_pct: 1.5, crop_y_min_pct: 1.2, crop_y_max_pct: 2.2, max_tilt_deg: 0.25, perspective_pct: 0.0, ambient_frame_pct: 0.0, hue_shift_deg: 0.0, light_leak_pct: 0.0, snow_min_flakes: 115, snow_max_flakes: 175, enable_bokeh: false, enable_wind_trail: false, tone_jitter_pct: 1.2, noise_sigma: 1.2, vignette_pct: 0, border_px: 0, flip_horizontal: false, jpeg_quality_min: 90, jpeg_quality_max: 95 },
  minimal:    { crop_x_min_pct: 0.8, crop_x_max_pct: 1.5, crop_y_min_pct: 1.2, crop_y_max_pct: 2.2, max_tilt_deg: 0.25, perspective_pct: 0.0, ambient_frame_pct: 0.0, hue_shift_deg: 0.0, light_leak_pct: 0.0, snow_min_flakes: 45, snow_max_flakes: 85, enable_bokeh: false, enable_wind_trail: false, tone_jitter_pct: 1.2, noise_sigma: 1.2, vignette_pct: 0, border_px: 0, flip_horizontal: false, jpeg_quality_min: 90, jpeg_quality_max: 95 }
};

let sessionsCache = [];
let presetsCache = [];
let mediaLibraryCache = [];
let analyticsCache = [];
let spyPostsCache = [];

let campaignMode = 'upload';
let campaignSelectedSessions = new Set();
let campaignInitializedSelection = false;
let campaignUploadedPhotos = [];
let campaignUploadedVideo = null;
let campaignSelectedServerMedia = ['IMG_7620.jpeg', 'IMG_7621.jpeg'];

let sessionTableChecked = new Set();
let selectedPhotosBase64 = [];
let singleServerSlides = [];
let singleVideoBase64 = null;
let brandAvatarDataUrl = '';
let commentProofImgDataUrl = '';
let musicTargetInputId = 'c_music_id';

function showToast(msg, kind = 'info') {
  const box = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = 'toast-item ' + (kind === 'ok' ? 'ok' : (kind === 'err' ? 'err' : ''));
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => { el.remove(); }, 3600);
}

function escapeHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    ...opts
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok && !data.status) throw new Error(data.error || ('HTTP ' + res.status));
  return data;
}

function switchTab(name, btn) {
  document.querySelectorAll('.tab-pane').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  if (btn) btn.classList.add('active');
  if (['sessions', 'photo', 'campaign', 'warmup', 'branding', 'comments'].includes(name)) loadSessions();
  if (name === 'campaign') loadMediaLibrary();
  if (name === 'signup') loadRegisteredAccounts();
  updateToolsCounts();
}

function toggleKeyVis() { const inp = document.getElementById('apiKeyInput'); inp.type = inp.type === 'password' ? 'text' : 'password'; }
async function saveApiKey() {
  const key = document.getElementById('apiKeyInput').value.trim();
  await api('/api/config', { method: 'POST', body: JSON.stringify({ api_key: key }) });
  document.getElementById('cfg_api_key').value = key;
  showToast('API ключ сохранён!', 'ok');
}

/* ---------------- PRESETS ---------------- */

async function loadPresets() {
  const data = await api('/api/presets');
  presetsCache = data.presets || [];
  const sel = document.getElementById('c_preset_select');
  const prev = sel.value;
  sel.innerHTML = presetsCache.map(p => `<option value="${escapeHtml(p.id)}">${escapeHtml(p.name)}</option>`).join('');
  if (prev && presetsCache.some(p => p.id === prev)) sel.value = prev;
}

function collectCurrentCampaignConfig() {
  const uMode = document.getElementById('c_uniq_mode').value;
  return {
    action_mode: campaignMode,
    content_type: document.getElementById('c_content_type').value,
    threads: parseInt(document.getElementById('c_threads').value || '3', 10),
    max_retries: parseInt(document.getElementById('c_retries').value || '4', 10),
    geo_mode: document.getElementById('c_geo_mode').value,
    region: document.getElementById('c_region').value.trim().toUpperCase(),
    phone_region: document.getElementById('c_phone_region').value.trim().toUpperCase(),
    app_locale: document.getElementById('c_locale').value.trim(),
    auto_sticky_proxy: document.getElementById('c_auto_sticky').checked,
    verify_proxy_geo: document.getElementById('c_verify_proxy').checked,
    warmup_before_upload: document.getElementById('c_warmup_before').checked,
    warmup_videos_count: parseInt(document.getElementById('c_warmup_count').value || '3', 10),
    proxies_text: document.getElementById('c_proxies').value,
    delete_old_posts: document.getElementById('c_del_old').checked,
    copies_count: parseInt(document.getElementById('c_copies').value || '6', 10),
    delay_range: document.getElementById('c_delay').value.trim() || '10',
    restart_every_n: parseInt(document.getElementById('c_restart_n').value || '0', 10),
    description: document.getElementById('c_desc').value,
    randomize_tags: document.getElementById('c_rand_tags').checked,
    auto_music_query: document.getElementById('c_music_query').value.trim(),
    music_id: document.getElementById('c_music_id').value.trim(),
    is_private: document.getElementById('c_private').value === '1',
    is_story: document.getElementById('c_story').checked,
    disable_comments: document.getElementById('c_nocomments').checked,
    bio_text: document.getElementById('c_bio_text').value,
    auto_appeal_on_upload: document.getElementById('c_appeal_on').checked,
    only_account_ineligible: document.getElementById('c_only_2048') ? document.getElementById('c_only_2048').checked : true,
    auto_appeal_pre_upload: document.getElementById('c_appeal_pre').checked,
    auto_appeal_during_upload: document.getElementById('c_appeal_during').checked,
    auto_appeal_post_upload: document.getElementById('c_appeal_post').checked,
    auto_appeal_hide_rejected: document.getElementById('c_appeal_hide_rej').checked,
    auto_appeal_post_wait_sec: parseInt(document.getElementById('c_appeal_wait').value || '12', 10),
    auto_appeal_quiet_window_sec: parseInt(document.getElementById('c_appeal_quiet').value || '75', 10),
    auto_appeal_max_passes: parseInt(document.getElementById('c_appeal_passes').value || '6', 10),
    auto_appeal_text: document.getElementById('c_appeal_text').value,
    uniquify_photos: document.getElementById('c_uniq_on').checked,
    uniquify_mode: uMode,
    uniquifier: {
      mode: uMode,
      perspective_pct: parseFloat(document.getElementById('u_persp')?.value || '2.4'),
      ambient_frame_pct: parseFloat(document.getElementById('u_ambient')?.value || '11.5'),
      hue_shift_deg: parseFloat(document.getElementById('u_hue')?.value || '22'),
      light_leak_pct: parseFloat(document.getElementById('u_leak')?.value || '16.5'),
      crop_x_min_pct: parseFloat(document.getElementById('u_cx_min').value || '0.2'),
      crop_x_max_pct: parseFloat(document.getElementById('u_cx_max').value || '0.8'),
      crop_y_min_pct: parseFloat(document.getElementById('u_cy_min').value || '0.5'),
      crop_y_max_pct: parseFloat(document.getElementById('u_cy_max').value || '1.6'),
      snow_min_flakes: parseInt(document.getElementById('u_snow_min').value || '0', 10),
      snow_max_flakes: parseInt(document.getElementById('u_snow_max').value || '0', 10),
      max_tilt_deg: parseFloat(document.getElementById('u_tilt').value || '2.6'),
      tone_jitter_pct: parseFloat(document.getElementById('u_tone').value || '5.2'),
      noise_sigma: parseFloat(document.getElementById('u_noise').value || '3.6'),
      vignette_pct: parseFloat(document.getElementById('u_vignette').value || '8.0'),
      border_px: parseInt(document.getElementById('u_border').value || '3', 10),
      jpeg_quality_min: parseInt(document.getElementById('u_q_min').value || '83', 10),
      jpeg_quality_max: parseInt(document.getElementById('u_q_max').value || '92', 10),
      enable_bokeh: document.getElementById('u_bokeh').checked,
      enable_wind_trail: document.getElementById('u_wind').checked,
      flip_horizontal: document.getElementById('u_flip').checked
    },
    server_media_files: [...campaignSelectedServerMedia]
  };
}

function applyPresetObject(p) {
  if (!p) return;
  setCampaignMode(p.action_mode || 'upload');
  if (p.content_type) { document.getElementById('c_content_type').value = p.content_type; toggleCampaignContentType(); }
  if (p.threads) document.getElementById('c_threads').value = p.threads;
  if (p.max_retries) document.getElementById('c_retries').value = p.max_retries;
  document.getElementById('c_geo_mode').value = p.geo_mode || 'override';
  toggleCampaignGeoMode();
  if (p.region) document.getElementById('c_region').value = p.region;
  if (p.phone_region) document.getElementById('c_phone_region').value = p.phone_region;
  if (p.app_locale) document.getElementById('c_locale').value = p.app_locale;
  highlightGeoChip(p.region || '');
  document.getElementById('c_auto_sticky').checked = p.auto_sticky_proxy !== false;
  document.getElementById('c_verify_proxy').checked = p.verify_proxy_geo !== false;
  document.getElementById('c_warmup_before').checked = Boolean(p.warmup_before_upload);
  if (p.warmup_videos_count) document.getElementById('c_warmup_count').value = p.warmup_videos_count;
  document.getElementById('c_del_old').checked = p.delete_old_posts !== false;
  if (p.copies_count) document.getElementById('c_copies').value = p.copies_count;
  if (p.delay_range !== undefined) document.getElementById('c_delay').value = p.delay_range;
  if (p.restart_every_n !== undefined) document.getElementById('c_restart_n').value = p.restart_every_n;
  if (p.description !== undefined) document.getElementById('c_desc').value = p.description;
  document.getElementById('c_rand_tags').checked = p.randomize_tags !== false;
  if (p.auto_music_query !== undefined) document.getElementById('c_music_query').value = p.auto_music_query;
  if (p.music_id !== undefined) document.getElementById('c_music_id').value = p.music_id;
  document.getElementById('c_private').value = p.is_private ? '1' : '0';
  document.getElementById('c_story').checked = Boolean(p.is_story);
  document.getElementById('c_nocomments').checked = Boolean(p.disable_comments);
  if (p.auto_appeal_on_upload !== undefined) document.getElementById('c_appeal_on').checked = Boolean(p.auto_appeal_on_upload);
  if (p.auto_appeal_pre_upload !== undefined) document.getElementById('c_appeal_pre').checked = Boolean(p.auto_appeal_pre_upload);
  if (p.auto_appeal_during_upload !== undefined) document.getElementById('c_appeal_during').checked = Boolean(p.auto_appeal_during_upload);
  if (p.auto_appeal_post_upload !== undefined) document.getElementById('c_appeal_post').checked = Boolean(p.auto_appeal_post_upload);
  if (p.auto_appeal_hide_rejected !== undefined) document.getElementById('c_appeal_hide_rej').checked = Boolean(p.auto_appeal_hide_rejected);
  if (p.auto_appeal_post_wait_sec !== undefined) document.getElementById('c_appeal_wait').value = p.auto_appeal_post_wait_sec;
  if (p.auto_appeal_quiet_window_sec !== undefined) document.getElementById('c_appeal_quiet').value = p.auto_appeal_quiet_window_sec;
  if (p.auto_appeal_max_passes !== undefined) document.getElementById('c_appeal_passes').value = p.auto_appeal_max_passes;
  if (p.auto_appeal_text !== undefined) document.getElementById('c_appeal_text').value = p.auto_appeal_text;
  syncAppealCampaignControls();
  document.getElementById('c_uniq_on').checked = p.uniquify_photos !== false;
  if (p.uniquifier) { document.getElementById('c_uniq_mode').value = p.uniquifier.mode || 'minimal'; fillUniqFields(p.uniquifier); }
  syncUniqControlsVisibility();
  if (Array.isArray(p.server_media_files) && p.server_media_files.length) {
    campaignSelectedServerMedia = [...p.server_media_files];
    renderMediaLibrary();
  }
}

function applySelectedPreset() {
  const pid = document.getElementById('c_preset_select').value;
  const p = presetsCache.find(x => x.id === pid);
  if (p) { applyPresetObject(p); showToast(`Применён профиль: ${p.name}`, 'ok'); }
}

async function promptSaveCurrentPreset() {
  const name = prompt('Название нового профиля конфигурации:', 'Мой конфиг залива');
  if (!name || !name.trim()) return;
  const cfg = collectCurrentCampaignConfig();
  cfg.name = name.trim();
  cfg.id = 'custom_' + Date.now();
  await api('/api/presets/save', { method: 'POST', body: JSON.stringify(cfg) });
  await loadPresets();
  document.getElementById('c_preset_select').value = cfg.id;
  showToast('Профиль сохранён!', 'ok');
}

async function deleteSelectedPreset() {
  const pid = document.getElementById('c_preset_select').value;
  if (!pid || !confirm('Удалить выбранный пресет?')) return;
  await api('/api/presets/delete', { method: 'POST', body: JSON.stringify({ id: pid }) });
  await loadPresets();
  showToast('Пресет удалён');
}

function exportCurrentPresetJson() {
  const cfg = collectCurrentCampaignConfig();
  cfg.name = 'Экспортированный профиль';
  showJsonModal('JSON конфигурации залива', cfg);
}

async function importPresetJson() {
  const raw = document.getElementById('cfg_import_preset_json').value.trim();
  if (!raw) return;
  try {
    const obj = JSON.parse(raw);
    if (!obj.name) obj.name = 'Импорт ' + new Date().toLocaleTimeString();
    await api('/api/presets/save', { method: 'POST', body: JSON.stringify(obj) });
    await loadPresets();
    document.getElementById('cfg_import_preset_json').value = '';
    showToast('Пресет импортирован!', 'ok');
  } catch (e) { showToast('Ошибка JSON: ' + e.message, 'err'); }
}

async function saveGlobalSettings() {
  const payload = {
    api_key: document.getElementById('cfg_api_key').value.trim(),
    greedy_api_key: document.getElementById('cfg_greedy_key').value.trim(),
    default_signup_proxy: document.getElementById('cfg_default_proxy').value.trim(),
    default_region: document.getElementById('cfg_default_region').value.trim().toUpperCase() || 'US',
    threads: parseInt(document.getElementById('cfg_default_threads').value || '3', 10)
  };
  await api('/api/config', { method: 'POST', body: JSON.stringify(payload) });
  if (payload.api_key) document.getElementById('apiKeyInput').value = payload.api_key;
  if (payload.greedy_api_key) document.getElementById('reg_greedy_key').value = payload.greedy_api_key;
  showToast('Глобальные настройки сохранены!', 'ok');
}

/* ---------------- CAMPAIGN & UNIQUIFIER ---------------- */

function setCampaignMode(mode) {
  campaignMode = mode;
  document.querySelectorAll('#c_mode_cards .mode-card').forEach(el => el.classList.toggle('active', el.getAttribute('data-mode') === mode));
  document.getElementById('c_upload_only_sections').style.display = mode === 'upload' ? 'block' : 'none';
  document.getElementById('c_bio_only_wrap').style.display = mode === 'set_bio' ? 'block' : 'none';
}

function toggleCampaignContentType() {
  const ct = document.getElementById('c_content_type').value;
  document.getElementById('c_photo_upload_zone').style.display = ct === 'photo' ? 'block' : 'none';
  document.getElementById('c_video_upload_zone').style.display = ct === 'video' ? 'block' : 'none';
}

function handleCampaignVideoFile(files) {
  const f = (files || [])[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = ev => {
    campaignUploadedVideo = { name: f.name, data_url: ev.target.result };
    document.getElementById('c_video_info').textContent = `Выбрано MP4: ${f.name} (${(f.size / 1048576).toFixed(2)} МБ)`;
  };
  r.readAsDataURL(f);
}

function toggleCampaignGeoMode() {
  document.getElementById('c_geo_override_box').style.display = document.getElementById('c_geo_mode').value === 'override' ? 'block' : 'none';
}
function pickCampaignGeo(iso, loc) {
  document.getElementById('c_region').value = iso;
  document.getElementById('c_phone_region').value = iso;
  document.getElementById('c_locale').value = loc;
  highlightGeoChip(iso);
}
function highlightGeoChip(iso) {
  const up = String(iso || '').toUpperCase();
  document.querySelectorAll('#c_geo_chips .country-chip').forEach(btn => btn.classList.toggle('active', btn.getAttribute('data-iso') === up));
}

function parseExcludedSet() {
  const raw = document.getElementById('c_exclude_list')?.value || '';
  return new Set(raw.split(/[\s,;]+/).map(x => x.trim().replace(/^@/, '').toLowerCase()).filter(Boolean));
}
function getActiveSelectedSessionFiles() {
  const excl = parseExcludedSet();
  return sessionsCache
    .filter(s => !excl.has((s.username || '').toLowerCase()) && campaignSelectedSessions.has(s.filename))
    .map(s => s.filename);
}
function updateToolsCounts() {
  const cnt = getActiveSelectedSessionFiles().length;
  for (const id of ['w_sel_lbl', 'br_sel_lbl', 'cm_sel_lbl', 'ap_sel_lbl']) {
    const el = document.getElementById(id); if (el) el.textContent = cnt;
  }
}

function renderCampaignSessionList() {
  const box = document.getElementById('c_session_list');
  if (!box) return;
  const q = (document.getElementById('c_sess_filter')?.value || '').trim().toLowerCase();
  const excl = parseExcludedSet();
  const filtered = sessionsCache.filter(s => !q || String(s.username||'').toLowerCase().includes(q) || String(s.email||'').toLowerCase().includes(q) || String(s.region||'').toLowerCase().includes(q));
  box.innerHTML = filtered.length ? filtered.map(s => {
    const uname = s.username || s.filename.replace('.json', '');
    const isExcl = excl.has(uname.toLowerCase()) || excl.has(s.filename.toLowerCase());
    const checked = !isExcl && campaignSelectedSessions.has(s.filename);
    const pCount = (s.posts || []).length;
    return `
      <label class="sess-check-item ${checked ? 'checked' : ''} ${isExcl ? 'excluded' : ''}">
        <div style="display:flex; align-items:center; gap:6px; overflow:hidden;">
          <input type="checkbox" ${checked ? 'checked' : ''} ${isExcl ? 'disabled' : ''} onchange="toggleOneCampaignSession('${escapeHtml(s.filename)}', this.checked)" />
          <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-weight:600;">@${escapeHtml(uname)}</span>
        </div>
        <span style="font-size:11px; color:var(--muted); white-space:nowrap;">${escapeHtml(s.region || '—')} • 📸${pCount}</span>
      </label>
    `;
  }).join('') : '<div style="color:var(--muted); padding:8px;">Нет подходящих сессий.</div>';
  document.getElementById('c_sel_count_pill').textContent = `${getActiveSelectedSessionFiles().length} выбрано`;
  updateToolsCounts();
}

function toggleOneCampaignSession(fname, checked) {
  if (checked) campaignSelectedSessions.add(fname); else campaignSelectedSessions.delete(fname);
  renderCampaignSessionList();
}
function selectCampaignSessions(mode) {
  const excl = parseExcludedSet();
  sessionsCache.forEach(s => {
    if (excl.has((s.username || '').toLowerCase())) { campaignSelectedSessions.delete(s.filename); return; }
    const pCount = (s.posts || []).length;
    if (mode === 'all') campaignSelectedSessions.add(s.filename);
    else if (mode === 'none') campaignSelectedSessions.delete(s.filename);
    else if (mode === 'with_posts') { if (pCount > 0) campaignSelectedSessions.add(s.filename); else campaignSelectedSessions.delete(s.filename); }
    else if (mode === 'empty') { if (pCount === 0) campaignSelectedSessions.add(s.filename); else campaignSelectedSessions.delete(s.filename); }
    else if (mode === 'invert') { if (campaignSelectedSessions.has(s.filename)) campaignSelectedSessions.delete(s.filename); else campaignSelectedSessions.add(s.filename); }
  });
  renderCampaignSessionList();
}

async function loadMediaLibrary() {
  const data = await api('/api/media/list');
  mediaLibraryCache = data.files || [];
  renderMediaLibrary();
}

function renderMediaLibrary() {
  const grid = document.getElementById('c_media_lib');
  if (!grid) return;
  if (!mediaLibraryCache.length) { grid.innerHTML = '<div class="hint">Папка media/ пуста.</div>'; return; }
  grid.innerHTML = mediaLibraryCache.map(f => {
    const idx = campaignSelectedServerMedia.indexOf(f.name);
    const sel = idx !== -1;
    const inner = f.kind === 'video'
      ? `<div class="vid-box">🎬</div>`
      : `<img src="/api/media/file?name=${encodeURIComponent(f.name)}" />`;
    return `
      <div class="media-item ${sel ? 'selected' : ''}" onclick="toggleServerMediaItem('${escapeHtml(f.name)}', '${escapeHtml(f.kind || 'photo')}')" title="${escapeHtml(f.name)}">
        ${sel ? `<span class="media-order-badge">#${idx + 1}</span>` : ''}
        ${inner}
        <div class="m-name">${escapeHtml(f.name)}</div>
      </div>
    `;
  }).join('');
}

function toggleServerMediaItem(name, kind) {
  if (kind === 'video') {
    document.getElementById('c_content_type').value = 'video';
    toggleCampaignContentType();
    campaignUploadedVideo = null;
    campaignSelectedServerMedia = [name];
  } else {
    campaignUploadedPhotos = [];
    document.getElementById('c_upload_thumbs').innerHTML = '';
    const idx = campaignSelectedServerMedia.indexOf(name);
    if (idx !== -1) campaignSelectedServerMedia.splice(idx, 1);
    else if (campaignSelectedServerMedia.length < 10) campaignSelectedServerMedia.push(name);
  }
  renderMediaLibrary();
}

async function handleCampaignFiles(fileList) {
  const files = Array.from(fileList || []).slice(0, 10);
  if (!files.length) return;
  campaignSelectedServerMedia = [];
  renderMediaLibrary();
  campaignUploadedPhotos = [];
  for (const f of files) {
    const dataUrl = await new Promise(res => { const r = new FileReader(); r.onload = ev => res(ev.target.result); r.readAsDataURL(f); });
    campaignUploadedPhotos.push({ name: f.name, data_url: dataUrl });
  }
  document.getElementById('c_upload_thumbs').innerHTML = campaignUploadedPhotos.map((it, i) => `<div class="thumb-card"><span class="thumb-badge">#${i+1}</span><img src="${it.data_url}" /></div>`).join('');
  try { await api('/api/media/upload', { method: 'POST', body: JSON.stringify({ files: campaignUploadedPhotos }) }); await loadMediaLibrary(); } catch (e) {}
}

function clearCampaignMedia() {
  campaignUploadedPhotos = []; campaignUploadedVideo = null; campaignSelectedServerMedia = [];
  document.getElementById('c_files').value = '';
  document.getElementById('c_upload_thumbs').innerHTML = '';
  renderMediaLibrary();
}

function fillUniqFields(u) {
  if (document.getElementById('u_persp')) document.getElementById('u_persp').value = u.perspective_pct ?? 2.4;
  if (document.getElementById('u_ambient')) document.getElementById('u_ambient').value = u.ambient_frame_pct ?? 11.5;
  if (document.getElementById('u_hue')) document.getElementById('u_hue').value = u.hue_shift_deg ?? 22;
  if (document.getElementById('u_leak')) document.getElementById('u_leak').value = u.light_leak_pct ?? 16.5;
  document.getElementById('u_cx_min').value = u.crop_x_min_pct ?? 0.2;
  document.getElementById('u_cx_max').value = u.crop_x_max_pct ?? 0.8;
  document.getElementById('u_cy_min').value = u.crop_y_min_pct ?? 0.5;
  document.getElementById('u_cy_max').value = u.crop_y_max_pct ?? 1.6;
  document.getElementById('u_snow_min').value = u.snow_min_flakes ?? 240;
  document.getElementById('u_snow_max').value = u.snow_max_flakes ?? 440;
  document.getElementById('u_tilt').value = u.max_tilt_deg ?? 2.6;
  document.getElementById('u_tone').value = u.tone_jitter_pct ?? 5.2;
  document.getElementById('u_noise').value = u.noise_sigma ?? 3.6;
  document.getElementById('u_vignette').value = u.vignette_pct ?? 8.0;
  document.getElementById('u_border').value = u.border_px ?? 3;
  document.getElementById('u_q_min').value = u.jpeg_quality_min ?? 83;
  document.getElementById('u_q_max').value = u.jpeg_quality_max ?? 92;
  document.getElementById('u_bokeh').checked = Boolean(u.enable_bokeh);
  document.getElementById('u_wind').checked = Boolean(u.enable_wind_trail);
  document.getElementById('u_flip').checked = Boolean(u.flip_horizontal);
}
function onUniqPresetChange() { const m = document.getElementById('c_uniq_mode').value; if (UNIQ_PRESETS[m]) fillUniqFields(UNIQ_PRESETS[m]); }
function markUniqCustom() { document.getElementById('c_uniq_mode').value = 'custom'; }
function syncUniqControlsVisibility() { document.getElementById('c_uniq_details').style.opacity = document.getElementById('c_uniq_on').checked ? '1' : '0.42'; }
function syncAppealCampaignControls() {
  const el = document.getElementById('c_appeal_details');
  if (el) el.style.opacity = document.getElementById('c_appeal_on').checked ? '1' : '0.42';
}

async function previewUniquifier() {
  const cfg = collectCurrentCampaignConfig();
  const payload = { uniquifier: cfg.uniquifier };
  const firstImg = campaignSelectedServerMedia.find(n => !n.toLowerCase().endsWith('.mp4'));
  if (campaignUploadedPhotos.length > 0) payload.data_url = campaignUploadedPhotos[0].data_url;
  else if (firstImg) payload.server_file = firstImg;
  else if (mediaLibraryCache.some(f => f.kind !== 'video')) payload.server_file = mediaLibraryCache.find(f => f.kind !== 'video').name;
  else { showToast('Выберите фото-слайд для предпросмотра!', 'err'); return; }

  try {
    const res = await api('/api/uniquifier/preview', { method: 'POST', body: JSON.stringify(payload) });
    document.getElementById('uniqOrigImg').src = res.orig_data_url;
    document.getElementById('uniqAfterImg').src = res.uniq_data_url;
    document.getElementById('uniqModalMeta').textContent = `Оригинал: ${res.orig_kb} KB (SHA256: ${res.orig_sha})  ➔  Уник: ${res.uniq_kb} KB (SHA256: ${res.uniq_sha}) • Режим: ${res.applied.mode}`;
    document.getElementById('uniqPreviewModal').classList.add('open');
  } catch (e) { showToast('Ошибка: ' + e.message, 'err'); }
}
function closeUniqModal() { document.getElementById('uniqPreviewModal').classList.remove('open'); }

async function startCampaign() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const chosenFiles = getActiveSelectedSessionFiles();
  if ((!apiKey && campaignMode !== 'auto_appeal') || !chosenFiles.length) { showToast('Укажите ключ и выберите сессии!', 'err'); return; }
  const cfg = collectCurrentCampaignConfig();
  cfg.api_key = apiKey;
  cfg.session_files = chosenFiles;
  cfg.uploaded_photos = campaignUploadedPhotos;
  cfg.uploaded_video = campaignUploadedVideo;
  try {
    await api('/api/campaign/start', { method: 'POST', body: JSON.stringify(cfg) });
    showToast('Кампания запущена!', 'ok');
    pollState();
  } catch (e) { showToast('Ошибка: ' + e.message, 'err'); }
}
async function stopCampaign() { await api('/api/campaign/stop', { method: 'POST', body: '{}' }); showToast('Запрошена остановка'); }
function copyCampaignUrls() { const txt = document.getElementById('c_urls_box').value.trim(); if (txt) { navigator.clipboard.writeText(txt); showToast('Ссылки скопированы!', 'ok'); } }

/* ---------------- AUTO APPEAL STANDALONE & WATCHDOG ---------------- */

let appealTabMode = 'unban';
let appealRowsCache = [];

function setAppealTabMode(mode) {
  appealTabMode = mode;
  document.querySelectorAll('#ap_mode_cards .mode-card').forEach(el => {
    el.classList.toggle('active', el.getAttribute('data-apmode') === mode);
  });
  const iw = document.getElementById('ap_interval_wrap');
  if (iw) iw.style.display = mode === 'watch' ? 'block' : 'none';
}

function selectZeroViewSessionsForAppeal() {
  const excl = parseExcludedSet();
  const zeroFiles = new Set(
    (analyticsCache || [])
      .filter(a => Number(a.posts_count || 0) > 0 && Number(a.views || 0) === 0)
      .map(a => a.session_file)
  );
  if (!zeroFiles.size) {
    showToast('Сначала запустите Скан в Аналитике или нет аккаунтов с 0 просм.', 'err');
    return 0;
  }
  campaignSelectedSessions.clear();
  sessionsCache.forEach(s => {
    if (!excl.has((s.username || '').toLowerCase()) && zeroFiles.has(s.filename)) {
      campaignSelectedSessions.add(s.filename);
    }
  });
  renderCampaignSessionList();
  showToast(`Выбрано ${campaignSelectedSessions.size} аккаунтов с 0 просм.!`, 'ok');
  return campaignSelectedSessions.size;
}

async function appealZeroViewAccounts() {
  const cnt = selectZeroViewSessionsForAppeal();
  if (!cnt) return;
  switchTab('appeal', document.getElementById('btn-tab-appeal'));
  setAppealTabMode('unban');
  await startStandaloneAppeal();
}

let appealFoldersCache = {};

function renderAppealFolders(folders) {
  if (!folders) return;
  appealFoldersCache = folders;
  const mapIds = {
    clean: 'ap_fld_cnt_clean',
    ogran_na_proverke: 'ap_fld_cnt_review',
    ogran_ne_snyat: 'ap_fld_cnt_restricted',
    errors: 'ap_fld_cnt_errors'
  };
  for (const [k, elId] of Object.entries(mapIds)) {
    const el = document.getElementById(elId);
    if (el && folders[k]) el.textContent = folders[k].count || 0;
  }
}

async function recheckFolderAccounts(folderKey, modeOverride) {
  const f = (appealFoldersCache || {})[folderKey];
  const sessFiles = (f && Array.isArray(f.session_files)) ? f.session_files : [];
  if (!sessFiles.length) {
    showToast(`В папке ${folderKey} пока нет сессий для перепроверки!`, 'err');
    return;
  }
  if (modeOverride) setAppealTabMode(modeOverride);
  const payload = {
    session_files: sessFiles,
    accounts_text: '',
    api_key: document.getElementById('apiKeyInput').value.trim(),
    login_region: (document.getElementById('ap_login_region')?.value || 'US').trim().toUpperCase(),
    mode: modeOverride || appealTabMode,
    threads: parseInt(document.getElementById('ap_threads').value || '4', 10),
    max_passes: parseInt(document.getElementById('ap_max_passes').value || '4', 10),
    quiet_window_sec: 0,
    interval_min: parseInt(document.getElementById('ap_interval').value || '15', 10),
    only_account_ineligible: document.getElementById('ap_only_2048') ? document.getElementById('ap_only_2048').checked : true,
    hide_rejected: document.getElementById('ap_hide_rejected').checked,
    use_browser_fallback: document.getElementById('ap_browser_fb').checked,
    stagger_appeals: document.getElementById('ap_stagger').checked,
    appeal_text: document.getElementById('ap_text').value,
    proxies_text: document.getElementById('ap_proxies').value
  };
  try {
    await api('/api/appeal/start', { method: 'POST', body: JSON.stringify(payload) });
    showToast(`🔄 Запущена перепроверка папки (${sessFiles.length} акк.)!`, 'ok');
    pollState();
  } catch (e) {
    showToast('Ошибка: ' + e.message, 'err');
  }
}

async function startStandaloneAppeal() {
  const rawAccText = (document.getElementById('ap_accounts_text')?.value || '').trim();
  const inclSelected = document.getElementById('ap_include_selected') ? document.getElementById('ap_include_selected').checked : true;
  const chosenFiles = inclSelected ? getActiveSelectedSessionFiles() : [];
  if (!rawAccText && !chosenFiles.length) {
    showToast('Вставьте строки аккаунтов ИЛИ отметьте готовые сессии!', 'err');
    return;
  }
  const payload = {
    session_files: chosenFiles,
    accounts_text: rawAccText,
    api_key: document.getElementById('apiKeyInput').value.trim(),
    login_region: (document.getElementById('ap_login_region')?.value || 'US').trim().toUpperCase(),
    force_relogin: Boolean(document.getElementById('ap_force_relogin')?.checked),
    mode: appealTabMode,
    threads: parseInt(document.getElementById('ap_threads').value || '4', 10),
    max_passes: parseInt(document.getElementById('ap_max_passes').value || '4', 10),
    quiet_window_sec: parseInt(document.getElementById('ap_quiet_sec').value || '0', 10),
    interval_min: parseInt(document.getElementById('ap_interval').value || '15', 10),
    hide_rejected: document.getElementById('ap_hide_rejected').checked,
    use_browser_fallback: document.getElementById('ap_browser_fb').checked,
    stagger_appeals: document.getElementById('ap_stagger').checked,
    appeal_text: document.getElementById('ap_text').value,
    proxies_text: document.getElementById('ap_proxies').value
  };
  try {
    const res = await api('/api/appeal/start', { method: 'POST', body: JSON.stringify(payload) });
    showToast(`🛡️ ${res.message || 'Запущено!'}`, 'ok');
    pollState();
  } catch (e) {
    showToast('Ошибка Auto-Appeal: ' + e.message, 'err');
  }
}

async function stopStandaloneAppeal() {
  await api('/api/appeal/stop', { method: 'POST', body: '{}' });
  showToast('Запрошена остановка Auto-Appeal');
}

async function runSingleSessionAppeal(sessionFile) {
  if (!sessionFile) return;
  try {
    await api('/api/appeal/single', {
      method: 'POST',
      body: JSON.stringify({
        session_file: sessionFile,
        max_passes: parseInt(document.getElementById('ap_max_passes')?.value || '4', 10),
        hide_rejected: Boolean(document.getElementById('ap_hide_rejected')?.checked),
        appeal_text: document.getElementById('ap_text')?.value || ''
      })
    });
    showToast(`🛡️ Быстрое снятие запущено для ${sessionFile}!`, 'ok');
    switchTab('appeal', document.getElementById('btn-tab-appeal'));
    pollState();
  } catch (e) {
    showToast('Ошибка: ' + e.message, 'err');
  }
}

function inspectAppealRow(idx) {
  const row = appealRowsCache[idx];
  if (!row) return;
  showJsonModal(`🛡️ Детали ограничений и папки @${row.username}`, row);
}

function renderAppealTable() {
  const tb = document.getElementById('appeal_rows_tbody');
  if (!tb) return;
  const flt = document.getElementById('ap_filter')?.value || 'all';
  const list = (appealRowsCache || []).filter(r => {
    if (flt === 'all') return true;
    if (r.folder_key) return r.folder_key === flt;
    if (flt === 'ogran_ne_snyat') return r.verdict === 'restricted';
    if (flt === 'ogran_na_proverke') return r.verdict === 'appealed' || r.verdict === 'reviewing';
    if (flt === 'clean') return r.verdict === 'clean' || r.verdict === 'restored';
    if (flt === 'errors') return r.verdict === 'error';
    return true;
  });
  if (!list.length) {
    tb.innerHTML = '<tr><td colspan="4" style="color:var(--muted);">Нет записей в выбранной папке.</td></tr>';
    return;
  }
  tb.innerHTML = list.map((r) => {
    const origIdx = appealRowsCache.indexOf(r);
    const fKey = r.folder_key || '';
    const cls = (fKey === 'clean' || r.verdict === 'clean' || r.verdict === 'restored')
      ? 'ok'
      : (fKey === 'ogran_na_proverke' || r.verdict === 'appealed' || r.verdict === 'reviewing' || r.verdict === 'running' ? 'warn' : 'err');
    const folderBadge = r.folder_title
      ? `<div style="margin-bottom:4px;"><span class="pill ${cls}">📁 ${escapeHtml(r.folder_title)}</span></div>`
      : '';
    const geoStr = `${escapeHtml((r.reg_country || '?').toUpperCase())} ➔ ${escapeHtml((r.current_region || '?').toUpperCase())}`;
    const noticesHtml = (r.notices || []).map(v => {
      const nCls = v.can_appeal ? 'err' : (v.status_code === 4 ? 'warn' : 'ok');
      return `<div style="margin-bottom:3px;"><span class="pill ${nCls}" style="font-size:10.5px;">🔔 ${escapeHtml(v.title)} (${v.punish_type})</span> <span class="hint">${escapeHtml(v.status_label)}</span></div>`;
    }).join('');
    const postsHtml = (r.flagged_posts || []).map(p => {
      const pCls = (p.appeal_status === 0 || p.v2_can_appeal) ? 'err' : (p.appeal_status === 3 ? 'warn' : (p.appeal_status === 5 ? 'err' : 'ok'));
      const rsn = (p.reason_labels || []).join(',') || 'FYP';
      return `<div style="margin-bottom:3px;"><a class="link" href="${escapeHtml(p.url)}" target="_blank">🎬 ${escapeHtml(p.item_id.slice(-7))}</a> <span class="pill ${pCls}" style="font-size:10.5px;">${escapeHtml(rsn)}: ${escapeHtml(p.appeal_status_label)}</span></div>`;
    }).join('');
    const errHtml = r.error ? `<div style="color:#f87171; font-size:12px;">❌ ${escapeHtml(r.error)}</div>` : '';
    const summaryHtml = errHtml || (noticesHtml + postsHtml) || `<span class="hint">Постов проверено: ${r.total_posts || 0} • Ограничений 0 (чистый аккаунт)</span>`;
    return `
      <tr>
        <td>
          <strong>@${escapeHtml(r.username || '')}</strong>
          <div class="hint">${geoStr}${r.idc_gateway ? ' • ' + escapeHtml(r.idc_gateway.split('.')[0]) : ''}</div>
        </td>
        <td>
          ${folderBadge}
          <span class="hint">${escapeHtml(r.verdict_label || r.verdict)}</span>
          ${r.appeals_sent_total ? `<div class="hint" style="color:#4ade80;">Отправлено: ${r.appeals_sent_total}</div>` : ''}
        </td>
        <td>${summaryHtml}</td>
        <td style="white-space:nowrap;">
          <button class="btn btn-sec btn-sm" onclick="inspectAppealRow(${origIdx})" title="JSON отчёт">🔍</button>
          ${r.session_file ? `<button class="btn btn-sm" onclick="runSingleSessionAppeal('${escapeHtml(r.session_file)}')" title="Повторно проверить/дожать">⚡ Дожать</button>` : ''}
        </td>
      </tr>
    `;
  }).join('');
}

async function scheduleCurrentCampaignFromMain() {
  const mins = prompt('Через сколько минут автоматически запустить текущую кампанию залива?', '15');
  if (!mins) return;
  const cfg = collectCurrentCampaignConfig();
  cfg.api_key = document.getElementById('apiKeyInput').value.trim();
  cfg.session_files = getActiveSelectedSessionFiles();
  cfg.uploaded_photos = campaignUploadedPhotos;
  cfg.uploaded_video = campaignUploadedVideo;
  await api('/api/autopilot/add', {
    method: 'POST',
    body: JSON.stringify({
      kind: 'delayed_campaign',
      name: `Залив (${cfg.session_files.length} акк, ${cfg.region})`,
      delay_minutes: parseFloat(mins),
      repeat_minutes: 0,
      campaign_payload: cfg
    })
  });
  showToast(`Кампания запланирована через ${mins} мин!`, 'ok');
  switchTab('autopilot', document.getElementById('btn-tab-autopilot'));
}

/* ---------------- MUSIC SEARCH & FYP TRENDS ---------------- */

function openMusicSearchModal(targetId, querySourceId) {
  musicTargetInputId = targetId;
  document.getElementById('ms_query_inp').value = document.getElementById(querySourceId)?.value || 'Fortnite';
  document.getElementById('musicModal').classList.add('open');
  executeMusicSearch();
}
function closeMusicModal() { document.getElementById('musicModal').classList.remove('open'); }

function renderMusicTracks(tracks) {
  const tb = document.getElementById('ms_results_tbody');
  tb.innerHTML = tracks.length ? tracks.map(t => `
    <tr>
      <td><strong>${escapeHtml(t.title)}</strong></td>
      <td>${escapeHtml(t.author)}</td>
      <td><code class="inline">${escapeHtml(t.id)}</code></td>
      <td><button class="btn btn-sm" onclick="pickMusicId('${escapeHtml(t.id)}')">Выбрать</button></td>
    </tr>
  `).join('') : '<tr><td colspan="4" style="color:var(--muted);">Треки не найдены.</td></tr>';
}

async function executeMusicSearch() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const q = document.getElementById('ms_query_inp').value.trim() || 'Fortnite';
  const region = document.getElementById('c_region').value.trim() || 'US';
  const btn = document.getElementById('ms_search_btn');
  btn.disabled = true; btn.textContent = '⏳...';
  try {
    const res = await api('/api/music/search', { method: 'POST', body: JSON.stringify({ api_key: apiKey, keyword: q, region }) });
    renderMusicTracks(res.tracks || []);
  } catch (e) { showToast('Ошибка: ' + e.message, 'err'); }
  finally { btn.disabled = false; btn.textContent = '🔍 Поиск по слову'; }
}

async function executeTrendingMusic() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const region = document.getElementById('c_region').value.trim() || 'US';
  const btn = document.getElementById('ms_trend_btn');
  btn.disabled = true; btn.textContent = `⏳ Лента ${region}...`;
  try {
    const res = await api('/api/music/trending', { method: 'POST', body: JSON.stringify({ api_key: apiKey, region }) });
    renderMusicTracks(res.tracks || []);
    showToast(`Собрано ${(res.tracks||[]).length} трендовых звуков из FYP (${region})`, 'ok');
  } catch (e) { showToast('Ошибка: ' + e.message, 'err'); }
  finally { btn.disabled = false; btn.textContent = '📈 Тренды FYP ГЕО'; }
}

function pickMusicId(mid) {
  document.getElementById(musicTargetInputId).value = mid;
  closeMusicModal();
  showToast('Подставлен Music ID: ' + mid, 'ok');
}

/* ---------------- ANALYTICS v2 ---------------- */

async function startAnalyticsScan(scope, explicitFiles = null) {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const files = explicitFiles || (scope === 'selected' ? getActiveSelectedSessionFiles() : sessionsCache.map(s => s.filename));
  if (!apiKey || !files.length) { showToast('Укажите ключ и сессии!', 'err'); return; }
  const threads = parseInt(document.getElementById('an_threads').value || '4', 10);
  await api('/api/analytics/scan', { method: 'POST', body: JSON.stringify({ api_key: apiKey, session_files: files, threads }) });
  showToast(`Запущен скан аналитики (${files.length} сессий)`, 'ok');
  pollState();
}

function scanCheckedAnalytics() {
  if (!sessionTableChecked.size) { showToast('Отметьте сессии в таблице!', 'err'); return; }
  switchTab('analytics', document.getElementById('btn-tab-analytics'));
  startAnalyticsScan('custom', Array.from(sessionTableChecked));
}

function renderAnalyticsTable() {
  const flt = document.getElementById('an_filter').value;
  const tb = document.getElementById('an_tbody');
  const list = analyticsCache.filter(r => {
    if (flt === 'hot') return r.views > 0;
    if (flt === 'zero') return r.verdict === 'zero';
    if (flt === 'empty') return r.verdict === 'empty';
    return true;
  });
  tb.innerHTML = list.length ? list.map(r => {
    const pillCls = r.verdict === 'hot' ? 'ok' : (r.verdict === 'zero' || r.verdict === 'error' ? 'err' : 'warn');
    const dlt = r.views_delta > 0 ? ` <span class="pill ok">+${r.views_delta}</span>` : '';
    return `
      <tr>
        <td><a class="link" href="https://www.tiktok.com/@${encodeURIComponent(r.username)}" target="_blank"><strong>@${escapeHtml(r.username)}</strong></a> <span class="pill">${escapeHtml(r.region)}</span></td>
        <td>${r.followers}</td>
        <td><strong>${r.posts_count}</strong></td>
        <td style="font-size:14px; font-weight:800; color:${r.views > 0 ? '#4ade80' : 'var(--text)'};">${r.views.toLocaleString('ru-RU')}${dlt}</td>
        <td>${r.likes.toLocaleString('ru-RU')}</td>
        <td>💬${r.comments} • 🔁${r.shares} • 🔖${r.collects}</td>
        <td><span class="pill ${pillCls}">${escapeHtml(r.verdict_label)}</span></td>
        <td style="white-space:nowrap;">
          <button class="btn btn-sec btn-sm" onclick="openAccountPostsModal('${escapeHtml(r.session_file)}')">📋 Посты (${r.posts_count})</button>
          <button class="btn btn-sm" onclick="runSingleSessionAppeal('${escapeHtml(r.session_file)}')" title="Проверить и снять все ограничения на этом аккаунте">🛡️ Огран</button>
        </td>
      </tr>
    `;
  }).join('') : '<tr><td colspan="8" style="color:var(--muted);">Нет данных по выбранному фильтру.</td></tr>';
}

function openAccountPostsModal(sf) {
  const acc = analyticsCache.find(x => x.session_file === sf);
  if (!acc) return;
  document.getElementById('modalTitle').textContent = `Посты @${acc.username} (${acc.posts_count} шт.)`;
  document.getElementById('modalContent').style.display = 'none';
  const hb = document.getElementById('modalHtmlBody');
  hb.style.display = 'block';
  hb.innerHTML = acc.posts.length ? `<table><thead><tr><th>ID / Дата</th><th>ГЕО</th><th>👁 Просм</th><th>❤️ / 💬</th><th>Видимость</th><th>Управление</th></tr></thead><tbody>` +
    acc.posts.map(p => `
      <tr>
        <td><a class="link" href="${escapeHtml(p.url)}" target="_blank"><code class="inline">${escapeHtml(p.aweme_id)}</code> ↗</a><div class="hint">${escapeHtml(p.created_at)}</div></td>
        <td><span class="pill">${escapeHtml(p.region)}</span></td>
        <td><strong>${p.views}</strong></td>
        <td>❤️${p.likes} • 💬${p.comments}</td>
        <td>${p.private_status === 1 ? '<span class="pill warn">Приват</span>' : '<span class="pill ok">Публич</span>'}</td>
        <td>
          <div style="display:flex; gap:5px;">
            <button class="btn btn-sec btn-sm" onclick="jumpToTopComment('${escapeHtml(p.url)}')">💬 В ТОП</button>
            <button class="btn btn-sec btn-sm" onclick="changePostVis('${escapeHtml(sf)}','${escapeHtml(p.aweme_id)}', ${p.private_status === 1 ? 1 : 2})">${p.private_status === 1 ? '🔓' : '🔒'}</button>
            <button class="btn btn-danger btn-sm" onclick="deleteSinglePost('${escapeHtml(sf)}','${escapeHtml(p.aweme_id)}')">🗑</button>
          </div>
        </td>
      </tr>
    `).join('') + `</tbody></table>` : '<div class="hint">0 постов.</div>';
  document.getElementById('jsonModal').classList.add('open');
}

function jumpToTopComment(postUrl) {
  closeModal();
  document.getElementById('cm_target_post').value = postUrl;
  switchTab('comments', document.getElementById('btn-tab-comments'));
}

async function changePostVis(sf, aid, visType) {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  await api('/api/post/visibility', { method: 'POST', body: JSON.stringify({ api_key: apiKey, session_file: sf, aweme_id: aid, type: visType }) });
  showToast('Видимость поста изменена!', 'ok');
  closeModal();
}

async function deleteSinglePost(sf, aid) {
  if (!confirm('Удалить этот пост?')) return;
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  await api('/api/post/delete_one', { method: 'POST', body: JSON.stringify({ api_key: apiKey, session_file: sf, aweme_id: aid }) });
  showToast('Пост удалён!', 'ok');
  closeModal();
}

function reuploadZeroViewAccounts() {
  const excl = parseExcludedSet();
  const zeroFiles = analyticsCache.filter(r => r.verdict === 'zero' && !excl.has((r.username||'').toLowerCase())).map(r => r.session_file);
  if (!zeroFiles.length) { showToast('Нет подходящих аккаунтов с 0 просмотров!', 'err'); return; }
  campaignSelectedSessions = new Set(zeroFiles);
  setCampaignMode('upload');
  document.getElementById('c_del_old').checked = true;
  renderCampaignSessionList();
  switchTab('campaign', document.getElementById('btn-tab-campaign'));
  showToast(`Выбрано ${zeroFiles.length} аккаунтов с 0 просмотров для перезалива!`, 'ok');
}

/* ---------------- COMPETITOR SPY & CLONER ---------------- */

async function runCompetitorSpy() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const q = document.getElementById('spy_query').value.trim();
  const region = document.getElementById('spy_region').value.trim() || 'US';
  const count = parseInt(document.getElementById('spy_count').value || '12', 10);
  if (!apiKey || !q) { showToast('Введите @username или ссылку на пост!', 'err'); return; }

  const btn = document.getElementById('spy_btn');
  btn.disabled = true; btn.textContent = '⏳ Разведка...';
  try {
    const res = await api('/api/spy/analyze', { method: 'POST', body: JSON.stringify({ api_key: apiKey, target: q, region, count }) });
    const p = res.profile;
    const sm = res.summary;
    spyPostsCache = res.posts || [];

    const musicHtml = (sm.top_music || []).map(m =>
      `<span class="country-chip" onclick="document.getElementById('c_music_id').value='${escapeHtml(m.id)}'; showToast('Music ID ${escapeHtml(m.id)} скопирован в Залив!','ok')">🎵 ${escapeHtml(m.title.slice(0,26))} (${m.uses}x)</span>`
    ).join(' ');
    const tagsHtml = (sm.top_hashtags || []).map(t => `<code class="inline">${escapeHtml(t)}</code>`).join(' ');

    document.getElementById('spy_profile_header').innerHTML = `
      <div style="display:flex; flex-wrap:wrap; gap:14px; align-items:center; justify-content:space-between;">
        <div>
          <div style="font-size:16px; font-weight:800;">@${escapeHtml(p.username)} <span style="color:var(--muted); font-weight:500;">(${escapeHtml(p.nickname)})</span></div>
          <div class="hint">${escapeHtml(p.signature || 'БИО пусто')} ${p.bio_url ? `• 🔗 <a class="link" href="${escapeHtml(p.bio_url)}" target="_blank">${escapeHtml(p.bio_url)}</a>` : ''}</div>
        </div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <span class="pill">Подписчики: ${p.followers.toLocaleString('ru-RU')}</span>
          <span class="pill ok">👁 Просмотров (${sm.posts_analyzed} пост.): ${sm.total_views.toLocaleString('ru-RU')}</span>
          <span class="pill">Средние: ${sm.avg_views.toLocaleString('ru-RU')}</span>
          <span class="pill warn">Пик: ${sm.max_views.toLocaleString('ru-RU')}</span>
        </div>
      </div>
      ${tagsHtml ? `<div style="margin-top:8px;"><strong>Топ теги:</strong> ${tagsHtml}</div>` : ''}
      ${musicHtml ? `<div style="margin-top:6px;"><strong>Топ звуки (клик = в Залив):</strong> ${musicHtml}</div>` : ''}
    `;

    document.getElementById('spy_posts_grid').innerHTML = spyPostsCache.map(post => `
      <div class="spy-post-card">
        ${post.cover_url ? `<img src="${escapeHtml(post.cover_url)}" />` : `<div style="height:180px; display:grid; place-items:center; background:#090b10;">🎬 ${escapeHtml(post.kind)}</div>`}
        <div class="spy-post-body">
          <div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
              <span class="pill ok">👁 ${post.views.toLocaleString('ru-RU')}</span>
              <span class="hint">${post.kind === 'photo' ? `📸 ${post.slides_count} сл.` : '🎬 MP4'} • ${escapeHtml(post.created_at)}</span>
            </div>
            <div style="font-size:11.8px; color:var(--muted); margin-bottom:5px;">❤️${post.likes} • 💬${post.comments} • 🔖${post.collects}</div>
            <div style="font-size:11.8px; max-height:42px; overflow:hidden;">${escapeHtml(post.full_desc || '')}</div>
            ${post.music_id ? `<div class="hint">🎵 ${escapeHtml(post.music_title.slice(0,28))} (<code class="inline">${escapeHtml(post.music_id)}</code>)</div>` : ''}
          </div>
          <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:6px;">
            <button class="btn btn-sec btn-sm" onclick="downloadSpyCreative('${escapeHtml(post.aweme_id)}', false)">📥 В media/</button>
            <button class="btn btn-sm" onclick="downloadSpyCreative('${escapeHtml(post.aweme_id)}', true)">🚀 Клонировать в Залив</button>
          </div>
        </div>
      </div>
    `).join('');

    document.getElementById('spy_summary_box').style.display = 'block';
  } catch (e) { showToast('Ошибка разведки: ' + e.message, 'err'); }
  finally { btn.disabled = false; btn.textContent = '🔍 Разведка'; }
}

async function downloadSpyCreative(awemeId, cloneToCampaign) {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const region = document.getElementById('spy_region').value.trim() || 'US';
  showToast('Скачивание креатива без водяного знака...');
  try {
    const res = await api('/api/spy/download', { method: 'POST', body: JSON.stringify({ api_key: apiKey, aweme_id: awemeId, region }) });
    await loadMediaLibrary();
    if (cloneToCampaign) {
      document.getElementById('c_content_type').value = res.kind;
      toggleCampaignContentType();
      campaignUploadedPhotos = []; campaignUploadedVideo = null;
      campaignSelectedServerMedia = res.saved_files;
      if (res.desc) document.getElementById('c_desc').value = res.desc;
      if (res.music_id) document.getElementById('c_music_id').value = res.music_id;
      renderMediaLibrary();
      switchTab('campaign', document.getElementById('btn-tab-campaign'));
      showToast(`Связка клонирована (${res.saved_files.length} файл., Music ID подставлен)!`, 'ok');
    } else {
      showToast(`Сохранено в media/: ${res.saved_files.join(', ')}`, 'ok');
    }
  } catch (e) { showToast('Ошибка скачивания: ' + e.message, 'err'); }
}

/* ---------------- TOP-COMMENT MARKETING ---------------- */

function handleCommentProofImg(files) {
  const f = (files || [])[0];
  if (!f) { commentProofImgDataUrl = ''; return; }
  const r = new FileReader();
  r.onload = ev => { commentProofImgDataUrl = ev.target.result; };
  r.readAsDataURL(f);
}

async function loadPostCommentsLive() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const target = document.getElementById('cm_target_post').value.trim();
  const region = document.getElementById('cm_region').value.trim() || 'US';
  if (!apiKey || !target) { showToast('Укажите ссылку на пост!', 'err'); return; }
  try {
    const res = await api('/api/comments/list', { method: 'POST', body: JSON.stringify({ api_key: apiKey, target_post: target, region }) });
    const list = res.comments || [];
    document.getElementById('cm_live_tbody').innerHTML = list.length ? list.map(c => `
      <tr>
        <td><strong>@${escapeHtml(c.username)}</strong><div class="hint">${escapeHtml(c.created_at)}</div></td>
        <td>${escapeHtml(c.text)}<div class="hint">CID: <code class="inline">${escapeHtml(c.cid)}</code></div></td>
        <td>❤️${c.likes} • 💬${c.replies}</td>
        <td><button class="btn btn-sm" onclick="document.getElementById('cm_existing_cid').value='${escapeHtml(c.cid)}'; showToast('Выбран CID ${escapeHtml(c.cid)} для вывода в ТОП!','ok')">🚀 В ТОП</button></td>
      </tr>
    `).join('') : '<tr><td colspan="4" style="color:var(--muted);">Комментариев пока нет.</td></tr>';
  } catch (e) { showToast('Ошибка: ' + e.message, 'err'); }
}

async function startTopCommentBoost() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const boosters = getActiveSelectedSessionFiles();
  const target = document.getElementById('cm_target_post').value.trim();
  if (!apiKey || !target || !boosters.length) { showToast('Укажите пост и выберите сессии!', 'err'); return; }
  await api('/api/comments/boost_top', {
    method: 'POST',
    body: JSON.stringify({
      api_key: apiKey,
      target_post: target,
      region: document.getElementById('cm_region').value.trim() || 'US',
      threads: parseInt(document.getElementById('cm_threads').value || '4', 10),
      seed_session: document.getElementById('cm_seed_session').value,
      comment_id: document.getElementById('cm_existing_cid').value.trim(),
      lead_comment_text: document.getElementById('cm_lead_text').value.trim(),
      lead_image_data_url: commentProofImgDataUrl,
      session_files: boosters,
      reply_prob: parseInt(document.getElementById('cm_reply_prob').value || '0', 10),
      reply_templates: document.getElementById('cm_replies').value
    })
  });
  showToast('Запущен вывод комментария в ТОП!', 'ok');
  pollState();
}

/* ---------------- AUTOPILOT SCHEDULER ---------------- */

function toggleAutopilotFields() {
  const k = document.getElementById('ap_kind').value;
  document.getElementById('ap_age_wrap').style.display = k === 'zero_view_watchdog' ? 'block' : 'none';
  if (k === 'zero_view_watchdog') document.getElementById('ap_name').value = 'Сторож Нулей (авто-перезалив)';
  else if (k === 'periodic_analytics') document.getElementById('ap_name').value = 'Регулярный чек просмотров';
  else document.getElementById('ap_name').value = 'Отложенный запуск залива';
}

async function createAutopilotTask() {
  const cfg = collectCurrentCampaignConfig();
  cfg.api_key = document.getElementById('apiKeyInput').value.trim();
  cfg.session_files = getActiveSelectedSessionFiles();
  cfg.uploaded_photos = campaignUploadedPhotos;
  cfg.uploaded_video = campaignUploadedVideo;

  await api('/api/autopilot/add', {
    method: 'POST',
    body: JSON.stringify({
      kind: document.getElementById('ap_kind').value,
      name: document.getElementById('ap_name').value.trim(),
      delay_minutes: parseFloat(document.getElementById('ap_delay').value || '15'),
      repeat_minutes: parseFloat(document.getElementById('ap_repeat').value || '0'),
      min_post_age_minutes: parseInt(document.getElementById('ap_min_age').value || '20', 10),
      exclude_usernames: document.getElementById('ap_exclude').value.trim(),
      campaign_payload: cfg
    })
  });
  showToast('Задача добавлена в Авто-Пилот!', 'ok');
  pollState();
}

async function deleteAutopilotTask(tid) {
  await api('/api/autopilot/delete', { method: 'POST', body: JSON.stringify({ id: tid }) });
  pollState();
}

/* ---------------- WARMUP, BRANDING, SESSIONS, LIVE 2FA ---------------- */

function toggleWarmupMode() {
  const m = document.getElementById('w_mode').value;
  document.getElementById('w_fyp_box').style.display = m === 'warmup_fyp' ? 'block' : 'none';
  document.getElementById('w_boost_box').style.display = m === 'boost_target' ? 'block' : 'none';
}

async function startWarmupOrBoost() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const files = getActiveSelectedSessionFiles();
  if (!apiKey || !files.length) { showToast('Укажите ключ и выберите сессии!', 'err'); return; }
  await api('/api/tools/warmup_boost', {
    method: 'POST',
    body: JSON.stringify({
      api_key: apiKey, session_files: files,
      mode: document.getElementById('w_mode').value,
      threads: parseInt(document.getElementById('w_threads').value || '4', 10),
      region: document.getElementById('w_region').value.trim() || 'US',
      videos_count: parseInt(document.getElementById('w_videos').value || '5', 10),
      like_prob: parseInt(document.getElementById('w_like_prob').value || '35', 10),
      collect_prob: parseInt(document.getElementById('w_collect_prob').value || '15', 10),
      target_post: document.getElementById('w_target_post').value.trim(),
      target_username: document.getElementById('w_target_user').value.trim(),
      do_view: document.getElementById('w_do_view').checked,
      do_like: document.getElementById('w_do_like').checked,
      do_collect: document.getElementById('w_do_collect').checked,
      do_repost: document.getElementById('w_do_repost').checked,
      do_follow: document.getElementById('w_do_follow').checked,
      comments_text: document.getElementById('w_comments').value
    })
  });
  showToast('Задача запущена!', 'ok');
  pollState();
}

function handleBrandAvatar(files) {
  const f = (files || [])[0]; if (!f) return;
  const r = new FileReader();
  r.onload = ev => {
    brandAvatarDataUrl = ev.target.result;
    document.getElementById('br_avatar_preview').innerHTML = `<img src="${brandAvatarDataUrl}" style="width:60px; height:60px; border-radius:50%; object-fit:cover; border:2px solid var(--accent);" />`;
  };
  r.readAsDataURL(f);
}
function clearBrandAvatar() { brandAvatarDataUrl = ''; document.getElementById('br_avatar_file').value = ''; document.getElementById('br_avatar_preview').innerHTML = ''; }

async function startBrandingJob() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const files = getActiveSelectedSessionFiles();
  if (!apiKey || !files.length) { showToast('Укажите ключ и выберите сессии!', 'err'); return; }
  await api('/api/tools/branding', {
    method: 'POST',
    body: JSON.stringify({
      api_key: apiKey, session_files: files,
      threads: parseInt(document.getElementById('br_threads').value || '3', 10),
      avatar_data_url: brandAvatarDataUrl,
      uniquify_avatar: document.getElementById('br_uniq_avatar').checked,
      nickname_template: document.getElementById('br_nickname').value.trim(),
      username_prefix: document.getElementById('br_uname_prefix').value.trim(),
      bio_template: document.getElementById('br_bio').value.trim(),
      bio_url: document.getElementById('br_bio_url').value.trim(),
      new_password: document.getElementById('br_password').value.trim(),
      enable_totp: document.getElementById('br_enable_totp').checked
    })
  });
  showToast('Оформление профилей запущено!', 'ok');
  pollState();
}

async function stopToolsJob() { await api('/api/tools/stop', { method: 'POST', body: '{}' }); showToast('Запрошена остановка'); }

async function loadSessions() {
  const data = await api('/api/sessions');
  sessionsCache = data.sessions || [];
  document.getElementById('statSessions').textContent = 'Сессий: ' + sessionsCache.length;
  if (!campaignInitializedSelection && sessionsCache.length) {
    const excl = parseExcludedSet();
    sessionsCache.forEach(s => { if (!excl.has((s.username||'').toLowerCase())) campaignSelectedSessions.add(s.filename); });
    campaignInitializedSelection = true;
  }
  renderCampaignSessionList();
  renderSessionsTable();

  const optsHtml = sessionsCache.length
    ? sessionsCache.map(s => `<option value="${escapeHtml(s.filename)}">@${escapeHtml(s.username || s.filename)} (${escapeHtml(s.region || '—')}, 📸${(s.posts||[]).length})</option>`).join('')
    : '<option value="">Нет сессий</option>';
  for (const sid of ['p_session', 'cm_seed_session']) {
    const sel = document.getElementById(sid);
    if (!sel) continue;
    const pv = sel.value;
    sel.innerHTML = optsHtml;
    if (pv && sessionsCache.some(s => s.filename === pv)) sel.value = pv;
  }
}

function renderSessionsTable() {
  const tbody = document.getElementById('sessionsTableBody');
  if (!tbody) return;
  const q = (document.getElementById('sess_table_search')?.value || '').trim().toLowerCase();
  const flt = document.getElementById('sess_table_filter')?.value || 'all';
  const list = sessionsCache.filter(s => {
    const pc = (s.posts || []).length;
    if (flt === 'with_posts' && pc === 0) return false;
    if (flt === 'no_posts' && pc > 0) return false;
    return !q || String(s.username||'').toLowerCase().includes(q) || String(s.email||'').toLowerCase().includes(q) || String(s.region||'').toLowerCase().includes(q);
  });
  document.getElementById('sess_checked_pill').textContent = 'Отмечено: ' + sessionTableChecked.size;
  tbody.innerHTML = list.length ? list.map(s => {
    const prof = s.username ? `<a class="link" href="https://www.tiktok.com/@${encodeURIComponent(s.username)}" target="_blank"><strong>@${escapeHtml(s.username)}</strong></a>` : s.filename;
    const pc = (s.posts || []).length;
    const postHtml = pc > 0 && s.posts[0].url ? `<a class="link" href="${escapeHtml(s.posts[0].url)}" target="_blank">📸 ${pc} шт. ↗</a>` : '0';
    return `
      <tr>
        <td><input type="checkbox" ${sessionTableChecked.has(s.filename) ? 'checked' : ''} onchange="toggleSessionRowCheck('${escapeHtml(s.filename)}', this.checked)" /></td>
        <td>${prof}</td>
        <td style="font-size:11.8px;">
          ${escapeHtml(s.email || '—')}
          <div style="margin-top:3px;"><button class="btn btn-sec btn-sm" onclick="copySessionTotp('${encodeURIComponent(s.filename)}')">🔐 Код 2FA</button></div>
        </td>
        <td style="max-width:170px;">${s.signature ? escapeHtml(s.signature) : '<span style="color:var(--muted);">пусто</span>'}</td>
        <td>${postHtml}</td>
        <td><span class="pill">${escapeHtml(s.region || 'US')}</span><div class="hint" style="max-width:160px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(s.proxy)}</div></td>
        <td>
          <div style="display:flex; gap:5px; flex-wrap:wrap;">
            <button class="btn btn-sm" onclick="jumpToPhotoPost('${escapeHtml(s.filename)}')">📸</button>
            <button class="btn btn-sec btn-sm" onclick="restartSessionApp('${encodeURIComponent(s.filename)}')">🔄</button>
            <button class="btn btn-danger btn-sm" onclick="deleteOldPostsSession('${encodeURIComponent(s.filename)}')">🗑 Видео</button>
            <button class="btn btn-sec btn-sm" onclick="promptChangeBio('${encodeURIComponent(s.filename)}', '${escapeHtml(s.signature || '')}')">✏️ БИО</button>
            <button class="btn btn-sec btn-sm" onclick="viewSessionJson('${encodeURIComponent(s.filename)}')">JSON</button>
            <button class="btn btn-danger btn-sm" onclick="deleteSingleSessionFile('${encodeURIComponent(s.filename)}')">❌</button>
          </div>
        </td>
      </tr>
    `;
  }).join('') : '<tr><td colspan="7" style="color:var(--muted);">Сессии не найдены.</td></tr>';
}

async function copySessionTotp(fnameEnc) {
  try {
    const res = await api('/api/sessions/totp?file=' + fnameEnc);
    navigator.clipboard.writeText(res.code);
    showToast(`🔐 2FA код: ${res.code} (скопирован, действует ещё ${res.remaining_sec} сек)`, 'ok');
  } catch (e) { showToast(e.message, 'err'); }
}

function toggleSessionRowCheck(fname, checked) { if (checked) sessionTableChecked.add(fname); else sessionTableChecked.delete(fname); document.getElementById('sess_checked_pill').textContent = 'Отмечено: ' + sessionTableChecked.size; }
function toggleAllSessionTableChecks(checked) { sessionsCache.forEach(s => { if (checked) sessionTableChecked.add(s.filename); else sessionTableChecked.delete(s.filename); }); renderSessionsTable(); }
function sendCheckedToCampaign(mode) {
  if (!sessionTableChecked.size) { showToast('Отметьте сессии галочками!', 'err'); return; }
  campaignSelectedSessions = new Set(sessionTableChecked);
  setCampaignMode(mode);
  renderCampaignSessionList();
  switchTab('campaign', document.getElementById('btn-tab-campaign'));
}

function openImportSessionsModal() { document.getElementById('importSessModal').classList.add('open'); }
async function submitImportSessions() {
  const txt = document.getElementById('imp_sess_text').value.trim();
  if (!txt) return;
  const res = await api('/api/sessions/import', { method: 'POST', body: JSON.stringify({ raw_text: txt }) });
  document.getElementById('importSessModal').classList.remove('open');
  document.getElementById('imp_sess_text').value = '';
  await loadSessions();
  showToast('Импортировано сессий: ' + res.imported, 'ok');
}

async function runProxyChecker() {
  const raw = document.getElementById('px_check_input').value.trim() || document.getElementById('cfg_default_proxy').value.trim();
  if (!raw) { showToast('Введите хотя бы 1 прокси!', 'err'); return; }
  const btn = document.getElementById('px_check_btn');
  btn.disabled = true; btn.textContent = '⏳ Проверка...';
  try {
    const res = await api('/api/proxy/check', { method: 'POST', body: JSON.stringify({ proxies_text: raw }) });
    document.getElementById('px_check_tbody').innerHTML = (res.results || []).map(r => r.ok
      ? `<tr><td><span class="pill ok">✅ OK (${escapeHtml(r.tiktok_http)})</span></td><td><strong>${escapeHtml(r.ip)}</strong> • ${escapeHtml(r.country)} (${escapeHtml(r.city)})</td><td>${escapeHtml(r.isp)}</td><td>${r.latency_ms} мс</td></tr>`
      : `<tr><td><span class="pill err">❌ Сбой</span></td><td colspan="3">${escapeHtml(r.error)}</td></tr>`
    ).join('');
  } catch (e) { showToast('Ошибка: ' + e.message, 'err'); }
  finally { btn.disabled = false; btn.textContent = '⚡ Проверить прокси'; }
}

function showJsonModal(title, obj) {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalHtmlBody').style.display = 'none';
  const pre = document.getElementById('modalContent');
  pre.style.display = 'block';
  pre.textContent = JSON.stringify(obj, null, 2);
  document.getElementById('jsonModal').classList.add('open');
}
function closeModal() { document.getElementById('jsonModal').classList.remove('open'); }
async function viewSessionJson(fname) { const data = await api('/api/sessions/item?file=' + fname); showJsonModal('Сессия: ' + decodeURIComponent(fname), data); }

async function deleteSingleSessionFile(fnameEnc) {
  const fname = decodeURIComponent(fnameEnc);
  if (!confirm(`Удалить файл сессии ${fname}?`)) return;
  await api('/api/sessions/delete_file', { method: 'POST', body: JSON.stringify({ filenames: [fname] }) });
  sessionTableChecked.delete(fname); campaignSelectedSessions.delete(fname);
  await loadSessions();
}
async function deleteCheckedSessionFiles() {
  if (!sessionTableChecked.size || !confirm(`Удалить ${sessionTableChecked.size} файлов сессий с диска?`)) return;
  await api('/api/sessions/delete_file', { method: 'POST', body: JSON.stringify({ filenames: Array.from(sessionTableChecked) }) });
  sessionTableChecked.clear();
  await loadSessions();
}
function jumpToPhotoPost(filename) { switchTab('photo', document.getElementById('btn-tab-photo')); document.getElementById('p_session').value = filename; }
async function restartSessionApp(fnameEnc) {
  await api('/api/sessions/restart_app', { method: 'POST', body: JSON.stringify({ api_key: document.getElementById('apiKeyInput').value.trim(), filename: decodeURIComponent(fnameEnc) }) });
  showToast('Приложение TikTok перезапущено!', 'ok');
}
async function deleteOldPostsSession(fnameEnc) {
  if (!confirm('Удалить все видео на этом аккаунте?')) return;
  const res = await api('/api/sessions/delete_posts', { method: 'POST', body: JSON.stringify({ api_key: document.getElementById('apiKeyInput').value.trim(), filename: decodeURIComponent(fnameEnc) }) });
  loadSessions();
  showToast('Удалено видео: ' + (res.deleted || 0), 'ok');
}
async function promptChangeBio(fnameEnc, currentBio) {
  const nextBio = prompt('Новый текст БИО:', currentBio || '');
  if (nextBio === null) return;
  await api('/api/sessions/set_bio', { method: 'POST', body: JSON.stringify({ api_key: document.getElementById('apiKeyInput').value.trim(), filename: decodeURIComponent(fnameEnc), text: nextBio }) });
  loadSessions();
  showToast('БИО обновлено!', 'ok');
}

/* ---------------- SINGLE POST, SIGNUP & AUTH ---------------- */

function toggleSinglePostMediaType() {
  const t = document.getElementById('p_media_type').value;
  document.getElementById('p_photo_box').style.display = t === 'photo' ? 'block' : 'none';
  document.getElementById('p_video_box').style.display = t === 'video' ? 'block' : 'none';
}
function handleSingleVideoFile(files) {
  const f = (files || [])[0]; if (!f) return;
  const r = new FileReader();
  r.onload = ev => { singleVideoBase64 = { name: f.name, data_url: ev.target.result }; document.getElementById('p_video_info').textContent = `Выбрано: ${f.name} (${(f.size/1048576).toFixed(2)} МБ)`; };
  r.readAsDataURL(f);
}
function handlePhotoFiles(fileList) {
  singleServerSlides = []; selectedPhotosBase64 = [];
  Array.from(fileList || []).slice(0, 10).forEach(f => {
    const reader = new FileReader();
    reader.onload = ev => {
      selectedPhotosBase64.push({ name: f.name, data_url: ev.target.result });
      document.getElementById('p_thumbs').innerHTML = selectedPhotosBase64.map((it, i) => `<div class="thumb-card"><span class="thumb-badge">#${i+1}</span><img src="${it.data_url}" /></div>`).join('');
    };
    reader.readAsDataURL(f);
  });
}
function useLatestPirateSlides() {
  selectedPhotosBase64 = []; singleServerSlides = ['IMG_7620.jpeg', 'IMG_7621.jpeg'];
  document.getElementById('p_thumbs').innerHTML = singleServerSlides.map((nm, i) => `<div class="thumb-card"><span class="thumb-badge">#${i+1}</span><img src="/api/media/file?name=${encodeURIComponent(nm)}" /></div>`).join('');
}
function clearSelectedPhotos() { singleServerSlides = []; selectedPhotosBase64 = []; document.getElementById('p_thumbs').innerHTML = ''; }

async function submitSinglePost() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();
  const sessionFile = document.getElementById('p_session').value;
  const mType = document.getElementById('p_media_type').value;
  if (!apiKey || !sessionFile) { showToast('Укажите ключ и сессию!', 'err'); return; }

  const btn = document.getElementById('p_submit_btn');
  btn.disabled = true; btn.textContent = 'Публикация...';
  document.getElementById('p_result_box').classList.remove('visible');
  try {
    if (mType === 'video') {
      if (!singleVideoBase64) { showToast('Выберите MP4 видео!', 'err'); return; }
      const res = await api('/api/post/video', {
        method: 'POST',
        body: JSON.stringify({
          api_key: apiKey, session_filename: sessionFile, video: singleVideoBase64,
          description: document.getElementById('p_desc').value,
          region: document.getElementById('p_region').value.trim(),
          phone_region: document.getElementById('p_phone_region').value.trim(),
          app_locale: document.getElementById('p_locale').value.trim(),
          proxy_override: document.getElementById('p_proxy').value.trim(),
          music_id: document.getElementById('p_music').value.trim(),
          is_story: document.getElementById('p_story').checked,
          disable_comments: document.getElementById('p_nocomments').checked
        })
      });
      document.getElementById('p_result_links').innerHTML = `<a class="link" href="${escapeHtml(res.url)}" target="_blank"><strong>${escapeHtml(res.url)} ↗</strong></a>`;
    } else {
      const uMode = document.getElementById('p_uniq_mode').value;
      const res = await api('/api/post/photo', {
        method: 'POST',
        body: JSON.stringify({
          api_key: apiKey, session_filename: sessionFile,
          server_media_files: singleServerSlides, photos: selectedPhotosBase64,
          description: document.getElementById('p_desc').value,
          region: document.getElementById('p_region').value.trim(),
          phone_region: document.getElementById('p_phone_region').value.trim(),
          app_locale: document.getElementById('p_locale').value.trim(),
          proxy_override: document.getElementById('p_proxy').value.trim(),
          delete_old_posts: document.getElementById('p_del_old').checked,
          randomize_tags: document.getElementById('p_rand_tags').checked,
          uniquify_photos: uMode !== 'off', uniquify_mode: uMode,
          copies_count: parseInt(document.getElementById('p_copies').value || '1', 10),
          delay_range: document.getElementById('p_delay').value.trim() || '10',
          restart_every_n: parseInt(document.getElementById('p_restart_every').value || '0', 10),
          music_id: document.getElementById('p_music').value.trim(),
          auto_music_query: document.getElementById('p_music_query').value.trim(),
          is_story: document.getElementById('p_story').checked,
          disable_comments: document.getElementById('p_nocomments').checked
        })
      });
      const allList = res.post.all_posts || [res.post];
      document.getElementById('p_result_links').innerHTML = allList.map((it, idx) => `<div>#${idx+1} <a class="link" href="${escapeHtml(it.url)}" target="_blank"><strong>${escapeHtml(it.url)} ↗</strong></a></div>`).join('');
    }
    document.getElementById('p_result_box').classList.add('visible');
    loadSessions();
  } catch (e) { showToast('Ошибка: ' + e.message, 'err'); }
  finally { btn.disabled = false; btn.textContent = '🚀 Опубликовать'; }
}

let signupCountriesCache = [];
let selectedSignupCountryId = 151;
function renderSignupCountryOptions(filterText = '') {
  const sel = document.getElementById('reg_country'); if (!sel) return;
  const q = String(filterText || '').trim().toLowerCase();
  const filtered = signupCountriesCache.filter(c => !q || String(c.rus||'').toLowerCase().includes(q) || String(c.eng||'').toLowerCase().includes(q) || String(c.iso2||'').toLowerCase().includes(q) || String(c.dial_code||'').includes(q));
  sel.innerHTML = filtered.length ? filtered.map(c => {
    const pr = c.min_price != null ? ` — от ${Number(c.min_price).toFixed(2)} ₽ (${c.total_count} шт.)` : '';
    return `<option value="${c.id}">${escapeHtml(`${c.flag} ${c.rus} [${c.iso2}, ${c.dial_code}]${pr}`)}</option>`;
  }).join('') : '<option value="">Не найдено</option>';
  if (filtered.some(c => Number(c.id) === Number(selectedSignupCountryId))) sel.value = String(selectedSignupCountryId);
  syncCountryChipHighlight();
}
function filterSignupCountries() { renderSignupCountryOptions(document.getElementById('reg_country_search').value); }
function pickQuickCountry(cid) { selectedSignupCountryId = Number(cid); document.getElementById('reg_country_search').value = ''; renderSignupCountryOptions(''); document.getElementById('reg_country').value = String(cid); syncCountryChipHighlight(); }
function syncCountryChipHighlight() {
  selectedSignupCountryId = Number(document.getElementById('reg_country').value || selectedSignupCountryId);
  document.querySelectorAll('#reg_quick_chips .country-chip').forEach(b => b.classList.toggle('active', Number(b.getAttribute('data-cid')) === selectedSignupCountryId));
}
async function loadSignupCountries(live = false) {
  const gk = (document.getElementById('reg_greedy_key')?.value || '').trim();
  const data = await api(`/api/signup/countries?live=${live ? '1' : '0'}&greedy_key=${encodeURIComponent(gk)}`);
  if (data.countries) { signupCountriesCache = data.countries; renderSignupCountryOptions(''); }
  if (data.balance != null) document.getElementById('reg_balance_pill').textContent = `💰 ${Number(data.balance).toFixed(2)} ₽`;
}
async function loadRegisteredAccounts() { const data = await api('/api/signup/registered'); document.getElementById('reg_output_lines').value = (data.lines || []).join('\n'); }
function copyRegisteredLines() { navigator.clipboard.writeText(document.getElementById('reg_output_lines').value); showToast('Скопировано!', 'ok'); }
async function startSignupJob() {
  await api('/api/signup/start', {
    method: 'POST',
    body: JSON.stringify({
      api_key: document.getElementById('apiKeyInput').value.trim(),
      greedy_api_key: document.getElementById('reg_greedy_key').value.trim(),
      country_id: parseInt(document.getElementById('reg_country').value || '151', 10),
      count: parseInt(document.getElementById('reg_count').value || '1', 10),
      threads: parseInt(document.getElementById('reg_threads').value || '1', 10),
      max_price: parseFloat(document.getElementById('reg_max_price').value || '3.5'),
      sms_timeout_sec: parseInt(document.getElementById('reg_sms_timeout').value || '110', 10),
      proxies_text: document.getElementById('reg_proxies').value.trim(),
      enable_totp: document.getElementById('reg_enable_totp').checked,
      auto_match_proxy: document.getElementById('reg_match_proxy').checked,
      fixed_password: document.getElementById('reg_password').value.trim(),
      username_prefix: document.getElementById('reg_uname_prefix').value.trim()
    })
  });
  showToast('Авто-регистрация запущена!', 'ok');
}
async function stopSignupJob() { await api('/api/signup/stop', { method: 'POST', body: '{}' }); }

function toggleSingleFlow() {
  const flow = document.getElementById('s_flow').value;
  document.getElementById('s_username_wrap').style.display = flow === 'username_totp' ? 'block' : 'none';
  document.getElementById('s_imap_wrap').style.display = flow === 'email' ? 'block' : 'none';
}
async function startSingleLogin() {
  const btn = document.getElementById('s_submit_btn');
  btn.disabled = true; btn.textContent = 'Вход...';
  try {
    const flow = document.getElementById('s_flow').value;
    const res = await api('/api/single/login_auto', {
      method: 'POST',
      body: JSON.stringify({
        api_key: document.getElementById('apiKeyInput').value.trim(),
        login_mode: flow === 'username_totp' ? 'username_totp' : 'password_imap',
        raw_line: document.getElementById('s_raw_line').value.trim(),
        username: document.getElementById('s_username').value.trim(),
        email: document.getElementById('s_email').value.trim(),
        tiktok_password: document.getElementById('s_tt_pass').value,
        totp_token: document.getElementById('s_totp').value.trim(),
        mail_password: document.getElementById('s_mail_pass').value,
        proxy: document.getElementById('s_proxy').value.trim(),
        region: document.getElementById('s_region').value.trim() || 'US',
        delete_old_posts: document.getElementById('s_del_old').checked
      })
    });
    if (res.status === 'success') {
      document.getElementById('s_res_title').textContent = '✅ @' + (res.session.username || res.session.email);
      document.getElementById('s_res_device').value = res.session.x_device || '';
      document.getElementById('s_result_box').classList.add('visible');
      loadSessions();
    } else showToast(res.error || 'Ошибка входа', 'err');
  } catch (e) { showToast('Ошибка: ' + e.message, 'err'); }
  finally { btn.disabled = false; btn.textContent = 'Войти'; }
}
async function startBatch() {
  await api('/api/batch/start', {
    method: 'POST',
    body: JSON.stringify({
      api_key: document.getElementById('apiKeyInput').value.trim(),
      login_mode: document.getElementById('b_mode').value,
      threads: parseInt(document.getElementById('b_threads').value || '3', 10),
      default_region: document.getElementById('b_region').value.trim() || 'US',
      accounts_text: document.getElementById('b_accounts').value.trim(),
      proxies_text: document.getElementById('b_proxies').value.trim(),
      bio_after_login: document.getElementById('b_bio').value,
      delete_old_posts: document.getElementById('b_del_old').checked
    })
  });
  showToast('Массовый вход запущен!', 'ok');
}
async function stopBatch() { await api('/api/batch/stop', { method: 'POST', body: '{}' }); }
async function clearLogs() { await api('/api/logs/clear', { method: 'POST', body: '{}' }); pollState(); }

/* ---------------- POLLING ---------------- */

let prevCampRunning = false;

async function pollState() {
  try {
    const st = await api('/api/state');
    document.getElementById('statSessions').textContent = 'Сессий: ' + st.sessions_count;

    const apList = st.autopilot || [];
    const activeAp = apList.filter(t => t.status === 'scheduled' || t.status === 'running').length;
    document.getElementById('statAutopilot').textContent = `⏰ Авто-Пилот: ${activeAp}`;
    document.getElementById('ap_tbody').innerHTML = apList.length ? apList.map(t => `
      <tr>
        <td><strong>${escapeHtml(t.name)}</strong><div class="hint">${escapeHtml(t.kind)}</div></td>
        <td>${t.status === 'scheduled' ? `${escapeHtml(t.next_run_str)} (через ${t.in_sec}с)` : '—'}</td>
        <td>${t.runs_count}</td>
        <td><span class="pill ${t.status === 'scheduled' ? 'ok' : ''}">${escapeHtml(t.last_result)}</span></td>
        <td><button class="btn btn-danger btn-sm" onclick="deleteAutopilotTask('${escapeHtml(t.id)}')">✕</button></td>
      </tr>
    `).join('') : '<tr><td colspan="5" style="color:var(--muted);">Нет запланированных задач.</td></tr>';

    const apSt = st.appeal || {};
    const anyRunning = st.campaign.running || apSt.running || st.batch.running || st.signup.running || st.analytics.running || st.tools.running;
    const jobPill = document.getElementById('statActiveJob');
    jobPill.textContent = anyRunning ? '⚡ Потоки активны' : 'Потоки: ожидание';
    jobPill.className = 'pill ' + (anyRunning ? 'ok' : '');

    const htmlLogs = st.logs.map(l => `<div class="log-line"><span class="log-time">[${l.time}]</span><span class="log-${l.level}">${escapeHtml(l.text)}</span></div>`).join('');
    for (const id of ['logBoxCampaign', 'logBoxAppeal', 'logBoxPhoto', 'logBoxBatch', 'logBoxSignup', 'logBoxWarmup', 'logBoxBranding', 'logBoxComments']) {
      const box = document.getElementById(id);
      if (!box) continue;
      const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 65;
      box.innerHTML = htmlLogs || '<div style="color:#64748b;">Готов к работе.</div>';
      if (nearBottom) box.scrollTop = box.scrollHeight;
    }

    const c = st.campaign;
    document.getElementById('c_start_btn').disabled = c.running;
    document.getElementById('c_stop_btn').disabled = !c.running;
    document.getElementById('c_status_pill').textContent = c.running ? '⚡ Выполняется...' : (c.done_accounts > 0 ? '✅ Готово' : 'Ожидание');
    document.getElementById('c_stat_acc').textContent = `Аккаунты: ${c.done_accounts} / ${c.total_accounts}`;
    document.getElementById('c_stat_posts').textContent = c.target_posts_total > 0 ? `Постов: ${c.published_posts_total} / ${c.target_posts_total}` : `Постов: ${c.published_posts_total}`;
    document.getElementById('c_stat_del').textContent = `Удалено: ${c.deleted_posts_total}`;
    document.getElementById('c_stat_appeals').textContent = `🛡️ Снято огранов: ${c.appeals_sent_total || 0}`;
    document.getElementById('c_stat_err').textContent = `Ошибок: ${c.failed_accounts}`;
    const cpct = c.target_posts_total > 0 ? Math.round((c.published_posts_total / c.target_posts_total) * 100) : (c.total_accounts > 0 ? Math.round((c.done_accounts / c.total_accounts) * 100) : 0);
    document.getElementById('c_progress').style.width = Math.min(100, cpct) + '%';
    document.getElementById('c_urls_count').textContent = (c.published_urls || []).length;
    document.getElementById('c_urls_box').value = (c.published_urls || []).join('\n');
    if (c.rows && c.rows.length) {
      document.getElementById('c_rows_tbody').innerHTML = c.rows.map(r => {
        const cls = r.status === 'completed' ? 'ok' : (r.status === 'running' ? 'warn' : (r.status === 'error' ? 'err' : ''));
        return `<tr><td><strong>@${escapeHtml(r.username)}</strong></td><td><span class="pill ${cls}">${escapeHtml(r.detail || r.status)}</span></td><td>📸${r.published||0} • 🗑${r.deleted||0} • 🛡️${r.appeals_sent||0}</td><td>${r.last_url ? `<a class="link" href="${escapeHtml(r.last_url)}" target="_blank">Пост ↗</a>` : '—'}</td></tr>`;
      }).join('');
    }
    if (prevCampRunning && !c.running) loadSessions();
    prevCampRunning = c.running;

    // Auto Appeal Standalone Tab Update
    document.getElementById('ap_start_btn').disabled = Boolean(apSt.running);
    document.getElementById('ap_stop_btn').disabled = !apSt.running;
    const apPill = document.getElementById('ap_status_pill');
    if (apSt.running) {
      apPill.textContent = apSt.next_run_at ? `🔁 Сторож (след. в ${apSt.next_run_at})` : `⚡ В работе (${apSt.done_accounts || 0}/${apSt.total_accounts || 0})`;
      apPill.className = 'pill ok';
    } else {
      apPill.textContent = (apSt.rows && apSt.rows.length) ? '✅ Готово' : 'Ожидание';
      apPill.className = 'pill';
    }
    document.getElementById('ap_kpi_done').textContent = `${apSt.done_accounts || (apSt.rows ? apSt.rows.length : 0)} / ${apSt.total_accounts || (apSt.rows ? apSt.rows.length : 0)}`;
    document.getElementById('ap_kpi_clean').textContent = apSt.clean_accounts || 0;
    document.getElementById('ap_kpi_appealed').textContent = apSt.appealed_accounts || 0;
    document.getElementById('ap_kpi_restricted').textContent = apSt.restricted_accounts || 0;
    document.getElementById('ap_kpi_sent').textContent = apSt.appeals_sent_total || 0;
    document.getElementById('ap_kpi_hidden').textContent = apSt.posts_hidden_total || 0;
    document.getElementById('ap_progress').style.width = (apSt.total_accounts > 0 ? Math.round(((apSt.done_accounts || 0) / apSt.total_accounts) * 100) : 0) + '%';
    if (apSt.last_saved_at) document.getElementById('ap_saved_lbl').textContent = 'Обновлено: ' + apSt.last_saved_at;
    if (apSt.folders) renderAppealFolders(apSt.folders);
    if (Array.isArray(apSt.rows) && apSt.rows.length) {
      appealRowsCache = apSt.rows;
      renderAppealTable();
    }

    const an = st.analytics;
    document.getElementById('an_scan_btn').disabled = an.running;
    document.getElementById('an_scan_btn').textContent = an.running ? `⏳ Скан ${an.done}/${an.total}...` : '🔄 Скан всех сессий';
    if (an.updated_at) document.getElementById('an_updated_lbl').textContent = 'Обновлено: ' + an.updated_at;
    if (an.kpi) {
      const vd = an.kpi.views_delta > 0 ? ` (+${an.kpi.views_delta})` : '';
      document.getElementById('an_kpi_views').textContent = (an.kpi.views_total || 0).toLocaleString('ru-RU') + vd;
      document.getElementById('an_kpi_likes').textContent = (an.kpi.likes_total || 0).toLocaleString('ru-RU');
      document.getElementById('an_kpi_comments').textContent = (an.kpi.comments_total || 0).toLocaleString('ru-RU');
      document.getElementById('an_kpi_shares').textContent = ((an.kpi.shares_total || 0) + (an.kpi.collects_total || 0)).toLocaleString('ru-RU');
      document.getElementById('an_kpi_hot').textContent = an.kpi.active_traffic_accounts || 0;
      document.getElementById('an_kpi_zero').textContent = an.kpi.zero_view_accounts || 0;
    }
    if ((an.accounts || []).length && (!analyticsCache.length || !an.running)) {
      analyticsCache = an.accounts || [];
      renderAnalyticsTable();
    }

    const tj = st.tools;
    document.getElementById('w_start_btn').disabled = tj.running;
    document.getElementById('w_stop_btn').disabled = !tj.running;
    document.getElementById('br_start_btn').disabled = tj.running;
    document.getElementById('cm_start_btn').disabled = tj.running;
    document.getElementById('t_job_pill').textContent = tj.running ? `⚡ ${tj.done}/${tj.total}` : 'Ожидание';
    document.getElementById('t_job_prog').style.width = (tj.total > 0 ? Math.round((tj.done / tj.total) * 100) : 0) + '%';
    document.getElementById('t_job_results').value = (tj.results || []).join('\n');

    const b = st.batch;
    document.getElementById('b_start_btn').disabled = b.running;
    document.getElementById('b_stop_btn').disabled = !b.running;
    document.getElementById('b_status_pill').textContent = b.running ? 'В работе...' : 'Ожидание';
    document.getElementById('b_stat_done').textContent = `${b.done} / ${b.total}`;
    document.getElementById('b_stat_ok').textContent = `Успешно: ${b.success}`;
    document.getElementById('b_stat_err').textContent = `Ошибок: ${b.failed}`;
    document.getElementById('b_progress').style.width = (b.total > 0 ? Math.round((b.done / b.total) * 100) : 0) + '%';

    const sg = st.signup;
    document.getElementById('reg_start_btn').disabled = sg.running;
    document.getElementById('reg_stop_btn').disabled = !sg.running;
    document.getElementById('reg_stat_done').textContent = `${sg.done} / ${sg.total}`;
    document.getElementById('reg_stat_ok').textContent = `Создано: ${sg.success}`;
    document.getElementById('reg_stat_err').textContent = `Ошибок: ${sg.failed}`;
    document.getElementById('reg_progress').style.width = (sg.total > 0 ? Math.round((sg.done / sg.total) * 100) : 0) + '%';
  } catch (e) {}
}

async function initApp() {
  const cfg = await api('/api/config');
  if (cfg.api_key) { document.getElementById('apiKeyInput').value = cfg.api_key; document.getElementById('cfg_api_key').value = cfg.api_key; }
  if (cfg.greedy_api_key) { document.getElementById('reg_greedy_key').value = cfg.greedy_api_key; document.getElementById('cfg_greedy_key').value = cfg.greedy_api_key; }
  if (cfg.default_signup_proxy) {
    for (const id of ['reg_proxies', 'cfg_default_proxy', 's_proxy', 'b_proxies', 'px_check_input']) {
      const el = document.getElementById(id); if (el) el.value = cfg.default_signup_proxy;
    }
  }
  if (cfg.sms_country_id) selectedSignupCountryId = Number(cfg.sms_country_id);
  if (cfg.sms_max_price) document.getElementById('reg_max_price').value = cfg.sms_max_price;
  if (cfg.default_region) document.getElementById('cfg_default_region').value = cfg.default_region;
  if (cfg.threads) { document.getElementById('cfg_default_threads').value = cfg.threads; document.getElementById('c_threads').value = cfg.threads; }

  await loadPresets();
  await loadMediaLibrary();
  await loadSessions();
  await loadSignupCountries(Boolean(cfg.greedy_api_key));
  await loadRegisteredAccounts();
  pollState();
  setInterval(pollState, 1500);
}

initApp();
</script>
</body>
</html>
"""


class WebHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def _send_json(self, payload: Any, status: int = 200) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _send_bytes(
        self, data: bytes, content_type: str, filename: Optional[str] = None, status: int = 200
    ) -> None:
        try:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Access-Control-Allow-Origin", "*")
            if filename:
                self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _read_json(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        qs = urllib.parse.parse_qs(parsed.query)

        if path in ("/", "/index.html"):
            self._send_bytes(DASHBOARD_HTML.encode("utf-8"), "text/html; charset=utf-8")
            return

        if path == "/api/config":
            self._send_json(load_saved_config())
            return

        if path == "/api/presets":
            self._send_json({"presets": load_presets(), "defaults": PRESET_DEFAULTS, "locales": GEO_LOCALE_DEFAULTS})
            return

        if path == "/api/media/list":
            self._send_json({"files": list_media_library()})
            return

        if path == "/api/media/file":
            name = os.path.basename((qs.get("name") or [""])[0])
            fp = MEDIA_DIR / name
            if not name or not fp.exists():
                self._send_json({"error": "File not found"}, status=404)
                return
            ext = fp.suffix.lower()
            ctype = "video/mp4" if ext == ".mp4" else ("image/png" if ext == ".png" else "image/jpeg")
            self._send_bytes(fp.read_bytes(), ctype)
            return

        if path == "/api/analytics/export.csv":
            self._send_bytes(ANALYTICS.export_csv_bytes(), "text/csv; charset=utf-8", "tiktok_analytics.csv")
            return

        if path == "/api/campaign/report":
            rp = OUTPUT_DIR / "last_campaign_report.json"
            self._send_bytes(rp.read_bytes() if rp.exists() else b"[]", "application/json; charset=utf-8", "campaign_report.json")
            return

        if path == "/api/appeal/report":
            self._send_bytes(
                AUTO_APPEAL_REPORT_FILE.read_bytes() if AUTO_APPEAL_REPORT_FILE.exists() else b"{}",
                "application/json; charset=utf-8",
                "auto_appeal_report.json",
            )
            return

        if path == "/api/appeal/folders":
            self._send_json({"folders": get_sorted_folders_summary()})
            return

        if path == "/api/appeal/folder_export":
            fkey = (qs.get("folder") or ["clean"])[0]
            fmt = (qs.get("fmt") or ["txt"])[0]
            data_bytes, mime_type, dl_name = export_sorted_folder_archive(fkey, fmt=fmt)
            self._send_bytes(data_bytes, mime_type, dl_name)
            return

        if path == "/api/state":
            sessions = STORE.list_sessions()
            with STATE.lock:
                payload = {
                    "sessions_count": len(sessions),
                    "logs": list(STATE.logs[-240:]),
                    "campaign": CAMPAIGN.snapshot(),
                    "appeal": AUTO_APPEAL.snapshot(),
                    "analytics": ANALYTICS.snapshot(),
                    "tools": TOOLS_JOB.snapshot(),
                    "autopilot": AUTOPILOT.snapshot(),
                    "batch": {
                        "running": STATE.batch_running,
                        "total": STATE.batch_total,
                        "done": STATE.batch_done,
                        "success": STATE.batch_success,
                        "failed": STATE.batch_failed,
                    },
                    "signup": {
                        "running": STATE.signup_running,
                        "total": STATE.signup_total,
                        "done": STATE.signup_done,
                        "success": STATE.signup_success,
                        "failed": STATE.signup_failed,
                    },
                }
            self._send_json(payload)
            return

        if path == "/api/signup/countries":
            live = (qs.get("live") or ["0"])[0] == "1"
            gkey = ((qs.get("greedy_key") or [""])[0] or load_saved_config().get("greedy_api_key") or "").strip()
            if live and gkey:
                save_config({"greedy_api_key": gkey})
                with GreedySMSClient(api_key=gkey) as gs:
                    me = gs.get_me()
                    cats = gs.get_countries_catalog()
                self._send_json({"balance": me.get("balance"), "countries": [c.to_dict() for c in cats]})
            else:
                self._send_json({"countries": [c.to_dict() for c in get_static_country_catalog()]})
            return

        if path == "/api/signup/registered":
            txt_fp = OUTPUT_DIR / "registered_accounts.txt"
            lines = [ln.strip() for ln in txt_fp.read_text(encoding="utf-8").splitlines() if ln.strip()] if txt_fp.exists() else []
            self._send_json({"lines": lines})
            return

        if path == "/api/signup/export/txt":
            txt_fp = OUTPUT_DIR / "registered_accounts.txt"
            self._send_bytes(txt_fp.read_bytes() if txt_fp.exists() else b"", "text/plain; charset=utf-8", "registered_accounts.txt")
            return

        if path == "/api/sessions":
            self._send_json({"sessions": STORE.list_sessions()})
            return

        if path == "/api/sessions/item":
            fname = (qs.get("file") or [""])[0]
            item = STORE.get_session(fname)
            if not item:
                self._send_json({"error": "Сессия не найдена"}, status=404)
                return
            self._send_json(item)
            return

        if path == "/api/sessions/totp":
            fname = (qs.get("file") or [""])[0]
            item = STORE.get_session(fname)
            if not item:
                self._send_json({"error": "Сессия не найдена"}, status=404)
                return
            secret = str(item.get("totp_token") or item.get("totp_secret") or "").strip()
            self._send_json(generate_live_totp_info(secret))
            return

        if path == "/api/sessions/export/jsonl":
            jsonl_path = OUTPUT_DIR / "sessions.jsonl"
            self._send_bytes(jsonl_path.read_bytes() if jsonl_path.exists() else b"", "application/x-ndjson; charset=utf-8", "sessions.jsonl")
            return

        if path == "/api/sessions/export/zip":
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for fp in SESSIONS_DIR.glob("*.json"):
                    zf.write(fp, arcname=f"sessions/{fp.name}")
                for extra in (
                    "sessions.jsonl",
                    "success.txt",
                    "failed.txt",
                    "registered_accounts.txt",
                    "registered_accounts.json",
                    "last_campaign_report.json",
                    "analytics_report.json",
                    "auto_appeal_report.json",
                ):
                    ep = OUTPUT_DIR / extra
                    if ep.exists():
                        zf.write(ep, arcname=f"output/{extra}")
            self._send_bytes(buf.getvalue(), "application/zip", "kintaro_sessions.zip")
            return

        self._send_json({"error": "Not found"}, status=404)

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        try:
            body = self._read_json()
        except Exception as exc:
            self._send_json({"error": f"Некорректный JSON: {exc}"}, status=400)
            return

        try:
            if path == "/api/appeal/start":
                ok_ap, msg_ap = AUTO_APPEAL.start(body)
                if not ok_ap:
                    self._send_json({"error": msg_ap}, status=400)
                else:
                    self._send_json({"ok": True, "message": msg_ap})
                return

            if path == "/api/appeal/stop":
                AUTO_APPEAL.stop()
                self._send_json({"ok": True})
                return

            if path == "/api/appeal/single":
                sf = os.path.basename(str(body.get("session_file") or ""))
                if not sf:
                    self._send_json({"error": "Укажите session_file"}, status=400)
                    return

                def _bg_single(_sf: str = sf, _b: Dict[str, Any] = dict(body)) -> None:
                    try:
                        res_single = ensure_session_clean_loop(
                            store=STORE,
                            session_file=_sf,
                            dry_run=bool(_b.get("dry_run", False)),
                            appeal_text=str(_b.get("appeal_text") or DEFAULT_APPEAL_TEXT),
                            hide_rejected=bool(_b.get("hide_rejected", False)),
                            max_passes=int(_b.get("max_passes") or 4),
                            log_fn=STATE.log,
                        )
                        with AUTO_APPEAL.lock:
                            replaced = False
                            for idx_r, r0 in enumerate(AUTO_APPEAL.rows):
                                if r0.get("session_file") == _sf:
                                    AUTO_APPEAL.rows[idx_r] = res_single
                                    replaced = True
                                    break
                            if not replaced:
                                AUTO_APPEAL.rows.insert(0, res_single)
                            AUTO_APPEAL._recompute_kpis_unlocked()
                            AUTO_APPEAL._save_report_unlocked()
                    except Exception as s_exc:
                        STATE.log(f"[{_sf}] ❌ Ошибка одиночного Auto-Appeal: {s_exc}", "error")

                threading.Thread(target=_bg_single, daemon=True).start()
                self._send_json({"ok": True, "started": True, "session_file": sf})
                return

            if path == "/api/config":
                save_config(body)
                self._send_json({"ok": True})
                return

            if path == "/api/presets/save":
                self._send_json({"ok": True, "presets": save_preset(body)})
                return

            if path == "/api/presets/delete":
                self._send_json({"ok": True, "presets": delete_preset(str(body.get("id") or ""))})
                return

            if path == "/api/media/upload":
                self._send_json({"ok": True, "saved": save_media_files(body.get("files") or [])})
                return

            if path == "/api/uniquifier/preview":
                self._handle_uniquifier_preview(body)
                return

            if path == "/api/music/search":
                self._handle_music_search(body, trending=False)
                return

            if path == "/api/music/trending":
                self._handle_music_search(body, trending=True)
                return

            if path == "/api/spy/analyze":
                api_key = (body.get("api_key") or load_saved_config().get("api_key") or "").strip()
                res = spy_competitor_or_post(
                    api_key=api_key,
                    store=STORE,
                    target_input=str(body.get("target") or ""),
                    region=str(body.get("region") or "US").upper(),
                    count=int(body.get("count") or 12),
                )
                STATE.log(
                    f"🕵️ Шпион: разобран профиль @{res['profile']['username']} ({res['summary']['posts_analyzed']} постов, 👁 {res['summary']['total_views']})",
                    "success",
                )
                self._send_json(res)
                return

            if path == "/api/spy/download":
                api_key = (body.get("api_key") or load_saved_config().get("api_key") or "").strip()
                res = download_creative_to_media(
                    api_key=api_key,
                    store=STORE,
                    aweme_id_or_url=str(body.get("aweme_id") or ""),
                    region=str(body.get("region") or "US").upper(),
                )
                STATE.log(f"📥 Скачан креатив {res['aweme_id']} -> {', '.join(res['saved_files'])}", "success")
                self._send_json(res)
                return

            if path == "/api/comments/list":
                api_key = (body.get("api_key") or load_saved_config().get("api_key") or "").strip()
                res = fetch_post_comments_structured(
                    api_key=api_key,
                    store=STORE,
                    aweme_id_or_url=str(body.get("target_post") or ""),
                    region=str(body.get("region") or "US").upper(),
                )
                self._send_json(res)
                return

            if path == "/api/comments/boost_top":
                self._handle_start_tools_job(body, job_kind="top_comment")
                return

            if path == "/api/autopilot/add":
                rec = AUTOPILOT.add_task(body)
                self._send_json({"ok": True, "task": rec})
                return

            if path == "/api/autopilot/delete":
                AUTOPILOT.delete_task(str(body.get("id") or ""))
                self._send_json({"ok": True})
                return

            if path == "/api/analytics/scan":
                self._handle_analytics_scan(body)
                return

            if path == "/api/post/visibility":
                self._handle_post_visibility(body)
                return

            if path == "/api/post/delete_one":
                self._handle_post_delete_one(body)
                return

            if path == "/api/post/video":
                self._handle_post_video(body)
                return

            if path == "/api/tools/warmup_boost":
                self._handle_start_tools_job(body, job_kind="warmup_boost")
                return

            if path == "/api/tools/branding":
                self._handle_start_tools_job(body, job_kind="branding")
                return

            if path == "/api/tools/stop":
                with TOOLS_JOB.lock:
                    TOOLS_JOB.stop_requested = True
                STATE.log("Запрошена остановка фонового инструмента...", "warn")
                self._send_json({"ok": True})
                return

            if path == "/api/proxy/check":
                lines = (body.get("proxies_text") or "").splitlines()
                self._send_json({"results": check_proxies_batch(lines)})
                return

            if path == "/api/sessions/import":
                cfg = load_saved_config()
                imp = import_sessions_bulk(
                    store=STORE,
                    raw_text=body.get("raw_text") or "",
                    default_proxy=cfg.get("default_signup_proxy") or "",
                    default_region=cfg.get("default_region") or "US",
                )
                STATE.log(f"📥 Импортировано сессий: {imp} шт.", "success")
                self._send_json({"ok": True, "imported": imp})
                return

            if path == "/api/campaign/start":
                save_config({"api_key": (body.get("api_key") or "").strip(), "threads": int(body.get("threads") or 3)})
                ok = _trigger_campaign_programmatically(body)
                if not ok:
                    self._send_json({"error": "Кампания уже выполняется или не выбраны сессии!"}, status=400)
                else:
                    self._send_json({"ok": True, "total": len(body.get("session_files") or [])})
                return

            if path == "/api/campaign/stop":
                with CAMPAIGN.lock:
                    CAMPAIGN.stop_requested = True
                STATE.log("Запрошена остановка массовой кампании...", "warn")
                self._send_json({"ok": True})
                return

            if path == "/api/logs/clear":
                with STATE.lock:
                    STATE.logs.clear()
                self._send_json({"ok": True})
                return

            if path == "/api/single/login_auto":
                self._handle_single_login_auto(body)
                return

            if path == "/api/post/photo":
                self._handle_post_photo(body)
                return

            if path == "/api/signup/start":
                self._handle_signup_start(body)
                return

            if path == "/api/signup/stop":
                with STATE.lock:
                    STATE.signup_stop_requested = True
                self._send_json({"ok": True})
                return

            if path == "/api/batch/start":
                self._handle_batch_start(body)
                return

            if path == "/api/batch/stop":
                with STATE.lock:
                    STATE.batch_stop_requested = True
                self._send_json({"ok": True})
                return

            if path == "/api/sessions/delete_file":
                deleted_files = sum(1 for fn in (body.get("filenames") or []) if STORE.delete_session(str(fn)))
                self._send_json({"ok": True, "deleted_files": deleted_files})
                return

            if path == "/api/sessions/check_self":
                self._handle_session_action(body, action="self")
                return

            if path == "/api/sessions/set_bio":
                self._handle_session_action(body, action="set_bio")
                return

            if path == "/api/sessions/restart_app":
                restart_tiktok_app_for_session(
                    api_key=(body.get("api_key") or "").strip(),
                    session_filename=(body.get("filename") or "").strip(),
                    store=STORE,
                    log_fn=STATE.log,
                )
                self._send_json({"ok": True})
                return

            if path == "/api/sessions/delete_posts":
                deleted = delete_all_posts_for_session(
                    api_key=(body.get("api_key") or "").strip(),
                    session_filename=(body.get("filename") or "").strip(),
                    store=STORE,
                    log_fn=STATE.log,
                )
                self._send_json({"ok": True, "deleted": deleted})
                return

            self._send_json({"error": "Not found"}, status=404)
        except Exception as exc:
            STATE.log(f"Ошибка запроса {path}: {exc}", "error")
            traceback.print_exc()
            self._send_json({"error": str(exc)}, status=500)

    def _handle_music_search(self, body: Dict[str, Any], trending: bool = False) -> None:
        api_key = (body.get("api_key") or load_saved_config().get("api_key") or "").strip()
        keyword = (body.get("keyword") or "Fortnite").strip()
        region = (body.get("region") or "US").upper().strip()
        sessions = STORE.list_sessions()
        px = ""
        dev = None
        for s in sessions:
            if (s.get("username") or "").lower() != "user6961737737217":
                s0 = STORE.get_session(s["filename"]) or {}
                px = _resolve_session_proxy(s0, region)
                dev = s0.get("device") or s0.get("x_device")
                break
        with KintaroClient(api_key=api_key) as kt:
            if trending:
                tracks = kt.get_trending_fyp_music(proxy=px, device=dev, region=region, rounds=2)
            else:
                tracks = kt.build_music_pool(keyword=keyword, proxy=px or None, device=dev, region=region)
        self._send_json({"tracks": tracks})

    def _handle_analytics_scan(self, body: Dict[str, Any]) -> None:
        with ANALYTICS.lock:
            if ANALYTICS.running:
                self._send_json({"error": "Сканирование аналитики уже идёт!"}, status=400)
                return
            files = [os.path.basename(str(x)) for x in (body.get("session_files") or []) if x]
            ANALYTICS.running = True
            ANALYTICS.total = len(files)
            ANALYTICS.done = 0

        api_key = (body.get("api_key") or "").strip()
        threads = max(1, min(15, int(body.get("threads") or 4)))
        threading.Thread(
            target=run_analytics_scan,
            args=(ANALYTICS, STORE, api_key, files, threads, STATE.log),
            daemon=True,
        ).start()
        self._send_json({"ok": True, "total": len(files)})

    def _handle_post_visibility(self, body: Dict[str, Any]) -> None:
        api_key = (body.get("api_key") or "").strip()
        sf = os.path.basename(str(body.get("session_file") or ""))
        aid = str(body.get("aweme_id") or "").strip()
        vis_type = int(body.get("type") or 1)
        sess = STORE.get_session(sf)
        if not sess:
            self._send_json({"error": "Сессия не найдена"}, status=404)
            return
        px = _resolve_session_proxy(sess)
        with KintaroClient(api_key=api_key) as kt:
            _, upd = kt.change_post_visibility(
                proxy=px, device=sess.get("device") or sess.get("x_device"), aweme_id=aid, vis_type=vis_type
            )
        if upd is not None:
            STORE.update_session_data(sf, lambda d: d.__setitem__("device", upd))
        STATE.log(f"[@{sess.get('username')}] Сменена видимость поста {aid} -> type={vis_type}", "success")
        self._send_json({"ok": True})

    def _handle_post_delete_one(self, body: Dict[str, Any]) -> None:
        api_key = (body.get("api_key") or "").strip()
        sf = os.path.basename(str(body.get("session_file") or ""))
        aid = str(body.get("aweme_id") or "").strip()
        sess = STORE.get_session(sf)
        if not sess:
            self._send_json({"error": "Сессия не найдена"}, status=404)
            return
        px = _resolve_session_proxy(sess)
        with KintaroClient(api_key=api_key) as kt:
            _, upd = kt.delete_post(proxy=px, device=sess.get("device") or sess.get("x_device"), aweme_id=aid)

        def _u(d: Dict[str, Any]) -> None:
            if upd is not None:
                d["device"] = upd
            d["posts"] = [p for p in (d.get("posts") or []) if str(p.get("aweme_id")) != aid]

        STORE.update_session_data(sf, _u)
        STATE.log(f"[@{sess.get('username')}] 🗑 Удалён пост {aid}", "success")
        self._send_json({"ok": True})

    def _handle_post_video(self, body: Dict[str, Any]) -> None:
        api_key = (body.get("api_key") or "").strip()
        sf = os.path.basename(str(body.get("session_filename") or ""))
        sess = STORE.get_session(sf)
        if not sess:
            self._send_json({"error": "Сессия не найдена"}, status=404)
            return
        vobj = body.get("video") or {}
        durl = str(vobj.get("data_url") or "")
        b64p = durl.split(",", 1)[1] if "," in durl else durl
        raw_v = base64.b64decode(b64p)
        fname = str(vobj.get("name") or "video.mp4")

        region = (body.get("region") or sess.get("region") or "US").upper().strip()
        phone_reg = (body.get("phone_region") or region).upper().strip()
        locale = (body.get("app_locale") or "").strip()
        px_over = (body.get("proxy_override") or "").strip()
        px = normalize_proxy(px_over) if px_over else _resolve_session_proxy(sess, region)
        dev = apply_device_geo_profile(sess.get("device") or sess.get("x_device"), phone_reg, app_locale=locale or None)
        desc = expand_spintax(body.get("description") or "")

        with KintaroClient(api_key=api_key) as kt:
            resp_body, upd = kt.create_video_post(
                proxy=px,
                device=dev,
                video=(fname, raw_v),
                description=desc,
                music_id=(body.get("music_id") or "").strip(),
                region=region,
                is_story=bool(body.get("is_story", False)),
                disable_comments=bool(body.get("disable_comments", False)),
            )
        aweme = (resp_body.get("aweme") if isinstance(resp_body, dict) else None) or {}
        aid = str(aweme.get("aweme_id") or "")
        uname = (aweme.get("author") or {}).get("unique_id") or sess.get("username") or ""
        url = f"https://www.tiktok.com/@{uname}/video/{aid}" if uname and aid else ""
        STATE.log(f"[@{uname}] 🎬 Видео опубликовано! {url}", "success")
        if upd is not None:
            STORE.update_session_data(sf, lambda d: d.__setitem__("device", upd))
        self._send_json({"status": "success", "aweme_id": aid, "url": url})

    def _handle_start_tools_job(self, body: Dict[str, Any], job_kind: str) -> None:
        with TOOLS_JOB.lock:
            if TOOLS_JOB.running:
                self._send_json({"error": "Фоновая задача уже выполняется!"}, status=400)
                return
            files = [os.path.basename(str(x)) for x in (body.get("session_files") or []) if x]
            TOOLS_JOB.running = True
            TOOLS_JOB.stop_requested = False
            TOOLS_JOB.job_type = job_kind
            TOOLS_JOB.total = len(files)
            TOOLS_JOB.done = 0
            TOOLS_JOB.success = 0
            TOOLS_JOB.failed = 0
            TOOLS_JOB.results = []

        if job_kind == "top_comment":
            target_fn = run_top_comment_boost_background
        elif job_kind == "warmup_boost":
            target_fn = run_warmup_or_boost_background
        else:
            target_fn = run_profile_branding_background
        threading.Thread(target=target_fn, args=(TOOLS_JOB, STORE, body, STATE.log), daemon=True).start()
        self._send_json({"ok": True, "total": len(files)})

    def _handle_uniquifier_preview(self, body: Dict[str, Any]) -> None:
        raw_bytes: Optional[bytes] = None
        if body.get("data_url"):
            durl = str(body["data_url"])
            b64part = durl.split(",", 1)[1] if "," in durl else durl
            raw_bytes = base64.b64decode(b64part)
        elif body.get("server_file"):
            fp = MEDIA_DIR / os.path.basename(str(body["server_file"]))
            if fp.exists():
                raw_bytes = fp.read_bytes()

        if not raw_bytes:
            self._send_json({"error": "Слайд для предпросмотра не найден"}, status=400)
            return

        uset = UniquifierSettings.from_dict(body.get("uniquifier") or {}, fallback_mode="minimal")
        uniq_bytes = uniquify_single_image(raw_bytes, settings=uset)

        self._send_json(
            {
                "orig_data_url": "data:image/jpeg;base64," + base64.b64encode(raw_bytes).decode("ascii"),
                "uniq_data_url": "data:image/jpeg;base64," + base64.b64encode(uniq_bytes).decode("ascii"),
                "orig_kb": round(len(raw_bytes) / 1024.0, 1),
                "uniq_kb": round(len(uniq_bytes) / 1024.0, 1),
                "orig_sha": compute_sha256_short(raw_bytes),
                "uniq_sha": compute_sha256_short(uniq_bytes),
                "applied": uset.to_dict(),
            }
        )

    def _handle_single_login_auto(self, body: Dict[str, Any]) -> None:
        api_key = (body.get("api_key") or "").strip()
        login_mode = body.get("login_mode") or "username_totp"
        region = (body.get("region") or "US").upper().strip()
        proxy_raw = (body.get("proxy") or "").strip()
        save_config({"api_key": api_key, "default_region": region})

        raw_line = (body.get("raw_line") or "").strip()
        parsed_task = parse_account_line(raw_line, login_mode=login_mode, default_region=region) if raw_line else None
        if parsed_task:
            task = parsed_task
            if proxy_raw:
                task.proxy = proxy_raw
            task.region = region
        else:
            task = AccountTask(
                email=(body.get("email") or "").strip(),
                username=(body.get("username") or "").strip().lstrip("@") or None,
                tiktok_password=(body.get("tiktok_password") or "").strip() or None,
                mail_password=(body.get("mail_password") or "").strip() or None,
                totp_token=(body.get("totp_token") or "").strip() or None,
                proxy=proxy_raw,
                region=region,
            )
        options = LoginOptions(
            api_key=api_key,
            login_mode=login_mode,
            default_region=region,
            pre_register_device=True,
            reuse_existing_device=True,
            check_self_after_login=True,
            delete_old_posts=bool(body.get("delete_old_posts", False)),
            allow_manual_code=False,
        )
        res = process_single_account(task=task, proxy_raw=proxy_raw, options=options, store=STORE, log_fn=STATE.log)
        self._send_json(res, status=200 if res.get("status") == "success" else 400)

    def _handle_post_photo(self, body: Dict[str, Any]) -> None:
        api_key = (body.get("api_key") or "").strip()
        session_filename = (body.get("session_filename") or "").strip()
        photos_input: List[Any] = []
        if body.get("server_media_files"):
            for mname in body["server_media_files"]:
                fp = MEDIA_DIR / os.path.basename(str(mname))
                if fp.exists():
                    photos_input.append(str(fp))
        else:
            for idx, item in enumerate(body.get("photos") or [], start=1):
                durl = item.get("data_url") or ""
                fname = item.get("name") or f"slide_{idx}.jpg"
                b64part = durl.split(",", 1)[1] if "," in durl else durl
                photos_input.append((fname, base64.b64decode(b64part)))

        d_min, d_max = parse_delay_range(body.get("delay_range"), default_min=10.0, default_max=10.0)
        u_mode = str(body.get("uniquify_mode") or "minimal")
        post_record = publish_photo_carousel_for_session(
            api_key=api_key,
            session_filename=session_filename,
            photos=photos_input,
            description=body.get("description") or "",
            region=(body.get("region") or "").strip(),
            phone_region=(body.get("phone_region") or "").strip(),
            app_locale=(body.get("app_locale") or "").strip(),
            proxy_override=(body.get("proxy_override") or "").strip(),
            delete_old_posts=bool(body.get("delete_old_posts", False)),
            randomize_tags=bool(body.get("randomize_tags", False)),
            uniquify_photos=bool(body.get("uniquify_photos", True)),
            uniquify_mode=u_mode,
            copies_count=max(1, min(30, int(body.get("copies_count") or 1))),
            delay_min_sec=d_min,
            delay_max_sec=d_max,
            restart_every_n=max(0, int(body.get("restart_every_n") or 0)),
            store=STORE,
            log_fn=STATE.log,
            music_id=(body.get("music_id") or "").strip(),
            auto_music_query=(body.get("auto_music_query") or "").strip(),
            is_story=bool(body.get("is_story", False)),
            disable_comments=bool(body.get("disable_comments", False)),
        )
        self._send_json({"status": "success", "post": post_record})

    def _handle_batch_start(self, body: Dict[str, Any]) -> None:
        with STATE.lock:
            if STATE.batch_running:
                self._send_json({"error": "Массовый поток уже запущен!"}, status=400)
                return
        api_key = (body.get("api_key") or "").strip()
        login_mode = body.get("login_mode") or "username_totp"
        threads = max(1, min(30, int(body.get("threads") or 3)))
        region = (body.get("default_region") or "US").upper().strip()
        tasks = [
            t
            for ln in (body.get("accounts_text") or "").splitlines()
            if (t := parse_account_line(ln, login_mode=login_mode, default_region=region))
        ]
        proxies = [ln.strip() for ln in (body.get("proxies_text") or "").splitlines() if ln.strip() and not ln.strip().startswith("#")]
        if not tasks or (any(not t.proxy for t in tasks) and not proxies):
            self._send_json({"error": "Проверьте список аккаунтов и прокси"}, status=400)
            return
        options = LoginOptions(
            api_key=api_key,
            login_mode=login_mode,
            default_region=region,
            threads=threads,
            delete_old_posts=bool(body.get("delete_old_posts", False)),
            bio_after_login=(body.get("bio_after_login") or "").strip(),
            allow_manual_code=False,
        )
        with STATE.lock:
            STATE.batch_running = True
            STATE.batch_stop_requested = False
            STATE.batch_total = len(tasks)
            STATE.batch_done = 0
            STATE.batch_success = 0
            STATE.batch_failed = 0
        threading.Thread(target=_run_batch_job, args=(tasks, proxies, options), daemon=True).start()
        self._send_json({"ok": True, "total": len(tasks)})

    def _handle_signup_start(self, body: Dict[str, Any]) -> None:
        with STATE.lock:
            if STATE.signup_running:
                self._send_json({"error": "Авто-регистрация уже запущена!"}, status=400)
                return
        api_key = (body.get("api_key") or "").strip()
        greedy_key = (body.get("greedy_api_key") or "").strip()
        proxies = [ln.strip() for ln in (body.get("proxies_text") or "").splitlines() if ln.strip() and not ln.strip().startswith("#")]
        if not api_key or not greedy_key or not proxies:
            self._send_json({"error": "Укажите оба API ключа и прокси"}, status=400)
            return
        count = max(1, min(100, int(body.get("count") or 1)))
        s_options = MobileSignupOptions(
            kintaro_api_key=api_key,
            greedy_api_key=greedy_key,
            country=int(body.get("country_id") or 151),
            max_price=float(body.get("max_price") or 3.5),
            sms_timeout_sec=max(30, min(300, int(body.get("sms_timeout_sec") or 110))),
            enable_totp_at_end=bool(body.get("enable_totp", True)),
            auto_match_proxy_country=bool(body.get("auto_match_proxy", True)),
            fixed_password=(body.get("fixed_password") or "").strip(),
            username_prefix=(body.get("username_prefix") or "").strip(),
            count=count,
            threads=max(1, min(15, int(body.get("threads") or 1))),
        )
        with STATE.lock:
            STATE.signup_running = True
            STATE.signup_stop_requested = False
            STATE.signup_total = count
            STATE.signup_done = 0
            STATE.signup_success = 0
            STATE.signup_failed = 0
        threading.Thread(target=_run_signup_job, args=(proxies, s_options), daemon=True).start()
        self._send_json({"ok": True, "total": count})

    def _handle_session_action(self, body: Dict[str, Any], action: str) -> None:
        api_key = (body.get("api_key") or "").strip()
        filename = body.get("filename") or ""
        sess = STORE.get_session(filename)
        if not sess:
            self._send_json({"error": "Сессия не найдена"}, status=404)
            return
        proxy = _resolve_session_proxy(sess)
        device = sess.get("device") or sess.get("x_device")
        with KintaroClient(api_key=api_key) as client:
            if action == "self":
                res_body, updated_dev = client.get_self(proxy=proxy, device=device)
                prof = extract_profile_summary(res_body)
                STORE.update_session_data(
                    filename,
                    lambda d: d.update(
                        {
                            "self_info": res_body,
                            **({"device": updated_dev} if updated_dev else {}),
                            **({"signature": prof["signature"]} if prof.get("signature") is not None else {}),
                        }
                    ),
                )
                self._send_json(res_body)
                return
            if action == "set_bio":
                new_text = expand_spintax(body.get("text") or "")
                res_body, updated_dev = client.set_bio(proxy=proxy, device=device, text=new_text)
                STORE.update_session_data(
                    filename,
                    lambda d: d.update({"signature": new_text, **({"device": updated_dev} if updated_dev else {})}),
                )
                self._send_json({"status": "success", "response": res_body})
                return


def main() -> None:
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    server = ThreadingHTTPServer((host, port), WebHandler)
    print(f"Kintaro Studio v6 ENTERPRISE (AUTO APPEAL) запущен на http://{host}:{port}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
